import { Navigate, useLocation } from "react-router-dom";
import { useRole } from "@/contexts/RoleContext";
import { useAllowedPaths } from "@/hooks/use-permissions";

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: string[];
  // When true, treat any internal user as allowed for the outer guard
  // (per-page access is enforced via the role permissions system).
  internalOnly?: boolean;
}

const ProtectedRoute = ({ children, allowedRoles, internalOnly }: ProtectedRouteProps) => {
  const { session, role, loading, recoveryMode, isInternal } = useRole();
  const location = useLocation();
  const allowedPaths = useAllowedPaths(role);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-sm">جارٍ التحميل...</p>
      </div>
    );
  }

  if (recoveryMode) return <Navigate to="/reset-password" replace />;
  if (!session) return <Navigate to="/login" replace />;

  // Wait for the permissions hook to resolve before deciding access. Otherwise
  // a custom-role user gets bounced to "/" while perms are still loading.
  if (isInternal && allowedPaths === undefined) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-sm">جارٍ التحميل...</p>
      </div>
    );
  }

  // Outer internal-area guard
  if (internalOnly) {
    if (!isInternal) return <Navigate to="/volunteer" replace />;
  } else if (allowedRoles && !allowedRoles.includes(role)) {
    // Allow if explicit permissions grant access to this exact path
    if (Array.isArray(allowedPaths) && allowedPaths.includes(location.pathname)) {
      // OK — permission-based access overrides legacy role whitelist
    } else {
      if (role === "volunteer") return <Navigate to="/volunteer" replace />;
      return <Navigate to="/" replace />;
    }
  }

  // If explicit permissions exist for this role, enforce them on every internal route.
  if (Array.isArray(allowedPaths) && isInternal && location.pathname !== "/" && !location.pathname.startsWith("/volunteer")) {
    if (!allowedPaths.includes(location.pathname)) {
      // Redirect to the first allowed page or a friendly message
      const first = allowedPaths[0];
      if (first && first !== location.pathname) return <Navigate to={first} replace />;
      return (
        <div className="min-h-[60vh] flex items-center justify-center text-center p-8">
          <div>
            <p className="text-lg font-bold mb-2">لا تملك صلاحية الوصول إلى هذه الصفحة</p>
            <p className="text-sm text-muted-foreground">الرجاء التواصل مع مدير النظام لمنحك الصلاحية المناسبة.</p>
          </div>
        </div>
      );
    }
  }

  return <>{children}</>;
};

export default ProtectedRoute;
