import { NavLink } from "react-router-dom";
import {
  LayoutDashboard, Users, CalendarCheck, ClipboardList, FileCheck,
  Clock, UserCog, BarChart3, Settings, X, Bell, Plug, Key, TicketCheck, UserCog2, Award, FileBadge, Megaphone,
} from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import { useBranding } from "@/hooks/use-branding";
import { useAllowedPaths } from "@/hooks/use-permissions";
import { BUILTIN_ROLES } from "@/lib/permissions";
import fallbackLogo from "@/assets/logo.png";

const allNavItems = [
  { to: "/dashboard", label: "الرئيسية", icon: LayoutDashboard, roles: ["director", "supervisor", "observer"] },
  { to: "/volunteers", label: "المتطوعون", icon: Users, roles: ["director", "supervisor", "observer"] },
  { to: "/opportunities", label: "الفرص", icon: CalendarCheck, roles: ["director", "supervisor", "observer"] },
  { to: "/participations", label: "المشاركات", icon: ClipboardList, roles: ["director", "supervisor", "observer"] },
  { to: "/proofs", label: "الإثباتات", icon: FileCheck, roles: ["director", "supervisor", "observer"] },
  { to: "/hours", label: "الساعات", icon: Clock, roles: ["director", "supervisor", "observer"] },
  { to: "/notifications", label: "التنبيهات", icon: Bell, roles: ["director", "supervisor", "observer"] },
  { to: "/broadcast-notifications", label: "إدارة الإشعارات", icon: Megaphone, roles: ["director"] },
  { to: "/support-tickets", label: "تذاكر الدعم", icon: TicketCheck, roles: ["director", "supervisor"] },
  { to: "/profile-changes", label: "طلبات تعديل البيانات", icon: UserCog2, roles: ["director"] },
  { to: "/certificate-templates", label: "قوالب الشهادات", icon: Award, roles: ["director"] },
  { to: "/issued-certificates", label: "الشهادات الصادرة", icon: FileBadge, roles: ["director", "supervisor"] },
  { to: "/users", label: "المستخدمون الداخليون", icon: UserCog, roles: ["director"] },
  { to: "/users/roles", label: "الأدوار والصلاحيات", icon: UserCog, roles: ["director"] },
  { to: "/reports", label: "التقارير", icon: BarChart3, roles: ["director", "observer"] },
  { to: "/integrations", label: "التكاملات", icon: Plug, roles: ["director"] },
  { to: "/api-keys", label: "API", icon: Key, roles: ["director"] },
  { to: "/settings", label: "الإعدادات", icon: Settings, roles: ["director"] },
];

const BUILTIN_KEYS = BUILTIN_ROLES.map(r => r.key);

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

export const Sidebar = ({ open, onClose }: SidebarProps) => {
  const { role } = useRole();
  const { platform_name, org_name, logo_url } = useBranding();
  const allowedPaths = useAllowedPaths(role);
  const navItems = allNavItems.filter((item) => {
    // If explicit permissions exist for this role, they are the source of truth.
    if (Array.isArray(allowedPaths)) return allowedPaths.includes(item.to);
    // Otherwise, fall back to the legacy role whitelist (built-in roles only).
    if (BUILTIN_KEYS.includes(role)) return item.roles.includes(role);
    // Custom role with no permissions defined → hide everything until configured.
    return false;
  });

  return (
    <aside
      className={`fixed top-0 right-0 z-40 h-full w-64 bg-sidebar text-sidebar-foreground flex flex-col transition-transform duration-300 ${
        open ? "translate-x-0" : "translate-x-full"
      } lg:translate-x-0`}
    >
      <div className="flex items-center justify-between p-5 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <img src={logo_url || fallbackLogo} alt={platform_name} className="h-9 w-9 rounded-lg bg-sidebar-foreground/10 object-contain p-1" onError={e => { (e.currentTarget as HTMLImageElement).src = fallbackLogo; }} />
          <div>
            <h1 className="text-sm font-bold leading-tight">{platform_name}</h1>
          </div>
        </div>
        <button onClick={onClose} className="lg:hidden p-1.5 rounded-lg hover:bg-sidebar-accent transition-colors">
          <X className="h-5 w-5" />
        </button>
      </div>

      <nav className="flex-1 py-3 overflow-y-auto scrollbar-thin">
        <ul className="space-y-0.5 px-3">
          {navItems.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                end={item.to === "/dashboard"}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm" : "hover:bg-sidebar-accent/50 text-sidebar-foreground/75"
                  }`
                }
              >
                <item.icon className="h-[18px] w-[18px] shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-4 border-t border-sidebar-border text-[11px] opacity-50 text-center">
        {org_name}
      </div>
    </aside>
  );
};
