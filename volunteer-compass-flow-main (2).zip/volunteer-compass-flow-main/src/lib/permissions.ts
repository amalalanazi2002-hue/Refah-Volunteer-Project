// Central registry of pages exposed to the role-permissions system.
// Only internal-area pages are listed (volunteer pages are not gated here).
import { supabase } from "@/integrations/supabase/client";

export interface PageDef {
  path: string;
  label: string;
}

export const ALL_PAGES: PageDef[] = [
  { path: "/dashboard", label: "الرئيسية" },
  { path: "/volunteers", label: "المتطوعون" },
  { path: "/opportunities", label: "الفرص" },
  { path: "/participations", label: "المشاركات" },
  { path: "/proofs", label: "الإثباتات" },
  { path: "/hours", label: "الساعات" },
  { path: "/notifications", label: "التنبيهات" },
  { path: "/broadcast-notifications", label: "إدارة الإشعارات" },
  { path: "/support-tickets", label: "تذاكر الدعم" },
  { path: "/profile-changes", label: "طلبات تعديل البيانات" },
  { path: "/certificate-templates", label: "قوالب الشهادات" },
  { path: "/issued-certificates", label: "الشهادات الصادرة" },
  { path: "/users", label: "المستخدمون الداخليون" },
  { path: "/users/roles", label: "الأدوار والصلاحيات" },
  { path: "/reports", label: "التقارير" },
  { path: "/integrations", label: "التكاملات" },
  { path: "/api-keys", label: "API" },
  { path: "/settings", label: "الإعدادات" },
];

export interface CustomRole {
  key: string;       // unique identifier used in internal_users.role
  label: string;     // display label (Arabic)
  builtin?: boolean; // true for director/supervisor/observer
}

// Stable Arabic → Latin transliteration for generating role keys.
const AR_MAP: Record<string, string> = {
  "ا":"a","أ":"a","إ":"i","آ":"aa","ب":"b","ت":"t","ث":"th","ج":"j","ح":"h","خ":"kh",
  "د":"d","ذ":"dh","ر":"r","ز":"z","س":"s","ش":"sh","ص":"s","ض":"d","ط":"t","ظ":"z",
  "ع":"a","غ":"gh","ف":"f","ق":"q","ك":"k","ل":"l","م":"m","ن":"n","ه":"h","و":"w",
  "ي":"y","ى":"a","ئ":"y","ؤ":"w","ء":"","ة":"h","َ":"","ُ":"","ِ":"","ّ":"","ْ":"","ً":"","ٌ":"","ٍ":"",
};
export const slugifyRoleKey = (input: string): string => {
  if (!input) return "";
  let s = input.trim().toLowerCase();
  s = s.split("").map(ch => AR_MAP[ch] !== undefined ? AR_MAP[ch] : ch).join("");
  s = s.replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").replace(/_+/g, "_");
  return s.slice(0, 40);
};

export const BUILTIN_ROLES: CustomRole[] = [
  { key: "director", label: "مدير الجهة", builtin: true },
  { key: "supervisor", label: "مشرف", builtin: true },
  { key: "observer", label: "مراقب", builtin: true },
];

export type RolePermissionsMap = Record<string, string[]>; // role key -> allowed paths

const SETTING_ROLES = "custom_roles";
const SETTING_PERMS = "role_permissions";

const readSetting = async (key: string): Promise<any> => {
  const { data } = await supabase.from("system_settings").select("value").eq("key", key).limit(1).maybeSingle();
  if (!data?.value) return null;
  try { return JSON.parse(data.value); } catch { return null; }
};

const writeSetting = async (key: string, value: any) => {
  const json = JSON.stringify(value);
  const { data: existing } = await supabase.from("system_settings").select("id").eq("key", key).limit(1).maybeSingle();
  if (existing?.id) await supabase.from("system_settings").update({ value: json }).eq("id", existing.id);
  else await supabase.from("system_settings").insert({ key, value: json });
};

export const loadCustomRoles = async (): Promise<CustomRole[]> => {
  const arr = await readSetting(SETTING_ROLES);
  if (Array.isArray(arr)) return arr;
  return [];
};

export const saveCustomRoles = (roles: CustomRole[]) => writeSetting(SETTING_ROLES, roles);

export const loadRolePermissions = async (): Promise<RolePermissionsMap> => {
  const obj = await readSetting(SETTING_PERMS);
  if (obj && typeof obj === "object") return obj as RolePermissionsMap;
  return {};
};

export const saveRolePermissions = (perms: RolePermissionsMap) => writeSetting(SETTING_PERMS, perms);

// Returns the list of allowed paths for a role, or null if no explicit
// permissions are defined (caller should fall back to the legacy behavior).
export const getAllowedPathsForRole = (role: string, perms: RolePermissionsMap): string[] | null => {
  const v = perms[role];
  if (Array.isArray(v)) return v;
  return null;
};
