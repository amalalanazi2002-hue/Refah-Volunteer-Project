import { useEffect, useState } from "react";
import { loadRolePermissions, getAllowedPathsForRole, RolePermissionsMap } from "@/lib/permissions";
import { supabase } from "@/integrations/supabase/client";

// Returns:
//  - undefined while loading
//  - null when no explicit permissions are defined for the role (legacy behavior)
//  - string[] of allowed paths when permissions are defined
export const useAllowedPaths = (role: string | null | undefined) => {
  const [paths, setPaths] = useState<string[] | null | undefined>(undefined);

  useEffect(() => {
    let cancelled = false;
    const fetchPerms = async () => {
      if (!role) { setPaths(null); return; }
      const perms: RolePermissionsMap = await loadRolePermissions();
      if (cancelled) return;
      setPaths(getAllowedPathsForRole(role, perms));
    };
    fetchPerms();

    // Re-fetch when system_settings changes (best-effort realtime).
    // Use a unique channel name per hook instance to avoid "cannot add
    // callbacks after subscribe()" when the same hook mounts in multiple places.
    const channel = supabase.channel(`perms-${role}-${Math.random().toString(36).slice(2)}`);
    channel
      .on("postgres_changes", { event: "*", schema: "public", table: "system_settings" }, () => {
        fetchPerms();
      })
      .subscribe();

    return () => { cancelled = true; supabase.removeChannel(channel); };
  }, [role]);

  return paths;
};
