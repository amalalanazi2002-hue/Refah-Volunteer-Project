import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Plus, Search, Pencil, KeyRound, UserPlus, Send, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { loadCustomRoles, BUILTIN_ROLES, CustomRole } from "@/lib/permissions";
import { Link } from "react-router-dom";
import { ShieldCheck } from "lucide-react";

const builtinRoleMap: Record<string, string> = { director: "مدير الجهة", supervisor: "مشرف", observer: "مراقب" };
const statusMap: Record<string, string> = { active: "نشط", inactive: "غير نشط" };
const roleVariant = (r: string) => r === "director" ? "primary" : r === "supervisor" ? "success" : r === "observer" ? "warning" : "neutral";

const InternalUsers = () => {
  const [data, setData] = useState<any[]>([]);
  const [customRoles, setCustomRoles] = useState<CustomRole[]>([]);
  const allRoles: CustomRole[] = [...BUILTIN_ROLES, ...customRoles];
  const roleMap: Record<string, string> = Object.fromEntries(allRoles.map(r => [r.key, r.label] as const));
  const [search, setSearch] = useState("");
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({ id: "", full_name: "", email: "", role: "", status: "" });
  const { role } = useRole();
  const isDirector = role === "director";

  // Password reset state
  const [pwOpen, setPwOpen] = useState(false);
  const [pwUser, setPwUser] = useState<any>(null);
  const [pwForm, setPwForm] = useState({ password: "", confirm: "" });
  const [pwLoading, setPwLoading] = useState(false);

  // Create-account state
  const [creatingFor, setCreatingFor] = useState<string | null>(null);
  const [credsDialog, setCredsDialog] = useState<{ open: boolean; fullName: string; email: string; password: string | null } | null>(null);

  const fetchData = async () => {
    const { data: rows } = await supabase.from("internal_users").select("*").order("created_at", { ascending: false });
    setData(rows || []);
  };

  useEffect(() => { fetchData(); loadCustomRoles().then(setCustomRoles); }, []);

  const [form, setForm] = useState({ full_name: "", email: "", role: "" });

  const handleAdd = async () => {
    if (!form.full_name || !form.role) return;
    await supabase.from("internal_users").insert({ id: crypto.randomUUID(), full_name: form.full_name, email: form.email || null, role: form.role });
    setForm({ full_name: "", email: "", role: "" });
    fetchData();
  };

  const toggleStatus = async (user: any) => {
    const newStatus = user.status === "active" ? "inactive" : "active";
    const { error } = await supabase.from("internal_users").update({ status: newStatus }).eq("id", user.id);
    if (error) { toast.error("خطأ في تحديث الحالة"); return; }
    toast.success(newStatus === "active" ? "تم تفعيل المستخدم" : "تم تعطيل المستخدم");
    fetchData();
  };

  const handleEdit = async () => {
    if (!editForm.full_name) return;
    if (!editForm.role) { toast.error("الرجاء اختيار دور"); return; }
    // Ensure the chosen role exists in the loaded role list (built-in or custom)
    const known = allRoles.some(r => r.key === editForm.role);
    if (!known) { toast.error("دور غير معروف — حدّث الصفحة"); return; }

    const { data: updated, error } = await supabase
      .from("internal_users")
      .update({
        full_name: editForm.full_name,
        email: editForm.email || null,
        role: editForm.role,
        status: editForm.status,
      })
      .eq("id", editForm.id)
      .select("id, role")
      .maybeSingle();

    if (error) {
      console.error("[InternalUsers] update error:", error);
      toast.error(`خطأ في التعديل: ${error.message}`);
      return;
    }
    if (!updated) {
      toast.error("لم يتم تحديث المستخدم — تحقق من الصلاحيات (RLS)");
      return;
    }
    if (updated.role !== editForm.role) {
      toast.error(`لم يُحفظ الدور المختار. القيمة المخزنة: ${updated.role}`);
      return;
    }
    toast.success("تم تعديل المستخدم بنجاح");
    setEditOpen(false);
    fetchData();
  };

  const handlePasswordReset = async () => {
    if (!pwForm.password || pwForm.password.length < 6) {
      toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }
    if (pwForm.password !== pwForm.confirm) {
      toast.error("كلمة المرور وتأكيدها غير متطابقين");
      return;
    }
    if (!pwUser?.auth_id) {
      toast.error("هذا المستخدم غير مربوط بحساب تسجيل دخول");
      return;
    }
    setPwLoading(true);
    const { data: result, error } = await supabase.functions.invoke("admin-update-password", {
      body: { p_auth_id: pwUser.auth_id, p_new_password: pwForm.password },
    });
    setPwLoading(false);

    if (error) {
      toast.error(`خطأ: ${error.message}`);
      return;
    }

    const res = result as any;
    if (res?.success) {
      toast.success("تم تغيير كلمة المرور بنجاح");
      setPwOpen(false);
      setPwForm({ password: "", confirm: "" });
    } else {
      toast.error(res?.error || "فشل في تغيير كلمة المرور");
    }
  };

  const createInternalAccount = async (user: any) => {
    if (user.auth_id) { toast.message("هذا المستخدم لديه حساب دخول مسبقًا"); return; }
    if (!user.email) { toast.error("لا يمكن إنشاء حساب: البريد الإلكتروني غير موجود"); return; }
    setCreatingFor(user.id);
    try {
      const { data, error } = await supabase.functions.invoke("create-internal-user-account", {
        body: { internal_user_id: user.id },
      });
      if (error) {
        toast.error(`تعذر إنشاء الحساب: ${error.message}. تأكد من نشر دالة create-internal-user-account.`);
        return;
      }
      const res = data as any;
      if (res?.already_linked) { toast.message("الحساب موجود ومرتبط مسبقًا"); fetchData(); return; }
      if (!res?.ok) {
        const errMap: Record<string, string> = {
          invalid_or_missing_email: "البريد الإلكتروني غير صالح أو غير موجود",
          forbidden_not_admin: "صلاحياتك لا تسمح بإنشاء حسابات",
          missing_service_role_secret: "ينقص SUPABASE_SERVICE_ROLE_KEY",
          email_exists_but_user_not_found: "البريد مسجّل لدى مستخدم آخر — تعذر الربط",
        };
        toast.error(errMap[res?.error] || `فشل: ${res?.error || "خطأ غير معروف"}`);
        return;
      }
      toast.success(res.linked_existing ? "تم ربط حساب الدخول الموجود" : "تم إنشاء حساب الدخول بنجاح");
      setCredsDialog({ open: true, fullName: user.full_name, email: res.email, password: res.password || null });
      fetchData();
    } catch (e: any) {
      toast.error(`خطأ: ${e?.message || "تعذر الاتصال بالدالة"}`);
    } finally {
      setCreatingFor(null);
    }
  };

  const filtered = data.filter(u => u.full_name.includes(search) || (u.email || "").includes(search));

  const exportData = filtered.map(r => ({
    full_name: r.full_name, email: r.email || "—", role: roleMap[r.role] || r.role, status: statusMap[r.status] || r.status,
  }));
  const exportCols = [
    { header: "الاسم", key: "full_name" }, { header: "البريد الإلكتروني", key: "email" },
    { header: "الدور", key: "role" }, { header: "الحالة", key: "status" },
  ];

  return (
    <div>
      <PageHeader title="المستخدمون الداخليون" description="إدارة المستخدمين الداخليين وأدوارهم" actions={
        <div className="flex gap-2 items-center flex-wrap">
          <Link to="/users/roles"><Button variant="outline" size="sm"><ShieldCheck className="h-4 w-4 ml-2" />الأدوار والصلاحيات</Button></Link>
          <ExportButtons data={exportData} columns={exportCols} title="المستخدمون الداخليون" filename="internal_users" />
          <Dialog>
            <DialogTrigger asChild><Button><Plus className="h-4 w-4 ml-2" />إضافة مستخدم</Button></DialogTrigger>
            <DialogContent className="max-w-lg" dir="rtl">
              <DialogHeader><DialogTitle>إضافة مستخدم داخلي</DialogTitle></DialogHeader>
              <div className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div><Label>الاسم الكامل</Label><Input placeholder="أدخل الاسم" className="mt-1.5" value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} /></div>
                  <div><Label>البريد الإلكتروني</Label><Input type="email" placeholder="example@rafah.org" className="mt-1.5" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
                  <div><Label>الدور</Label>
                    <Select onValueChange={v => setForm({ ...form, role: v })}>
                      <SelectTrigger className="mt-1.5"><SelectValue placeholder="اختر الدور" /></SelectTrigger>
                      <SelectContent>
                        {allRoles.map(r => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button className="w-full sm:w-auto" onClick={handleAdd}>إضافة</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      } />

      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="بحث بالاسم أو البريد..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
      </div>

      <DataTable
        columns={[
          { header: "الاسم", accessor: "full_name" },
          { header: "البريد الإلكتروني", accessor: (r: any) => r.email || "—" },
          { header: "الدور", accessor: (r: any) => <StatusBadge status={roleMap[r.role] || r.role} variant={roleVariant(r.role)} /> },
          { header: "الحالة", accessor: (r: any) => (
            <div className="flex items-center gap-2">
              <Switch checked={r.status === "active"} onCheckedChange={() => toggleStatus(r)} />
              <span className={`text-xs font-medium ${r.status === "active" ? "text-success" : "text-muted-foreground"}`}>{statusMap[r.status] || r.status}</span>
            </div>
          )},
          { header: "إجراءات", accessor: (r: any) => (
            <div className="flex gap-1 flex-wrap">
              <Button variant="ghost" size="sm" onClick={() => { setEditForm({ id: r.id, full_name: r.full_name, email: r.email || "", role: r.role, status: r.status }); setEditOpen(true); }}>
                <Pencil className="h-3.5 w-3.5 ml-1" />تعديل
              </Button>
              {isDirector && !r.auth_id && (
                <Button variant="outline" size="sm" disabled={creatingFor === r.id} onClick={() => createInternalAccount(r)}>
                  <UserPlus className="h-3.5 w-3.5 ml-1" />
                  {creatingFor === r.id ? "جارٍ الإنشاء..." : "إنشاء حساب دخول"}
                </Button>
              )}
              {isDirector && r.auth_id && (
                <Button variant="ghost" size="sm" onClick={() => { setPwUser(r); setPwForm({ password: "", confirm: "" }); setPwOpen(true); }}>
                  <KeyRound className="h-3.5 w-3.5 ml-1" />كلمة المرور
                </Button>
              )}
              {!r.auth_id && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-warning/10 text-warning self-center">بدون حساب</span>
              )}
            </div>
          )},
        ]}
        data={filtered}
      />

      {/* Edit Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>تعديل المستخدم</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><Label>الاسم الكامل</Label><Input className="mt-1.5" value={editForm.full_name} onChange={e => setEditForm({ ...editForm, full_name: e.target.value })} /></div>
              <div><Label>البريد الإلكتروني</Label><Input type="email" className="mt-1.5" value={editForm.email} onChange={e => setEditForm({ ...editForm, email: e.target.value })} /></div>
              <div><Label>الدور</Label>
                <Select value={editForm.role} onValueChange={v => setEditForm({ ...editForm, role: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {allRoles.map(r => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>الحالة</Label>
                <Select value={editForm.status} onValueChange={v => setEditForm({ ...editForm, status: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">نشط</SelectItem>
                    <SelectItem value="inactive">غير نشط</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={handleEdit}>حفظ التعديلات</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Password Reset Dialog */}
      <Dialog open={pwOpen} onOpenChange={setPwOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle>تغيير كلمة المرور</DialogTitle></DialogHeader>
          {pwUser && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">تغيير كلمة مرور: <span className="font-semibold text-foreground">{pwUser.full_name}</span></p>
              {!pwUser.auth_id && (
                <div className="bg-destructive/10 text-destructive text-xs rounded-lg p-3">
                  هذا المستخدم غير مربوط بحساب تسجيل دخول (auth_id غير موجود)
                </div>
              )}
              <div>
                <Label>كلمة المرور الجديدة</Label>
                <Input type="password" className="mt-1.5" value={pwForm.password} onChange={e => setPwForm({ ...pwForm, password: e.target.value })} placeholder="6 أحرف على الأقل" />
              </div>
              <div>
                <Label>تأكيد كلمة المرور</Label>
                <Input type="password" className="mt-1.5" value={pwForm.confirm} onChange={e => setPwForm({ ...pwForm, confirm: e.target.value })} placeholder="أعد إدخال كلمة المرور" />
              </div>
              <DialogFooter>
                <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
                <Button onClick={handlePasswordReset} disabled={pwLoading || !pwUser.auth_id}>
                  {pwLoading ? "جارٍ التحديث..." : "تغيير كلمة المرور"}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Credentials display dialog (after account creation) */}
      <Dialog open={!!credsDialog?.open} onOpenChange={open => { if (!open) setCredsDialog(null); }}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>بيانات الدخول الجديدة</DialogTitle></DialogHeader>
          {credsDialog && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">المستخدم: <strong className="text-foreground">{credsDialog.fullName}</strong></p>
              <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground text-xs">البريد:</span>
                  <code dir="ltr" className="text-xs">{credsDialog.email}</code>
                </div>
                {credsDialog.password && (
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground text-xs">كلمة المرور:</span>
                    <div className="flex items-center gap-1">
                      <code dir="ltr" className="text-xs bg-background px-2 py-1 rounded">{credsDialog.password}</code>
                      <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(credsDialog.password!); toast.success("تم نسخ كلمة المرور"); }}>
                        <Copy className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
              <p className="text-xs text-warning">⚠️ احفظ كلمة المرور الآن — لن تظهر مرة أخرى.</p>
              <DialogFooter>
                <DialogClose asChild><Button>تم</Button></DialogClose>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default InternalUsers;
