import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { DataTable } from "@/components/shared/DataTable";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Plug, Plus, Pencil, Trash2, TestTube, RefreshCw, FileText, Send, ShieldAlert, Globe, Info,
} from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import { useAllowedPaths } from "@/hooks/use-permissions";
import { formatDateTime } from "@/lib/format-date";
import { channels, providerFields, type ChannelDef } from "@/lib/integrations/providers";
import { eventTypes, getEvent } from "@/lib/integrations/events";
import { dispatchEvent } from "@/lib/integrations/dispatcher";

const statusVariant = (s: string) =>
  s === "connected" ? "success" : s === "configured" ? "primary" : s === "error" ? "danger" : "warning";
const statusLabel = (s: string) =>
  s === "connected" ? "متصل" : s === "configured" ? "جاهز (يحتاج backend)" : s === "error" ? "خطأ" : "غير مضبوط";

// ============================================================
// Main Component
// ============================================================
const Integrations = () => {
  const { role } = useRole();
  const allowedPaths = useAllowedPaths(role);
  const permsLoading = allowedPaths === undefined;
  const isDirector = role === "director" || (Array.isArray(allowedPaths) && allowedPaths.includes("/integrations"));

  const [configs, setConfigs] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [webhooks, setWebhooks] = useState<any[]>([]);
  const [dnsRecords, setDnsRecords] = useState<any[]>([]);

  // Dialogs
  const [templateDialog, setTemplateDialog] = useState(false);
  const [templateForm, setTemplateForm] = useState({ name: "", channel: "whatsapp", event_type: "new_opportunity", subject: "", body: "", placeholders: "[]", is_enabled: true });
  const [editingTemplate, setEditingTemplate] = useState<any>(null);

  const [webhookDialog, setWebhookDialog] = useState(false);
  const [webhookForm, setWebhookForm] = useState({ name: "", url: "", events: [] as string[], is_active: true });

  const [dnsDialog, setDnsDialog] = useState(false);
  const [dnsForm, setDnsForm] = useState({ domain: "", record_type: "A", name: "", value: "", ttl: 3600, priority: 0 });

  const fetchAll = async () => {
    const [cfgRes, tplRes, logRes, whRes, dnsRes] = await Promise.all([
      supabase.from("integration_configs").select("*").order("channel"),
      supabase.from("message_templates").select("*").order("channel"),
      supabase.from("integration_logs").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("webhook_configs").select("*").order("created_at", { ascending: false }),
      supabase.from("dns_records").select("*").order("created_at", { ascending: false }),
    ]);
    setConfigs(cfgRes.data || []);
    setTemplates(tplRes.data || []);
    setLogs(logRes.data || []);
    setWebhooks(whRes.data || []);
    setDnsRecords(dnsRes.data || []);
  };

  useEffect(() => { fetchAll(); }, []);

  // Block non-directors after all hooks
  if (!isDirector && !permsLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
        <ShieldAlert className="h-12 w-12 text-destructive" />
        <p className="text-lg font-semibold text-foreground">غير مصرح بالوصول</p>
        <p className="text-sm text-muted-foreground">هذه الصفحة متاحة للمدير فقط</p>
      </div>
    );
  }

  // ----- Channel Config Helpers -----
  // We treat each channel as having ONE active row. Switching provider updates
  // the same row, so the (channel) lookup below always reflects the saved state.
  const getConfig = (channel: string) => configs.find(c => c.channel === channel);

  const saveChannelConfig = async (channel: string, provider: string, configData: Record<string, string>, enabled: boolean) => {
    // Match by channel only (one row per channel) so the displayed row and the
    // persisted row always line up after refresh — even if the provider changed.
    const existing = configs.find(c => c.channel === channel);
    if (existing) {
      const { error } = await supabase
        .from("integration_configs")
        .update({
          provider,
          config: configData,
          is_enabled: enabled,
          updated_at: new Date().toISOString(),
        })
        .eq("id", existing.id);
      if (error) {
        toast.error(`تعذّر حفظ الإعدادات: ${error.message}`);
        return;
      }
    } else {
      const { error } = await supabase
        .from("integration_configs")
        .insert({ channel, provider, config: configData, is_enabled: enabled });
      if (error) {
        toast.error(`تعذّر حفظ الإعدادات: ${error.message}`);
        return;
      }
    }
    toast.success(`تم حفظ إعدادات القناة (${enabled ? "مفعّلة" : "غير مفعّلة"})`);
    await fetchAll();
  };

  const testConnection = async (channel: string, provider: string) => {
    // Honest test: from the browser we cannot reach provider APIs (CORS + secrets).
    // We only verify that the config is saved and well-formed, and record a log.
    // Real network test will run in a backend Edge Function once it's deployed.
    const cfg = configs.find(c => c.channel === channel && c.provider === provider);
    const requiredFields = providerFields[provider] || [];
    const missing = requiredFields.filter(f => !cfg?.config?.[f.key]).map(f => f.label);

    const status = missing.length === 0 ? "configured" : "error";
    const errorMessage = missing.length === 0 ? null : `حقول ناقصة: ${missing.join("، ")}`;

    if (cfg) {
      await supabase.from("integration_configs").update({
        connection_status: status,
        last_tested_at: new Date().toISOString(),
      }).eq("id", cfg.id);
    }
    await supabase.from("integration_logs").insert({
      channel, provider, event_type: "test", operation: "test_connection",
      status: status === "configured" ? "pending" : "failed",
      error_message: errorMessage || "الإعدادات محفوظة — التنفيذ الفعلي يحتاج backend",
    });

    if (missing.length === 0) {
      toast.message("تم التحقق من الإعدادات", {
        description: "الإعدادات محفوظة بشكل صحيح. الإرسال الفعلي للمزود يحتاج تفعيل backend.",
      });
    } else {
      toast.error(`حقول ناقصة: ${missing.join("، ")}`);
    }
    fetchAll();
  };

  // ----- Templates -----
  const saveTemplate = async () => {
    if (!templateForm.name || !templateForm.body) return;
    let placeholders: any = [];
    try { placeholders = JSON.parse(templateForm.placeholders); } catch { placeholders = []; }

    if (editingTemplate) {
      await supabase.from("message_templates").update({
        name: templateForm.name, channel: templateForm.channel, event_type: templateForm.event_type,
        subject: templateForm.subject || null, body: templateForm.body, placeholders, is_enabled: templateForm.is_enabled,
        updated_at: new Date().toISOString(),
      }).eq("id", editingTemplate.id);
      toast.success("تم تعديل القالب");
    } else {
      await supabase.from("message_templates").insert({
        name: templateForm.name, channel: templateForm.channel, event_type: templateForm.event_type,
        subject: templateForm.subject || null, body: templateForm.body, placeholders, is_enabled: templateForm.is_enabled,
      });
      toast.success("تم إضافة القالب");
    }
    setTemplateDialog(false);
    setEditingTemplate(null);
    setTemplateForm({ name: "", channel: "whatsapp", event_type: "new_opportunity", subject: "", body: "", placeholders: "[]", is_enabled: true });
    fetchAll();
  };

  const deleteTemplate = async (id: string) => {
    await supabase.from("message_templates").delete().eq("id", id);
    toast.success("تم حذف القالب");
    fetchAll();
  };

  // ----- Webhooks -----
  const saveWebhook = async () => {
    if (!webhookForm.name || !webhookForm.url) return;
    await supabase.from("webhook_configs").insert({
      name: webhookForm.name, url: webhookForm.url, events: webhookForm.events, is_active: webhookForm.is_active,
    });
    toast.success("تم إضافة Webhook");
    setWebhookDialog(false);
    setWebhookForm({ name: "", url: "", events: [], is_active: true });
    fetchAll();
  };

  const toggleWebhook = async (wh: any) => {
    await supabase.from("webhook_configs").update({ is_active: !wh.is_active }).eq("id", wh.id);
    fetchAll();
  };

  const deleteWebhook = async (id: string) => {
    await supabase.from("webhook_configs").delete().eq("id", id);
    toast.success("تم حذف Webhook");
    fetchAll();
  };

  // ----- DNS -----
  const saveDns = async () => {
    if (!dnsForm.domain || !dnsForm.name || !dnsForm.value) return;
    await supabase.from("dns_records").insert(dnsForm);
    toast.success("تم إضافة سجل DNS");
    setDnsDialog(false);
    setDnsForm({ domain: "", record_type: "A", name: "", value: "", ttl: 3600, priority: 0 });
    fetchAll();
  };

  const deleteDns = async (id: string) => {
    await supabase.from("dns_records").delete().eq("id", id);
    toast.success("تم حذف السجل");
    fetchAll();
  };

  return (
    <div>
      <PageHeader title="التكاملات" description="إدارة قنوات الإرسال والمزودات والربط الخارجي" />

      <Tabs defaultValue="channels" className="w-full">
        <TabsList className="mb-4 flex-wrap h-auto gap-1">
          <TabsTrigger value="channels"><Plug className="h-4 w-4 ml-1" />القنوات</TabsTrigger>
          <TabsTrigger value="templates"><FileText className="h-4 w-4 ml-1" />القوالب</TabsTrigger>
          <TabsTrigger value="webhooks"><Send className="h-4 w-4 ml-1" />Webhooks</TabsTrigger>
          <TabsTrigger value="dns"><Globe className="h-4 w-4 ml-1" />النطاقات</TabsTrigger>
          <TabsTrigger value="logs"><RefreshCw className="h-4 w-4 ml-1" />السجلات</TabsTrigger>
        </TabsList>

        {/* ===== CHANNELS TAB ===== */}
        <TabsContent value="channels">
          <div className="space-y-4">
            {channels.map(ch => (
              <ChannelCard key={ch.key} channel={ch} config={configs.find(c => c.channel === ch.key)} templates={templates} onSave={saveChannelConfig} onTest={testConnection} />
            ))}
          </div>
        </TabsContent>

        {/* ===== TEMPLATES TAB ===== */}
        <TabsContent value="templates">
          <div dir="rtl" className="flex justify-start mb-4">
            <Button onClick={() => { setEditingTemplate(null); setTemplateForm({ name: "", channel: "whatsapp", event_type: "new_opportunity", subject: "", body: "", placeholders: "[]", is_enabled: true }); setTemplateDialog(true); }}>
              <Plus className="h-4 w-4 ml-1" />إضافة قالب
            </Button>
          </div>
          <DataTable
            columns={[
              { header: "الاسم", accessor: "name" },
              { header: "القناة", accessor: (r: any) => channels.find(c => c.key === r.channel)?.label || r.channel },
              { header: "الحدث", accessor: (r: any) => eventTypes.find(e => e.value === r.event_type)?.label || r.event_type },
              { header: "الحالة", accessor: (r: any) => <StatusBadge status={r.is_enabled ? "مفعّل" : "معطّل"} variant={r.is_enabled ? "success" : "neutral"} /> },
              { header: "إجراءات", accessor: (r: any) => (
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" onClick={() => {
                    setEditingTemplate(r);
                    setTemplateForm({ name: r.name, channel: r.channel, event_type: r.event_type, subject: r.subject || "", body: r.body, placeholders: JSON.stringify(r.placeholders || []), is_enabled: r.is_enabled });
                    setTemplateDialog(true);
                  }}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button variant="ghost" size="sm" className="text-destructive" onClick={() => deleteTemplate(r.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              )},
            ]}
            data={templates}
            emptyMessage="لا توجد قوالب رسائل بعد"
          />
        </TabsContent>

        {/* ===== WEBHOOKS TAB ===== */}
        <TabsContent value="webhooks">
          <div dir="rtl" className="flex justify-start mb-4">
            <Button onClick={() => setWebhookDialog(true)}><Plus className="h-4 w-4 ml-1" />إضافة Webhook</Button>
          </div>
          <DataTable
            columns={[
              { header: "الاسم", accessor: "name" },
              { header: "URL", accessor: (r: any) => <span className="text-xs font-mono" dir="ltr">{r.url}</span> },
              { header: "الأحداث", accessor: (r: any) => (r.events || []).length + " حدث" },
              { header: "الحالة", accessor: (r: any) => (
                <div className="flex items-center gap-2">
                  <Switch checked={r.is_active} onCheckedChange={() => toggleWebhook(r)} />
                  <span className="text-xs">{r.is_active ? "مفعّل" : "معطّل"}</span>
                </div>
              )},
              { header: "Secret", accessor: (r: any) => <span className="text-xs font-mono text-muted-foreground" dir="ltr">{r.secret?.slice(0, 12)}...</span> },
              { header: "إجراءات", accessor: (r: any) => (
                <Button variant="ghost" size="sm" className="text-destructive" onClick={() => deleteWebhook(r.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
              )},
            ]}
            data={webhooks}
            emptyMessage="لا توجد Webhooks بعد"
          />
        </TabsContent>

        {/* ===== DNS TAB ===== */}
        <TabsContent value="dns">
          {/* Domain config card */}
          <div className="mb-4">
            <ChannelCard channel={channels.find(c => c.key === "domain_dns")!} config={configs.find(c => c.channel === "domain_dns")} onSave={saveChannelConfig} onTest={testConnection} />
          </div>
          <div dir="rtl" className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-foreground">سجلات DNS</h3>
            <Button onClick={() => setDnsDialog(true)}><Plus className="h-4 w-4 ml-1" />إضافة سجل</Button>
          </div>
          <DataTable
            columns={[
              { header: "النطاق", accessor: "domain" },
              { header: "النوع", accessor: "record_type" },
              { header: "الاسم", accessor: "name" },
              { header: "القيمة", accessor: (r: any) => <span className="text-xs font-mono" dir="ltr">{r.value}</span> },
              { header: "TTL", accessor: "ttl" },
              { header: "الأولوية", accessor: (r: any) => r.priority || "—" },
              { header: "إجراءات", accessor: (r: any) => (
                <Button variant="ghost" size="sm" className="text-destructive" onClick={() => deleteDns(r.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
              )},
            ]}
            data={dnsRecords}
            emptyMessage="لا توجد سجلات DNS"
          />
        </TabsContent>

        {/* ===== LOGS TAB ===== */}
        <TabsContent value="logs">
          <DataTable
            columns={[
              { header: "القناة", accessor: (r: any) => channels.find(c => c.key === r.channel)?.label || r.channel },
              { header: "المزود", accessor: (r: any) => r.provider || "—" },
              { header: "الحدث", accessor: (r: any) => eventTypes.find(e => e.value === r.event_type)?.label || r.event_type },
              { header: "العملية", accessor: "operation" },
              { header: "الحالة", accessor: (r: any) => <StatusBadge status={r.status === "success" ? "ناجح" : r.status === "failed" ? "فشل" : "معلّق"} variant={r.status === "success" ? "success" : r.status === "failed" ? "danger" : "warning"} /> },
              { header: "الهدف", accessor: (r: any) => r.target || "—" },
              { header: "الخطأ", accessor: (r: any) => r.error_message ? <span className="text-xs text-destructive">{r.error_message}</span> : "—" },
              { header: "التاريخ", accessor: (r: any) => formatDateTime(r.created_at) },
            ]}
            data={logs}
            emptyMessage="لا توجد سجلات بعد"
          />
        </TabsContent>
      </Tabs>

      {/* ===== Template Dialog ===== */}
      <Dialog open={templateDialog} onOpenChange={setTemplateDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>{editingTemplate ? "تعديل القالب" : "إضافة قالب جديد"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>اسم القالب</Label><Input className="mt-1.5" value={templateForm.name} onChange={e => setTemplateForm(p => ({ ...p, name: e.target.value }))} /></div>
              <div><Label>القناة</Label>
                <Select value={templateForm.channel} onValueChange={v => setTemplateForm(p => ({ ...p, channel: v }))}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>{channels.filter(c => c.key !== "domain_dns").map(c => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>الحدث</Label>
                <Select value={templateForm.event_type} onValueChange={v => setTemplateForm(p => ({ ...p, event_type: v }))}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>{eventTypes.map(e => <SelectItem key={e.value} value={e.value}>{e.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {templateForm.channel === "email" && (
                <div><Label>العنوان</Label><Input className="mt-1.5" value={templateForm.subject} onChange={e => setTemplateForm(p => ({ ...p, subject: e.target.value }))} /></div>
              )}
            </div>
            <div><Label>نص الرسالة</Label><Textarea className="mt-1.5" rows={4} value={templateForm.body} onChange={e => setTemplateForm(p => ({ ...p, body: e.target.value }))} placeholder="مرحبًا {{volunteer_name}}، ..." /></div>

            {/* Variable helper for the selected event */}
            {(() => {
              const ev = getEvent(templateForm.event_type);
              if (!ev || ev.variables.length === 0) return null;
              return (
                <div className="rounded-md border border-border bg-muted/40 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs font-semibold text-foreground">المتغيرات المتاحة لهذا الحدث</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {ev.variables.map(va => (
                      <button
                        key={va.key}
                        type="button"
                        onClick={() => setTemplateForm(p => ({ ...p, body: `${p.body}{{${va.key}}}` }))}
                        className="px-2 py-1 rounded border border-border bg-background hover:bg-accent hover:text-accent-foreground text-[11px] font-mono"
                        dir="ltr"
                        title={va.label}
                      >
                        {`{{${va.key}}}`}
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-2">اضغط على المتغير لإدراجه في نص الرسالة.</p>
                </div>
              );
            })()}

            <div className="flex items-center gap-2">
              <Switch checked={templateForm.is_enabled} onCheckedChange={v => setTemplateForm(p => ({ ...p, is_enabled: v }))} />
              <Label>مفعّل</Label>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={saveTemplate}>{editingTemplate ? "حفظ التعديلات" : "إضافة"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Webhook Dialog ===== */}
      <Dialog open={webhookDialog} onOpenChange={setWebhookDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>إضافة Webhook</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>الاسم</Label><Input className="mt-1.5" value={webhookForm.name} onChange={e => setWebhookForm(p => ({ ...p, name: e.target.value }))} /></div>
            <div><Label>URL</Label><Input className="mt-1.5 font-mono text-xs" dir="ltr" value={webhookForm.url} onChange={e => setWebhookForm(p => ({ ...p, url: e.target.value }))} placeholder="https://example.com/webhook" /></div>
            <div>
              <Label>الأحداث</Label>
              <div className="grid grid-cols-2 gap-2 mt-1.5">
                {eventTypes.map(ev => (
                  <label key={ev.value} className="flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={webhookForm.events.includes(ev.value)} onChange={e => {
                      setWebhookForm(p => ({ ...p, events: e.target.checked ? [...p.events, ev.value] : p.events.filter(x => x !== ev.value) }));
                    }} />
                    {ev.label}
                  </label>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={saveWebhook}>إضافة</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== DNS Dialog ===== */}
      <Dialog open={dnsDialog} onOpenChange={setDnsDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>إضافة سجل DNS</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>النطاق</Label><Input className="mt-1.5" dir="ltr" value={dnsForm.domain} onChange={e => setDnsForm(p => ({ ...p, domain: e.target.value }))} placeholder="example.com" /></div>
              <div><Label>النوع</Label>
                <Select value={dnsForm.record_type} onValueChange={v => setDnsForm(p => ({ ...p, record_type: v }))}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">A</SelectItem>
                    <SelectItem value="CNAME">CNAME</SelectItem>
                    <SelectItem value="TXT">TXT</SelectItem>
                    <SelectItem value="MX">MX</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>الاسم</Label><Input className="mt-1.5" dir="ltr" value={dnsForm.name} onChange={e => setDnsForm(p => ({ ...p, name: e.target.value }))} placeholder="@" /></div>
              <div><Label>القيمة</Label><Input className="mt-1.5" dir="ltr" value={dnsForm.value} onChange={e => setDnsForm(p => ({ ...p, value: e.target.value }))} /></div>
              <div><Label>TTL</Label><Input className="mt-1.5" type="number" value={dnsForm.ttl} onChange={e => setDnsForm(p => ({ ...p, ttl: Number(e.target.value) }))} /></div>
              {dnsForm.record_type === "MX" && (
                <div><Label>الأولوية</Label><Input className="mt-1.5" type="number" value={dnsForm.priority} onChange={e => setDnsForm(p => ({ ...p, priority: Number(e.target.value) }))} /></div>
              )}
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={saveDns}>إضافة</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// ============================================================
// Channel Card Component
// ============================================================
interface ChannelCardProps {
  channel: ChannelDef;
  config: any;
  templates?: any[];
  onSave: (channel: string, provider: string, config: Record<string, string>, enabled: boolean) => void;
  onTest: (channel: string, provider: string) => void;
}

const ChannelCard = ({ channel, config, templates = [], onSave, onTest }: ChannelCardProps) => {
  const [provider, setProvider] = useState<string>(config?.provider || channel.providers[0]?.value || "");
  const [enabled, setEnabled] = useState<boolean>(config?.is_enabled === true);
  const [fields, setFields] = useState<Record<string, string>>(config?.config || {});
  const [expanded, setExpanded] = useState(false);

  // ----- SMS Test dialog state (only used for the SMS card) -----
  const [smsTestOpen, setSmsTestOpen] = useState(false);
  const [smsTestTo, setSmsTestTo] = useState("");
  const [smsTestMode, setSmsTestMode] = useState<"free" | "template">("free");
  const [smsTestBody, setSmsTestBody] = useState("");
  const [smsTestTemplateId, setSmsTestTemplateId] = useState<string>("");
  const [smsTestSending, setSmsTestSending] = useState(false);

  const smsTemplates = (templates || []).filter(t => t.channel === "sms" && t.is_enabled);
  const selectedSmsTemplate = smsTemplates.find(t => t.id === smsTestTemplateId);

  // Sync local UI state whenever the persisted config row changes (e.g. after save+refetch).
  // Depend on primitive fields so we don't miss updates when the parent recreates the object.
  useEffect(() => {
    if (config) {
      setProvider(config.provider || channel.providers[0]?.value || "");
      setEnabled(config.is_enabled === true);
      setFields(config.config || {});
    } else {
      setProvider(channel.providers[0]?.value || "");
      setEnabled(false);
      setFields({});
    }
  }, [config?.id, config?.provider, config?.is_enabled, config?.config, channel.providers]);


  const currentFields = providerFields[provider] || [];
  const currentProviderDef = channel.providers.find(p => p.value === provider);

  // Accepts: 9665XXXXXXXX, 05XXXXXXXX, +9665XXXXXXXX, etc. Min 8 digits.
  const isValidPhone = (raw: string) => {
    const cleaned = raw.replace(/[\s\-()]/g, "");
    return /^\+?\d{8,15}$/.test(cleaned);
  };

  const sendSmsTest = async () => {
    const to = smsTestTo.trim();
    if (!isValidPhone(to)) {
      toast.error("رقم الجوال غير صالح");
      return;
    }
    if (!enabled) {
      toast.error("قناة الرسائل النصية غير مفعّلة");
      return;
    }
    if (!config || !config.is_enabled) {
      toast.error("لا يوجد مزود SMS مفعّل. احفظ الإعدادات وفعّل القناة أولًا.");
      return;
    }
    const requiredFields = providerFields[config.provider] || [];
    const missing = requiredFields.filter(f => !config?.config?.[f.key]).map(f => f.label);
    if (missing.length > 0) {
      toast.error(`إعدادات المزود غير مكتملة: ${missing.join("، ")}`);
      return;
    }

    setSmsTestSending(true);
    try {
      if (smsTestMode === "free") {
        const body = smsTestBody.trim();
        if (!body) {
          toast.error("نص الرسالة فارغ");
          setSmsTestSending(false);
          return;
        }

        // Verify we have an authenticated session before invoking the function.
        const { data: sessionData } = await supabase.auth.getSession();
        const accessToken = sessionData?.session?.access_token;
        if (!accessToken) {
          toast.error("الجلسة منتهية. يرجى تسجيل الدخول مجددًا.");
          setSmsTestSending(false);
          return;
        }

        const payload = {
          channel: "sms",
          provider: config.provider,
          event: "test",
          to,
          subject: null,
          body,
          providerConfig: config.config,
          templateId: null,
        };

        // Use direct fetch instead of supabase.functions.invoke so we can
        // surface precise errors (404 = not deployed, 401 = unauth, CORS, network).
        const SUPABASE_URL = "https://zrvzxlpokekenneiovvt.supabase.co";
        const SUPABASE_ANON = "sb_publishable_Xy6ZNvZT-uYzkm8QQjG47Q_0C9n5k8K";
        const fnUrl = `${SUPABASE_URL}/functions/v1/dispatch-message`;

        let res: Response;
        try {
          res = await fetch(fnUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${accessToken}`,
              apikey: SUPABASE_ANON,
            },
            body: JSON.stringify(payload),
          });
        } catch (netErr: any) {
          // TypeError: Failed to fetch — usually CORS or network unreachable
          toast.error(
            `تعذّر الوصول إلى Edge Function (Network/CORS). تأكد من نشر الدالة "dispatch-message". التفاصيل: ${netErr?.message || "Network error"}`
          );
          setSmsTestSending(false);
          return;
        }

        if (res.status === 404) {
          toast.error('الدالة "dispatch-message" غير منشورة في هذا المشروع. يجب نشرها أولًا.');
          setSmsTestSending(false);
          return;
        }
        if (res.status === 401 || res.status === 403) {
          toast.error(`غير مصرّح (${res.status}). تحقق من الجلسة وإعدادات الدالة.`);
          setSmsTestSending(false);
          return;
        }

        let data: any = null;
        const rawText = await res.text();
        try {
          data = rawText ? JSON.parse(rawText) : null;
        } catch {
          // non-JSON response
        }

        if (!res.ok) {
          const msg = data?.error || rawText?.slice(0, 300) || `HTTP ${res.status}`;
          toast.error(`فشل الإرسال (${res.status}): ${msg}`);
        } else if (data?.ok) {
          toast.success("تم إرسال الرسالة بنجاح");
        } else {
          toast.error(`فشل الإرسال: ${data?.error || "خطأ غير معروف من المزود"}`);
        }
      } else {
        if (!selectedSmsTemplate) {
          toast.error("يرجى اختيار قالب");
          setSmsTestSending(false);
          return;
        }

        // Build a vars map from the event definition's example values, so the
        // test message reflects what the recipient would actually see in
        // production. Any placeholder in the template body that we can't
        // resolve is reported clearly — we never send raw {{var}} text.
        const ev = getEvent(selectedSmsTemplate.event_type);
        const vars: Record<string, string> = {};
        (ev?.variables || []).forEach((variable) => {
          if (variable.example) vars[variable.key] = variable.example;
        });

        const rawBody = String(selectedSmsTemplate.body || "");
        const placeholders = Array.from(
          rawBody.matchAll(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g)
        ).map((m) => m[1]);
        const missingVars = Array.from(new Set(placeholders.filter((k) => !(k in vars))));
        if (missingVars.length > 0) {
          toast.error(
            `لا يمكن إرسال القالب: متغيرات غير متوفرة (${missingVars.join("، ")}). أضف قيمها أو احذفها من نص القالب.`
          );
          setSmsTestSending(false);
          return;
        }

        const renderedBody = rawBody.replace(
          /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g,
          (_, k) => String(vars[k])
        );

        // Send the rendered body via the same authenticated edge-function
        // path as the free-text mode so behavior stays consistent.
        const { data: sessionData } = await supabase.auth.getSession();
        const accessToken = sessionData?.session?.access_token;
        if (!accessToken) {
          toast.error("الجلسة منتهية. يرجى تسجيل الدخول مجددًا.");
          setSmsTestSending(false);
          return;
        }

        const SUPABASE_URL = "https://zrvzxlpokekenneiovvt.supabase.co";
        const SUPABASE_ANON = "sb_publishable_Xy6ZNvZT-uYzkm8QQjG47Q_0C9n5k8K";
        const fnUrl = `${SUPABASE_URL}/functions/v1/dispatch-message`;

        const res = await fetch(fnUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
            apikey: SUPABASE_ANON,
          },
          body: JSON.stringify({
            channel: "sms",
            provider: config.provider,
            event: selectedSmsTemplate.event_type,
            to,
            subject: null,
            body: renderedBody,
            providerConfig: config.config,
            templateId: selectedSmsTemplate.id,
          }),
        });
        const rawText = await res.text();
        let data: any = null;
        try { data = rawText ? JSON.parse(rawText) : null; } catch { /* noop */ }
        if (!res.ok) {
          toast.error(`فشل الإرسال (${res.status}): ${data?.error || rawText?.slice(0, 200) || "خطأ"}`);
        } else if (data?.ok) {
          toast.success("تم إرسال الرسالة بنجاح");
        } else {
          toast.error(`فشل الإرسال: ${data?.error || "خطأ غير معروف"}`);
        }
      }
    } catch (e: any) {
      toast.error(`خطأ: ${e?.message || "غير معروف"}`);
    } finally {
      setSmsTestSending(false);
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <channel.icon className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h4 className="font-bold text-foreground">{channel.label}</h4>
            <p className="text-xs text-muted-foreground">
              {config ? `المزود: ${provider || "غير محدد"}` : "غير مضبوط"}
              {config?.connection_status && (
                <span className="mr-2">
                  <StatusBadge status={statusLabel(config.connection_status)} variant={statusVariant(config.connection_status)} />
                </span>
              )}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {channel.key === "sms" && (
            <Button variant="outline" size="sm" onClick={() => setSmsTestOpen(true)}>
              <Send className="h-4 w-4 ml-1" />إرسال اختبار
            </Button>
          )}
          <Switch
            checked={enabled}
            onCheckedChange={async (next) => {
              // Optimistic UI; persist immediately so refreshing the page
              // keeps the toggle state without requiring a separate save click.
              setEnabled(next);
              await onSave(channel.key, provider, fields, next);
            }}
          />
          <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
            {expanded ? "إخفاء" : "إعدادات"}
          </Button>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-border pt-4 space-y-4">
          <div>
            <Label>المزود</Label>
            <Select value={provider} onValueChange={v => { setProvider(v); setFields({}); }}>
              <SelectTrigger className="mt-1.5 w-64"><SelectValue placeholder="اختر المزود" /></SelectTrigger>
              <SelectContent>
                {channel.providers.map(p => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {currentProviderDef?.note && (
            <p className="text-xs text-muted-foreground -mt-2">{currentProviderDef.note}</p>
          )}

          {provider && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentFields.map(f => (
                <div key={f.key} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
                  <Label>{f.label}</Label>
                  {f.type === "textarea" ? (
                    <Textarea
                      className="mt-1.5 font-mono text-xs"
                      dir="ltr"
                      rows={3}
                      value={fields[f.key] || ""}
                      onChange={e => setFields(prev => ({ ...prev, [f.key]: e.target.value }))}
                    />
                  ) : (
                    <Input
                      className="mt-1.5 font-mono text-xs"
                      dir="ltr"
                      type={f.type || "text"}
                      value={fields[f.key] || ""}
                      onChange={e => setFields(prev => ({ ...prev, [f.key]: e.target.value }))}
                    />
                  )}
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <Button size="sm" onClick={() => onSave(channel.key, provider, fields, enabled)}>
              حفظ الإعدادات
            </Button>
            {config && (
              <Button size="sm" variant="outline" onClick={() => onTest(channel.key, provider)}>
                <TestTube className="h-4 w-4 ml-1" />اختبار الاتصال
              </Button>
            )}
          </div>
        </div>
      )}

      {/* ===== SMS Test Dialog (only mounted for SMS channel) ===== */}
      {channel.key === "sms" && (
        <Dialog open={smsTestOpen} onOpenChange={setSmsTestOpen}>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader>
              <DialogTitle>اختبار إرسال رسالة نصية</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>رقم المستلم</Label>
                <Input
                  className="mt-1.5 font-mono"
                  dir="ltr"
                  placeholder="9665XXXXXXXX"
                  value={smsTestTo}
                  onChange={e => setSmsTestTo(e.target.value)}
                />
                <p className="text-[11px] text-muted-foreground mt-1">
                  أدخل الرقم بصيغة دولية بدون + (مثال: 9665XXXXXXXX)
                </p>
              </div>

              <div>
                <Label>نوع الرسالة</Label>
                <Select value={smsTestMode} onValueChange={v => setSmsTestMode(v as "free" | "template")}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="free">نص حر</SelectItem>
                    <SelectItem value="template">قالب جاهز</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {smsTestMode === "free" ? (
                <div>
                  <Label>نص الرسالة</Label>
                  <Textarea
                    className="mt-1.5"
                    rows={4}
                    placeholder="اكتب نص الرسالة التجريبية..."
                    value={smsTestBody}
                    onChange={e => setSmsTestBody(e.target.value)}
                  />
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <Label>القالب</Label>
                    <Select value={smsTestTemplateId} onValueChange={setSmsTestTemplateId}>
                      <SelectTrigger className="mt-1.5">
                        <SelectValue placeholder={smsTemplates.length === 0 ? "لا توجد قوالب SMS مفعّلة" : "اختر قالبًا"} />
                      </SelectTrigger>
                      <SelectContent>
                        {smsTemplates.map(t => (
                          <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {smsTemplates.length === 0 && (
                      <p className="text-[11px] text-muted-foreground mt-1">
                        أضف قالبًا من تبويب "القوالب" بقناة SMS وفعّله ليظهر هنا.
                      </p>
                    )}
                  </div>

                  {selectedSmsTemplate && (
                    <div className="rounded-md border border-border bg-muted/40 p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Info className="h-4 w-4 text-muted-foreground" />
                        <span className="text-xs font-semibold text-foreground">معاينة نص القالب</span>
                      </div>
                      <pre className="text-xs whitespace-pre-wrap text-foreground font-sans">{selectedSmsTemplate.body}</pre>
                      <p className="text-[11px] text-muted-foreground mt-2">
                        ملاحظة: المتغيرات مثل {"{{volunteer_name}}"} سيتم استبدالها بقيم تجريبية قبل الإرسال.
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline" disabled={smsTestSending}>إلغاء</Button>
              </DialogClose>
              <Button onClick={sendSmsTest} disabled={smsTestSending}>
                {smsTestSending ? "جاري الإرسال..." : "إرسال"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default Integrations;
