import { useEffect, useState } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ShieldCheck, Save } from "lucide-react";
import {
  ALL_PAGES, BUILTIN_ROLES, CustomRole, RolePermissionsMap,
  loadCustomRoles, saveCustomRoles, loadRolePermissions, saveRolePermissions,
  slugifyRoleKey,
} from "@/lib/permissions";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const RolesPermissions = () => {
  const [customRoles, setCustomRoles] = useState<CustomRole[]>([]);
  const [perms, setPerms] = useState<RolePermissionsMap>({});
  const [loading, setLoading] = useState(true);
  const [usageCounts, setUsageCounts] = useState<Record<string, number>>({});

  // Add-role dialog
  const [addOpen, setAddOpen] = useState(false);
  const [newRole, setNewRole] = useState({ key: "", label: "", keyTouched: false });

  // Edit (rename) dialog
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<CustomRole | null>(null);

  const refresh = async () => {
    setLoading(true);
    const [roles, p] = await Promise.all([loadCustomRoles(), loadRolePermissions()]);
    setCustomRoles(roles);
    setPerms(p);
    // Count usage for safety on delete
    const { data: users } = await supabase.from("internal_users").select("role");
    const counts: Record<string, number> = {};
    (users || []).forEach((u: any) => { counts[u.role] = (counts[u.role] || 0) + 1; });
    setUsageCounts(counts);
    setLoading(false);
  };

  useEffect(() => { refresh(); }, []);

  const allRoles: CustomRole[] = [...BUILTIN_ROLES, ...customRoles];

  const togglePath = (roleKey: string, path: string) => {
    setPerms(prev => {
      const current = prev[roleKey] || [];
      const next = current.includes(path) ? current.filter(p => p !== path) : [...current, path];
      return { ...prev, [roleKey]: next };
    });
  };

  const setAllForRole = (roleKey: string, all: boolean) => {
    setPerms(prev => ({ ...prev, [roleKey]: all ? ALL_PAGES.map(p => p.path) : [] }));
  };

  const savePerms = async () => {
    await saveRolePermissions(perms);
    toast.success("تم حفظ الصلاحيات");
  };

  const handleAddRole = async () => {
    const key = slugifyRoleKey(newRole.key || newRole.label);
    const label = newRole.label.trim();
    if (!key || !label) { toast.error("الرجاء إدخال الاسم العربي والمعرّف الإنجليزي"); return; }
    if (!/^[a-z][a-z0-9_]*$/.test(key)) { toast.error("المعرّف يجب أن يبدأ بحرف إنجليزي ويحتوي حروفًا/أرقامًا/_ فقط"); return; }
    if (allRoles.some(r => r.key === key)) { toast.error("هذا المعرّف موجود مسبقًا"); return; }
    const next = [...customRoles, { key, label }];
    await saveCustomRoles(next);
    setCustomRoles(next);
    setNewRole({ key: "", label: "", keyTouched: false });
    setAddOpen(false);
    toast.success("تم إنشاء الدور");
  };

  const handleEditRole = async () => {
    if (!editing) return;
    const label = editing.label.trim();
    if (!label) { toast.error("الاسم مطلوب"); return; }
    const next = customRoles.map(r => r.key === editing.key ? { ...r, label } : r);
    await saveCustomRoles(next);
    setCustomRoles(next);
    setEditOpen(false);
    setEditing(null);
    toast.success("تم تحديث الدور");
  };

  const handleDeleteRole = async (role: CustomRole) => {
    if (role.builtin) { toast.error("لا يمكن حذف دور افتراضي"); return; }
    const inUse = usageCounts[role.key] || 0;
    if (inUse > 0) { toast.error(`لا يمكن حذف هذا الدور لأنه مرتبط بـ ${inUse} مستخدم`); return; }
    if (!confirm(`حذف الدور "${role.label}"؟`)) return;
    const nextRoles = customRoles.filter(r => r.key !== role.key);
    const nextPerms = { ...perms }; delete nextPerms[role.key];
    await Promise.all([saveCustomRoles(nextRoles), saveRolePermissions(nextPerms)]);
    setCustomRoles(nextRoles);
    setPerms(nextPerms);
    toast.success("تم حذف الدور");
  };

  return (
    <div>
      <PageHeader
        title="الأدوار والصلاحيات"
        description="إدارة الأدوار وتحديد الصفحات المسموح بها لكل دور"
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setAddOpen(true)}><Plus className="h-4 w-4 ml-2" />إضافة دور</Button>
            <Button onClick={savePerms}><Save className="h-4 w-4 ml-2" />حفظ الصلاحيات</Button>
          </div>
        }
      />

      <div className="bg-card border border-border rounded-lg p-4 mb-5 text-sm text-muted-foreground flex items-start gap-2">
        <ShieldCheck className="h-4 w-4 mt-0.5 text-primary shrink-0" />
        <p>
          الأدوار الافتراضية (مدير الجهة، مشرف، مراقب) لا يمكن حذفها. إذا لم تُحدَّد صلاحيات لدور، يستخدم النظام السلوك الافتراضي للأدوار الأساسية.
          الأدوار المخصصة بدون صلاحيات لن ترى أي صفحة حتى تُحدَّد لها صفحات مسموح بها.
        </p>
      </div>

      {loading ? (
        <p className="text-sm text-muted-foreground">جارٍ التحميل...</p>
      ) : (
        <div className="space-y-5">
          {allRoles.map(role => {
            const allowed = perms[role.key] || [];
            const isAll = allowed.length === ALL_PAGES.length;
            return (
              <div key={role.key} className="bg-card border border-border rounded-lg p-5">
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                      <ShieldCheck className="h-4 w-4" />
                    </div>
                    <div>
                      <h3 className="font-bold text-foreground">{role.label}</h3>
                      <p className="text-xs text-muted-foreground">
                        المعرّف: <code dir="ltr">{role.key}</code>
                        {role.builtin && <span className="mr-2 text-warning">(افتراضي)</span>}
                        <span className="mr-2">— عدد المستخدمين: {usageCounts[role.key] || 0}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => setAllForRole(role.key, !isAll)}>
                      {isAll ? "إلغاء الكل" : "تحديد الكل"}
                    </Button>
                    {!role.builtin && (
                      <>
                        <Button size="sm" variant="ghost" onClick={() => { setEditing({ ...role }); setEditOpen(true); }}>
                          <Pencil className="h-3.5 w-3.5 ml-1" />تعديل
                        </Button>
                        <Button size="sm" variant="ghost" className="text-destructive" onClick={() => handleDeleteRole(role)}>
                          <Trash2 className="h-3.5 w-3.5 ml-1" />حذف
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                  {ALL_PAGES.map(page => {
                    const checked = allowed.includes(page.path);
                    return (
                      <label key={page.path} className="flex items-center gap-2 p-2 rounded-md border border-border hover:bg-muted/50 cursor-pointer">
                        <Checkbox checked={checked} onCheckedChange={() => togglePath(role.key, page.path)} />
                        <div className="text-xs">
                          <div className="font-medium text-foreground">{page.label}</div>
                          <code className="text-[10px] text-muted-foreground" dir="ltr">{page.path}</code>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add role dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>إضافة دور جديد</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>الاسم العربي</Label>
              <Input
                className="mt-1.5"
                placeholder="مثل: قائد فريق"
                value={newRole.label}
                onChange={e => {
                  const label = e.target.value;
                  setNewRole(prev => ({
                    ...prev,
                    label,
                    key: prev.keyTouched ? prev.key : slugifyRoleKey(label),
                  }));
                }}
              />
            </div>
            <div>
              <Label>المعرّف الإنجليزي (تلقائي وقابل للتعديل)</Label>
              <Input
                className="mt-1.5"
                dir="ltr"
                placeholder="e.g. team_lead"
                value={newRole.key}
                onChange={e => setNewRole(prev => ({ ...prev, key: e.target.value, keyTouched: true }))}
              />
              <p className="text-[11px] text-muted-foreground mt-1">يُستخدم كقيمة role الفعلية للمستخدمين — أحرف إنجليزية وأرقام و _ فقط</p>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={handleAddRole}>إضافة</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit role dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>تعديل الدور</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-4">
              <div>
                <Label>المعرّف</Label>
                <Input className="mt-1.5" dir="ltr" value={editing.key} disabled />
              </div>
              <div>
                <Label>الاسم العربي</Label>
                <Input className="mt-1.5" value={editing.label} onChange={e => setEditing({ ...editing, label: e.target.value })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={handleEditRole}>حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RolesPermissions;
