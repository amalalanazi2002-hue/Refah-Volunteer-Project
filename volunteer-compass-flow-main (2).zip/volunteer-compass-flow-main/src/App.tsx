import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate, useLocation } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { RoleProvider, useRole } from "@/contexts/RoleContext";
import { ThemeProvider } from "@/components/ThemeProvider";
import ProtectedRoute from "@/components/ProtectedRoute";
import AppLayout from "@/components/layout/AppLayout";
import VolunteerLayout from "@/components/layout/VolunteerLayout";
import Index from "@/pages/Index";
import Login from "@/pages/Login";
import ForgotPassword from "@/pages/ForgotPassword";
import ResetPassword from "@/pages/ResetPassword";
import Dashboard from "@/pages/Dashboard";
import Volunteers from "@/pages/Volunteers";
import Opportunities from "@/pages/Opportunities";
import Participations from "@/pages/Participations";
import Proofs from "@/pages/Proofs";
import Hours from "@/pages/Hours";
import InternalUsers from "@/pages/InternalUsers";
import RolesPermissions from "@/pages/RolesPermissions";
import Reports from "@/pages/Reports";
import Integrations from "@/pages/Integrations";
import ApiKeysPage from "@/pages/ApiKeys";
import SettingsPage from "@/pages/Settings";
import NotificationsPage from "@/pages/Notifications";
import BroadcastNotifications from "@/pages/BroadcastNotifications";
import SupportTickets from "@/pages/SupportTickets";
import ProfileChangeRequests from "@/pages/ProfileChangeRequests";
import CertificateTemplates from "@/pages/CertificateTemplates";
import IssuedCertificates from "@/pages/IssuedCertificates";
import MyProfile from "@/pages/volunteer/MyProfile";
import MyParticipations from "@/pages/volunteer/MyParticipations";
import MyProofs from "@/pages/volunteer/MyProofs";
import MyHours from "@/pages/volunteer/MyHours";
import MyOpportunities from "@/pages/volunteer/MyOpportunities";
import MyTickets from "@/pages/volunteer/MyTickets";
import MyCertificates from "@/pages/volunteer/MyCertificates";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const internalRoles = ["director", "supervisor", "observer"];
void internalRoles;

const AuthRedirect = () => {
  const { session, loading } = useRole();
  if (loading) return <div className="min-h-screen bg-background flex items-center justify-center"><p className="text-muted-foreground text-sm">جارٍ التحميل...</p></div>;
  if (!session) return <Login />;
  return <Login />;
};

// Global guard: whenever the user is in recovery mode, force them to the
// reset-password page no matter which route they try to view. This blocks
// auto-login on landing/login/public pages right after the recovery email
// click — they MUST set a new password first.
const RecoveryGuard = ({ children }: { children: React.ReactNode }) => {
  const { recoveryMode } = useRole();
  const location = useLocation();
  if (recoveryMode && location.pathname !== "/reset-password") {
    return <Navigate to="/reset-password" replace />;
  }
  return <>{children}</>;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <TooltipProvider>
        <RoleProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <RecoveryGuard>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<AuthRedirect />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />

            {/* Internal users routes */}
            <Route element={
              <ProtectedRoute internalOnly>
                <AppLayout />
              </ProtectedRoute>
            }>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/volunteers" element={<Volunteers />} />
              <Route path="/opportunities" element={<Opportunities />} />
              <Route path="/participations" element={<Participations />} />
              <Route path="/proofs" element={<Proofs />} />
              <Route path="/hours" element={<Hours />} />
              <Route path="/notifications" element={<NotificationsPage />} />
              <Route path="/broadcast-notifications" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <BroadcastNotifications />
                </ProtectedRoute>
              } />
              <Route path="/support-tickets" element={
                <ProtectedRoute allowedRoles={["director", "supervisor"]}>
                  <SupportTickets />
                </ProtectedRoute>
              } />
              <Route path="/profile-changes" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <ProfileChangeRequests />
                </ProtectedRoute>
              } />
              <Route path="/certificate-templates" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <CertificateTemplates />
                </ProtectedRoute>
              } />
              <Route path="/issued-certificates" element={
                <ProtectedRoute allowedRoles={["director", "supervisor"]}>
                  <IssuedCertificates />
                </ProtectedRoute>
              } />
              <Route path="/users" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <InternalUsers />
                </ProtectedRoute>
              } />
              <Route path="/users/roles" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <RolesPermissions />
                </ProtectedRoute>
              } />
              <Route path="/reports" element={
                <ProtectedRoute allowedRoles={["director", "observer"]}>
                  <Reports />
                </ProtectedRoute>
              } />
              <Route path="/integrations" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <Integrations />
                </ProtectedRoute>
              } />
              <Route path="/api-keys" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <ApiKeysPage />
                </ProtectedRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute allowedRoles={["director"]}>
                  <SettingsPage />
                </ProtectedRoute>
              } />
            </Route>

            {/* Volunteer routes */}
            <Route element={
              <ProtectedRoute allowedRoles={["volunteer"]}>
                <VolunteerLayout />
              </ProtectedRoute>
            }>
              <Route path="/volunteer" element={<MyProfile />} />
              <Route path="/volunteer/opportunities" element={<MyOpportunities />} />
              <Route path="/volunteer/participations" element={<MyParticipations />} />
              <Route path="/volunteer/proofs" element={<MyProofs />} />
              <Route path="/volunteer/hours" element={<MyHours />} />
              <Route path="/volunteer/certificates" element={<MyCertificates />} />
              <Route path="/volunteer/tickets" element={<MyTickets />} />
              <Route path="/volunteer/notifications" element={<NotificationsPage />} />
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
          </RecoveryGuard>
        </BrowserRouter>
      </RoleProvider>
    </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
