-- دالة فحص تكرار بيانات المتطوع (تعمل للمستخدم المجهول)
-- يجب تنفيذ هذا في Supabase SQL Editor

-- حذف النسخة القديمة إن وجدت
DROP FUNCTION IF EXISTS public.check_volunteer_duplicate(text, text, text);

CREATE OR REPLACE FUNCTION public.check_volunteer_duplicate(
  p_mobile text,
  p_national_id text,
  p_email text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb := '{}';
BEGIN
  -- فحص جدول المتطوعين
  IF EXISTS (SELECT 1 FROM volunteers WHERE mobile = p_mobile) THEN
    result := result || '{"mobile": true}';
  END IF;
  IF EXISTS (SELECT 1 FROM volunteers WHERE national_id = p_national_id) THEN
    result := result || '{"national_id": true}';
  END IF;
  IF p_email IS NOT NULL AND p_email != '' AND EXISTS (SELECT 1 FROM volunteers WHERE email = p_email) THEN
    result := result || '{"email": true}';
  END IF;

  -- فحص طلبات التسجيل (pending + approved)
  IF NOT (result ? 'mobile') AND EXISTS (SELECT 1 FROM volunteer_registrations WHERE mobile = p_mobile AND status IN ('pending', 'approved')) THEN
    result := result || '{"mobile": true}';
  END IF;
  IF NOT (result ? 'national_id') AND EXISTS (SELECT 1 FROM volunteer_registrations WHERE national_id = p_national_id AND status IN ('pending', 'approved')) THEN
    result := result || '{"national_id": true}';
  END IF;
  IF p_email IS NOT NULL AND p_email != '' AND NOT (result ? 'email') AND EXISTS (SELECT 1 FROM volunteer_registrations WHERE email = p_email AND status IN ('pending', 'approved')) THEN
    result := result || '{"email": true}';
  END IF;

  RETURN result;
END;
$$;

-- السماح للمستخدم المجهول باستدعاء الدالة
GRANT EXECUTE ON FUNCTION public.check_volunteer_duplicate(text, text, text) TO anon;
GRANT EXECUTE ON FUNCTION public.check_volunteer_duplicate(text, text, text) TO authenticated;

-- ============================================================
-- دالة استيراد متطوعين (تفحص التكرار قبل الإدخال)
-- ============================================================
DROP FUNCTION IF EXISTS public.import_volunteers(jsonb);

CREATE OR REPLACE FUNCTION public.import_volunteers(p_rows jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  row_data jsonb;
  v_mobile text;
  v_national_id text;
  v_email text;
  v_full_name text;
  v_city text;
  accepted int := 0;
  rejected int := 0;
  errors jsonb := '[]'::jsonb;
  i int := 0;
  dup_field text;
BEGIN
  FOR row_data IN SELECT * FROM jsonb_array_elements(p_rows) LOOP
    i := i + 1;
    v_full_name := trim(row_data->>'full_name');
    v_mobile := trim(row_data->>'mobile');
    v_national_id := trim(row_data->>'national_id');
    v_email := trim(COALESCE(row_data->>'email', ''));
    v_city := trim(COALESCE(row_data->>'city', ''));

    dup_field := NULL;

    -- التحقق من الحقول المطلوبة
    IF v_full_name IS NULL OR v_full_name = '' THEN
      rejected := rejected + 1;
      errors := errors || jsonb_build_object('row', i, 'reason', 'الاسم الكامل مطلوب');
      CONTINUE;
    END IF;
    IF v_mobile IS NULL OR v_mobile = '' THEN
      rejected := rejected + 1;
      errors := errors || jsonb_build_object('row', i, 'reason', 'رقم الجوال مطلوب');
      CONTINUE;
    END IF;
    IF v_national_id IS NULL OR v_national_id = '' THEN
      rejected := rejected + 1;
      errors := errors || jsonb_build_object('row', i, 'reason', 'رقم الهوية مطلوب');
      CONTINUE;
    END IF;

    -- فحص التكرار
    IF EXISTS (SELECT 1 FROM volunteers WHERE mobile = v_mobile) OR EXISTS (SELECT 1 FROM volunteer_registrations WHERE mobile = v_mobile AND status IN ('pending','approved')) THEN
      dup_field := 'رقم الجوال مكرر';
    ELSIF EXISTS (SELECT 1 FROM volunteers WHERE national_id = v_national_id) OR EXISTS (SELECT 1 FROM volunteer_registrations WHERE national_id = v_national_id AND status IN ('pending','approved')) THEN
      dup_field := 'رقم الهوية مكرر';
    ELSIF v_email != '' AND (EXISTS (SELECT 1 FROM volunteers WHERE email = v_email) OR EXISTS (SELECT 1 FROM volunteer_registrations WHERE email = v_email AND status IN ('pending','approved'))) THEN
      dup_field := 'البريد الإلكتروني مكرر';
    END IF;

    IF dup_field IS NOT NULL THEN
      rejected := rejected + 1;
      errors := errors || jsonb_build_object('row', i, 'name', v_full_name, 'reason', dup_field);
      CONTINUE;
    END IF;

    -- إدخال المتطوع
    BEGIN
      INSERT INTO volunteers (full_name, mobile, national_id, email, city, status)
      VALUES (v_full_name, v_mobile, v_national_id, NULLIF(v_email, ''), NULLIF(v_city, ''), 'active');
      accepted := accepted + 1;
    EXCEPTION WHEN unique_violation THEN
      rejected := rejected + 1;
      errors := errors || jsonb_build_object('row', i, 'name', v_full_name, 'reason', 'بيانات مكررة في قاعدة البيانات');
    END;
  END LOOP;

  RETURN jsonb_build_object('accepted', accepted, 'rejected', rejected, 'errors', errors);
END;
$$;

GRANT EXECUTE ON FUNCTION public.import_volunteers(jsonb) TO authenticated;

-- ============================================================
-- دالة تعديل كلمة مرور مستخدم (للمدير فقط)
-- ============================================================
DROP FUNCTION IF EXISTS public.admin_update_user_password(uuid, text);

CREATE OR REPLACE FUNCTION public.admin_update_user_password(
  p_auth_id uuid,
  p_new_password text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, extensions
AS $$
DECLARE
  caller_role text;
BEGIN
  -- التحقق من أن المستدعي مدير
  SELECT role INTO caller_role
  FROM internal_users
  WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid())
    AND status = 'active';

  IF caller_role IS NULL OR caller_role != 'director' THEN
    RETURN jsonb_build_object('success', false, 'error', 'غير مصرح — المدير فقط');
  END IF;

  -- التحقق من وجود المستخدم
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = p_auth_id) THEN
    RETURN jsonb_build_object('success', false, 'error', 'المستخدم غير موجود في النظام');
  END IF;

  -- تحديث كلمة المرور
  UPDATE auth.users
  SET encrypted_password = extensions.crypt(p_new_password, extensions.gen_salt('bf'))
  WHERE id = p_auth_id;

  RETURN jsonb_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_update_user_password(uuid, text) TO authenticated;
