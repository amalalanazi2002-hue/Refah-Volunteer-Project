-- =========================================================
-- Fixes Round 3
-- شغّل هذا الملف كاملاً في Supabase SQL Editor
-- =========================================================

-- ---------------------------------------------------------
-- 1) إصلاح ticket_number المكرر
-- ---------------------------------------------------------

-- 1.a) إنشاء sequence إذا لم تكن موجودة
CREATE SEQUENCE IF NOT EXISTS support_tickets_number_seq START 1;

-- 1.b) حذف أي trigger / function قديمين معطوبين
DROP TRIGGER IF EXISTS trg_support_tickets_set_number ON public.support_tickets;
DROP FUNCTION IF EXISTS public.set_support_ticket_number();

-- 1.c) إعادة تعبئة السجلات القديمة التي ينقصها ticket_number أو فيها قيم مكررة
WITH ranked AS (
  SELECT id,
         ROW_NUMBER() OVER (ORDER BY created_at, id) AS rn
  FROM public.support_tickets
)
UPDATE public.support_tickets t
SET ticket_number = 'TKT-' || LPAD(r.rn::text, 4, '0')
FROM ranked r
WHERE t.id = r.id;

-- 1.d) ضبط sequence على آخر رقم مستخدم
SELECT setval(
  'support_tickets_number_seq',
  GREATEST(
    1,
    COALESCE((SELECT MAX(NULLIF(regexp_replace(ticket_number, '\D', '', 'g'), '')::int) FROM public.support_tickets), 0)
  )
);

-- 1.e) دالة جديدة لتوليد رقم فريد من sequence
CREATE OR REPLACE FUNCTION public.set_support_ticket_number()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  next_num int;
BEGIN
  IF NEW.ticket_number IS NULL OR NEW.ticket_number = '' THEN
    next_num := nextval('support_tickets_number_seq');
    NEW.ticket_number := 'TKT-' || LPAD(next_num::text, 4, '0');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_support_tickets_set_number
BEFORE INSERT ON public.support_tickets
FOR EACH ROW EXECUTE FUNCTION public.set_support_ticket_number();

-- 1.f) فهرس فريد بدل الفهرس القديم لو كان مكسوراً
DROP INDEX IF EXISTS idx_support_tickets_ticket_number;
CREATE UNIQUE INDEX idx_support_tickets_ticket_number
  ON public.support_tickets(ticket_number);

-- ---------------------------------------------------------
-- 2) ضمان عدم تكرار participations لنفس متطوع/فرصة
-- ---------------------------------------------------------
-- نظف أي تكرارات سابقة إن وُجدت
DELETE FROM public.participations
WHERE id NOT IN (
  SELECT DISTINCT ON (volunteer_id, opportunity_id) id
  FROM public.participations
  ORDER BY volunteer_id, opportunity_id, created_at NULLS LAST
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_participations_volunteer_opportunity
  ON public.participations(volunteer_id, opportunity_id);

-- ---------------------------------------------------------
-- 3) timezone في system_settings (إن لم يكن موجوداً)
-- ---------------------------------------------------------
INSERT INTO public.system_settings (key, value)
VALUES ('timezone', '"Asia/Riyadh"')
ON CONFLICT (key) DO NOTHING;
