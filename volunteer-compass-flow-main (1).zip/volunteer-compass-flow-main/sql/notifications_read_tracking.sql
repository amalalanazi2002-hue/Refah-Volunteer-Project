-- يضاف لجدول الإشعارات لدعم تتبع وقت القراءة ونوع الإجراء
-- شغّل هذا الملف يدويًا من Supabase SQL Editor (مرة واحدة فقط)

ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS read_at timestamptz,
  ADD COLUMN IF NOT EXISTS action_type text;

CREATE INDEX IF NOT EXISTS idx_notifications_related_entity
  ON public.notifications(related_entity_id);

-- استرجاع تلقائي لتاريخ القراءة عند التحديث
CREATE OR REPLACE FUNCTION public.set_notification_read_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.is_read = true AND (OLD.is_read = false OR OLD.is_read IS NULL) AND NEW.read_at IS NULL THEN
    NEW.read_at := now();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notifications_read_at ON public.notifications;
CREATE TRIGGER trg_notifications_read_at
  BEFORE UPDATE ON public.notifications
  FOR EACH ROW EXECUTE FUNCTION public.set_notification_read_at();
