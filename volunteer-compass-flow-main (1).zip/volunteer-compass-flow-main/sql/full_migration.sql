-- ============================================
-- Full Migration: All 7 Features
-- Run this in Supabase SQL Editor
-- ============================================

-- ============================================
-- 1) Clean duplicate participations + unique index
-- ============================================

-- Delete duplicates keeping the oldest record
DELETE FROM participations
WHERE id NOT IN (
  SELECT DISTINCT ON (volunteer_id, opportunity_id) id
  FROM participations
  ORDER BY volunteer_id, opportunity_id, created_at ASC
);

-- Create unique index to prevent future duplicates
CREATE UNIQUE INDEX IF NOT EXISTS idx_participations_volunteer_opportunity
ON participations(volunteer_id, opportunity_id);

-- ============================================
-- 2) Ensure opportunities has proper timestamp columns
-- (start_at and end_at should already exist, but ensure they're timestamptz)
-- ============================================

-- These columns likely already exist. If they're date type, alter them:
-- ALTER TABLE opportunities ALTER COLUMN start_at TYPE timestamptz USING start_at::timestamptz;
-- ALTER TABLE opportunities ALTER COLUMN end_at TYPE timestamptz USING end_at::timestamptz;

-- ============================================
-- 3) Volunteer profile change requests
-- ============================================

CREATE TABLE IF NOT EXISTS volunteer_profile_change_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  volunteer_id uuid NOT NULL REFERENCES volunteers(id) ON DELETE CASCADE,
  changes jsonb NOT NULL, -- {"full_name": "new name", "mobile": "new phone", ...}
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  review_note text,
  reviewed_by uuid REFERENCES internal_users(id),
  reviewed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_profile_change_requests_status ON volunteer_profile_change_requests(status);
CREATE INDEX IF NOT EXISTS idx_profile_change_requests_volunteer ON volunteer_profile_change_requests(volunteer_id);

ALTER TABLE volunteer_profile_change_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Volunteers can view own change requests"
ON volunteer_profile_change_requests FOR SELECT TO authenticated USING (true);

CREATE POLICY "Volunteers can insert own change requests"
ON volunteer_profile_change_requests FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Internal users can update change requests"
ON volunteer_profile_change_requests FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- ============================================
-- 4) Support tickets system
-- ============================================

CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  volunteer_id uuid NOT NULL REFERENCES volunteers(id) ON DELETE CASCADE,
  title text NOT NULL,
  category text NOT NULL DEFAULT 'general' CHECK (category IN ('general', 'technical', 'account', 'opportunity', 'hours', 'other')),
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'waiting_reply', 'closed')),
  assigned_to uuid REFERENCES internal_users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS support_ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  sender_type text NOT NULL CHECK (sender_type IN ('volunteer', 'admin')),
  sender_name text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_support_tickets_status ON support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_support_tickets_volunteer ON support_tickets(volunteer_id);
CREATE INDEX IF NOT EXISTS idx_support_ticket_messages_ticket ON support_ticket_messages(ticket_id);

ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_ticket_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read tickets" ON support_tickets FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert tickets" ON support_tickets FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated can update tickets" ON support_tickets FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated can read messages" ON support_ticket_messages FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert messages" ON support_ticket_messages FOR INSERT TO authenticated WITH CHECK (true);

-- ============================================
-- 5) Certificate system
-- ============================================

CREATE TABLE IF NOT EXISTS certificate_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  design_config jsonb NOT NULL DEFAULT '{}', -- stores colors, layout, etc.
  is_active boolean DEFAULT true,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS generated_certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  volunteer_id uuid NOT NULL REFERENCES volunteers(id) ON DELETE CASCADE,
  participation_id uuid NOT NULL REFERENCES participations(id) ON DELETE CASCADE,
  opportunity_id uuid NOT NULL REFERENCES opportunities(id) ON DELETE CASCADE,
  template_id uuid REFERENCES certificate_templates(id),
  certificate_number text NOT NULL,
  volunteer_name text NOT NULL,
  opportunity_title text NOT NULL,
  approved_hours numeric NOT NULL DEFAULT 0,
  department_name text,
  completion_date date,
  issued_at timestamptz DEFAULT now(),
  UNIQUE(participation_id)
);

CREATE INDEX IF NOT EXISTS idx_generated_certificates_volunteer ON generated_certificates(volunteer_id);
CREATE INDEX IF NOT EXISTS idx_generated_certificates_participation ON generated_certificates(participation_id);

ALTER TABLE certificate_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE generated_certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read templates" ON certificate_templates FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can manage templates" ON certificate_templates FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated can read certificates" ON generated_certificates FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert certificates" ON generated_certificates FOR INSERT TO authenticated WITH CHECK (true);

-- Add certificate_template_id to opportunities
ALTER TABLE opportunities ADD COLUMN IF NOT EXISTS certificate_template_id uuid REFERENCES certificate_templates(id);
ALTER TABLE opportunities ADD COLUMN IF NOT EXISTS enable_certificate boolean DEFAULT false;

-- Add enable_certificates to system_settings if not exists
INSERT INTO system_settings (key, value)
VALUES ('enable_certificates', 'true')
ON CONFLICT (key) DO NOTHING;

-- Insert a default certificate template
INSERT INTO certificate_templates (name, description, is_active, is_default, design_config)
VALUES (
  'القالب الافتراضي',
  'قالب الشهادة الافتراضي للمنصة',
  true,
  true,
  '{"bg_color": "#F6F3F8", "border_color": "#5E4EA2", "text_color": "#1A1A2E", "accent_color": "#A86DA8", "layout": "classic"}'
) ON CONFLICT DO NOTHING;
