-- =============================================
-- RLS policies for integration tables
-- Only director can manage these tables
-- Uses internal_users table to verify role
-- =============================================

-- 1) Security definer function to check director role by auth email
CREATE OR REPLACE FUNCTION public.is_director()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.internal_users
    WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid())
      AND role = 'director'
      AND status = 'active'
  )
$$;

-- =============================================
-- integration_configs
-- =============================================
ALTER TABLE public.integration_configs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Director can select integration_configs" ON public.integration_configs;
CREATE POLICY "Director can select integration_configs"
  ON public.integration_configs FOR SELECT
  TO authenticated
  USING (public.is_director());

DROP POLICY IF EXISTS "Director can insert integration_configs" ON public.integration_configs;
CREATE POLICY "Director can insert integration_configs"
  ON public.integration_configs FOR INSERT
  TO authenticated
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can update integration_configs" ON public.integration_configs;
CREATE POLICY "Director can update integration_configs"
  ON public.integration_configs FOR UPDATE
  TO authenticated
  USING (public.is_director())
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can delete integration_configs" ON public.integration_configs;
CREATE POLICY "Director can delete integration_configs"
  ON public.integration_configs FOR DELETE
  TO authenticated
  USING (public.is_director());

-- =============================================
-- message_templates
-- =============================================
ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Director can select message_templates" ON public.message_templates;
CREATE POLICY "Director can select message_templates"
  ON public.message_templates FOR SELECT
  TO authenticated
  USING (public.is_director());

DROP POLICY IF EXISTS "Director can insert message_templates" ON public.message_templates;
CREATE POLICY "Director can insert message_templates"
  ON public.message_templates FOR INSERT
  TO authenticated
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can update message_templates" ON public.message_templates;
CREATE POLICY "Director can update message_templates"
  ON public.message_templates FOR UPDATE
  TO authenticated
  USING (public.is_director())
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can delete message_templates" ON public.message_templates;
CREATE POLICY "Director can delete message_templates"
  ON public.message_templates FOR DELETE
  TO authenticated
  USING (public.is_director());

-- =============================================
-- api_keys
-- =============================================
ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Director can select api_keys" ON public.api_keys;
CREATE POLICY "Director can select api_keys"
  ON public.api_keys FOR SELECT
  TO authenticated
  USING (public.is_director());

DROP POLICY IF EXISTS "Director can insert api_keys" ON public.api_keys;
CREATE POLICY "Director can insert api_keys"
  ON public.api_keys FOR INSERT
  TO authenticated
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can update api_keys" ON public.api_keys;
CREATE POLICY "Director can update api_keys"
  ON public.api_keys FOR UPDATE
  TO authenticated
  USING (public.is_director())
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can delete api_keys" ON public.api_keys;
CREATE POLICY "Director can delete api_keys"
  ON public.api_keys FOR DELETE
  TO authenticated
  USING (public.is_director());

-- =============================================
-- webhook_configs
-- =============================================
ALTER TABLE public.webhook_configs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Director can select webhook_configs" ON public.webhook_configs;
CREATE POLICY "Director can select webhook_configs"
  ON public.webhook_configs FOR SELECT
  TO authenticated
  USING (public.is_director());

DROP POLICY IF EXISTS "Director can insert webhook_configs" ON public.webhook_configs;
CREATE POLICY "Director can insert webhook_configs"
  ON public.webhook_configs FOR INSERT
  TO authenticated
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can update webhook_configs" ON public.webhook_configs;
CREATE POLICY "Director can update webhook_configs"
  ON public.webhook_configs FOR UPDATE
  TO authenticated
  USING (public.is_director())
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can delete webhook_configs" ON public.webhook_configs;
CREATE POLICY "Director can delete webhook_configs"
  ON public.webhook_configs FOR DELETE
  TO authenticated
  USING (public.is_director());

-- =============================================
-- integration_logs
-- =============================================
ALTER TABLE public.integration_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Director can select integration_logs" ON public.integration_logs;
CREATE POLICY "Director can select integration_logs"
  ON public.integration_logs FOR SELECT
  TO authenticated
  USING (public.is_director());

DROP POLICY IF EXISTS "Director can insert integration_logs" ON public.integration_logs;
CREATE POLICY "Director can insert integration_logs"
  ON public.integration_logs FOR INSERT
  TO authenticated
  WITH CHECK (public.is_director());

-- =============================================
-- dns_records
-- =============================================
ALTER TABLE public.dns_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Director can select dns_records" ON public.dns_records;
CREATE POLICY "Director can select dns_records"
  ON public.dns_records FOR SELECT
  TO authenticated
  USING (public.is_director());

DROP POLICY IF EXISTS "Director can insert dns_records" ON public.dns_records;
CREATE POLICY "Director can insert dns_records"
  ON public.dns_records FOR INSERT
  TO authenticated
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can update dns_records" ON public.dns_records;
CREATE POLICY "Director can update dns_records"
  ON public.dns_records FOR UPDATE
  TO authenticated
  USING (public.is_director())
  WITH CHECK (public.is_director());

DROP POLICY IF EXISTS "Director can delete dns_records" ON public.dns_records;
CREATE POLICY "Director can delete dns_records"
  ON public.dns_records FOR DELETE
  TO authenticated
  USING (public.is_director());
