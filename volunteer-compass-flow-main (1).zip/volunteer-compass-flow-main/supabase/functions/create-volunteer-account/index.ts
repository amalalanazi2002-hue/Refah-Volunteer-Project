// deno-lint-ignore-file no-explicit-any
// Edge Function: create-volunteer-account
//
// Creates (or links) an auth user for an existing volunteer record.
// - Requires the caller to be authenticated as an admin/director.
// - Uses the Supabase service role to call the Auth Admin API.
// - On success, sets `volunteers.auth_id = <new user id>` and returns a
//   generated random password to the caller (so the dashboard can offer to
//   send it to the volunteer via SMS/Email).
//
// Required secrets (set via Supabase project settings):
//   SUPABASE_URL                 (auto)
//   SUPABASE_SERVICE_ROLE_KEY    (must be added)
//   SUPABASE_ANON_KEY            (auto)
//
// Request body: { volunteer_id: string }
// Response:     { ok, auth_id, email, password, already_linked? , error? }

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (status: number, body: any) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

function genPassword(len = 14): string {
  const lowers = "abcdefghijkmnopqrstuvwxyz";
  const uppers = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const digits = "23456789";
  const symbols = "!@#$%*?";
  const all = lowers + uppers + digits + symbols;
  const buf = new Uint32Array(len);
  crypto.getRandomValues(buf);
  let out = "";
  // ensure at least one of each class
  out += lowers[buf[0] % lowers.length];
  out += uppers[buf[1] % uppers.length];
  out += digits[buf[2] % digits.length];
  out += symbols[buf[3] % symbols.length];
  for (let i = 4; i < len; i++) out += all[buf[i] % all.length];
  // shuffle
  return out.split("").sort(() => 0.5 - Math.random()).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { ok: false, error: "method_not_allowed" });

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
  if (!SERVICE_ROLE) {
    return json(500, { ok: false, error: "missing_service_role_secret" });
  }

  // Verify caller is an authenticated admin/director.
  const authHeader = req.headers.get("authorization") || "";
  const userClient = createClient(SUPABASE_URL, ANON, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) {
    return json(401, { ok: false, error: "unauthorized" });
  }

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

  // Role check (best-effort: look in internal_users by auth_id OR by email)
  let roleRow: any = null;
  const { data: byAuth } = await admin
    .from("internal_users")
    .select("role, status")
    .eq("auth_id", userData.user.id)
    .maybeSingle();
  roleRow = byAuth;
  if (!roleRow && userData.user.email) {
    const { data: byEmail } = await admin
      .from("internal_users")
      .select("role, status")
      .eq("email", userData.user.email)
      .maybeSingle();
    roleRow = byEmail;
  }
  const role = roleRow?.role;
  const status = roleRow?.status;
  if (!roleRow || (status && status !== "active") || !["director", "admin", "manager", "supervisor"].includes(role)) {
    return json(403, { ok: false, error: "forbidden_not_admin", debug: { role, status, found: !!roleRow } });
  }

  let body: any = {};
  try { body = await req.json(); } catch { /* ignore */ }
  const volunteer_id = body?.volunteer_id;
  if (!volunteer_id || typeof volunteer_id !== "string") {
    return json(400, { ok: false, error: "missing_volunteer_id" });
  }

  // Load volunteer
  const { data: vol, error: volErr } = await admin
    .from("volunteers")
    .select("id, full_name, email, mobile, auth_id")
    .eq("id", volunteer_id)
    .maybeSingle();
  if (volErr || !vol) return json(404, { ok: false, error: "volunteer_not_found" });
  if (vol.auth_id) {
    return json(200, { ok: false, already_linked: true, error: "already_linked", auth_id: vol.auth_id, email: vol.email });
  }
  if (!vol.email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(vol.email)) {
    return json(400, { ok: false, error: "invalid_or_missing_email" });
  }

  // If a user with this email already exists, link it instead of creating
  // a duplicate (the Admin API throws on duplicate email).
  const password = genPassword(14);
  let authUserId: string | null = null;

  const { data: created, error: createErr } = await admin.auth.admin.createUser({
    email: vol.email,
    password,
    email_confirm: true,
    user_metadata: { full_name: vol.full_name, volunteer_id: vol.id },
  });

  if (createErr) {
    const msg = String(createErr.message || "").toLowerCase();
    if (msg.includes("already") || msg.includes("registered") || msg.includes("exists")) {
      // Try to find the existing user by email via listUsers (paged, simple scan)
      // For small projects this is fine; for large, switch to a dedicated lookup.
      const { data: list } = await admin.auth.admin.listUsers({ page: 1, perPage: 200 });
      const existing = list?.users?.find((u: any) => (u.email || "").toLowerCase() === vol.email!.toLowerCase());
      if (existing) {
        authUserId = existing.id;
      } else {
        return json(409, { ok: false, error: "email_exists_but_user_not_found" });
      }
    } else {
      return json(500, { ok: false, error: createErr.message });
    }
  } else {
    authUserId = created?.user?.id || null;
  }

  if (!authUserId) return json(500, { ok: false, error: "auth_user_creation_failed" });

  const { error: linkErr } = await admin
    .from("volunteers")
    .update({ auth_id: authUserId })
    .eq("id", volunteer_id);
  if (linkErr) return json(500, { ok: false, error: `link_failed: ${linkErr.message}` });

  return json(200, {
    ok: true,
    auth_id: authUserId,
    email: vol.email,
    password,
    linked_existing: !created?.user,
  });
});
