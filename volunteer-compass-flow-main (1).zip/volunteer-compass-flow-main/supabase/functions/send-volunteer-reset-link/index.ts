// Edge Function: send-volunteer-reset-link
//
// Generates a Supabase Auth recovery link for a linked volunteer account and
// dispatches it via the existing message channels (email / sms). The recovient
// MUST set a new password before they can sign in — we use the standard
// `recovery` link type which lands the user on /reset-password where the
// frontend forces a password update.
//
// Caller must be an authenticated admin/director (verified via internal_users).
// Requires SUPABASE_SERVICE_ROLE_KEY in function secrets.

// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (status: number, body: any) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { ok: false, error: "method_not_allowed" });

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
  const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!SERVICE_ROLE) return json(500, { ok: false, error: "missing_service_role_secret" });

  // Auth: require an admin caller
  const authHeader = req.headers.get("authorization") || "";
  const userClient = createClient(SUPABASE_URL, ANON, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) return json(401, { ok: false, error: "unauthorized" });

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

  // Role check
  let roleRow: any = null;
  const { data: byAuth } = await admin
    .from("internal_users")
    .select("role, status")
    .eq("auth_id", userData.user.id)
    .maybeSingle();
  roleRow = byAuth;
  if (!roleRow && userData.user.email) {
    const { data: byEmail } = await admin
      .from("internal_users")
      .select("role, status")
      .eq("email", userData.user.email)
      .maybeSingle();
    roleRow = byEmail;
  }
  const role = roleRow?.role;
  const status = roleRow?.status;
  if (!roleRow || (status && status !== "active") || !["director", "admin", "manager", "supervisor"].includes(role)) {
    return json(403, { ok: false, error: "forbidden_not_admin" });
  }

  let body: any = {};
  try { body = await req.json(); } catch { return json(400, { ok: false, error: "invalid_json" }); }
  const volunteer_id = String(body?.volunteer_id || "").trim();
  const channels: string[] = Array.isArray(body?.channels) ? body.channels : [];
  const redirect_origin = String(body?.redirect_origin || "").trim();

  if (!volunteer_id) return json(400, { ok: false, error: "missing_volunteer_id" });
  if (channels.length === 0) return json(400, { ok: false, error: "no_channel_selected" });
  if (!redirect_origin || !/^https?:\/\//.test(redirect_origin)) {
    return json(400, { ok: false, error: "invalid_redirect_origin" });
  }

  // Look up volunteer
  const { data: vol, error: volErr } = await admin
    .from("volunteers")
    .select("id, full_name, email, mobile, auth_id")
    .eq("id", volunteer_id)
    .maybeSingle();
  if (volErr || !vol) return json(404, { ok: false, error: "volunteer_not_found" });
  if (!vol.auth_id) return json(400, { ok: false, error: "volunteer_has_no_account" });
  if (!vol.email) return json(400, { ok: false, error: "volunteer_has_no_email" });

  // Generate a recovery link for the volunteer's email.
  // The redirectTo points to /reset-password where the frontend forces a new
  // password. Without setting a new password the user cannot sign in.
  const { data: linkData, error: linkErr } = await (admin.auth.admin as any).generateLink({
    type: "recovery",
    email: vol.email,
    options: { redirectTo: `${redirect_origin}/reset-password` },
  });
  if (linkErr) return json(500, { ok: false, error: `generate_link_failed: ${linkErr.message}` });
  const action_link: string | undefined =
    linkData?.properties?.action_link || linkData?.action_link;
  if (!action_link) return json(500, { ok: false, error: "no_action_link_returned" });

  // Dispatch through configured channels using the existing dispatch-message
  // function. We do NOT silently swallow errors — caller must see channel-level
  // results.
  const results: Array<{ channel: string; ok: boolean; error?: string }> = [];

  const sendVia = async (channel: "email" | "sms", to: string) => {
    const { data: cfg } = await admin
      .from("integration_configs")
      .select("provider, config, is_enabled")
      .eq("channel", channel)
      .eq("is_enabled", true)
      .limit(1)
      .maybeSingle();
    if (!cfg || !(cfg as any).provider) {
      results.push({ channel, ok: false, error: `قناة ${channel === "sms" ? "الرسائل النصية" : "البريد"} غير مفعّلة في صفحة التكاملات` });
      return;
    }
    const subject = "رابط تعيين كلمة مرور جديدة — منصة رفادة";
    const text = `مرحبًا ${vol.full_name}،\n\nاستخدم الرابط التالي لتعيين كلمة مرور جديدة لحسابك على منصة رفادة:\n${action_link}\n\nالرابط صالح لفترة محدودة. يجب تعيين كلمة مرور جديدة قبل الدخول.`;

    // Forward the caller's auth header so dispatch-message stays authenticated.
    const dispatchResp = await fetch(`${SUPABASE_URL}/functions/v1/dispatch-message`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: authHeader,
        apikey: ANON,
      },
      body: JSON.stringify({
        channel,
        provider: (cfg as any).provider,
        event: "send_password_reset_link",
        to,
        subject: channel === "email" ? subject : null,
        body: text,
        providerConfig: (cfg as any).config || null,
        templateId: null,
      }),
    });
    let payload: any = null;
    try { payload = await dispatchResp.json(); } catch { /* ignore */ }
    if (!dispatchResp.ok || !payload?.ok) {
      results.push({
        channel,
        ok: false,
        error: payload?.error || `HTTP ${dispatchResp.status}`,
      });
      return;
    }
    results.push({ channel, ok: true });
  };

  if (channels.includes("email")) await sendVia("email", vol.email);
  if (channels.includes("sms")) {
    if (!vol.mobile) results.push({ channel: "sms", ok: false, error: "لا يوجد رقم جوال للمتطوع" });
    else await sendVia("sms", vol.mobile);
  }

  const anyOk = results.some((r) => r.ok);
  return json(200, { ok: anyOk, results });
});
