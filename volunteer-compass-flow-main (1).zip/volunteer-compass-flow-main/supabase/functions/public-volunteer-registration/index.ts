// Edge Function: public-volunteer-registration
//
// Allows ANONYMOUS users (visitors of the public landing page) to submit a
// volunteer registration request without violating RLS on
// `volunteer_registrations`. We use the service role on the server and run
// minimal validation. NEVER call this from authenticated admin flows.
//
// Configured with verify_jwt = false in supabase/config.toml for public access.

// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (status: number, body: any) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { ok: false, error: "method_not_allowed" });

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!SERVICE_ROLE) return json(500, { ok: false, error: "missing_service_role_secret" });

  let body: any = {};
  try { body = await req.json(); } catch { return json(400, { ok: false, error: "invalid_json" }); }

  const full_name = String(body?.full_name || "").trim();
  const mobile = String(body?.mobile || "").trim();
  const email = body?.email ? String(body.email).trim() : null;
  const national_id = String(body?.national_id || "").trim();
  const city = body?.city ? String(body.city).trim() : null;

  if (!full_name || full_name.length < 3) return json(400, { ok: false, error: "invalid_full_name" });
  if (!/^\+?\d{8,15}$/.test(mobile.replace(/\s|-/g, ""))) return json(400, { ok: false, error: "invalid_mobile" });
  if (!/^\d{8,15}$/.test(national_id)) return json(400, { ok: false, error: "invalid_national_id" });
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json(400, { ok: false, error: "invalid_email" });

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

  const { data: inserted, error } = await admin
    .from("volunteer_registrations")
    .insert({
      full_name,
      mobile,
      email,
      national_id,
      city,
      status: "pending",
    })
    .select("id")
    .single();

  if (error) return json(400, { ok: false, error: error.message });
  return json(200, { ok: true, id: inserted?.id });
});
