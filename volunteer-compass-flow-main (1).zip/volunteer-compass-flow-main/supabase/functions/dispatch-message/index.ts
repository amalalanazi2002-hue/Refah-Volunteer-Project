/**
 * dispatch-message — Provider-agnostic message dispatcher.
 *
 * Receives a prepared payload from the frontend (already rendered with
 * variables substituted) and forwards it to the right provider based on
 * { channel, provider }. Logs the real outcome to integration_logs.
 *
 * Frontend contract:
 *   supabase.functions.invoke("dispatch-message", { body: {
 *     channel: "sms" | "whatsapp" | "email",
 *     provider: "4jawaly" | "sendpulse" | "google" | "microsoft" | "smtp" | "custom",
 *     event: string,                 // e.g. "application_approved"
 *     to: string,                    // phone or email
 *     subject?: string,              // email only
 *     body: string,                  // already-rendered message body
 *     providerConfig?: Record<string, unknown>,  // credentials from integration_configs
 *     templateId?: string,
 *   }})
 *
 * Returns: { ok: boolean, status: "success" | "failed", error?: string, providerResponse?: unknown }
 *
 * Adding a new provider = add a new branch in `sendViaProvider`. Nothing else.
 */

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface DispatchPayload {
  channel: "sms" | "whatsapp" | "email";
  provider: string;
  event: string;
  to: string;
  subject?: string;
  body: string;
  providerConfig?: Record<string, unknown>;
  templateId?: string;
}

// ---------------------------------------------------------------------------
// Provider implementations (each returns { ok, error?, response? })
// ---------------------------------------------------------------------------

async function sendVia4jawaly(p: DispatchPayload) {
  const cfg = p.providerConfig || {};
  const apiKey = (cfg.api_key as string) || Deno.env.get("FOURJAWALY_API_KEY");
  const apiSecret =
    (cfg.api_secret as string) || Deno.env.get("FOURJAWALY_API_SECRET");
  const sender =
    (cfg.sender_name as string) || Deno.env.get("FOURJAWALY_SENDER") || "";
  if (!apiKey || !apiSecret) return { ok: false, error: "missing 4jawaly credentials" };

  const auth = btoa(`${apiKey}:${apiSecret}`);
  const res = await fetch("https://api-sms.4jawaly.com/api/v1/account/area/sms/send", {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messages: [{ text: p.body, numbers: [p.to], sender }],
    }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { ok: false, error: `4jawaly ${res.status}: ${JSON.stringify(data)}`, response: data };
  return { ok: true, response: data };
}

async function sendViaSendPulse(p: DispatchPayload) {
  const cfg = p.providerConfig || {};
  const clientId = (cfg.client_id as string) || Deno.env.get("SENDPULSE_CLIENT_ID");
  const clientSecret =
    (cfg.client_secret as string) || Deno.env.get("SENDPULSE_CLIENT_SECRET");
  const botId = (cfg.bot_id as string) || Deno.env.get("SENDPULSE_BOT_ID");
  if (!clientId || !clientSecret || !botId)
    return { ok: false, error: "missing sendpulse credentials" };

  // 1. OAuth
  const tokenRes = await fetch("https://api.sendpulse.com/oauth/access_token", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });
  const tokenData = await tokenRes.json().catch(() => ({}));
  if (!tokenRes.ok || !tokenData.access_token)
    return { ok: false, error: `sendpulse oauth failed: ${JSON.stringify(tokenData)}` };

  // 2. Send WhatsApp message via bot
  const sendRes = await fetch("https://api.sendpulse.com/whatsapp/contacts/sendByPhone", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${tokenData.access_token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      bot_id: botId,
      phone: p.to,
      message: { type: "text", text: { body: p.body } },
    }),
  });
  const sendData = await sendRes.json().catch(() => ({}));
  if (!sendRes.ok)
    return { ok: false, error: `sendpulse send ${sendRes.status}: ${JSON.stringify(sendData)}`, response: sendData };
  return { ok: true, response: sendData };
}

async function sendViaGoogle(p: DispatchPayload) {
  const cfg = p.providerConfig || {};
  const clientId = (cfg.client_id as string) || Deno.env.get("GOOGLE_CLIENT_ID");
  const clientSecret =
    (cfg.client_secret as string) || Deno.env.get("GOOGLE_CLIENT_SECRET");
  const refreshToken =
    (cfg.refresh_token as string) || Deno.env.get("GOOGLE_REFRESH_TOKEN");
  const fromEmail = (cfg.from_email as string) || Deno.env.get("GOOGLE_FROM_EMAIL");
  const fromName = (cfg.from_name as string) || "";
  if (!clientId || !clientSecret || !refreshToken || !fromEmail)
    return { ok: false, error: "missing google credentials" };

  // 1. Refresh access token
  const params = new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
    grant_type: "refresh_token",
  });
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  const tokenData = await tokenRes.json().catch(() => ({}));
  if (!tokenRes.ok || !tokenData.access_token)
    return { ok: false, error: `google oauth failed: ${JSON.stringify(tokenData)}` };

  // 2. Build RFC 822 message
  const from = fromName ? `${fromName} <${fromEmail}>` : fromEmail;
  const subject = p.subject || "";
  const mime =
    `From: ${from}\r\n` +
    `To: ${p.to}\r\n` +
    `Subject: =?UTF-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=\r\n` +
    `MIME-Version: 1.0\r\n` +
    `Content-Type: text/plain; charset=UTF-8\r\n\r\n` +
    p.body;
  const raw = btoa(unescape(encodeURIComponent(mime)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

  const sendRes = await fetch(
    "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw }),
    }
  );
  const sendData = await sendRes.json().catch(() => ({}));
  if (!sendRes.ok)
    return { ok: false, error: `gmail send ${sendRes.status}: ${JSON.stringify(sendData)}`, response: sendData };
  return { ok: true, response: sendData };
}

async function sendViaMicrosoft(p: DispatchPayload) {
  const cfg = p.providerConfig || {};
  const tenantId = (cfg.tenant_id as string) || Deno.env.get("MS_TENANT_ID");
  const clientId = (cfg.client_id as string) || Deno.env.get("MS_CLIENT_ID");
  const clientSecret =
    (cfg.client_secret as string) || Deno.env.get("MS_CLIENT_SECRET");
  const fromEmail = (cfg.from_email as string) || Deno.env.get("MS_FROM_EMAIL");
  if (!tenantId || !clientId || !clientSecret || !fromEmail)
    return { ok: false, error: "missing microsoft credentials" };

  // 1. Client credentials token
  const params = new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    scope: "https://graph.microsoft.com/.default",
    grant_type: "client_credentials",
  });
  const tokenRes = await fetch(
    `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    }
  );
  const tokenData = await tokenRes.json().catch(() => ({}));
  if (!tokenRes.ok || !tokenData.access_token)
    return { ok: false, error: `microsoft oauth failed: ${JSON.stringify(tokenData)}` };

  // 2. Graph sendMail
  const sendRes = await fetch(
    `https://graph.microsoft.com/v1.0/users/${encodeURIComponent(fromEmail)}/sendMail`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: {
          subject: p.subject || "",
          body: { contentType: "Text", content: p.body },
          toRecipients: [{ emailAddress: { address: p.to } }],
        },
        saveToSentItems: true,
      }),
    }
  );
  if (!sendRes.ok) {
    const errText = await sendRes.text().catch(() => "");
    return { ok: false, error: `graph sendMail ${sendRes.status}: ${errText}` };
  }
  return { ok: true, response: { status: sendRes.status } };
}

async function sendViaProvider(p: DispatchPayload) {
  if (p.channel === "sms" && p.provider === "4jawaly") return sendVia4jawaly(p);
  if (p.channel === "whatsapp" && p.provider === "sendpulse") return sendViaSendPulse(p);
  if (p.channel === "email" && p.provider === "google") return sendViaGoogle(p);
  if (p.channel === "email" && p.provider === "microsoft") return sendViaMicrosoft(p);
  return { ok: false, error: `provider not implemented: ${p.channel}/${p.provider}` };
}

// ---------------------------------------------------------------------------
// HTTP handler
// ---------------------------------------------------------------------------

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

  // Auth check
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let payload: DispatchPayload;
  try {
    payload = (await req.json()) as DispatchPayload;
  } catch {
    return new Response(JSON.stringify({ error: "invalid json" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (!payload?.channel || !payload?.provider || !payload?.to || !payload?.body) {
    return new Response(
      JSON.stringify({ error: "missing required fields: channel, provider, to, body" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  // Use service role to write logs (bypass RLS), since this is server-side audit.
  const adminClient = createClient(supabaseUrl, serviceRole);

  let result: { ok: boolean; error?: string; response?: unknown };
  try {
    result = await sendViaProvider(payload);
  } catch (e) {
    result = { ok: false, error: e instanceof Error ? e.message : String(e) };
  }

  await adminClient.from("integration_logs").insert({
    channel: payload.channel,
    provider: payload.provider,
    event_type: payload.event,
    operation: "send",
    status: result.ok ? "success" : "failed",
    target: payload.to,
    error_message: result.ok ? null : (result.error || "unknown error").slice(0, 1000),
  });

  return new Response(
    JSON.stringify({
      ok: result.ok,
      status: result.ok ? "success" : "failed",
      error: result.ok ? undefined : result.error,
      providerResponse: result.response,
    }),
    {
      status: result.ok ? 200 : 502,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    }
  );
});
