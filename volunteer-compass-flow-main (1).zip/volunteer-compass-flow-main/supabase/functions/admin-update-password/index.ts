// Edge Function: admin-update-password
//
// Updates the password of an auth user via the Supabase Auth Admin API.
// Replaces the broken `admin_update_user_password` SQL RPC which relied on
// pgcrypto's gen_salt(), unavailable in the project.
//
// Caller must be an authenticated admin/director (verified via internal_users).
// Requires SUPABASE_SERVICE_ROLE_KEY in function secrets.

// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (status: number, body: any) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { success: false, error: "method_not_allowed" });

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
  const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!SERVICE_ROLE) return json(500, { success: false, error: "missing_service_role_secret" });

  const authHeader = req.headers.get("authorization") || "";
  const userClient = createClient(SUPABASE_URL, ANON, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) return json(401, { success: false, error: "unauthorized" });

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

  // Role check — look up by auth_id, fall back to email
  let roleRow: any = null;
  const { data: byAuth } = await admin
    .from("internal_users")
    .select("role, status")
    .eq("auth_id", userData.user.id)
    .maybeSingle();
  roleRow = byAuth;
  if (!roleRow && userData.user.email) {
    const { data: byEmail } = await admin
      .from("internal_users")
      .select("role, status")
      .eq("email", userData.user.email)
      .maybeSingle();
    roleRow = byEmail;
  }
  const role = roleRow?.role;
  const status = roleRow?.status;
  if (!roleRow || (status && status !== "active") || !["director", "admin", "manager", "supervisor"].includes(role)) {
    return json(403, { success: false, error: "forbidden_not_admin" });
  }

  let body: any = {};
  try { body = await req.json(); } catch { return json(400, { success: false, error: "invalid_json" }); }
  const auth_id = body?.p_auth_id || body?.auth_id;
  const password = body?.p_new_password || body?.new_password;

  if (!auth_id || typeof auth_id !== "string") return json(400, { success: false, error: "missing_auth_id" });
  if (!password || typeof password !== "string" || password.length < 6) {
    return json(400, { success: false, error: "password_too_short" });
  }

  const { error: updErr } = await admin.auth.admin.updateUserById(auth_id, { password });
  if (updErr) return json(500, { success: false, error: updErr.message });

  return json(200, { success: true });
});
