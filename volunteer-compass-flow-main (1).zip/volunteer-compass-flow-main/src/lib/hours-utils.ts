/**
 * Anomaly detection for volunteer hours.
 * A record is anomalous if approved_hours > 12 or < 0, or total_minutes > 720 or < 0.
 */

export const isAnomalousHours = (approvedHours: number): boolean =>
  approvedHours > 12 || approvedHours < 0;

export const isAnomalousMinutes = (totalMinutes: number): boolean =>
  totalMinutes > 720 || totalMinutes < 0;

export const roundHours = (hours: number): number =>
  Math.round(hours * 100) / 100;

// Statuses considered "not counted": reversed, cancelled, rejected.
// Anything else (approved, or rows with no/legacy status) counts if numeric value is sane.
const NON_COUNTED_STATUSES = new Set(["reversed", "cancelled", "rejected"]);

export const filterValidHours = (rows: any[]): any[] =>
  rows.filter(
    (r) =>
      !NON_COUNTED_STATUSES.has(String(r.status || "").toLowerCase()) &&
      !isAnomalousHours(Number(r.approved_hours))
  );

export const sumValidHours = (rows: any[]): number =>
  roundHours(filterValidHours(rows).reduce((s, r) => s + Number(r.approved_hours), 0));

export const countValidHours = (rows: any[]): number =>
  filterValidHours(rows).length;

export const avgValidHours = (rows: any[]): number => {
  const count = countValidHours(rows);
  return count > 0 ? roundHours(sumValidHours(rows) / count) : 0;
};
