import { supabase } from "@/integrations/supabase/client";

export type NotificationType =
  | "new_opportunity"
  | "opportunity_started"
  | "proof_approved"
  | "proof_rejected"
  | "proof_needs_completion"
  | "participation_started"
  | "participation_ended"
  | "application_submitted"
  | "application_approved"
  | "application_rejected";

export interface CreateNotificationParams {
  user_type: "internal" | "volunteer";
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  related_entity_type?: string;
  related_entity_id?: string;
  action_url?: string;
  action_label?: string;
  requires_action?: boolean;
}

export async function createNotification(params: CreateNotificationParams) {
  const { error } = await supabase.from("notifications").insert({
    user_type: params.user_type,
    user_id: params.user_id,
    title: params.title,
    message: params.message,
    type: params.type,
    related_entity_type: params.related_entity_type || null,
    related_entity_id: params.related_entity_id || null,
    is_read: false,
    action_url: params.action_url || null,
    action_label: params.action_label || null,
    requires_action: params.requires_action || false,
  });
  if (error) console.error("Notification error:", error);
}

/** Notify all active volunteers about a new opportunity */
export async function notifyNewOpportunity(opportunityTitle: string, opportunityId: string) {
  const { data: volunteers } = await supabase
    .from("volunteers")
    .select("id")
    .eq("status", "active");
  if (!volunteers) return;
  
  const notifications = volunteers.map((v) => ({
    user_type: "volunteer" as const,
    user_id: v.id,
    title: "فرصة تطوعية جديدة",
    message: `تم إضافة فرصة جديدة: ${opportunityTitle}`,
    type: "new_opportunity" as NotificationType,
    related_entity_type: "opportunity",
    related_entity_id: opportunityId,
    is_read: false,
    action_url: "/volunteer/opportunities",
    action_label: "عرض الفرص",
    requires_action: true,
  }));

  if (notifications.length > 0) {
    await supabase.from("notifications").insert(notifications);
  }
}

/** Notify volunteer when their participation starts */
export async function notifyParticipationStarted(
  volunteerId: string,
  opportunityTitle: string,
  participationId: string
) {
  await createNotification({
    user_type: "volunteer",
    user_id: volunteerId,
    title: "بدأت مشاركتك",
    message: `تم بدء مشاركتك في: ${opportunityTitle}`,
    type: "participation_started",
    related_entity_type: "participation",
    related_entity_id: participationId,
    action_url: "/volunteer/participations",
    action_label: "عرض مشاركاتي",
    requires_action: false,
  });
}

/** Notify volunteer when their participation ends */
export async function notifyParticipationEnded(
  volunteerId: string,
  opportunityTitle: string,
  participationId: string,
  totalMinutes: number
) {
  await createNotification({
    user_type: "volunteer",
    user_id: volunteerId,
    title: "انتهت مشاركتك",
    message: `انتهت مشاركتك في: ${opportunityTitle} — ${totalMinutes} دقيقة`,
    type: "participation_ended",
    related_entity_type: "participation",
    related_entity_id: participationId,
    action_url: "/volunteer/participations",
    action_label: "عرض مشاركاتي",
    requires_action: false,
  });
}

/** Notify volunteer about proof review decision */
export async function notifyProofDecision(
  volunteerId: string,
  opportunityTitle: string,
  proofId: string,
  decision: "approved" | "rejected" | "needs_completion"
) {
  const typeMap: Record<string, NotificationType> = {
    approved: "proof_approved",
    rejected: "proof_rejected",
    needs_completion: "proof_needs_completion",
  };
  const titleMap: Record<string, string> = {
    approved: "تم قبول إثباتك",
    rejected: "تم رفض إثباتك",
    needs_completion: "إثباتك يحتاج استكمال",
  };
  const msgMap: Record<string, string> = {
    approved: `تم قبول إثبات مشاركتك في: ${opportunityTitle}`,
    rejected: `تم رفض إثبات مشاركتك في: ${opportunityTitle}`,
    needs_completion: `إثبات مشاركتك في ${opportunityTitle} يحتاج استكمال`,
  };

  await createNotification({
    user_type: "volunteer",
    user_id: volunteerId,
    title: titleMap[decision],
    message: msgMap[decision],
    type: typeMap[decision],
    related_entity_type: "proof",
    related_entity_id: proofId,
    action_url: decision === "needs_completion" ? "/volunteer/proofs" : "/volunteer/hours",
    action_label: decision === "needs_completion" ? "استكمال الإثبات" : "عرض ساعاتي",
    requires_action: decision === "needs_completion",
  });
}

/** Notify supervisor/director about new proof submission */
export async function notifyInternalNewProof(
  volunteerName: string,
  opportunityTitle: string,
  proofId: string
) {
  const { data: internals } = await supabase
    .from("internal_users")
    .select("id")
    .in("role", ["director", "supervisor"])
    .eq("status", "active");
  if (!internals) return;

  const notifications = internals.map((u) => ({
    user_type: "internal" as const,
    user_id: u.id,
    title: "إثبات جديد",
    message: `قام ${volunteerName} برفع إثبات لمشاركته في: ${opportunityTitle}`,
    type: "proof_approved" as NotificationType,
    related_entity_type: "proof",
    related_entity_id: proofId,
    is_read: false,
    action_url: "/proofs",
    action_label: "مراجعة الإثبات",
    requires_action: true,
  }));

  if (notifications.length > 0) {
    await supabase.from("notifications").insert(notifications);
  }
}

/** Notify internal users about new application */
export async function notifyInternalNewApplication(
  volunteerName: string,
  opportunityTitle: string,
  applicationId: string
) {
  const { data: internals } = await supabase
    .from("internal_users")
    .select("id")
    .in("role", ["director", "supervisor"])
    .eq("status", "active");
  if (!internals) return;

  const notifications = internals.map((u) => ({
    user_type: "internal" as const,
    user_id: u.id,
    title: "طلب انضمام جديد",
    message: `تقدم ${volunteerName} بطلب انضمام لفرصة: ${opportunityTitle}`,
    type: "application_submitted" as NotificationType,
    related_entity_type: "application",
    related_entity_id: applicationId,
    is_read: false,
    action_url: "/opportunities",
    action_label: "مراجعة الطلب",
    requires_action: true,
  }));

  if (notifications.length > 0) {
    await supabase.from("notifications").insert(notifications);
  }
}

/** Notify volunteer about application decision */
export async function notifyApplicationDecision(
  volunteerId: string,
  opportunityTitle: string,
  applicationId: string,
  decision: "approved" | "rejected",
  reviewNote?: string
) {
  const isApproved = decision === "approved";
  const noteText = reviewNote ? `\nالسبب: ${reviewNote}` : "";
  await createNotification({
    user_type: "volunteer",
    user_id: volunteerId,
    title: isApproved ? "تم قبول طلبك" : "تم رفض طلبك",
    message: isApproved
      ? `تم قبول طلب انضمامك لفرصة: ${opportunityTitle}`
      : `تم رفض طلب انضمامك لفرصة: ${opportunityTitle}${noteText}`,
    type: isApproved ? "application_approved" : "application_rejected",
    related_entity_type: "application",
    related_entity_id: applicationId,
    action_url: isApproved ? "/volunteer/participations" : "/volunteer/opportunities",
    action_label: isApproved ? "عرض مشاركاتي" : "عرض الفرص",
    requires_action: false,
  });
}

/** Notify internal director/supervisor users about a new public volunteer registration request */
export async function notifyInternalNewRegistration(
  fullName: string,
  registrationId: string,
) {
  const { data: internals } = await supabase
    .from("internal_users")
    .select("id")
    .in("role", ["director", "supervisor"])
    .eq("status", "active");
  if (!internals || internals.length === 0) return;

  const notifications = internals.map((u) => ({
    user_type: "internal" as const,
    user_id: u.id,
    title: "طلب تسجيل متطوع جديد",
    message: `تقدم ${fullName} بطلب تسجيل كمتطوع جديد — يحتاج إلى مراجعة`,
    type: "application_submitted" as NotificationType,
    related_entity_type: "volunteer_registration",
    related_entity_id: registrationId,
    is_read: false,
    action_url: "/volunteers",
    action_label: "مراجعة الطلب",
    requires_action: true,
  }));

  await supabase.from("notifications").insert(notifications);
}

/**
 * Notify supervisor (and directors) that an opportunity's window has ended
 * and still appears active — needs a status update from admin.
 * Sends to the assigned supervisor when present, plus all active directors.
 */
export async function notifyInternalOpportunityEnded(
  opportunityTitle: string,
  opportunityId: string,
  supervisorId?: string | null,
) {
  const { data: internals } = await supabase
    .from("internal_users")
    .select("id, role")
    .in("role", ["director", "supervisor"])
    .eq("status", "active");
  if (!internals || internals.length === 0) return;

  const targets = internals.filter(u =>
    u.role === "director" || (supervisorId && u.id === supervisorId),
  );
  if (targets.length === 0) return;

  const notifications = targets.map((u) => ({
    user_type: "internal" as const,
    user_id: u.id,
    title: "انتهت مدة فرصة تطوعية",
    message: `انتهت مدة الفرصة: ${opportunityTitle} — يرجى تحديث حالتها (إلى منتهية أو مؤرشفة)`,
    type: "participation_ended" as NotificationType,
    related_entity_type: "opportunity",
    related_entity_id: opportunityId,
    is_read: false,
    action_url: "/opportunities",
    action_label: "مراجعة الفرصة",
    requires_action: true,
  }));

  await supabase.from("notifications").insert(notifications);
}

