/**
 * Unified stats source for Dashboard and Volunteer Profile.
 * Centralizes hour-summing logic with the same fallback used in Hours/MyHours.
 */
import { supabase } from "@/integrations/supabase/client";
import { isAnomalousHours, roundHours, sumValidHours } from "@/lib/hours-utils";

export interface DashboardStats {
  volunteers: number;
  activeOpportunities: number;
  pendingProofs: number;
  totalHours: number;
  totalParticipations: number;
  internalUsers: number;
  unreadNotifications: number;
  fetchedAt: string;
}

const enrichHourRow = (r: any) => {
  const stored = Number(r.approved_hours);
  if (!Number.isNaN(stored) && stored > 0 && !isAnomalousHours(stored)) return r;
  const minutes = Number(r?.participations?.total_minutes || 0);
  if (minutes > 0) return { ...r, approved_hours: roundHours(minutes / 60) };
  const minH = Number(r?.opportunities?.minimum_hours || 0);
  if (minH > 0) return { ...r, approved_hours: roundHours(minH) };
  return r;
};

export async function fetchDashboardStats(): Promise<DashboardStats> {
  const [volRes, oppRes, proofRes, hoursRes, partsRes, internalRes, notifRes] = await Promise.all([
    supabase.from("volunteers").select("id", { count: "exact", head: true }),
    supabase.from("opportunities").select("id", { count: "exact", head: true }).eq("status", "active"),
    supabase.from("proofs").select("id", { count: "exact", head: true }).eq("review_status", "pending"),
    supabase.from("volunteer_hours").select("approved_hours, status, opportunities(minimum_hours), participations(total_minutes)"),
    supabase.from("participations").select("id", { count: "exact", head: true }),
    supabase.from("internal_users").select("id", { count: "exact", head: true }),
    supabase.from("notifications").select("id", { count: "exact", head: true }).eq("is_read", false),
  ]);

  const enriched = (hoursRes.data || []).map(enrichHourRow);
  const totalHours = sumValidHours(enriched);

  return {
    volunteers: volRes.count || 0,
    activeOpportunities: oppRes.count || 0,
    pendingProofs: proofRes.count || 0,
    totalHours,
    totalParticipations: partsRes.count || 0,
    internalUsers: internalRes.count || 0,
    unreadNotifications: notifRes.count || 0,
    fetchedAt: new Date().toISOString(),
  };
}

export interface VolunteerStats {
  totalHours: number;
  totalParticipations: number;
  totalOpps: number;
  fetchedAt: string;
}

export async function fetchVolunteerStats(volunteerId: string): Promise<VolunteerStats> {
  const [hoursRes, partsRes] = await Promise.all([
    supabase
      .from("volunteer_hours")
      .select("approved_hours, status, opportunities(minimum_hours), participations(total_minutes)")
      .eq("volunteer_id", volunteerId),
    supabase
      .from("participations")
      .select("id, opportunity_id")
      .eq("volunteer_id", volunteerId),
  ]);

  const enriched = (hoursRes.data || []).map(enrichHourRow);
  const totalHours = sumValidHours(enriched);
  const parts = partsRes.data || [];
  const uniqueOpps = new Set(parts.map((p: any) => p.opportunity_id));

  return {
    totalHours,
    totalParticipations: parts.length,
    totalOpps: uniqueOpps.size,
    fetchedAt: new Date().toISOString(),
  };
}
