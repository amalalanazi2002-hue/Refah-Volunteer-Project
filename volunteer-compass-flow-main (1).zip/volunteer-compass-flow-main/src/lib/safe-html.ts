import DOMPurify from "dompurify";

const CONFIG = {
  ALLOWED_TAGS: ["b","strong","i","em","u","p","br","ul","ol","li","a","img","span","div","h1","h2","h3","h4","blockquote","font"],
  ALLOWED_ATTR: ["href","target","rel","src","alt","style","color","size","face","align"],
  ALLOWED_URI_REGEXP: /^(?:https?:|mailto:|tel:|\/|#)/i,
};

export function sanitizeHtml(input: string): string {
  if (!input) return "";
  const clean = DOMPurify.sanitize(input, CONFIG);
  // force links to open safely
  return clean.replace(/<a /g, '<a target="_blank" rel="noopener noreferrer" ');
}

const HTML_RE = /<\/?[a-z][\s\S]*>/i;
export function isHtml(s: string) {
  return HTML_RE.test(s || "");
}

export function htmlToPlainText(html: string): string {
  if (!html) return "";
  if (!isHtml(html)) return html;
  const tmp = document.createElement("div");
  tmp.innerHTML = sanitizeHtml(html);
  return tmp.textContent || tmp.innerText || "";
}
