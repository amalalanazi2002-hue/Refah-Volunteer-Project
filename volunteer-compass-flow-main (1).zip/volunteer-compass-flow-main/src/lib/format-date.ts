// Centralized date/time formatting with timezone support
// Default: Asia/Riyadh (UTC+3)

let _timezone = "Asia/Riyadh";
let _listeners: Array<(tz: string) => void> = [];

export function setTimezone(tz: string) {
  _timezone = tz;
  _listeners.forEach(fn => fn(tz));
}

export function getTimezone() {
  return _timezone;
}

export function onTimezoneChange(fn: (tz: string) => void) {
  _listeners.push(fn);
  return () => { _listeners = _listeners.filter(f => f !== fn); };
}

// Force Latin digits regardless of locale. We build yyyy/MM/dd manually
// using Intl parts to honor the configured timezone.
const LOCALE = "en-GB";

function partsFor(date: Date, withTime: boolean): Record<string, string> {
  const opts: Intl.DateTimeFormatOptions = {
    timeZone: _timezone, year: "numeric", month: "2-digit", day: "2-digit",
    ...(withTime ? { hour: "2-digit", minute: "2-digit", hour12: false } : {}),
    // @ts-ignore numberingSystem is valid in modern runtimes
    numberingSystem: "latn",
  };
  const parts = new Intl.DateTimeFormat(LOCALE, opts as any).formatToParts(date);
  const out: Record<string, string> = {};
  parts.forEach(p => { if (p.type !== "literal") out[p.type] = p.value; });
  return out;
}

export function formatDate(dateStr: string | null | undefined, options?: { withTime?: boolean }): string {
  if (!dateStr) return "—";
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return "—";
    const p = partsFor(date, !!options?.withTime);
    const datePart = `${p.year}/${p.month}/${p.day}`;
    if (options?.withTime) {
      return `${datePart} ${p.hour}:${p.minute}`;
    }
    return datePart;
  } catch {
    return "—";
  }
}

export function formatDateTime(dateStr: string | null | undefined): string {
  return formatDate(dateStr, { withTime: true });
}

// Format a number with Latin digits (and optional thousands separator).
export function formatNumber(value: number | string | null | undefined, opts?: Intl.NumberFormatOptions): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "number" ? value : Number(value);
  if (Number.isNaN(n)) return String(value);
  return new Intl.NumberFormat(LOCALE, { numberingSystem: "latn", ...opts } as any).format(n);
}

// Common timezone options for the settings page
export const timezoneOptions = [
  { value: "Asia/Riyadh", label: "الرياض (UTC+3)" },
  { value: "Asia/Dubai", label: "دبي (UTC+4)" },
  { value: "Asia/Kuwait", label: "الكويت (UTC+3)" },
  { value: "Africa/Cairo", label: "القاهرة (UTC+2)" },
  { value: "Asia/Amman", label: "عمّان (UTC+3)" },
  { value: "Asia/Beirut", label: "بيروت (UTC+2)" },
  { value: "Asia/Baghdad", label: "بغداد (UTC+3)" },
  { value: "Europe/London", label: "لندن (UTC+0)" },
  { value: "UTC", label: "UTC" },
];
