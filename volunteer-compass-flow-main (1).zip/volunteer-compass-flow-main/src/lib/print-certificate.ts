// Print a certificate by rendering an HTML view from the template's design_config
// All data comes from the generated_certificates row + the related certificate_templates row.

import { formatDate } from "@/lib/format-date";

interface PrintCertArgs {
  cert: any; // generated_certificates row
  template: any | null; // certificate_templates row (with design_config)
  organizationName?: string;
}

const escape = (v: any) => String(v ?? "—").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const buildPlaceholderValues = (cert: any, organizationName: string): Record<string, string> => ({
  "{{volunteer_name}}": cert.volunteer_name || "—",
  "{{opportunity_title}}": cert.opportunity_title || "—",
  "{{approved_hours}}": `${cert.approved_hours ?? 0} ساعة`,
  "{{completion_date}}": cert.completion_date ? formatDate(cert.completion_date) : "—",
  "{{certificate_number}}": cert.certificate_number || "—",
  "{{organization_name}}": organizationName,
  "{{department_name}}": cert.department_name || "—",
  "{{issue_date}}": cert.issued_at ? formatDate(cert.issued_at) : formatDate(new Date().toISOString()),
});

export function printCertificate({ cert, template, organizationName = "منصة رفادة التطوعية" }: PrintCertArgs) {
  const win = window.open("", "_blank", "width=1100,height=800");
  if (!win) return;

  const config = template?.design_config || {};
  const bg = config.bg_color || "#FAFAFA";
  const border = config.border_color || "#5E4EA2";
  const bgImage = config.bg_image_url || "";
  const placeholders: any[] = (config.placeholders || []).filter((p: any) => p?.enabled !== false);
  const values = buildPlaceholderValues(cert, organizationName);

  const placeholderHtml = placeholders.map(p => {
    const text = escape(values[p.key] ?? p.label);
    const align = p.align || "center";
    const transform = `translate(${align === "center" ? "-50%" : align === "right" ? "-100%" : "0"}, -50%)`;
    return `<div style="
      position:absolute;
      left:${p.x}%;
      top:${p.y}%;
      transform:${transform};
      font-size:${p.fontSize}px;
      font-weight:${p.fontWeight || "normal"};
      color:${p.color || "#1a1a2e"};
      text-align:${align};
      white-space:nowrap;
    ">${text}</div>`;
  }).join("");

  const html = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<title>شهادة ${escape(cert.certificate_number || "")}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');
  * { box-sizing:border-box; }
  body { margin:0; padding:24px; font-family:'Cairo',sans-serif; background:#e9e9ef; }
  .toolbar { max-width:1050px; margin:0 auto 16px; display:flex; justify-content:space-between; gap:8px; align-items:center; }
  .toolbar h2 { margin:0; color:#5E4EA2; font-size:16px; }
  .toolbar button { padding:10px 20px; background:#5E4EA2; color:#fff; border:0; border-radius:8px; cursor:pointer; font-family:inherit; font-weight:600; }
  .toolbar button.secondary { background:#fff; color:#5E4EA2; border:1px solid #5E4EA2; }
  .cert-wrap { max-width:1050px; margin:0 auto; }
  .cert {
    position:relative;
    width:100%;
    aspect-ratio: 297 / 210;
    background:${bg};
    border:6px solid ${border};
    box-shadow:0 14px 40px rgba(0,0,0,.12);
    overflow:hidden;
    border-radius:6px;
  }
  .cert .bg-img {
    position:absolute; inset:0; width:100%; height:100%; object-fit:cover; opacity:.95;
  }
  @media print {
    body { padding:0; background:#fff; }
    .toolbar { display:none; }
    .cert-wrap { max-width:none; }
    .cert { box-shadow:none; border-radius:0; }
    @page { size: A4 landscape; margin: 0; }
  }
</style>
</head>
<body>
  <div class="toolbar">
    <h2>${escape(cert.opportunity_title || "")} — ${escape(cert.volunteer_name || "")}</h2>
    <div>
      <button class="secondary" onclick="window.close()">إغلاق</button>
      <button onclick="window.print()">طباعة الشهادة</button>
    </div>
  </div>
  <div class="cert-wrap">
    <div class="cert">
      ${bgImage ? `<img class="bg-img" src="${escape(bgImage)}" onerror="this.style.display='none'" />` : ""}
      ${placeholderHtml}
    </div>
  </div>
  <script>
    window.addEventListener('load', () => setTimeout(() => { try { window.focus(); } catch(e){} }, 100));
  </script>
</body>
</html>`;

  win.document.open();
  win.document.write(html);
  win.document.close();
}
