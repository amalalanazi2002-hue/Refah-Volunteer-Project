/**
 * Central validators for user inputs across the app.
 * All messages are Arabic. All numeric inputs normalized to Latin digits first.
 */

export const toLatinDigits = (value: string): string =>
  String(value ?? "")
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));

/** Saudi mobile: 10 digits, must start with 05 */
export const MOBILE_REGEX = /^05\d{8}$/;
/** Saudi national id: 10 digits, starts with 1 or 2 */
export const NATIONAL_ID_REGEX = /^[12]\d{9}$/;
/** Email: simple but strict pattern */
export const EMAIL_REGEX = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

export const normalizeMobile = (raw: string): string => {
  let v = toLatinDigits(raw).replace(/\D/g, "");
  if (v.startsWith("00966")) v = "0" + v.slice(5);
  else if (v.startsWith("966")) v = "0" + v.slice(3);
  else if (v.startsWith("5") && v.length === 9) v = "0" + v;
  return v.slice(0, 10);
};

export const normalizeNationalId = (raw: string): string =>
  toLatinDigits(raw).replace(/\D/g, "").slice(0, 10);

export const normalizeEmail = (raw: string): string =>
  toLatinDigits(raw).trim().toLowerCase();

export interface ValidationResult {
  ok: boolean;
  error?: string;
}

export const validateMobile = (raw: string): ValidationResult => {
  const v = normalizeMobile(raw);
  if (!v) return { ok: false, error: "رقم الجوال مطلوب" };
  if (!MOBILE_REGEX.test(v))
    return { ok: false, error: "رقم الجوال يجب أن يكون 10 أرقام ويبدأ بـ 05" };
  return { ok: true };
};

export const validateNationalId = (raw: string): ValidationResult => {
  const v = normalizeNationalId(raw);
  if (!v) return { ok: false, error: "رقم الهوية مطلوب" };
  if (!NATIONAL_ID_REGEX.test(v))
    return { ok: false, error: "رقم الهوية يجب أن يكون 10 أرقام ويبدأ بـ 1 أو 2" };
  return { ok: true };
};

/**
 * Strict typing handlers — block disallowed characters at keystroke time.
 * Always returns Latin digits, never exceeds the field's max length.
 */
export const handleMobileInput = (raw: string): string => {
  // Latinize, strip non-digits, cap at 10
  return toLatinDigits(raw).replace(/\D/g, "").slice(0, 10);
};

export const handleNationalIdInput = (raw: string): string => {
  return toLatinDigits(raw).replace(/\D/g, "").slice(0, 10);
};

export const handleEmailInput = (raw: string): string => {
  // Allow standard email chars only; latinize digits
  return toLatinDigits(raw).replace(/[^A-Za-z0-9._%+\-@]/g, "").slice(0, 254);
};

export const validateEmail = (raw: string, required = false): ValidationResult => {
  const v = normalizeEmail(raw);
  if (!v) return required ? { ok: false, error: "البريد الإلكتروني مطلوب" } : { ok: true };
  if (!EMAIL_REGEX.test(v)) return { ok: false, error: "صيغة البريد الإلكتروني غير صحيحة" };
  return { ok: true };
};

/** Bulk validate a registration-like payload. Returns errors keyed by field. */
export const validateContactForm = (payload: {
  mobile?: string;
  national_id?: string;
  email?: string;
  full_name?: string;
  emailRequired?: boolean;
}): Record<string, string> => {
  const errors: Record<string, string> = {};
  if (payload.full_name !== undefined) {
    const n = String(payload.full_name).trim();
    if (!n) errors.full_name = "الاسم الكامل مطلوب";
    else if (n.length > 120) errors.full_name = "الاسم طويل جدًا";
  }
  if (payload.mobile !== undefined) {
    const r = validateMobile(payload.mobile);
    if (!r.ok) errors.mobile = r.error!;
  }
  if (payload.national_id !== undefined) {
    const r = validateNationalId(payload.national_id);
    if (!r.ok) errors.national_id = r.error!;
  }
  if (payload.email !== undefined) {
    const r = validateEmail(payload.email, !!payload.emailRequired);
    if (!r.ok) errors.email = r.error!;
  }
  return errors;
};
