// Helpers for support-ticket message attachments.
// Assumes:
// - storage bucket: "support-ticket-attachments"
// - table: support_ticket_attachments(message_id, file_path, file_name, file_type)

import { supabase } from "@/integrations/supabase/client";

export const TICKET_BUCKET = "support-ticket-attachments";

export interface TicketAttachment {
  id: string;
  message_id: string;
  file_path: string;
  file_name: string;
  file_type: string | null;
  uploaded_at?: string;
}

// Upload a file to storage and insert an attachment row linked to the message.
export async function uploadTicketAttachment(opts: {
  ticketId: string;
  messageId: string;
  file: File;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    const ext = opts.file.name.split(".").pop() || "file";
    const path = `${opts.ticketId}/${opts.messageId}/${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from(TICKET_BUCKET).upload(path, opts.file);
    if (upErr) return { ok: false, error: upErr.message };

    const { error: insErr } = await supabase.from("support_ticket_attachments").insert({
      message_id: opts.messageId,
      file_path: path,
      file_name: opts.file.name,
      file_type: opts.file.type || null,
    });
    if (insErr) return { ok: false, error: insErr.message };
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message || "خطأ غير متوقع" };
  }
}

// Fetch attachments for a list of message IDs, grouped by message_id.
export async function fetchAttachmentsForMessages(messageIds: string[]): Promise<Record<string, TicketAttachment[]>> {
  if (messageIds.length === 0) return {};
  const { data, error } = await supabase
    .from("support_ticket_attachments")
    .select("*")
    .in("message_id", messageIds);
  if (error || !data) return {};
  const map: Record<string, TicketAttachment[]> = {};
  data.forEach((a: any) => {
    if (!map[a.message_id]) map[a.message_id] = [];
    map[a.message_id].push(a);
  });
  return map;
}

// Build a short-lived signed URL to view/download an attachment.
export async function getAttachmentUrl(filePath: string, download = false): Promise<string | null> {
  const { data, error } = await supabase.storage
    .from(TICKET_BUCKET)
    .createSignedUrl(filePath, 300, download ? { download: true } : undefined);
  if (error || !data?.signedUrl) return null;
  return data.signedUrl;
}

export const isImageAttachment = (att: TicketAttachment) => {
  if (att.file_type?.startsWith("image/")) return true;
  return /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(att.file_name || "");
};
