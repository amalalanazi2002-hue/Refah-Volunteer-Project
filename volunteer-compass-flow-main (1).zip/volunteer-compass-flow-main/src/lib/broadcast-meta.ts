// Hidden metadata markers embedded in notification.message
// Used to avoid DB schema changes while still tracking sender + attachments.
//
// Sender:      [[from:NAME|USER_ID]]\n\n<message>
// Attachment:  [[attach:{"name":"x","path":"x","type":"x","size":n}]]
//
// Markers are stripped before display.

const FROM_RE = /^\[\[from:([^|\]]+)\|([^\]]+)\]\]\n?\n?/;
const ATTACH_RE = /\[\[attach:({[^\]]+})\]\]/g;

export interface AttachmentMeta {
  name: string;
  path: string;
  type?: string;
  size?: number;
}

export function encodeSender(message: string, name: string, id: string) {
  const safeName = (name || "").replace(/[\|\]]/g, " ").slice(0, 80);
  const safeId = (id || "").replace(/[\|\]]/g, "").slice(0, 64);
  return `[[from:${safeName}|${safeId}]]\n\n${message}`;
}

export function encodeAttachment(att: AttachmentMeta) {
  return `[[attach:${JSON.stringify(att)}]]`;
}

export function parseSender(message: string): { name?: string; id?: string; clean: string } {
  if (!message) return { clean: "" };
  const m = message.match(FROM_RE);
  if (!m) return { clean: stripAttachMarkers(message) };
  return { name: m[1], id: m[2], clean: stripAttachMarkers(message.replace(FROM_RE, "")) };
}

export function parseAttachments(message: string): AttachmentMeta[] {
  if (!message) return [];
  const out: AttachmentMeta[] = [];
  const matches = message.matchAll(ATTACH_RE);
  for (const m of matches) {
    try { out.push(JSON.parse(m[1])); } catch { /* ignore */ }
  }
  return out;
}

function stripAttachMarkers(s: string) {
  return s.replace(ATTACH_RE, "").trim();
}

// Plain text version (also strips HTML tags) for previews like the bell
export function plainPreview(message: string, max = 120): string {
  const { clean } = parseSender(message);
  const noHtml = clean.replace(/<[^>]+>/g, " ").replace(/https?:\/\/\S+/g, "🔗 رابط").replace(/\s+/g, " ").trim();
  return noHtml.length > max ? noHtml.slice(0, max - 1) + "…" : noHtml;
}
