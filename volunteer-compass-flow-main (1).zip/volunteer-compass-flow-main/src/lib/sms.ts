/**
 * SMS hook — UI/logic placeholder.
 *
 * NOTE: Actual SMS delivery is intentionally NOT performed here.
 * When the user enables an SMS provider integration later, replace the
 * body of `sendSms` with the real call. For now, this just logs a
 * structured payload (so QA can inspect that the option was passed).
 */

export interface SmsPayload {
  to: string; // E.164 or local 05xxxxxxxx
  message: string;
  context?: Record<string, unknown>;
}

export async function sendSms(payload: SmsPayload): Promise<{ ok: boolean; reason?: string }> {
  if (!payload.to || !payload.message) {
    return { ok: false, reason: "missing to/message" };
  }
  // Intentional: do NOT perform an actual API call. Provider not configured.
  // eslint-disable-next-line no-console
  console.info("[sms-stub] would send sms →", payload);
  return { ok: false, reason: "sms-provider-not-configured" };
}
