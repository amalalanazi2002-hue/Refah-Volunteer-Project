import { supabase } from "@/integrations/supabase/client";
import type { NotificationType } from "@/lib/notifications";

/** Notify internal users about a new support ticket */
export async function notifyNewTicket(volunteerName: string, ticketTitle: string, ticketId: string) {
  const { data: internals } = await supabase
    .from("internal_users").select("id").in("role", ["director", "supervisor"]).eq("status", "active");
  if (!internals?.length) return;
  const notifications = internals.map(u => ({
    user_type: "internal" as const, user_id: u.id,
    title: "تذكرة دعم جديدة",
    message: `أنشأ ${volunteerName} تذكرة: ${ticketTitle}`,
    type: "application_submitted" as NotificationType,
    related_entity_type: "support_ticket", related_entity_id: ticketId,
    is_read: false, action_url: "/support-tickets", action_label: "عرض التذكرة", requires_action: true,
  }));
  await supabase.from("notifications").insert(notifications);
}

/** Notify volunteer about admin reply on ticket */
export async function notifyTicketReply(volunteerId: string, ticketTitle: string, ticketId: string, senderType: "admin" | "volunteer") {
  if (senderType === "admin") {
    // Notify volunteer
    await supabase.from("notifications").insert({
      user_type: "volunteer", user_id: volunteerId,
      title: "رد جديد على تذكرتك",
      message: `تم الرد على تذكرة: ${ticketTitle}`,
      type: "application_approved" as NotificationType,
      related_entity_type: "support_ticket", related_entity_id: ticketId,
      is_read: false, action_url: "/volunteer/tickets", action_label: "عرض التذكرة", requires_action: false,
    });
  } else {
    // Notify internals
    const { data: internals } = await supabase
      .from("internal_users").select("id").in("role", ["director", "supervisor"]).eq("status", "active");
    if (!internals?.length) return;
    const notifications = internals.map(u => ({
      user_type: "internal" as const, user_id: u.id,
      title: "رد متطوع على تذكرة",
      message: `رد على تذكرة: ${ticketTitle}`,
      type: "application_submitted" as NotificationType,
      related_entity_type: "support_ticket", related_entity_id: ticketId,
      is_read: false, action_url: "/support-tickets", action_label: "عرض التذكرة", requires_action: true,
    }));
    await supabase.from("notifications").insert(notifications);
  }
}

/** Notify about ticket status change */
export async function notifyTicketStatusChange(volunteerId: string, ticketTitle: string, ticketId: string, newStatus: string) {
  const statusLabels: Record<string, string> = { open: "مفتوحة", in_progress: "قيد المعالجة", waiting_reply: "بانتظار الرد", closed: "مغلقة" };
  await supabase.from("notifications").insert({
    user_type: "volunteer", user_id: volunteerId,
    title: "تحديث حالة التذكرة",
    message: `تم تغيير حالة تذكرة "${ticketTitle}" إلى: ${statusLabels[newStatus] || newStatus}`,
    type: "application_approved" as NotificationType,
    related_entity_type: "support_ticket", related_entity_id: ticketId,
    is_read: false, action_url: "/volunteer/tickets", action_label: "عرض التذكرة", requires_action: false,
  });
}

/** Notify about profile change request */
export async function notifyProfileChangeRequest(volunteerName: string, volunteerId: string, requestId: string) {
  const { data: internals } = await supabase
    .from("internal_users").select("id").in("role", ["director"]).eq("status", "active");
  if (!internals?.length) return;
  const notifications = internals.map(u => ({
    user_type: "internal" as const, user_id: u.id,
    title: "طلب تعديل بيانات",
    message: `طلب ${volunteerName} تعديل بياناته الشخصية`,
    type: "application_submitted" as NotificationType,
    related_entity_type: "profile_change_request", related_entity_id: requestId,
    is_read: false, action_url: "/profile-changes", action_label: "مراجعة الطلب", requires_action: true,
  }));
  await supabase.from("notifications").insert(notifications);
}

/** Notify volunteer about profile change decision */
export async function notifyProfileChangeDecision(volunteerId: string, decision: "approved" | "rejected", requestId: string) {
  await supabase.from("notifications").insert({
    user_type: "volunteer", user_id: volunteerId,
    title: decision === "approved" ? "تم قبول طلب تعديل البيانات" : "تم رفض طلب تعديل البيانات",
    message: decision === "approved" ? "تم قبول طلب تعديل بياناتك الشخصية وتحديثها" : "تم رفض طلب تعديل بياناتك الشخصية",
    type: (decision === "approved" ? "application_approved" : "application_rejected") as NotificationType,
    related_entity_type: "profile_change_request", related_entity_id: requestId,
    is_read: false, action_url: "/volunteer", action_label: "عرض ملفي", requires_action: false,
  });
}
