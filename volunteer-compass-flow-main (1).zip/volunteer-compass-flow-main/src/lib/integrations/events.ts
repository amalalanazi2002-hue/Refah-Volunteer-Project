/**
 * Event registry for the Integrations system.
 *
 * Each event lists the placeholder variables that the dispatcher CAN supply
 * when rendering a template body for that event. The variables here reflect
 * fields that already exist in the database (volunteers, opportunities,
 * participations, proofs, opportunity_applications). No invented variables.
 *
 * The list is provider-agnostic: it has nothing to do with SMS/WhatsApp/Email,
 * only with the business event itself. Any channel can render any template
 * for any event.
 */

export interface EventVariable {
  key: string;        // e.g. "volunteer_name"  → used as {{volunteer_name}} in template body
  label: string;      // Arabic label for the helper UI
  example?: string;   // optional example value to show next to the variable
}

export interface EventDef {
  value: string;      // stored in message_templates.event_type
  label: string;      // Arabic label
  /** What real DB fields can populate variables when this event fires. */
  variables: EventVariable[];
}

// Common variables used by many events
const v = {
  volunteerName: { key: "volunteer_name", label: "اسم المتطوع", example: "أحمد محمد" },
  volunteerMobile: { key: "volunteer_mobile", label: "جوال المتطوع", example: "05xxxxxxxx" },
  volunteerEmail: { key: "volunteer_email", label: "بريد المتطوع" },
  opportunityTitle: { key: "opportunity_title", label: "عنوان الفرصة" },
  departmentName: { key: "department_name", label: "اسم الإدارة" },
  startAt: { key: "start_at", label: "تاريخ البدء" },
  endAt: { key: "end_at", label: "تاريخ الانتهاء" },
  minimumHours: { key: "minimum_hours", label: "الحد الأدنى للساعات" },
  reviewerName: { key: "reviewer_name", label: "اسم المراجع" },
  reviewerNote: { key: "reviewer_note", label: "ملاحظة المراجع" },
  totalHours: { key: "total_hours", label: "إجمالي الساعات" },
};

export const events: EventDef[] = [
  {
    value: "new_opportunity",
    label: "فرصة جديدة",
    variables: [v.opportunityTitle, v.departmentName, v.startAt, v.endAt, v.minimumHours],
  },
  {
    value: "application_submitted",
    label: "طلب انضمام",
    variables: [v.volunteerName, v.volunteerMobile, v.opportunityTitle, v.departmentName],
  },
  {
    value: "application_approved",
    label: "قبول طلب",
    variables: [v.volunteerName, v.opportunityTitle, v.departmentName, v.startAt, v.reviewerName],
  },
  {
    value: "application_rejected",
    label: "رفض طلب",
    variables: [v.volunteerName, v.opportunityTitle, v.reviewerName, v.reviewerNote],
  },
  {
    value: "participation_started",
    label: "بدء مشاركة",
    variables: [v.volunteerName, v.opportunityTitle, v.departmentName, v.startAt],
  },
  {
    value: "participation_ended",
    label: "انتهاء مشاركة",
    variables: [v.volunteerName, v.opportunityTitle, v.endAt, v.totalHours],
  },
  {
    value: "proof_approved",
    label: "قبول إثبات",
    variables: [v.volunteerName, v.opportunityTitle, v.totalHours, v.reviewerName],
  },
  {
    value: "proof_rejected",
    label: "رفض إثبات",
    variables: [v.volunteerName, v.opportunityTitle, v.reviewerName, v.reviewerNote],
  },
  {
    value: "proof_needs_completion",
    label: "استكمال إثبات",
    variables: [v.volunteerName, v.opportunityTitle, v.reviewerNote],
  },
];

export const eventTypes = events.map(e => ({ value: e.value, label: e.label }));

export const getEvent = (value: string): EventDef | undefined =>
  events.find(e => e.value === value);
