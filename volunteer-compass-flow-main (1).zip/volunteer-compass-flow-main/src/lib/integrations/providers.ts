/**
 * Provider-agnostic registry for integration channels.
 *
 * IMPORTANT: This file defines WHAT providers are available for each channel
 * and WHAT credential fields each provider requires. It does NOT execute any
 * provider-specific calls — that is the job of the (future) backend dispatcher.
 *
 * Adding/removing/changing a provider is a one-place edit here. The Integrations
 * page reads channels + providerFields from this module, so the UI stays
 * provider-agnostic and future providers can be plugged in without touching
 * the page or the dispatcher contract.
 */

import { MessageSquare, Phone, Mail, BellRing, Globe, type LucideIcon } from "lucide-react";

export type ChannelKey = "whatsapp" | "sms" | "email" | "push" | "domain_dns";

export interface ProviderField {
  key: string;
  label: string;
  type?: "text" | "password" | "textarea";
  placeholder?: string;
  help?: string;
}

export interface ProviderDef {
  value: string;        // stored in integration_configs.provider
  label: string;        // shown in the UI
  fields: ProviderField[];
  /** Optional note shown under the provider in the settings card. */
  note?: string;
}

export interface ChannelDef {
  key: ChannelKey;
  label: string;
  icon: LucideIcon;
  providers: ProviderDef[];
}

// ---------------------------------------------------------------------------
// Approved providers (current scope). New providers can be appended here
// without changing the UI or the dispatcher contract.
// ---------------------------------------------------------------------------

const fourJawalyProvider: ProviderDef = {
  value: "4jawaly",
  label: "4jawaly",
  note: "مزود الرسائل النصية المعتمد حاليًا",
  fields: [
    { key: "api_key", label: "API Key", type: "password" },
    { key: "api_secret", label: "API Secret", type: "password" },
    { key: "sender_name", label: "اسم المرسل (Sender ID)" },
  ],
};

const sendPulseProvider: ProviderDef = {
  value: "sendpulse",
  label: "SendPulse",
  note: "مزود الواتساب المعتمد حاليًا",
  fields: [
    { key: "client_id", label: "Client ID" },
    { key: "client_secret", label: "Client Secret", type: "password" },
    { key: "bot_id", label: "Bot ID (WhatsApp)" },
    { key: "from_number", label: "رقم المرسل" },
  ],
};

const googleEmailProvider: ProviderDef = {
  value: "google",
  label: "Google (Gmail / Workspace)",
  note: "إرسال البريد عبر حساب Google / Workspace",
  fields: [
    { key: "client_id", label: "OAuth Client ID" },
    { key: "client_secret", label: "OAuth Client Secret", type: "password" },
    { key: "refresh_token", label: "Refresh Token", type: "password" },
    { key: "from_email", label: "بريد المرسل" },
    { key: "from_name", label: "اسم المرسل" },
  ],
};

const microsoftEmailProvider: ProviderDef = {
  value: "microsoft",
  label: "Microsoft (Outlook / 365)",
  note: "إرسال البريد عبر حساب Microsoft 365 / Outlook",
  fields: [
    { key: "tenant_id", label: "Tenant ID" },
    { key: "client_id", label: "Client ID" },
    { key: "client_secret", label: "Client Secret", type: "password" },
    { key: "from_email", label: "بريد المرسل" },
    { key: "from_name", label: "اسم المرسل" },
  ],
};

const smtpEmailProvider: ProviderDef = {
  value: "smtp",
  label: "SMTP عام",
  fields: [
    { key: "host", label: "SMTP Host" },
    { key: "port", label: "Port" },
    { key: "username", label: "اسم المستخدم" },
    { key: "password", label: "كلمة المرور", type: "password" },
    { key: "from_email", label: "بريد المرسل" },
  ],
};

const customProvider: ProviderDef = {
  value: "custom",
  label: "مزود مخصص (لاحقًا)",
  note: "ضع المفاتيح وستُستخدم عند ربط المزود لاحقًا",
  fields: [
    { key: "api_key", label: "API Key", type: "password" },
    { key: "base_url", label: "Base URL" },
    { key: "extra_config", label: "إعدادات إضافية (JSON)", type: "textarea" },
  ],
};

const fcmPushProvider: ProviderDef = {
  value: "fcm",
  label: "Firebase FCM",
  fields: [
    { key: "service_account_json", label: "Service Account (JSON)", type: "textarea" },
    { key: "project_id", label: "Project ID" },
  ],
};

const cloudflareDnsProvider: ProviderDef = {
  value: "cloudflare",
  label: "Cloudflare",
  fields: [
    { key: "api_token", label: "API Token", type: "password" },
    { key: "zone_id", label: "Zone ID" },
    { key: "account_id", label: "Account ID" },
  ],
};

const route53DnsProvider: ProviderDef = {
  value: "route53",
  label: "AWS Route 53",
  fields: [
    { key: "access_key", label: "Access Key" },
    { key: "secret_key", label: "Secret Key", type: "password" },
    { key: "hosted_zone_id", label: "Hosted Zone ID" },
  ],
};

// ---------------------------------------------------------------------------
// Channels
// ---------------------------------------------------------------------------

export const channels: ChannelDef[] = [
  {
    key: "sms",
    label: "الرسائل النصية",
    icon: Phone,
    providers: [fourJawalyProvider, customProvider],
  },
  {
    key: "whatsapp",
    label: "واتساب",
    icon: MessageSquare,
    providers: [sendPulseProvider, customProvider],
  },
  {
    key: "email",
    label: "البريد الإلكتروني",
    icon: Mail,
    providers: [googleEmailProvider, microsoftEmailProvider, smtpEmailProvider, customProvider],
  },
  {
    key: "push",
    label: "الإشعارات الفورية",
    icon: BellRing,
    providers: [fcmPushProvider, customProvider],
  },
  {
    key: "domain_dns",
    label: "النطاقات و DNS",
    icon: Globe,
    providers: [cloudflareDnsProvider, route53DnsProvider, customProvider],
  },
];

/**
 * Flat lookup: provider value -> required fields.
 * Used by the ChannelCard to render the right inputs once a provider is picked.
 */
export const providerFields: Record<string, ProviderField[]> = channels
  .flatMap(c => c.providers)
  .reduce((acc, p) => {
    acc[p.value] = p.fields;
    return acc;
  }, {} as Record<string, ProviderField[]>);

export const getChannel = (key: string): ChannelDef | undefined =>
  channels.find(c => c.key === key);

export const getProvider = (channelKey: string, providerValue: string): ProviderDef | undefined =>
  getChannel(channelKey)?.providers.find(p => p.value === providerValue);
