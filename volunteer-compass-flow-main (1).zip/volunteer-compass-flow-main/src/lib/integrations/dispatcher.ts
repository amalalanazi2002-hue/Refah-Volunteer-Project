/**
 * Provider-agnostic dispatcher (frontend-side preparation only).
 *
 * What this DOES today:
 *  - Looks up the active config for a channel (sms / whatsapp / email / push)
 *  - Looks up an enabled template matching (channel, event_type)
 *  - Renders the template body by substituting {{var}} with values from `vars`
 *  - Returns a structured payload the backend can later send to the actual
 *    provider (4jawaly / SendPulse / Google / Microsoft / future)
 *  - Writes an integration_logs entry so the operator can see what was prepared
 *
 * What this does NOT do (intentionally):
 *  - It does NOT call any provider HTTP API. CORS + secrets make that unsafe
 *    from the browser. Real delivery must run inside an Edge Function that
 *    reads the saved config + the prepared payload. See README at the bottom.
 *
 * The design is provider-agnostic on purpose: switching from 4jawaly to any
 * future SMS provider only requires (a) adding the provider to providers.ts
 * and (b) handling its `provider` value in the backend dispatcher. Nothing in
 * the page or in this file needs to change.
 */

import { supabase } from "@/integrations/supabase/client";
import type { ChannelKey } from "./providers";

export interface DispatchVars {
  [key: string]: string | number | null | undefined;
}

export interface DispatchInput {
  channel: ChannelKey;
  event: string;
  /** Recipient (phone for sms/whatsapp, email for email, deviceToken/userId for push) */
  to?: string;
  /** Variables to substitute into the template body. */
  vars?: DispatchVars;
}

export interface PreparedMessage {
  channel: ChannelKey;
  event: string;
  provider: string | null;
  to: string | null;
  subject: string | null;
  body: string;
  /** Provider config (credentials live here; never expose to client logs in prod) */
  providerConfig: Record<string, unknown> | null;
  templateId: string | null;
}

const renderTemplate = (body: string, vars: DispatchVars = {}): string => {
  return body.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_, key) => {
    const val = vars[key];
    return val === undefined || val === null ? `{{${key}}}` : String(val);
  });
};

/**
 * Prepare a message for an event. Returns null if no enabled template exists
 * for (channel, event) — caller should treat that as "skip silently".
 */
export async function prepareMessage(input: DispatchInput): Promise<PreparedMessage | null> {
  const [tplRes, cfgRes] = await Promise.all([
    supabase
      .from("message_templates")
      .select("*")
      .eq("channel", input.channel)
      .eq("event_type", input.event)
      .eq("is_enabled", true)
      .limit(1)
      .maybeSingle(),
    supabase
      .from("integration_configs")
      .select("*")
      .eq("channel", input.channel)
      .eq("is_enabled", true)
      .limit(1)
      .maybeSingle(),
  ]);

  const tpl = (tplRes as { data: Record<string, unknown> | null }).data;
  const cfg = (cfgRes as { data: Record<string, unknown> | null }).data;

  if (!tpl) return null;

  return {
    channel: input.channel,
    event: input.event,
    provider: (cfg?.provider as string) || null,
    to: input.to || null,
    subject: (tpl.subject as string) || null,
    body: renderTemplate((tpl.body as string) || "", input.vars),
    providerConfig: (cfg?.config as Record<string, unknown>) || null,
    templateId: (tpl.id as string) || null,
  };
}

/**
 * Dispatch an event end-to-end:
 *  1) Render template + lookup active provider config (frontend).
 *  2) Call the `dispatch-message` Edge Function with the prepared payload.
 *  3) The Edge Function performs the real provider call AND writes the
 *     final integration_logs row (success/failed). We do NOT write a log
 *     here to avoid duplicates — the function is the source of truth.
 *
 * If no template/provider is configured we still write a single "skipped"
 * log here so operators can see the attempt.
 */
export async function dispatchEvent(input: DispatchInput): Promise<{
  prepared: PreparedMessage | null;
  ok: boolean;
  status: "success" | "failed" | "skipped";
  error?: string;
  reason?: string;
}> {
  const prepared = await prepareMessage(input);

  if (!prepared) {
    await supabase.from("integration_logs").insert({
      channel: input.channel,
      provider: null,
      event_type: input.event,
      operation: "dispatch",
      status: "skipped",
      target: input.to || null,
      error_message: "no_enabled_template",
    });
    return { prepared: null, ok: false, status: "skipped", reason: "no_template" };
  }

  if (!prepared.provider || !prepared.to) {
    await supabase.from("integration_logs").insert({
      channel: input.channel,
      provider: prepared.provider,
      event_type: input.event,
      operation: "dispatch",
      status: "skipped",
      target: prepared.to,
      error_message: !prepared.provider ? "no_active_provider_config" : "missing_recipient",
    });
    return {
      prepared,
      ok: false,
      status: "skipped",
      reason: !prepared.provider ? "no_provider" : "no_recipient",
    };
  }

  // Call the Edge Function. It writes the final log row itself.
  const { data, error } = await supabase.functions.invoke("dispatch-message", {
    body: {
      channel: prepared.channel,
      provider: prepared.provider,
      event: prepared.event,
      to: prepared.to,
      subject: prepared.subject,
      body: prepared.body,
      providerConfig: prepared.providerConfig,
      templateId: prepared.templateId,
    },
  });

  if (error) {
    return { prepared, ok: false, status: "failed", error: error.message };
  }
  return {
    prepared,
    ok: !!data?.ok,
    status: data?.ok ? "success" : "failed",
    error: data?.error,
  };
}

/* -----------------------------------------------------------------------------
 * Backend (Edge Function) location: supabase/functions/dispatch-message/index.ts
 * Deploy with: supabase functions deploy dispatch-message
 * Required secrets are listed in that file.
 * --------------------------------------------------------------------------- */
