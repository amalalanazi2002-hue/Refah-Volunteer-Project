/**
 * Unified formatting for volunteer hours/durations across the app.
 * - Always uses Latin digits (English numerals).
 * - Negative or absurd values are clamped/marked as anomalous.
 * - Hours rounded to 2 decimals; whole hours show no trailing zeros.
 */

import { isAnomalousHours, isAnomalousMinutes, roundHours } from "./hours-utils";

const fmtNumber = (n: number, maxFraction = 2): string =>
  new Intl.NumberFormat("en-GB", {
    numberingSystem: "latn",
    maximumFractionDigits: maxFraction,
    minimumFractionDigits: 0,
  } as any).format(n);

/**
 * Format approved hours with the trailing word "ساعة".
 * Returns "—" for null/undefined/anomalous values.
 */
export function formatHours(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "number" ? value : Number(value);
  if (Number.isNaN(n)) return "—";
  if (isAnomalousHours(n)) return "—";
  const rounded = roundHours(n);
  return `${fmtNumber(rounded)} ساعة`;
}

/**
 * Format accumulated/total approved hours.
 * Unlike single-record hours, totals may exceed 12 naturally.
 */
export function formatTotalHours(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "number" ? value : Number(value);
  if (Number.isNaN(n) || n < 0) return "—";
  return `${fmtNumber(roundHours(n))} ساعة`;
}

/** Same as formatHours but returns just the number as a string (no unit). */
export function formatHoursNumber(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "0";
  const n = typeof value === "number" ? value : Number(value);
  if (Number.isNaN(n) || isAnomalousHours(n)) return "0";
  return fmtNumber(roundHours(n));
}

/**
 * Format a duration in minutes as either "X ساعة Y دقيقة" or "Y دقيقة".
 * Anomalous (negative or > 720) returns "—".
 */
export function formatMinutes(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const n = typeof value === "number" ? value : Number(value);
  if (Number.isNaN(n) || isAnomalousMinutes(n)) return "—";
  if (n < 1) return "0 دقيقة";
  const hrs = Math.floor(n / 60);
  const mins = Math.round(n % 60);
  if (hrs <= 0) return `${fmtNumber(mins, 0)} دقيقة`;
  if (mins <= 0) return `${fmtNumber(hrs, 0)} ساعة`;
  return `${fmtNumber(hrs, 0)} ساعة ${fmtNumber(mins, 0)} دقيقة`;
}

/** Convert minutes → hours rounded to 2 decimals. */
export function minutesToHours(minutes: number | string | null | undefined): number {
  const n = typeof minutes === "number" ? minutes : Number(minutes);
  if (Number.isNaN(n) || n <= 0) return 0;
  return roundHours(n / 60);
}
