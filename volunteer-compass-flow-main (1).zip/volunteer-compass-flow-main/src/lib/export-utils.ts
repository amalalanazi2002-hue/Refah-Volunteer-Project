/**
 * Export utilities for Excel and PDF generation
 */
import { formatDate } from "@/lib/format-date";

export function exportToCSV(data: Record<string, any>[], columns: { header: string; key: string }[], filename: string) {
  const BOM = "\uFEFF";
  const headers = columns.map(c => c.header).join(",");
  const rows = data.map(row =>
    columns.map(c => {
      const val = String(row[c.key] ?? "—").replace(/,/g, "،").replace(/"/g, '""');
      return `"${val}"`;
    }).join(",")
  );
  const csv = BOM + headers + "\n" + rows.join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  downloadBlob(blob, `${filename}.csv`);
}

export function exportToExcel(data: Record<string, any>[], columns: { header: string; key: string }[], filename: string) {
  // Generate simple XLSX-compatible XML (SpreadsheetML)
  const BOM = "\uFEFF";
  const xmlRows = data.map(row => {
    const cells = columns.map(c => {
      const val = String(row[c.key] ?? "—").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return `<Cell><Data ss:Type="String">${val}</Data></Cell>`;
    }).join("");
    return `<Row>${cells}</Row>`;
  });

  const headerCells = columns.map(c => {
    const val = c.header.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    return `<Cell ss:StyleID="header"><Data ss:Type="String">${val}</Data></Cell>`;
  }).join("");

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Styles>
<Style ss:ID="Default"><Alignment ss:Horizontal="Right" ss:ReadingOrder="RightToLeft"/><Font ss:FontName="Cairo" ss:Size="11"/></Style>
<Style ss:ID="header"><Alignment ss:Horizontal="Right" ss:ReadingOrder="RightToLeft"/><Font ss:FontName="Cairo" ss:Size="11" ss:Bold="1"/><Interior ss:Color="#E8E0F0" ss:Pattern="Solid"/></Style>
</Styles>
<Worksheet ss:Name="البيانات"><Table>
<Row>${headerCells}</Row>
${xmlRows.join("\n")}
</Table></Worksheet>
</Workbook>`;

  const blob = new Blob([BOM + xml], { type: "application/vnd.ms-excel;charset=utf-8;" });
  downloadBlob(blob, `${filename}.xls`);
}

export function exportToPDF(data: Record<string, any>[], columns: { header: string; key: string }[], title: string, filename: string) {
  // Create printable HTML for PDF
  const headerRow = columns.map(c => `<th style="padding:8px 12px;background:#5E4EA2;color:#fff;text-align:right;font-size:12px;border:1px solid #ddd;">${c.header}</th>`).join("");
  const bodyRows = data.map(row => {
    const cells = columns.map(c => `<td style="padding:6px 12px;text-align:right;font-size:11px;border:1px solid #eee;">${row[c.key] ?? "—"}</td>`).join("");
    return `<tr>${cells}</tr>`;
  }).join("");

  const html = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head><meta charset="utf-8"><title>${title}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
body{font-family:'Cairo',sans-serif;margin:20px;direction:rtl;}
h1{font-size:18px;color:#5E4EA2;margin-bottom:4px;}
p{font-size:12px;color:#666;margin-bottom:16px;}
table{width:100%;border-collapse:collapse;}
tr:nth-child(even){background:#f9f7fc;}
@media print{body{margin:0;} @page{size:landscape;margin:10mm;}}
</style></head>
<body>
<h1>${title}</h1>
<p>تاريخ التصدير: ${formatDate(new Date().toISOString())}</p>
<table><thead><tr>${headerRow}</tr></thead><tbody>${bodyRows}</tbody></table>
</body></html>`;

  const printWindow = window.open("", "_blank");
  if (printWindow) {
    printWindow.document.write(html);
    printWindow.document.close();
    setTimeout(() => printWindow.print(), 500);
  }
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
