import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Branding {
  platform_name: string;
  org_name: string;
  logo_url: string;
}

const defaults: Branding = {
  platform_name: "منصة رفادة التطوعية",
  org_name: "جمعية رفاه للأرامل والمطلقات",
  logo_url: "",
};

let cache: Branding | null = null;
let listeners: Array<(b: Branding) => void> = [];

const notify = (b: Branding) => { cache = b; listeners.forEach(fn => fn(b)); };

async function fetchBranding() {
  const { data } = await supabase
    .from("system_settings")
    .select("key, value")
    .in("key", ["platform_name", "org_name", "logo_url"]);

  const map: Record<string, string> = {};
  data?.forEach((r: any) => { map[r.key] = r.value; });

  const branding: Branding = {
    platform_name: map.platform_name || defaults.platform_name,
    org_name: map.org_name || defaults.org_name,
    logo_url: map.logo_url || defaults.logo_url,
  };
  notify(branding);
}

// Initial fetch once
fetchBranding();

export function refreshBranding() {
  fetchBranding();
}

export function useBranding(): Branding {
  const [branding, setBranding] = useState<Branding>(cache || defaults);

  useEffect(() => {
    if (cache) setBranding(cache);
    listeners.push(setBranding);
    return () => { listeners = listeners.filter(fn => fn !== setBranding); };
  }, []);

  return branding;
}
