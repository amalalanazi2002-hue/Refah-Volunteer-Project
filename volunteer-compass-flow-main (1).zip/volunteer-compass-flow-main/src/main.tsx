import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { supabase } from "./integrations/supabase/client";
import { setTimezone } from "./lib/format-date";

// Boot: load timezone from system_settings (default Asia/Riyadh) before app renders
(async () => {
  try {
    const { data } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "timezone")
      .limit(1);
    let tz = data?.[0]?.value || "Asia/Riyadh";
    if (typeof tz === "string") tz = tz.replace(/^"|"$/g, "");
    setTimezone(tz || "Asia/Riyadh");
  } catch {
    setTimezone("Asia/Riyadh");
  }
})();

createRoot(document.getElementById("root")!).render(<App />);
