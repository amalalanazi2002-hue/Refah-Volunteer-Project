import { useState, useEffect, useMemo } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { StatCard } from "@/components/shared/StatCard";
import { VolunteerListSection } from "@/components/shared/VolunteerListSection";
import { Clock, CheckCircle, History } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { sumValidHours, countValidHours, roundHours, isAnomalousHours } from "@/lib/hours-utils";
import { formatDate } from "@/lib/format-date";
import { formatHours, formatTotalHours } from "@/lib/hours-format";

const statusMap: Record<string, string> = { approved: "معتمد", reversed: "ملغي" };

// Compute the displayed/effective hours for a row.
// If approved_hours is 0 (or missing) but the participation has duration or
// the opportunity has a minimum_hours, use that as a fallback so an approved
// participation never shows "0 hours" incorrectly.
const effectiveHours = (row: any): number => {
  const stored = Number(row.approved_hours);
  if (!Number.isNaN(stored) && stored > 0 && !isAnomalousHours(stored)) return stored;
  const minutes = Number(row?.participations?.total_minutes || 0);
  if (minutes > 0) return roundHours(minutes / 60);
  const minHours = Number(row?.opportunities?.minimum_hours || 0);
  if (minHours > 0) return roundHours(minHours);
  return stored || 0;
};

const MyHours = () => {
  const { volunteerId } = useRole();
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    if (!volunteerId) return;
    const fetch = async () => {
      const { data: rows } = await supabase
        .from("volunteer_hours")
        .select("*, opportunities(title, minimum_hours), participations(total_minutes)")
        .eq("volunteer_id", volunteerId)
        .order("created_at", { ascending: false });
      setData(rows || []);
    };
    fetch();
  }, [volunteerId]);

  // Apply effective fallback before computing totals
  const enriched = useMemo(
    () => data.map((r) => ({ ...r, approved_hours: effectiveHours(r) })),
    [data]
  );
  const total = useMemo(() => sumValidHours(enriched), [enriched]);
  const count = useMemo(() => countValidHours(enriched), [enriched]);

  return (
    <div>
      <PageHeader title="ساعاتي" description="عرض ساعاتي التطوعية المعتمدة" />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4 mb-8">
        <StatCard title="إجمالي ساعاتي" value={formatTotalHours(total)} icon={Clock} color="primary" />
        <StatCard title="مشاركات معتمدة" value={count} icon={CheckCircle} color="success" />
      </div>

      <VolunteerListSection
        title="سجل الساعات"
        icon={<History className="h-4 w-4" />}
        total={enriched.length}
        summary={[
          { label: "معتمد", value: enriched.filter((r: any) => r.status === "approved").length, variant: "success" },
          { label: "ملغي", value: enriched.filter((r: any) => r.status === "reversed").length, variant: "danger" },
        ]}
      >
        {(limit) => (
          <div className="overflow-x-auto -mx-2 sm:mx-0 px-2 sm:px-0">
            <DataTable
              columns={[
                { header: "الفرصة", accessor: (r: any) => r.opportunities?.title || "—" },
                { header: "الساعات", accessor: (r: any) => formatHours(r.approved_hours) },
                { header: "تاريخ الاعتماد", accessor: (r: any) => r.approval_date ? formatDate(r.approval_date) : "—" },
                { header: "الحالة", accessor: (r: any) => <StatusBadge status={statusMap[r.status] || r.status} variant={r.status === "approved" ? "success" : "warning"} /> },
              ]}
              data={limit ? enriched.slice(0, limit) : enriched}
            />
          </div>
        )}
      </VolunteerListSection>
    </div>
  );
};

export default MyHours;
