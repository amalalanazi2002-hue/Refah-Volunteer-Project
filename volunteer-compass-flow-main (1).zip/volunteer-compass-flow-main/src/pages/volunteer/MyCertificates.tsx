import { useState, useEffect, useMemo } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { VolunteerListSection } from "@/components/shared/VolunteerListSection";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { useBranding } from "@/hooks/use-branding";
import { Award, Download, Eye } from "lucide-react";
import { formatDate } from "@/lib/format-date";
import { formatHours } from "@/lib/hours-format";
import { roundHours } from "@/lib/hours-utils";
import { printCertificate } from "@/lib/print-certificate";

const MyCertificates = () => {
  const { volunteerId } = useRole();
  const { org_name } = useBranding();
  const [certificates, setCertificates] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [enableCertificates, setEnableCertificates] = useState(true);

  useEffect(() => {
    if (!volunteerId) return;
    const fetchData = async () => {
      // Fetch certificates without nested joins (which can silently drop rows
      // if related rows are missing/blocked by RLS). Show all non-rejected
      // certificates belonging to this volunteer.
      const [certRes, tplRes, settingsRes] = await Promise.all([
        supabase
          .from("generated_certificates")
          .select("*, certificate_templates(id, name, design_config)")
          .eq("volunteer_id", volunteerId)
          .neq("status", "rejected")
          .order("issued_at", { ascending: false }),
        supabase.from("certificate_templates").select("id, name, design_config").eq("is_active", true),
        supabase.from("system_settings").select("value").eq("key", "enable_certificates").limit(1),
      ]);
      const certs = certRes.data || [];
      // Enrich hours from related records when cert's stored hours == 0.
      const partIds = Array.from(new Set(certs.map((c: any) => c.participation_id).filter(Boolean)));
      const hourIds = Array.from(new Set(certs.map((c: any) => c.volunteer_hours_id).filter(Boolean)));
      const [partsRes, hoursRes] = await Promise.all([
        partIds.length
          ? supabase.from("participations").select("id, total_minutes, opportunity_id, opportunities(minimum_hours)").in("id", partIds)
          : Promise.resolve({ data: [] as any[] }),
        hourIds.length
          ? supabase.from("volunteer_hours").select("id, approved_hours").in("id", hourIds)
          : Promise.resolve({ data: [] as any[] }),
      ]);
      const partsMap = new Map((partsRes.data || []).map((p: any) => [p.id, p]));
      const hoursMap = new Map((hoursRes.data || []).map((h: any) => [h.id, h]));
      const merged = certs.map((c: any) => ({
        ...c,
        participations: c.participation_id ? partsMap.get(c.participation_id) || null : null,
        volunteer_hours: c.volunteer_hours_id ? hoursMap.get(c.volunteer_hours_id) || null : null,
      }));
      setCertificates(merged);
      setTemplates(tplRes.data || []);
      if (settingsRes.data?.[0]?.value === "false") setEnableCertificates(false);
    };
    fetchData();
  }, [volunteerId]);

  // Compute the effective hours to display & print: prefer cert's own value,
  // then volunteer_hours, then participation duration, then opportunity minimum.
  const enriched = useMemo(() => certificates.map((c: any) => {
    const stored = Number(c.approved_hours);
    if (stored > 0) return c;
    const vh = Number(c?.volunteer_hours?.approved_hours || 0);
    if (vh > 0) return { ...c, approved_hours: roundHours(vh) };
    const minutes = Number(c?.participations?.total_minutes || 0);
    if (minutes > 0) return { ...c, approved_hours: roundHours(minutes / 60) };
    const minH = Number(c?.participations?.opportunities?.minimum_hours || 0);
    if (minH > 0) return { ...c, approved_hours: roundHours(minH) };
    return c;
  }), [certificates]);

  // Use the SAME rendering function as the admin Issued Certificates page,
  // pulling the joined template (with design_config) — fall back to active templates list.
  const handlePrint = (cert: any) => {
    const tpl = cert.certificate_templates || templates.find(t => t.id === cert.template_id) || null;
    printCertificate({ cert, template: tpl, organizationName: org_name });
  };

  if (!enableCertificates) {
    return (
      <div>
        <PageHeader title="شهاداتي" description="شهادات المشاركات التطوعية المكتملة" />
        <div className="text-center py-12 text-muted-foreground">
          <Award className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p>خاصية الشهادات غير مفعلة حاليًا</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="شهاداتي" description="شهادات المشاركات التطوعية المكتملة" />
      <VolunteerListSection
        title="سجل الشهادات"
        icon={<Award className="h-4 w-4" />}
        total={enriched.length}
      >
        {(limit) => (
          <div className="overflow-x-auto -mx-2 sm:mx-0 px-2 sm:px-0">
            <DataTable
              columns={[
                { header: "الفرصة", accessor: "opportunity_title" },
                { header: "الساعات", accessor: (r: any) => formatHours(r.approved_hours) },
                { header: "تاريخ الإصدار", accessor: (r: any) => formatDate(r.issued_at) },
                { header: "رقم الشهادة", accessor: "certificate_number" },
                { header: "إجراءات", accessor: (r: any) => (
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" onClick={() => handlePrint(r)}>
                      <Eye className="h-4 w-4 ml-1" />
                      معاينة
                    </Button>
                    <Button variant="default" size="sm" onClick={() => handlePrint(r)}>
                      <Download className="h-4 w-4 ml-1" />
                      تنزيل
                    </Button>
                  </div>
                )},
              ]}
              data={limit ? enriched.slice(0, limit) : enriched}
              emptyMessage="لا توجد شهادات بعد"
              emptyIcon={<Award className="h-10 w-10 text-muted-foreground/30" />}
            />
          </div>
        )}
      </VolunteerListSection>
    </div>
  );
};

export default MyCertificates;
