import { useState, useEffect, useMemo } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { VolunteerListSection } from "@/components/shared/VolunteerListSection";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { Upload, FileText, AlertCircle, Eye, ImageIcon, Download, ExternalLink, X } from "lucide-react";
import { formatDate } from "@/lib/format-date";

const statusMap: Record<string, string> = { pending: "قيد المراجعة", approved: "مقبول", rejected: "مرفوض", needs_completion: "يحتاج استكمال" };
const statusVariant = (s: string) => s === "approved" ? "success" : s === "rejected" ? "danger" : "warning";

const isImageProof = (p: any) => {
  if (p?.file_type?.startsWith?.("image/")) return true;
  return /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(p?.file_name || "");
};
const isPdfProof = (p: any) => {
  if (p?.file_type?.includes?.("pdf")) return true;
  return /\.pdf$/i.test(p?.file_name || "");
};

// Group: one row per participation, containing all related proof attachments
type ProofGroup = {
  id: string; // participation_id
  participation_id: string;
  participations: any;
  uploaded_at: string;
  review_status: string;
  reviewer_notes: string | null;
  attachments: any[];
};

const MAX_FILES = 5;
const MAX_BYTES = 2 * 1024 * 1024;

const MyProofs = () => {
  const { volunteerId } = useRole();
  const [data, setData] = useState<any[]>([]);
  const [reuploadGroup, setReuploadGroup] = useState<ProofGroup | null>(null);
  const [previewGroup, setPreviewGroup] = useState<ProofGroup | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewName, setPreviewName] = useState<string>("");
  const [thumbUrls, setThumbUrls] = useState<Record<string, string>>({});
  const [uploading, setUploading] = useState(false);
  const [reuploadFiles, setReuploadFiles] = useState<File[]>([]);

  const fetchData = async () => {
    if (!volunteerId) return;
    const { data: rows } = await supabase
      .from("proofs")
      .select("*, participations(*, opportunities(title))")
      .eq("volunteer_id", volunteerId)
      .order("uploaded_at", { ascending: false });
    setData(rows || []);
  };

  useEffect(() => { fetchData(); }, [volunteerId]);

  // Group by participation_id so each participation appears as a single row
  const groups: ProofGroup[] = useMemo(() => {
    const map = new Map<string, ProofGroup>();
    for (const r of data) {
      const pid = r.participation_id;
      if (!pid) continue;
      const existing = map.get(pid);
      if (!existing) {
        map.set(pid, {
          id: pid,
          participation_id: pid,
          participations: r.participations,
          uploaded_at: r.uploaded_at,
          review_status: r.review_status,
          reviewer_notes: r.reviewer_notes,
          attachments: [r],
        });
      } else {
        existing.attachments.push(r);
        if (r.uploaded_at && (!existing.uploaded_at || r.uploaded_at > existing.uploaded_at)) {
          existing.uploaded_at = r.uploaded_at;
        }
        // Status priority: needs_completion > rejected > pending > approved
        const order = (s: string) => s === "needs_completion" ? 4 : s === "rejected" ? 3 : s === "pending" ? 2 : 1;
        if (order(r.review_status) > order(existing.review_status)) {
          existing.review_status = r.review_status;
          existing.reviewer_notes = r.reviewer_notes;
        }
      }
    }
    return Array.from(map.values()).sort((a, b) => (b.uploaded_at || "").localeCompare(a.uploaded_at || ""));
  }, [data]);

  // Preload signed URLs for images when preview opens
  useEffect(() => {
    if (!previewGroup) return;
    (async () => {
      const next: Record<string, string> = {};
      for (const att of previewGroup.attachments) {
        if (isImageProof(att) && att.file_path) {
          const { data: signed } = await supabase.storage.from("proofs").createSignedUrl(att.file_path, 300);
          if (signed?.signedUrl) next[att.id] = signed.signedUrl;
        }
      }
      setThumbUrls(next);
    })();
  }, [previewGroup]);

  const openAttachment = async (att: any) => {
    if (!att.file_path) return;
    const { data: signed, error } = await supabase.storage.from("proofs").createSignedUrl(att.file_path, 300);
    if (error || !signed?.signedUrl) { toast.error("خطأ في فتح الملف"); return; }
    if (isImageProof(att)) {
      setPreviewUrl(signed.signedUrl);
      setPreviewName(att.file_name || "");
    } else {
      window.open(signed.signedUrl, "_blank", "noopener");
    }
  };

  const downloadAttachment = async (att: any) => {
    if (!att.file_path) return;
    const { data: signed, error } = await supabase.storage.from("proofs").createSignedUrl(att.file_path, 300, { download: true });
    if (error || !signed?.signedUrl) { toast.error("خطأ في تنزيل الملف"); return; }
    const a = document.createElement("a");
    a.href = signed.signedUrl;
    a.download = att.file_name || "proof";
    document.body.appendChild(a); a.click(); a.remove();
  };

  const validateFile = (f: File): string | null => {
    const okType = f.type.startsWith("image/") || f.type === "application/pdf" || /\.(png|jpe?g|gif|webp|pdf)$/i.test(f.name);
    if (!okType) return "النوع غير مسموح — صور أو PDF فقط";
    if (f.size > MAX_BYTES) return "الملف أكبر من 2 ميجا";
    return null;
  };

  const handleAddFiles = (files: FileList | null) => {
    if (!files) return;
    const incoming = Array.from(files);
    const next: File[] = [...reuploadFiles];
    for (const f of incoming) {
      if (next.length >= MAX_FILES) { toast.error(`الحد الأقصى ${MAX_FILES} مرفقات`); break; }
      const err = validateFile(f);
      if (err) { toast.error(`${f.name}: ${err}`); continue; }
      next.push(f);
    }
    setReuploadFiles(next);
  };

  const handleReuploadSubmit = async () => {
    if (!reuploadGroup || !volunteerId || reuploadFiles.length === 0) return;
    setUploading(true);
    try {
      // Mark old proofs as superseded by deleting their rows then inserting fresh ones
      const oldIds = reuploadGroup.attachments.map(a => a.id);
      // Upload each new file
      for (const file of reuploadFiles) {
        const ext = file.name.split(".").pop() || "file";
        const path = `${reuploadGroup.participation_id}/${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
        const { error: uploadError } = await supabase.storage.from("proofs").upload(path, file);
        if (uploadError) throw uploadError;
        await supabase.from("proofs").insert({
          participation_id: reuploadGroup.participation_id,
          volunteer_id: volunteerId,
          file_path: path,
          file_name: file.name,
          file_type: file.type,
          review_status: "pending",
        });
      }
      // Remove old proofs from DB (storage files left as-is to be safe)
      if (oldIds.length > 0) {
        await supabase.from("proofs").delete().in("id", oldIds);
      }
      await supabase.from("participations").update({ proof_status: "submitted", approval_status: "pending" }).eq("id", reuploadGroup.participation_id);
      toast.success("تم إعادة رفع الإثبات بنجاح — سيتم مراجعته من الإدارة");
      setReuploadGroup(null);
      setReuploadFiles([]);
      await fetchData();
    } catch (error: any) {
      toast.error(`خطأ في الرفع: ${error?.message || "حدث خطأ"}`);
    } finally {
      setUploading(false);
    }
  };

  const canReupload = (g: ProofGroup) => ["rejected", "needs_completion"].includes(g.review_status);

  return (
    <div>
      <PageHeader title="إثباتاتي" description="عرض إثباتات مشاركاتي التطوعية" />
      <VolunteerListSection
        title="سجل الإثباتات"
        icon={<FileText className="h-4 w-4" />}
        total={groups.length}
        summary={[
          { label: "مقبول", value: groups.filter(g => g.review_status === "approved").length, variant: "success" },
          { label: "قيد المراجعة", value: groups.filter(g => g.review_status === "pending").length, variant: "warning" },
          { label: "مرفوض", value: groups.filter(g => ["rejected", "needs_completion"].includes(g.review_status)).length, variant: "danger" },
        ]}
      >
        {(limit) => (
          <DataTable
            columns={[
              { header: "الفرصة", accessor: (g: ProofGroup) => g.participations?.opportunities?.title || "—" },
              { header: "عدد المرفقات", accessor: (g: ProofGroup) => g.attachments.length },
              { header: "تاريخ الرفع", accessor: (g: ProofGroup) => formatDate(g.uploaded_at) },
              { header: "الحالة", accessor: (g: ProofGroup) => <StatusBadge status={statusMap[g.review_status] || g.review_status} variant={statusVariant(g.review_status)} /> },
              { header: "ملاحظات المشرف", accessor: (g: ProofGroup) => g.reviewer_notes || "—" },
              { header: "إجراء", accessor: (g: ProofGroup) => (
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => setPreviewGroup(g)}>
                    <Eye className="h-4 w-4 ml-1" />معاينة
                  </Button>
                  {canReupload(g) && (
                    <Button size="sm" variant="outline" onClick={() => { setReuploadGroup(g); setReuploadFiles([]); }}>
                      <Upload className="h-4 w-4 ml-1" />إعادة رفع
                    </Button>
                  )}
                </div>
              )},
            ]}
            data={limit ? groups.slice(0, limit) : groups}
            emptyMessage="لا توجد إثباتات"
            emptyIcon={<FileText className="h-10 w-10 text-muted-foreground/30" />}
          />
        )}
      </VolunteerListSection>

      {/* Preview Dialog (read-only, no edit/delete/replace) */}
      <Dialog open={!!previewGroup} onOpenChange={open => { if (!open) { setPreviewGroup(null); setThumbUrls({}); } }}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>معاينة المرفقات</DialogTitle>
          </DialogHeader>
          {previewGroup && (
            <div className="space-y-4">
              <div className="text-sm">
                <p className="text-muted-foreground">الفرصة: <strong className="text-foreground">{previewGroup.participations?.opportunities?.title || "—"}</strong></p>
                <p className="text-muted-foreground mt-1">الحالة: <StatusBadge status={statusMap[previewGroup.review_status] || previewGroup.review_status} variant={statusVariant(previewGroup.review_status)} /></p>
                {previewGroup.reviewer_notes && (
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/40 mt-2">
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-muted-foreground" />
                    <div>
                      <p className="font-medium text-xs mb-1">ملاحظة المشرف:</p>
                      <p className="text-foreground text-xs">{previewGroup.reviewer_notes}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {previewGroup.attachments.map(att => (
                  <div key={att.id} className="border border-border rounded-lg overflow-hidden bg-card">
                    {isImageProof(att) ? (
                      <button type="button" onClick={() => openAttachment(att)} className="block w-full h-32 bg-muted/30 overflow-hidden">
                        {thumbUrls[att.id]
                          ? <img src={thumbUrls[att.id]} alt={att.file_name || ""} className="w-full h-full object-cover" />
                          : <div className="w-full h-full flex items-center justify-center"><ImageIcon className="h-8 w-8 text-muted-foreground/40" /></div>}
                      </button>
                    ) : (
                      <button type="button" onClick={() => openAttachment(att)} className="block w-full h-32 bg-muted/30 flex items-center justify-center">
                        <FileText className="h-10 w-10 text-muted-foreground/60" />
                      </button>
                    )}
                    <div className="p-2 flex items-center justify-between gap-2">
                      <span className="text-xs truncate flex-1" title={att.file_name || ""}>{att.file_name || "—"}</span>
                      <div className="flex gap-1 shrink-0">
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openAttachment(att)} title="فتح">
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => downloadAttachment(att)} title="تنزيل">
                          <Download className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {previewGroup.review_status === "approved" && (
                <p className="text-xs text-muted-foreground text-center">العرض للمعاينة فقط — لا يمكن التعديل بعد الاعتماد</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Image lightbox */}
      {previewUrl && (
        <div className="fixed inset-0 z-[80] bg-black/80 flex flex-col items-center justify-center p-4" onClick={() => setPreviewUrl(null)}>
          <Button size="sm" variant="secondary" className="absolute top-3 left-3" onClick={(e) => { e.stopPropagation(); setPreviewUrl(null); }}>
            <X className="h-4 w-4" />
          </Button>
          <img src={previewUrl} alt={previewName} className="max-h-[85vh] max-w-[95vw] rounded shadow-lg" onClick={e => e.stopPropagation()} />
          <p className="mt-2 text-xs text-white/80">{previewName}</p>
        </div>
      )}

      {/* Re-upload Dialog */}
      <Dialog open={!!reuploadGroup} onOpenChange={open => { if (!open) { setReuploadGroup(null); setReuploadFiles([]); } }}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>إعادة رفع الإثبات</DialogTitle></DialogHeader>
          {reuploadGroup && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">الفرصة: <strong className="text-foreground">{reuploadGroup.participations?.opportunities?.title || "—"}</strong></p>
              {reuploadGroup.reviewer_notes && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/5 text-sm">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-destructive" />
                  <div>
                    <p className="font-medium text-destructive text-xs mb-1">ملاحظة المشرف:</p>
                    <p className="text-foreground">{reuploadGroup.reviewer_notes}</p>
                  </div>
                </div>
              )}
              <div>
                <Label>أضف الملفات (حد أقصى {MAX_FILES} — صور أو PDF — أقل من 2 ميجا)</Label>
                <Input
                  type="file"
                  multiple
                  accept="image/*,application/pdf"
                  className="mt-1.5"
                  disabled={uploading || reuploadFiles.length >= MAX_FILES}
                  onChange={e => { handleAddFiles(e.target.files); e.target.value = ""; }}
                />
              </div>
              {reuploadFiles.length > 0 && (
                <div className="space-y-1.5">
                  {reuploadFiles.map((f, i) => (
                    <div key={i} className="flex items-center justify-between rounded-md bg-muted/40 px-2 py-1.5 text-xs">
                      <span className="truncate flex-1">{f.name}</span>
                      <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setReuploadFiles(reuploadFiles.filter((_, idx) => idx !== i))} disabled={uploading}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
              <Button className="w-full" disabled={uploading || reuploadFiles.length === 0} onClick={handleReuploadSubmit}>
                {uploading ? "جارٍ الرفع..." : `رفع ${reuploadFiles.length} مرفق`}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyProofs;
