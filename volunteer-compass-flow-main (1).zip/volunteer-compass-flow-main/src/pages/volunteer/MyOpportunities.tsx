import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { notifyInternalNewApplication } from "@/lib/notifications";
import { toast } from "sonner";
import { Send, CalendarCheck, ChevronDown, ChevronUp } from "lucide-react";
import { formatDate } from "@/lib/format-date";

const appStatusMap: Record<string, string> = {
  pending: "قيد المراجعة",
  approved: "مقبول",
  rejected: "مرفوض",
};

type TimeWindowStatus = "not_started" | "open" | "ended";

const getTimeWindow = (opp: any): TimeWindowStatus => {
  const now = new Date();
  if (opp.start_at && new Date(opp.start_at) > now) return "not_started";
  if (opp.end_at && new Date(opp.end_at) < now) return "ended";
  return "open";
};

const INITIAL_LIMIT = 5;

const MyOpportunities = () => {
  const { volunteerId, userName } = useRole();
  const [opportunities, setOpportunities] = useState<any[]>([]);
  const [applications, setApplications] = useState<any[]>([]);
  const [participations, setParticipations] = useState<any[]>([]);
  const [, setLoading] = useState(true);
  const [applying, setApplying] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);

  const fetchData = async () => {
    if (!volunteerId) return;
    setLoading(true);
    const [oppRes, appRes, partRes] = await Promise.all([
      supabase
        .from("opportunities")
        .select("*, departments(name)")
        .eq("status", "active")
        .order("created_at", { ascending: false }),
      supabase
        .from("opportunity_applications")
        .select("*")
        .eq("volunteer_id", volunteerId),
      supabase
        .from("participations")
        .select("*, opportunities(title, start_at, end_at), proofs(id, review_status)")
        .eq("volunteer_id", volunteerId)
        .order("created_at", { ascending: false }),
    ]);
    setOpportunities(oppRes.data || []);
    setApplications(appRes.data || []);
    setParticipations(partRes.data || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, [volunteerId]);

  const getApplication = (oppId: string) => applications.find((a) => a.opportunity_id === oppId);
  const getParticipation = (oppId: string) => participations.find((p) => p.opportunity_id === oppId);
  const isFull = (opp: any) => opp.capacity > 0 && opp.participant_count >= opp.capacity;

  const handleApply = async (opp: any) => {
    if (!volunteerId) return;
    if (isFull(opp)) { toast.error("عذرًا، الفرصة ممتلئة"); return; }
    if (getTimeWindow(opp) === "ended") { toast.error("انتهت فترة التقديم على هذه الفرصة"); return; }
    setApplying(opp.id);
    const { data: inserted, error } = await supabase
      .from("opportunity_applications")
      .insert({ volunteer_id: volunteerId, opportunity_id: opp.id, status: "pending" })
      .select("id").single();
    if (error) {
      if (error.code === "23505") toast.error("لقد تقدمت مسبقًا لهذه الفرصة");
      else toast.error("حدث خطأ أثناء تقديم الطلب");
    } else if (inserted) {
      toast.success("تم تقديم طلبك بنجاح");
      notifyInternalNewApplication(userName || "متطوع", opp.title, inserted.id);
      fetchData();
    }
    setApplying(null);
  };

  const getVolunteerStatus = (opp: any) => {
    const app = getApplication(opp.id);
    const part = getParticipation(opp.id);
    const tw = getTimeWindow(opp);
    if (!app) {
      if (tw === "ended") return { label: "انتهت فترة التقديم", variant: "danger" as const, action: null };
      if (isFull(opp)) return { label: "ممتلئة", variant: "danger" as const, action: null };
      return { label: "متاحة", variant: "success" as const, action: "apply" };
    }
    if (app.status === "pending") return { label: "طلب قيد المراجعة", variant: "warning" as const, action: null };
    if (app.status === "rejected") return { label: "طلب مرفوض", variant: "danger" as const, action: null };
    if (!part) return { label: "مقبول — بانتظار المشاركة", variant: "success" as const, action: null };
    const proofs = part.proofs || [];
    const proofApproved = proofs.some((p: any) => p.review_status === "approved");
    const proofPending = proofs.some((p: any) => p.review_status === "pending");
    if (proofApproved) return { label: "مكتمل — الساعات محتسبة", variant: "success" as const, action: null };
    if (proofPending) return { label: "الإثبات قيد المراجعة", variant: "warning" as const, action: null };
    if (tw === "not_started") return { label: "مقبول — لم يبدأ بعد", variant: "primary" as const, action: null };
    if (tw === "ended") return { label: "بانتظار رفع الإثبات في «مشاركاتي»", variant: "warning" as const, action: null };
    return { label: "قيد التنفيذ", variant: "primary" as const, action: null };
  };

  const total = opportunities.length;
  const availableCount = opportunities.filter(o => {
    const s = getVolunteerStatus(o);
    return s.action === "apply";
  }).length;
  const hasMore = total > INITIAL_LIMIT;
  const visible = expanded || !hasMore ? opportunities : opportunities.slice(0, INITIAL_LIMIT);

  return (
    <div>
      <PageHeader title="الفرص المتاحة" description="عرض الفرص التطوعية المتاحة وتقديم طلب الانضمام" />

      <section className="bg-card rounded-lg border border-border p-4 md:p-5">
        <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-primary shrink-0"><CalendarCheck className="h-4 w-4" /></span>
            <h3 className="font-bold text-foreground text-sm">الفرص المتاحة</h3>
            <span className="text-xs text-muted-foreground bg-muted/60 rounded-full px-2 py-0.5">
              {total} {total === 1 ? "فرصة" : "فرص"}
            </span>
          </div>
          {availableCount > 0 && (
            <span className="text-[11px] px-2 py-0.5 rounded-full border bg-success/10 text-success border-success/20">
              متاحة للتقديم: {availableCount}
            </span>
          )}
        </header>

        <DataTable
          columns={[
            { header: "اسم الفرصة", accessor: "title" },
            { header: "الإدارة", accessor: (r: any) => r.departments?.name || "—" },
            { header: "البداية", accessor: (r: any) => r.start_at ? formatDate(r.start_at) : "—" },
            { header: "النهاية", accessor: (r: any) => r.end_at ? formatDate(r.end_at) : "—" },
            {
              header: "المقاعد",
              accessor: (r: any) => {
                if (!r.capacity || r.capacity === 0) return <span className="text-xs text-muted-foreground">مفتوحة</span>;
                const left = Math.max(0, r.capacity - (r.participant_count || 0));
                const full = left === 0;
                return <span className={`text-xs font-medium ${full ? "text-destructive" : "text-foreground"}`}>{full ? "ممتلئة" : `${left} متبقي`}</span>;
              },
            },
            {
              header: "الحالة",
              accessor: (r: any) => {
                const s = getVolunteerStatus(r);
                return <StatusBadge status={s.label} variant={s.variant} />;
              },
            },
            {
              header: "إجراء",
              accessor: (r: any) => {
                const s = getVolunteerStatus(r);
                if (s.action === "apply") {
                  return (
                    <Button size="sm" onClick={() => handleApply(r)} disabled={applying === r.id}>
                      <Send className="h-4 w-4 ml-1" />تقديم
                    </Button>
                  );
                }
                return <span className="text-xs text-muted-foreground">{appStatusMap[s.label] || ""}</span>;
              },
            },
          ]}
          data={visible}
          emptyMessage="لا توجد فرص تطوعية متاحة حاليًا"
          emptyIcon={<CalendarCheck className="h-10 w-10 text-muted-foreground/30" />}
        />

        {hasMore && (
          <div className="mt-3 flex justify-center">
            <Button variant="ghost" size="sm" onClick={() => setExpanded(e => !e)} className="text-xs text-primary hover:text-primary">
              {expanded
                ? <><ChevronUp className="h-3.5 w-3.5 ml-1" />عرض أقل</>
                : <><ChevronDown className="h-3.5 w-3.5 ml-1" />عرض الكل ({total})</>}
            </Button>
          </div>
        )}
      </section>
    </div>
  );
};

export default MyOpportunities;
