import { useState, useEffect, useMemo } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { VolunteerListSection } from "@/components/shared/VolunteerListSection";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { notifyInternalNewProof } from "@/lib/notifications";
import { toast } from "sonner";
import { Upload, AlertCircle, ClipboardList, X, FileText, ImageIcon, Plus } from "lucide-react";
import { formatDateTime } from "@/lib/format-date";
import { formatHours } from "@/lib/hours-format";

type TimeWindowStatus = "not_started" | "running" | "ended";

const isDateOnlyValue = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value);
const isMidnightTimestamp = (value: string) =>
  /^\d{4}-\d{2}-\d{2}T00:00(?::00(?:\.0+)?)?(?:Z|[+-]\d{2}:\d{2})?$/.test(value);

const parseOpportunityDate = (value: string | null | undefined, boundary: "start" | "end") => {
  if (!value) return null;
  const normalizedDate = isDateOnlyValue(value)
    ? value
    : isMidnightTimestamp(value) ? value.slice(0, 10) : null;
  if (normalizedDate) {
    return new Date(`${normalizedDate}T${boundary === "start" ? "00:00:00" : "23:59:59.999"}`);
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
};

type DetailedTimeWindow = "not_started" | "before_unlock" | "running" | "ended";

const getTimeWindow = (opp: any): TimeWindowStatus => {
  if (!opp) return "running";
  const now = new Date();
  const startAt = parseOpportunityDate(opp.start_at, "start");
  const endAt = parseOpportunityDate(opp.end_at, "end");
  if (startAt && startAt > now) return "not_started";
  if (endAt && endAt < now) return "ended";
  return "running";
};

// Detailed window that takes proof_unlock_after_hours into account
const getDetailedWindow = (opp: any): DetailedTimeWindow => {
  if (!opp) return "running";
  const now = new Date();
  const startAt = parseOpportunityDate(opp.start_at, "start");
  const endAt = parseOpportunityDate(opp.end_at, "end");
  if (startAt && startAt > now) return "not_started";
  if (endAt && endAt < now) return "ended";
  // Between start and end → check unlock-after-hours
  const unlockAfter = Number(opp.proof_unlock_after_hours ?? 0);
  if (startAt && unlockAfter > 0) {
    const unlockAt = new Date(startAt.getTime() + unlockAfter * 3600 * 1000);
    if (now < unlockAt) return "before_unlock";
  }
  return "running";
};

// Compute proof upload deadline locally (mirrors DB logic for display only)
const computeProofDeadline = (row: any): Date | null => {
  // Manual override window from supervisor
  if (row.proof_reopened_until) {
    const d = new Date(row.proof_reopened_until);
    if (!Number.isNaN(d.getTime())) return d;
  }
  if (row.proof_upload_deadline) {
    const d = new Date(row.proof_upload_deadline);
    if (!Number.isNaN(d.getTime())) return d;
  }
  // Fallback: opportunity end + proof_window_hours (default 168 = 7 days)
  const endStr = row.opportunities?.end_at;
  if (!endStr) return null;
  const end = parseOpportunityDate(endStr, "end");
  if (!end) return null;
  const hours = Number(row.opportunities?.proof_window_hours ?? 168);
  return new Date(end.getTime() + hours * 3600 * 1000);
};

// Local fallback: is the proof upload window currently open based on time fields?
const isProofWindowOpenLocal = (row: any): boolean => {
  const opp = row.opportunities;
  if (!opp) return false;
  const dw = getDetailedWindow(opp);
  if (dw === "not_started" || dw === "before_unlock") return false;
  // dw is "running" (between unlock and end) OR "ended" (after end)
  // For "running": always allow upload
  if (dw === "running") return true;
  // For "ended": allow until deadline (end + proof_window_hours, default 168h)
  const deadline = computeProofDeadline(row);
  if (!deadline) return false;
  return Date.now() < deadline.getTime();
};

// Status label + canUpload determined from server-side flag (canUploadProof) + local time window
const getDisplayStatus = (row: any, canUploadProof: boolean) => {
  const proofs = row.proofs || [];
  const dw = getDetailedWindow(row.opportunities);
  const proofApproved = row.approval_status === "approved" || proofs.some((p: any) => p.review_status === "approved");
  const proofPending = row.proof_status === "submitted" || proofs.some((p: any) => p.review_status === "pending");
  const proofRejected =
    row.approval_status === "rejected" ||
    row.approval_status === "needs_completion" ||
    proofs.some((p: any) => ["rejected", "needs_completion"].includes(p.review_status));

  // Effective upload-allowed: server flag OR local time window says open
  const localOpen = isProofWindowOpenLocal(row);
  const effectiveCanUpload = canUploadProof || localOpen;

  if (proofApproved) return { label: "مكتمل", variant: "success" as const, canUpload: false };
  if (proofPending) return { label: "الإثبات قيد المراجعة", variant: "warning" as const, canUpload: false };

  if (proofRejected) {
    if (effectiveCanUpload) return { label: "تم طلب إعادة رفع الإثبات", variant: "danger" as const, canUpload: true };
    return { label: "الإثبات مرفوض", variant: "danger" as const, canUpload: false };
  }

  if (dw === "not_started") return { label: "لم يبدأ بعد", variant: "primary" as const, canUpload: false };
  if (dw === "before_unlock") return { label: "رفع الإثبات غير متاح بعد", variant: "warning" as const, canUpload: false };
  if (effectiveCanUpload) return { label: "جاهز لرفع الإثبات", variant: "success" as const, canUpload: true };
  if (dw === "running") return { label: "أثناء التنفيذ", variant: "primary" as const, canUpload: false };
  return { label: "انتهت مهلة رفع الإثبات", variant: "danger" as const, canUpload: false };
};

const formatExecutionWindow = (opp: any) => {
  if (!opp?.start_at && !opp?.end_at) return "—";
  const start = opp?.start_at ? formatDateTime(opp.start_at) : "—";
  const end = opp?.end_at ? formatDateTime(opp.end_at) : "—";
  return `${start} — ${end}`;
};

const formatRemaining = (row: any, canUploadProof: boolean) => {
  const opp = row.opportunities;
  const now = Date.now();
  const proofApproved = row.approval_status === "approved";
  if (proofApproved) return "مكتمل";

  const start = opp?.start_at ? parseOpportunityDate(opp.start_at, "start") : null;
  const end = opp?.end_at ? parseOpportunityDate(opp.end_at, "end") : null;

  // Before start
  if (start && now < start.getTime()) return "لم يبدأ بعد";

  // Before proof_unlock_after_hours
  const unlockAfter = Number(opp?.proof_unlock_after_hours ?? 0);
  if (start && unlockAfter > 0) {
    const unlockAt = start.getTime() + unlockAfter * 3600 * 1000;
    if (now < unlockAt) {
      const diff = unlockAt - now;
      const hrs = Math.floor(diff / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      const prefix = "حتى فتح رفع الإثبات: ";
      if (hrs > 0) return `${prefix}${hrs} ساعة ${mins} دقيقة`;
      return `${prefix}${mins} دقيقة`;
    }
  }

  // Before start (defensive)
  if (start && now < start.getTime()) return "لم يبدأ بعد";

  // During execution → show time until end
  if (end && now < end.getTime()) {
    const diff = end.getTime() - now;
    const hrs = Math.floor(diff / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    if (hrs >= 24) {
      const days = Math.floor(hrs / 24);
      const remHrs = hrs % 24;
      return `${days} يوم ${remHrs} ساعة`;
    }
    if (hrs > 0) return `${hrs} ساعة ${mins} دقيقة`;
    return `${mins} دقيقة`;
  }

  // After end → proof upload window
  const deadline = computeProofDeadline(row);
  if (deadline && now < deadline.getTime()) {
    const diff = deadline.getTime() - now;
    const days = Math.floor(diff / (24 * 3600000));
    const hrs = Math.floor((diff % (24 * 3600000)) / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    const prefix = "لرفع الإثبات: ";
    if (days > 0) return `${prefix}${days} يوم ${hrs} ساعة`;
    if (hrs > 0) return `${prefix}${hrs} ساعة ${mins} دقيقة`;
    return `${prefix}${mins} دقيقة`;
  }

  // After deadline
  if (canUploadProof) return "نافذة مفتوحة من المشرف";
  return "انتهت مهلة رفع الإثبات";
};

// ===== Upload constraints =====
const MAX_FILES = 5;
const MAX_FILE_SIZE_BYTES = 2 * 1024 * 1024; // 2MB per file
const ALLOWED_MIME_PREFIXES = ["image/"];
const ALLOWED_MIME_EXACT = ["application/pdf"];
const ALLOWED_EXT = /\.(png|jpe?g|gif|webp|bmp|svg|pdf)$/i;

const isAllowedFile = (f: File) => {
  if (f.type) {
    if (ALLOWED_MIME_PREFIXES.some(p => f.type.startsWith(p))) return true;
    if (ALLOWED_MIME_EXACT.includes(f.type)) return true;
  }
  return ALLOWED_EXT.test(f.name || "");
};

const MyParticipations = () => {
  const { volunteerId, userName } = useRole();
  const [data, setData] = useState<any[]>([]);
  const [hoursByParticipation, setHoursByParticipation] = useState<Record<string, number>>({});
  const [proofOpenMap, setProofOpenMap] = useState<Record<string, boolean>>({});
  const [uploadPartId, setUploadPartId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  // tick to recompute time-based labels every 60s
  const [, setTick] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTick(x => x + 1), 60_000);
    return () => clearInterval(t);
  }, []);

  const fetchData = async () => {
    if (!volunteerId) return;
    const [partRes, hoursRes] = await Promise.all([
      supabase
        .from("participations")
        .select("*, opportunities(title, start_at, end_at, minimum_hours, proof_window_hours, proof_unlock_after_hours), proofs(id, review_status, uploaded_at)")
        .eq("volunteer_id", volunteerId)
        .order("created_at", { ascending: false }),
      supabase
        .from("volunteer_hours")
        .select("participation_id, approved_hours")
        .eq("volunteer_id", volunteerId)
        .eq("status", "approved"),
    ]);

    if (partRes.error || hoursRes.error) {
      console.error("Participations fetch error:", partRes.error || hoursRes.error);
      toast.error("تعذر تحميل المشاركات");
      return;
    }

    const rows = partRes.data || [];
    setData(rows);
    setHoursByParticipation(
      Object.fromEntries(
        (hoursRes.data || [])
          .filter((row: any) => row.participation_id)
          .map((row: any) => [row.participation_id, row.approved_hours]),
      ),
    );

    // Fetch authoritative proof-window flag per participation via RPC
    const flagEntries = await Promise.all(
      rows.map(async (r: any) => {
        try {
          const { data: open } = await supabase.rpc("is_proof_upload_open", { participation_id: r.id });
          return [r.id, Boolean(open)] as const;
        } catch {
          return [r.id, false] as const;
        }
      }),
    );
    setProofOpenMap(Object.fromEntries(flagEntries));
  };

  useEffect(() => {
    fetchData();
  }, [volunteerId]);

  const addFiles = (files: File[]) => {
    if (!files.length) return;
    const accepted: File[] = [];
    let rejectedType = 0;
    let rejectedSize = 0;
    let rejectedCount = 0;

    const remainingSlots = Math.max(0, MAX_FILES - selectedFiles.length);
    if (remainingSlots <= 0) {
      toast.error(`لا يمكن رفع أكثر من ${MAX_FILES} مرفقات`);
      return;
    }

    for (const f of files) {
      if (accepted.length >= remainingSlots) {
        rejectedCount++;
        continue;
      }
      if (!isAllowedFile(f)) { rejectedType++; continue; }
      if (f.size > MAX_FILE_SIZE_BYTES) { rejectedSize++; continue; }
      accepted.push(f);
    }

    if (rejectedType > 0) toast.error("المسموح فقط: صورة أو PDF");
    if (rejectedSize > 0) toast.error("الحد الأقصى لحجم الملف 2MB");
    if (rejectedCount > 0) toast.error(`الحد الأقصى ${MAX_FILES} مرفقات`);

    if (accepted.length > 0) {
      setSelectedFiles(prev => [...prev, ...accepted]);
    }
  };

  const removeFileAt = (idx: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== idx));
  };

  const resetUploadDialog = () => {
    setSelectedFiles([]);
    setUploadPartId(null);
  };

  const handleSubmitProofs = async () => {
    if (!uploadPartId) return;
    if (!volunteerId) {
      toast.error("تعذر تحديد حساب المتطوع الحالي");
      return;
    }
    if (selectedFiles.length === 0) {
      toast.error("يرجى اختيار ملف واحد على الأقل");
      return;
    }

    const participationId = uploadPartId;
    setUploading(true);

    try {
      // Upload all files to storage and create one proofs row per file
      const uploaded: { path: string; name: string; type: string }[] = [];
      for (const file of selectedFiles) {
        const ext = file.name.split(".").pop() || "file";
        const path = `${participationId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        const { error: uploadError } = await supabase.storage.from("proofs").upload(path, file);
        if (uploadError) throw uploadError;
        uploaded.push({ path, name: file.name, type: file.type || "" });
      }

      // Check existing proof rows for this participation
      const { data: existing, error: existingError } = await supabase
        .from("proofs")
        .select("id")
        .eq("participation_id", participationId);

      if (existingError) throw existingError;

      let firstProofId: string | null = null;

      if (existing && existing.length > 0) {
        // Update first existing row with the first file, then insert the rest as new rows
        const [first, ...rest] = uploaded;
        const { error: updateProofError } = await supabase
          .from("proofs")
          .update({
            file_path: first.path,
            file_name: first.name,
            file_type: first.type,
            uploaded_at: new Date().toISOString(),
            review_status: "pending",
            reviewer_notes: null,
          })
          .eq("id", existing[0].id);
        if (updateProofError) throw updateProofError;
        firstProofId = existing[0].id;

        // Delete other prior proof rows (replacing previous attempt)
        if (existing.length > 1) {
          const otherIds = existing.slice(1).map((p: any) => p.id);
          await supabase.from("proofs").delete().in("id", otherIds);
        }

        if (rest.length > 0) {
          const inserts = rest.map(u => ({
            participation_id: participationId,
            volunteer_id: volunteerId,
            file_path: u.path,
            file_name: u.name,
            file_type: u.type,
            review_status: "pending",
          }));
          const { error: insertExtraError } = await supabase.from("proofs").insert(inserts);
          if (insertExtraError) throw insertExtraError;
        }
      } else {
        const inserts = uploaded.map(u => ({
          participation_id: participationId,
          volunteer_id: volunteerId,
          file_path: u.path,
          file_name: u.name,
          file_type: u.type,
          review_status: "pending",
        }));
        const { data: insertedProofs, error: insertProofError } = await supabase
          .from("proofs")
          .insert(inserts)
          .select("id");
        if (insertProofError) throw insertProofError;
        firstProofId = insertedProofs?.[0]?.id || null;
      }

      const { error: participationUpdateError } = await supabase
        .from("participations")
        .update({ proof_status: "submitted", approval_status: "pending" })
        .eq("id", participationId);

      if (participationUpdateError) throw participationUpdateError;

      const { data: part } = await supabase
        .from("participations")
        .select("opportunities(title)")
        .eq("id", participationId)
        .single();

      if (firstProofId) {
        notifyInternalNewProof(userName || "متطوع", (part as any)?.opportunities?.title || "", firstProofId);
      }

      toast.success(`تم رفع ${selectedFiles.length} مرفق — سيتم مراجعته من الإدارة`);
      resetUploadDialog();
      await fetchData();
    } catch (error: any) {
      console.error("Upload proof from MyParticipations failed:", error);
      toast.error(`تعذر رفع الإثبات: ${error?.message || "حدث خطأ غير متوقع"}`);
    } finally {
      setUploading(false);
    }
  };

  const formatApprovedHours = (row: any) => {
    const approvedHours = hoursByParticipation[row.id];
    if (typeof approvedHours === "number" && approvedHours > 0) return formatHours(approvedHours);

    // Fallback: derive from started_at/ended_at when total_minutes is missing
    let minutes = Number(row.total_minutes || 0);
    if ((!minutes || minutes <= 0) && row.started_at && row.ended_at) {
      const diff = Math.round((new Date(row.ended_at).getTime() - new Date(row.started_at).getTime()) / 60000);
      if (diff > 0) minutes = Math.min(diff, 720);
    }
    if (minutes > 0) return formatHours(minutes / 60);

    if (row.approval_status === "approved" && row.opportunities?.minimum_hours) {
      return formatHours(row.opportunities.minimum_hours);
    }
    return "—";
  };

  const remainingSlots = Math.max(0, MAX_FILES - selectedFiles.length);

  return (
    <div>
      <PageHeader title="مشاركاتي" description="عرض مشاركاتي في الفرص التطوعية ورفع الإثباتات" />
      <div className="mt-4">
        <VolunteerListSection
          title="سجل المشاركات"
          icon={<ClipboardList className="h-4 w-4" />}
          total={data.length}
          summary={[
            { label: "مكتمل", value: data.filter((r: any) => r.approval_status === "approved").length, variant: "success" },
            { label: "قيد المراجعة", value: data.filter((r: any) => r.approval_status === "pending" || r.proof_status === "submitted").length, variant: "warning" },
            { label: "مرفوض", value: data.filter((r: any) => ["rejected", "needs_completion"].includes(r.approval_status)).length, variant: "danger" },
          ]}
        >
          {(limit) => (
            <DataTable
              columns={[
                { header: "اسم الفرصة", accessor: (row: any) => row.opportunities?.title || "—" },
                { header: "فترة التنفيذ", accessor: (row: any) => formatExecutionWindow(row.opportunities) },
                {
                  header: "الحالة",
                  accessor: (row: any) => {
                    const status = getDisplayStatus(row, !!proofOpenMap[row.id]);
                    return <StatusBadge status={status.label} variant={status.variant} />;
                  },
                },
                {
                  header: "الوقت المتبقي",
                  accessor: (row: any) => <span className="text-xs">{formatRemaining(row, !!proofOpenMap[row.id])}</span>,
                },
                { header: "الساعات المعتمدة", accessor: (row: any) => formatApprovedHours(row) },
                {
                  header: "الإجراء",
                  accessor: (row: any) => {
                    const status = getDisplayStatus(row, !!proofOpenMap[row.id]);
                    if (status.canUpload) {
                      return (
                        <Button size="sm" onClick={() => { setSelectedFiles([]); setUploadPartId(row.id); }}>
                          <Upload className="h-4 w-4 ml-1" />رفع الإثبات
                        </Button>
                      );
                    }
                    return <span className="text-xs text-muted-foreground">—</span>;
                  },
                },
              ]}
              data={limit ? data.slice(0, limit) : data}
              emptyMessage="لا توجد مشاركات حتى الآن"
              emptyIcon={<ClipboardList className="h-10 w-10 text-muted-foreground/30" />}
            />
          )}
        </VolunteerListSection>
      </div>

      <Dialog open={!!uploadPartId} onOpenChange={open => { if (!open && !uploading) resetUploadDialog(); }}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>رفع إثبات المشاركة</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <div className="space-y-0.5 leading-relaxed">
                <p>يمكن رفع حتى {MAX_FILES} مرفقات.</p>
                <p>المسموح: صورة أو PDF فقط.</p>
                <p>الحد الأقصى لحجم الملف: 2MB.</p>
              </div>
            </div>

            <div>
              <Label>المرفقات ({selectedFiles.length}/{MAX_FILES})</Label>
              <label
                className={`mt-1.5 flex items-center justify-center gap-2 h-10 rounded-md border border-dashed border-input bg-background hover:bg-accent cursor-pointer text-sm ${
                  uploading || remainingSlots === 0 ? "opacity-50 pointer-events-none" : ""
                }`}
              >
                <Plus className="h-4 w-4" />
                <span>{remainingSlots > 0 ? `إضافة ملف (متبقٍ ${remainingSlots})` : "تم الوصول للحد الأقصى"}</span>
                <input
                  type="file"
                  multiple
                  className="hidden"
                  accept="image/*,.pdf,application/pdf"
                  disabled={uploading || remainingSlots === 0}
                  onChange={e => {
                    const files = Array.from(e.target.files || []);
                    addFiles(files);
                    e.target.value = "";
                  }}
                />
              </label>
            </div>

            {selectedFiles.length > 0 && (
              <ul className="space-y-1.5 max-h-48 overflow-y-auto">
                {selectedFiles.map((f, idx) => {
                  const isImg = f.type.startsWith("image/");
                  return (
                    <li
                      key={`${f.name}-${idx}`}
                      className="flex items-center gap-2 rounded-md border border-border bg-background/60 px-2 py-1.5 text-xs"
                    >
                      {isImg
                        ? <ImageIcon className="h-3.5 w-3.5 text-primary shrink-0" />
                        : <FileText className="h-3.5 w-3.5 text-primary shrink-0" />}
                      <span className="truncate flex-1" title={f.name}>{f.name}</span>
                      <span className="text-muted-foreground shrink-0">{(f.size / 1024).toFixed(0)} KB</span>
                      <button
                        type="button"
                        className="text-muted-foreground hover:text-destructive shrink-0"
                        onClick={() => removeFileAt(idx)}
                        disabled={uploading}
                        title="حذف"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={resetUploadDialog} disabled={uploading}>إلغاء</Button>
              <Button onClick={handleSubmitProofs} disabled={uploading || selectedFiles.length === 0}>
                {uploading ? "جارٍ الرفع..." : `رفع ${selectedFiles.length || ""}`.trim()}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyParticipations;
