import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { VolunteerListSection } from "@/components/shared/VolunteerListSection";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { Plus, MessageCircle, Send, TicketCheck, Search } from "lucide-react";
import { formatDate, formatDateTime } from "@/lib/format-date";
import { notifyNewTicket, notifyTicketReply } from "@/lib/ticket-notifications";
import { uploadTicketAttachment } from "@/lib/ticket-attachments";
import { AttachmentPickerButton, MessageAttachments, useMessageAttachments } from "@/components/tickets/TicketAttachments";

const statusMap: Record<string, string> = { open: "مفتوحة", in_progress: "قيد المعالجة", waiting_reply: "بانتظار الرد", closed: "مغلقة" };
const statusVariant = (s: string) => s === "closed" ? "neutral" : s === "open" ? "warning" : s === "in_progress" ? "primary" : "success";
const categoryMap: Record<string, string> = { general: "عام", technical: "تقني", account: "حسابي", opportunity: "فرصة تطوعية", hours: "ساعات", other: "أخرى" };
const priorityMap: Record<string, string> = { low: "منخفضة", medium: "متوسطة", high: "عالية", urgent: "عاجلة" };
const priorityVariant = (s: string) => s === "urgent" ? "danger" : s === "high" ? "warning" : "neutral";

const MyTickets = () => {
  const { volunteerId, userName } = useRole();
  const [tickets, setTickets] = useState<any[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [detailTicket, setDetailTicket] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [form, setForm] = useState({ title: "", category: "general", priority: "medium", description: "" });
  const [createFile, setCreateFile] = useState<File | null>(null);
  const [chatFile, setChatFile] = useState<File | null>(null);
  const [attachmentsRefresh, setAttachmentsRefresh] = useState(0);
  const messageIds = messages.map((m: any) => m.id);
  const attachmentsMap = useMessageAttachments(messageIds, attachmentsRefresh);

  const fetchTickets = async () => {
    if (!volunteerId) return;
    const { data } = await supabase.from("support_tickets").select("*").eq("volunteer_id", volunteerId).order("updated_at", { ascending: false });
    setTickets(data || []);
  };

  const fetchMessages = async (ticketId: string) => {
    const { data } = await supabase.from("support_ticket_messages").select("*").eq("ticket_id", ticketId).order("created_at", { ascending: true });
    setMessages(data || []);
  };

  useEffect(() => { fetchTickets(); }, [volunteerId]);

  const handleCreate = async () => {
    if (!volunteerId || !form.title.trim()) {
      toast.error("الرجاء إدخال عنوان التذكرة");
      return;
    }
    if (!form.description.trim() && !createFile) {
      toast.error("اكتب وصفًا أو أرفق ملفًا");
      return;
    }
    const { data: ticket, error } = await supabase.from("support_tickets").insert({
      volunteer_id: volunteerId, title: form.title, category: form.category, priority: form.priority,
    }).select("id, ticket_number").single();
    if (error) { toast.error(`خطأ: ${error.message}`); return; }

    const { data: msg, error: msgErr } = await supabase.from("support_ticket_messages").insert({
      ticket_id: ticket.id, sender_type: "volunteer", sender_name: userName || "متطوع",
      message: form.description.trim() || "(مرفق)",
    }).select("id").single();

    if (!msgErr && msg && createFile) {
      const res = await uploadTicketAttachment({ ticketId: ticket.id, messageId: msg.id, file: createFile });
      if (res.ok === false) toast.error(`تعذر رفع المرفق: ${res.error}`);
    }

    notifyNewTicket(userName || "متطوع", form.title, ticket.id);
    toast.success("تم إنشاء التذكرة بنجاح");
    setForm({ title: "", category: "general", priority: "medium", description: "" });
    setCreateFile(null);
    setCreateOpen(false);
    fetchTickets();
  };

  const openDetail = async (ticket: any) => {
    setDetailTicket(ticket);
    setChatFile(null);
    await fetchMessages(ticket.id);
  };

  const sendMessage = async () => {
    if (!detailTicket) return;
    if (!newMessage.trim() && !chatFile) return;
    setSending(true);

    const { data: msg, error } = await supabase.from("support_ticket_messages").insert({
      ticket_id: detailTicket.id, sender_type: "volunteer", sender_name: userName || "متطوع",
      message: newMessage.trim() || "(مرفق)",
    }).select("id").single();

    if (!error && msg && chatFile) {
      const res = await uploadTicketAttachment({ ticketId: detailTicket.id, messageId: msg.id, file: chatFile });
      if (res.ok === false) toast.error(`تعذر رفع المرفق: ${res.error}`);
    }

    if (detailTicket.status === "waiting_reply") {
      await supabase.from("support_tickets").update({ status: "open", updated_at: new Date().toISOString() }).eq("id", detailTicket.id);
      setDetailTicket({ ...detailTicket, status: "open" });
    }
    notifyTicketReply(detailTicket.volunteer_id, detailTicket.title, detailTicket.id, "volunteer");
    setNewMessage("");
    setChatFile(null);
    await fetchMessages(detailTicket.id);
    setAttachmentsRefresh(x => x + 1);
    setSending(false);
  };

  const filtered = tickets.filter(t => {
    if (search && !t.title.includes(search) && !(t.ticket_number || "").includes(search)) return false;
    if (filterStatus !== "all" && t.status !== filterStatus) return false;
    return true;
  });
  const openCount = tickets.filter(t => t.status !== "closed").length;

  return (
    <div>
      <PageHeader
        title="تذاكر الدعم"
        description={`إنشاء ومتابعة تذاكر الدعم${openCount > 0 ? ` — ${openCount} نشطة` : ""}`}
        actions={
          <Button onClick={() => setCreateOpen(true)}><Plus className="h-4 w-4 ml-2" />تذكرة جديدة</Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="بحث بالعنوان أو رقم التذكرة..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40 h-10"><SelectValue placeholder="الحالة" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الحالات</SelectItem>
            {Object.entries(statusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <VolunteerListSection
        title="سجل التذاكر"
        icon={<TicketCheck className="h-4 w-4" />}
        total={filtered.length}
        summary={[
          { label: "مفتوحة", value: tickets.filter(t => t.status === "open").length, variant: "warning" },
          { label: "قيد المعالجة", value: tickets.filter(t => t.status === "in_progress").length, variant: "primary" },
          { label: "مغلقة", value: tickets.filter(t => t.status === "closed").length, variant: "neutral" },
        ]}
      >
        {(limit) => (
          <DataTable
            columns={[
              { header: "رقم التذكرة", accessor: (r: any) => <span className="font-mono text-xs">{r.ticket_number || "—"}</span> },
              { header: "العنوان", accessor: "title" },
              { header: "التصنيف", accessor: (r: any) => categoryMap[r.category] || r.category },
              { header: "الأولوية", accessor: (r: any) => <StatusBadge status={priorityMap[r.priority] || r.priority} variant={priorityVariant(r.priority)} /> },
              { header: "الحالة", accessor: (r: any) => <StatusBadge status={statusMap[r.status] || r.status} variant={statusVariant(r.status)} /> },
              { header: "آخر تحديث", accessor: (r: any) => formatDateTime(r.updated_at || r.created_at) },
              { header: "تفاصيل", accessor: (r: any) => (
                <Button variant="ghost" size="sm" onClick={() => openDetail(r)}>
                  <MessageCircle className="h-4 w-4 text-primary" />
                </Button>
              )},
            ]}
            data={limit ? filtered.slice(0, limit) : filtered}
            emptyMessage="لا توجد تذاكر دعم"
            emptyIcon={<TicketCheck className="h-10 w-10 text-muted-foreground/30" />}
          />
        )}
      </VolunteerListSection>

      {/* Create Ticket Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>إنشاء تذكرة دعم جديدة</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>العنوان *</Label><Input className="mt-1.5" placeholder="عنوان التذكرة" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>التصنيف</Label>
                <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(categoryMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>الأولوية</Label>
                <Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(priorityMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>الوصف *</Label><Textarea className="mt-1.5" rows={4} placeholder="اشرح مشكلتك بالتفصيل..." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
            <div>
              <Label className="text-xs text-muted-foreground">إرفاق ملف (اختياري)</Label>
              <div className="mt-1.5">
                <AttachmentPickerButton
                  selectedFile={createFile}
                  onSelect={setCreateFile}
                  onClear={() => setCreateFile(null)}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline" onClick={() => setCreateFile(null)}>إلغاء</Button></DialogClose>
            <Button onClick={handleCreate}>إنشاء التذكرة</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Ticket Detail Dialog */}
      <Dialog open={!!detailTicket} onOpenChange={open => { if (!open) setDetailTicket(null); }}>
        <DialogContent className="max-w-lg max-h-[85vh] flex flex-col" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-base flex items-center gap-2">
              {detailTicket?.ticket_number && <span className="font-mono text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">{detailTicket.ticket_number}</span>}
              {detailTicket?.title}
            </DialogTitle>
            <div className="flex gap-2 mt-1">
              <StatusBadge status={statusMap[detailTicket?.status] || ""} variant={statusVariant(detailTicket?.status || "")} />
              <StatusBadge status={priorityMap[detailTicket?.priority] || ""} variant={priorityVariant(detailTicket?.priority || "")} />
              <span className="text-xs text-muted-foreground">{categoryMap[detailTicket?.category] || ""}</span>
            </div>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto space-y-3 py-2 min-h-[200px]">
            {messages.map(msg => (
              <div key={msg.id} className={`rounded-lg p-3 text-sm ${msg.sender_type === "volunteer" ? "bg-primary/5 mr-4" : "bg-muted ml-4"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-xs">{msg.sender_name} {msg.sender_type === "admin" ? "(مسؤول)" : ""}</span>
                  <span className="text-[10px] text-muted-foreground">{formatDateTime(msg.created_at)}</span>
                </div>
                <p className="whitespace-pre-wrap">{msg.message}</p>
                <MessageAttachments items={attachmentsMap[msg.id] || []} />
              </div>
            ))}
          </div>
          {detailTicket?.status !== "closed" && (
            <div className="flex flex-col gap-2 pt-2 border-t border-border">
              <div className="flex gap-2">
                <Textarea className="flex-1 min-h-[40px]" rows={2} placeholder="اكتب ردك..." value={newMessage} onChange={e => setNewMessage(e.target.value)} />
                <Button size="icon" className="shrink-0 self-end" onClick={sendMessage} disabled={sending || (!newMessage.trim() && !chatFile)}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              <AttachmentPickerButton
                selectedFile={chatFile}
                onSelect={setChatFile}
                onClear={() => setChatFile(null)}
                disabled={sending}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyTickets;
