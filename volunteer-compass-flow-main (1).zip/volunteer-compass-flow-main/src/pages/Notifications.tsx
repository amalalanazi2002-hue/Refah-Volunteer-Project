import { useState, useEffect, useCallback, useMemo } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Bell, CheckCheck, ExternalLink, ChevronDown, ChevronUp, User, Clock, AlertCircle, MessageSquare, Paperclip, Send, Download, Eye, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { useNavigate } from "react-router-dom";
import { formatDateTime } from "@/lib/format-date";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { parseSender, parseAttachments, encodeSender, encodeAttachment, AttachmentMeta } from "@/lib/broadcast-meta";
import { sanitizeHtml, isHtml } from "@/lib/safe-html";
import { toast } from "sonner";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  read_at: string | null;
  created_at: string;
  action_url: string | null;
  action_label: string | null;
  action_type: string | null;
  requires_action: boolean;
  related_entity_type: string | null;
  related_entity_id: string | null;
}

interface ReplyRow {
  id: string;
  created_at: string;
  user_type: string;
  user_id: string;
  senderName?: string;
  cleanText: string;
  attachments: AttachmentMeta[];
}

const typeMap: Record<string, string> = {
  new_opportunity: "فرصة جديدة",
  opportunity_started: "بدء فرصة",
  proof_approved: "إثبات مقبول",
  proof_rejected: "إثبات مرفوض",
  proof_needs_completion: "استكمال إثبات",
  participation_started: "بدء مشاركة",
  participation_ended: "انتهاء مشاركة",
  application_submitted: "إشعار",
  application_approved: "قبول طلب",
  application_rejected: "رفض طلب",
};

const typeVariant = (t: string) => {
  if (t.includes("approved")) return "success";
  if (t.includes("rejected")) return "danger";
  if (t.includes("needs_completion")) return "warning";
  return "primary";
};

const MAX_ATTACH_BYTES = 2 * 1024 * 1024;
const REPLIES_PREVIEW = 3;
const ATTACH_PREVIEW = 3;

const isImageType = (name?: string, type?: string) => {
  if (type?.startsWith("image/")) return true;
  return /\.(png|jpe?g|gif|webp|svg|bmp)$/i.test(name || "");
};

const isPdfType = (name?: string, type?: string) => {
  if (type === "application/pdf") return true;
  return /\.pdf$/i.test(name || "");
};

const humanSize = (n?: number) => {
  if (!n) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
};

const NotificationsPage = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Notification | null>(null);
  const [replies, setReplies] = useState<ReplyRow[]>([]);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "action" | "unread">("all");
  const [showAllReplies, setShowAllReplies] = useState(false);
  const [showAllAttachments, setShowAllAttachments] = useState(false);
  const { userId, volunteerId, userName, isVolunteer } = useRole();
  const navigate = useNavigate();

  const currentId = isVolunteer ? volunteerId : userId;
  const currentType = isVolunteer ? "volunteer" : "internal";
  const senderId = isVolunteer ? volunteerId : userId;

  const fetchNotifications = useCallback(async () => {
    if (!currentId) return;
    setLoading(true);
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_type", currentType)
      .eq("user_id", currentId)
      .order("created_at", { ascending: false });
    const filtered = (data as Notification[] || []).filter(n => n.related_entity_type !== "broadcast_reply");
    setNotifications(filtered);
    setLoading(false);
  }, [currentId, currentType]);

  useEffect(() => { fetchNotifications(); }, [fetchNotifications]);

  const [replyText, setReplyText] = useState("");
  const [sendingReply, setSendingReply] = useState(false);
  const [uploadingAttach, setUploadingAttach] = useState(false);

  const markAsRead = async (id: string) => {
    const nowIso = new Date().toISOString();
    await supabase.from("notifications").update({ is_read: true, read_at: nowIso }).eq("id", id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true, read_at: nowIso } : n));
    setActive(prev => prev && prev.id === id ? { ...prev, is_read: true, read_at: nowIso } : prev);
  };

  const fetchReplies = useCallback(async (n: Notification) => {
    if (!n.related_entity_id) { setReplies([]); return; }
    const { data } = await supabase
      .from("notifications")
      .select("id, message, created_at, user_type, user_id")
      .eq("related_entity_id", n.related_entity_id)
      .eq("related_entity_type", "broadcast_reply")
      .order("created_at", { ascending: true });
    const rows = (data || []) as any[];
    const enriched: ReplyRow[] = rows.map(r => {
      const ps = parseSender(r.message);
      return {
        id: r.id,
        created_at: r.created_at,
        user_type: r.user_type,
        user_id: r.user_id,
        senderName: ps.name,
        cleanText: ps.clean,
        attachments: parseAttachments(r.message),
      };
    });
    setReplies(enriched);
  }, []);

  const openNotification = async (n: Notification) => {
    setActive(n);
    setReplyText("");
    setShowAllReplies(false);
    setShowAllAttachments(false);
    if (!n.is_read) markAsRead(n.id);
    fetchReplies(n);
  };

  const markAllRead = async () => {
    if (!currentId) return;
    const nowIso = new Date().toISOString();
    await supabase.from("notifications").update({ is_read: true, read_at: nowIso })
      .eq("user_type", currentType).eq("user_id", currentId).eq("is_read", false);
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true, read_at: n.read_at || nowIso })));
  };

  const sendReply = async (extraAttachment?: AttachmentMeta) => {
    if (!active || !active.related_entity_id) return;
    if (!extraAttachment && !replyText.trim()) { toast.error("اكتب رسالة الرد"); return; }
    const sender = parseSender(active.message);
    if (!sender.id) { toast.error("لا يمكن تحديد المرسل الأصلي للإشعار"); return; }
    setSendingReply(true);
    const body = (replyText || (extraAttachment ? `📎 ${extraAttachment.name}` : "")).trim();
    const safe = sanitizeHtml(body);
    const withSender = encodeSender(safe, userName || "—", senderId || "");
    const finalMessage = extraAttachment ? `${withSender}\n${encodeAttachment(extraAttachment)}` : withSender;
    const { error } = await supabase.from("notifications").insert({
      user_type: "internal",
      user_id: sender.id,
      title: `رد على: ${active.title}`,
      message: finalMessage,
      type: "application_submitted",
      related_entity_type: "broadcast_reply",
      related_entity_id: active.related_entity_id,
      is_read: false,
      requires_action: false,
    } as any);
    setSendingReply(false);
    if (error) { toast.error(`فشل إرسال الرد: ${error.message}`); return; }
    toast.success("تم إرسال الرد");
    setReplyText("");
    fetchReplies(active);
  };

  const handleAttachment = async (file: File) => {
    if (!active || !active.related_entity_id) return;
    if (file.size > MAX_ATTACH_BYTES) {
      toast.error(`حجم الملف ${humanSize(file.size)} يتجاوز الحد الأقصى 2MB`);
      return;
    }
    setUploadingAttach(true);
    const safeName = file.name.replace(/[^\w.\-]/g, "_");
    const path = `broadcast-replies/${active.related_entity_id}/${Date.now()}-${safeName}`;
    const { error: upErr } = await supabase.storage.from("proofs").upload(path, file, {
      contentType: file.type || undefined,
      upsert: false,
    });
    if (upErr) {
      setUploadingAttach(false);
      toast.error(`فشل رفع الملف: ${upErr.message}`);
      return;
    }
    await sendReply({ name: file.name, path, type: file.type, size: file.size });
    setUploadingAttach(false);
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;
  const actionCount = notifications.filter(n => n.requires_action && !n.is_read).length;

  const filteredNotifications = useMemo(() => {
    if (filter === "action") return notifications.filter(n => n.requires_action);
    if (filter === "unread") return notifications.filter(n => !n.is_read);
    return notifications;
  }, [notifications, filter]);

  const [expanded, setExpanded] = useState(false);
  const INITIAL = 5;
  const hasMore = isVolunteer && filteredNotifications.length > INITIAL;
  const visible = isVolunteer && !expanded && hasMore ? filteredNotifications.slice(0, INITIAL) : filteredNotifications;

  const activeParsed = useMemo(() => active ? parseSender(active.message) : null, [active]);
  const activeAttachments = useMemo(() => active ? parseAttachments(active.message) : [], [active]);

  const visibleAttachments = showAllAttachments ? activeAttachments : activeAttachments.slice(0, ATTACH_PREVIEW);
  const visibleReplies = showAllReplies ? replies : replies.slice(-REPLIES_PREVIEW);
  const hiddenRepliesCount = replies.length - visibleReplies.length;

  return (
    <div>
      <PageHeader
        title="التنبيهات"
        description="جميع التنبيهات والإشعارات الخاصة بك"
        actions={
          unreadCount > 0 ? (
            <Button variant="outline" size="sm" onClick={markAllRead}>
              <CheckCheck className="h-4 w-4 ml-1" />
              تعليم الكل كمقروء ({unreadCount})
            </Button>
          ) : undefined
        }
      />

      {!loading && notifications.length > 0 && (
        <Tabs value={filter} onValueChange={(v) => { setFilter(v as any); setExpanded(false); }} className="mb-4">
          <TabsList>
            <TabsTrigger value="all">الكل ({notifications.length})</TabsTrigger>
            <TabsTrigger value="action">
              الإجراءات {actionCount > 0 && <span className="ml-1 mr-1 px-1.5 rounded bg-warning/20 text-warning text-[10px]">{actionCount}</span>}
            </TabsTrigger>
            <TabsTrigger value="unread">غير مقروء ({unreadCount})</TabsTrigger>
          </TabsList>
        </Tabs>
      )}

      {loading ? (
        <p className="text-sm text-muted-foreground">جارٍ التحميل...</p>
      ) : filteredNotifications.length === 0 ? (
        <div className="bg-card rounded-lg border border-border p-12 text-center">
          <Bell className="h-10 w-10 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground text-sm">{filter === "action" ? "لا توجد إجراءات حالية" : "لا توجد تنبيهات"}</p>
        </div>
      ) : (
        <>
          <div className="space-y-2">
            {visible.map(n => {
              const parsed = parseSender(n.message);
              const atts = parseAttachments(n.message);
              return (
                <div
                  key={n.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => openNotification(n)}
                  onKeyDown={(e) => { if (e.key === "Enter") openNotification(n); }}
                  className={`bg-card rounded-lg border p-4 transition-colors cursor-pointer hover:bg-muted/30 ${
                    n.requires_action && !n.is_read
                      ? "border-warning/40 bg-warning/[0.04]"
                      : !n.is_read
                        ? "border-primary/30 bg-primary/[0.02]"
                        : "border-border"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <h4 className={`text-sm ${!n.is_read ? "font-bold" : "font-medium"} text-foreground`}>
                          {n.title}
                        </h4>
                        <StatusBadge status={typeMap[n.type] || n.type} variant={typeVariant(n.type)} />
                        {n.requires_action && (
                          <StatusBadge status="يتطلب إجراء" variant="warning" />
                        )}
                        {atts.length > 0 && (
                          <span className="text-[10px] flex items-center gap-1 text-muted-foreground">
                            <Paperclip className="h-3 w-3" />{atts.length}
                          </span>
                        )}
                      </div>
                      {isHtml(parsed.clean) ? (
                        <div className="text-sm text-muted-foreground leading-relaxed line-clamp-2 [&_*]:!text-muted-foreground [&_img]:hidden [&_a]:underline"
                          dangerouslySetInnerHTML={{ __html: sanitizeHtml(parsed.clean) }} />
                      ) : (
                        <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line line-clamp-2">{parsed.clean}</p>
                      )}
                      <div className="flex items-center gap-3 mt-1.5 text-[11px] text-muted-foreground/70 flex-wrap">
                        <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{formatDateTime(n.created_at)}</span>
                        {parsed.name && (
                          <span className="flex items-center gap-1"><User className="h-3 w-3" />من: {parsed.name}</span>
                        )}
                      </div>
                    </div>
                    {n.requires_action && (
                      <Button size="sm" variant="outline" className="shrink-0 h-7 text-[11px] border-warning/40 text-warning hover:bg-warning/10" onClick={(e) => { e.stopPropagation(); openNotification(n); }}>
                        متابعة
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {hasMore && (
            <div className="mt-3 flex justify-center">
              <Button variant="ghost" size="sm" onClick={() => setExpanded(e => !e)} className="text-xs text-primary hover:text-primary">
                {expanded
                  ? <><ChevronUp className="h-3.5 w-3.5 ml-1" />عرض أقل</>
                  : <><ChevronDown className="h-3.5 w-3.5 ml-1" />عرض الكل ({filteredNotifications.length})</>}
              </Button>
            </div>
          )}
        </>
      )}

      {/* Reading dialog */}
      <Dialog open={!!active} onOpenChange={() => setActive(null)}>
        <DialogContent dir="rtl" className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 flex-wrap">
              <span>{active?.title}</span>
              {active && <StatusBadge status={typeMap[active.type] || active.type} variant={typeVariant(active.type)} />}
              {active?.requires_action && <StatusBadge status="يتطلب إجراء" variant="warning" />}
            </DialogTitle>
            <DialogDescription className="sr-only">تفاصيل الإشعار</DialogDescription>
          </DialogHeader>
          {active && (
            <div className="space-y-4">
              <div className="bg-muted/30 border border-border rounded-lg p-4">
                {isHtml(activeParsed?.clean || "") ? (
                  <div className="text-sm text-foreground leading-relaxed prose prose-sm max-w-none [&_img]:max-w-full [&_img]:rounded [&_a]:text-primary [&_a]:underline"
                    dangerouslySetInnerHTML={{ __html: sanitizeHtml(activeParsed?.clean || "") }} />
                ) : (
                  <p className="text-sm text-foreground whitespace-pre-line leading-relaxed">{activeParsed?.clean}</p>
                )}
              </div>

              {activeAttachments.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-foreground mb-2 flex items-center gap-1.5">
                    <Paperclip className="h-3.5 w-3.5 text-primary" />المرفقات ({activeAttachments.length})
                  </h4>
                  <AttachmentList atts={visibleAttachments} onPreview={setPreviewImage} />
                  {activeAttachments.length > ATTACH_PREVIEW && (
                    <div className="mt-2 flex justify-center">
                      <Button variant="ghost" size="sm" className="text-[11px] h-7 text-primary"
                        onClick={() => setShowAllAttachments(s => !s)}>
                        {showAllAttachments
                          ? <><ChevronUp className="h-3 w-3 ml-1" />عرض أقل</>
                          : <><ChevronDown className="h-3 w-3 ml-1" />عرض كل المرفقات ({activeAttachments.length})</>}
                      </Button>
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <MetaCell icon={User} label="المرسل" value={activeParsed?.name || "النظام"} />
                <MetaCell icon={Clock} label="تاريخ الإرسال" value={formatDateTime(active.created_at)} />
                <MetaCell icon={CheckCheck} label="حالة القراءة"
                  value={active.is_read ? (active.read_at ? formatDateTime(active.read_at) : "مقروء") : "لم يُقرأ بعد"} />
              </div>

              {active.requires_action && (
                <div className="border border-warning/30 bg-warning/[0.04] rounded-lg p-3 space-y-2">
                  <p className="text-xs font-medium text-warning flex items-center gap-1.5">
                    <AlertCircle className="h-3.5 w-3.5" />يتطلب هذا الإشعار اتخاذ إجراء
                  </p>
                  {(active.action_type === "external" || (!active.action_type && active.action_url && /^https?:/i.test(active.action_url))) && active.action_url && (
                    <a href={active.action_url} target="_blank" rel="noopener noreferrer" className="block">
                      <Button className="w-full"><ExternalLink className="h-4 w-4 ml-1" />{active.action_label || "فتح الرابط"}</Button>
                    </a>
                  )}
                  {(active.action_type === "internal_route" || (!active.action_type && active.action_url?.startsWith("/"))) && active.action_url && (
                    <Button className="w-full" onClick={() => { setActive(null); navigate(active.action_url!); }}>
                      <ExternalLink className="h-4 w-4 ml-1" />{active.action_label || "فتح الصفحة"}
                    </Button>
                  )}
                  {active.action_type === "reply" && (
                    <div className="space-y-2">
                      <Textarea value={replyText} onChange={e => setReplyText(e.target.value)} placeholder="اكتب ردك..." className="min-h-[90px]" />
                      <Button className="w-full" disabled={!replyText.trim() || sendingReply} onClick={() => sendReply()}>
                        <Send className="h-4 w-4 ml-1" />{sendingReply ? "جارٍ الإرسال..." : (active.action_label || "إرسال الرد")}
                      </Button>
                    </div>
                  )}
                  {active.action_type === "attachment" && (
                    <label className="block cursor-pointer">
                      <input type="file" className="hidden" disabled={uploadingAttach}
                        onChange={e => { const f = e.target.files?.[0]; if (f) handleAttachment(f); e.target.value=""; }} />
                      <Button asChild className="w-full" disabled={uploadingAttach}>
                        <span><Paperclip className="h-4 w-4 ml-1" />
                          {uploadingAttach ? "جارٍ الرفع..." : (active.action_label || "إرفاق ملف")}
                          <span className="text-[10px] opacity-70 mr-1">(ملف واحد، حد أقصى 2MB)</span>
                        </span>
                      </Button>
                    </label>
                  )}
                </div>
              )}

              {/* Replies thread */}
              {(replies.length > 0 || active.action_type === "reply" || active.action_type === "attachment") && (
                <div className="border-t border-border pt-3">
                  <h4 className="text-xs font-bold text-foreground mb-2 flex items-center gap-1.5">
                    <MessageSquare className="h-3.5 w-3.5 text-primary" />الردود ({replies.length})
                  </h4>
                  {replies.length === 0 ? (
                    <p className="text-[11px] text-muted-foreground bg-muted/30 rounded p-2 text-center">لا توجد ردود بعد</p>
                  ) : (
                    <>
                      {hiddenRepliesCount > 0 && (
                        <div className="mb-2 flex justify-center">
                          <Button variant="ghost" size="sm" className="text-[11px] h-7 text-primary"
                            onClick={() => setShowAllReplies(true)}>
                            <ChevronDown className="h-3 w-3 ml-1" />عرض الردود السابقة ({hiddenRepliesCount})
                          </Button>
                        </div>
                      )}
                      <div className="space-y-2">
                        {visibleReplies.map(r => (
                          <div key={r.id} className="bg-background border border-border rounded-md p-3">
                            <div className="flex items-center justify-between gap-2 mb-1.5 flex-wrap">
                              <div className="flex items-center gap-1.5 text-xs">
                                <User className="h-3 w-3 text-primary" />
                                <span className="font-semibold text-foreground">{r.senderName || (r.user_type === "volunteer" ? "متطوع" : "مستخدم داخلي")}</span>
                              </div>
                              <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                <Clock className="h-2.5 w-2.5" />{formatDateTime(r.created_at)}
                              </span>
                            </div>
                            {r.cleanText && (
                              isHtml(r.cleanText) ? (
                                <div className="text-xs text-foreground/90 leading-relaxed prose prose-sm max-w-none [&_a]:text-primary [&_a]:underline"
                                  dangerouslySetInnerHTML={{ __html: sanitizeHtml(r.cleanText) }} />
                              ) : (
                                <p className="text-xs text-foreground/90 whitespace-pre-line leading-relaxed">{r.cleanText}</p>
                              )
                            )}
                            {r.attachments.length > 0 && (
                              <div className="mt-2">
                                <AttachmentList atts={r.attachments} onPreview={setPreviewImage} compact />
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                      {showAllReplies && replies.length > REPLIES_PREVIEW && (
                        <div className="mt-2 flex justify-center">
                          <Button variant="ghost" size="sm" className="text-[11px] h-7 text-muted-foreground"
                            onClick={() => setShowAllReplies(false)}>
                            <ChevronUp className="h-3 w-3 ml-1" />عرض أقل
                          </Button>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Image preview lightbox */}
      <Dialog open={!!previewImage} onOpenChange={() => setPreviewImage(null)}>
        <DialogContent dir="rtl" className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>معاينة المرفق</DialogTitle>
            <DialogDescription className="sr-only">معاينة الصورة المرفقة</DialogDescription>
          </DialogHeader>
          {previewImage && (
            <img src={previewImage} alt="مرفق" className="w-full h-auto rounded-md max-h-[70vh] object-contain bg-muted" />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

const MetaCell = ({ icon: Icon, label, value }: { icon: any; label: string; value: string }) => (
  <div className="bg-background border border-border rounded-md p-2.5">
    <div className="flex items-center gap-1.5 text-muted-foreground mb-1"><Icon className="h-3 w-3" />{label}</div>
    <div className="font-medium text-foreground truncate">{value}</div>
  </div>
);

interface ResolvedAtt extends AttachmentMeta {
  url?: string;
  error?: string;
}

const AttachmentList = ({ atts, onPreview, compact }: { atts: AttachmentMeta[]; onPreview: (url: string) => void; compact?: boolean }) => {
  const [resolved, setResolved] = useState<ResolvedAtt[]>(() => atts.map(a => ({ ...a })));

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const out: ResolvedAtt[] = await Promise.all(
        atts.map(async (a) => {
          const { data, error } = await supabase.storage.from("proofs").createSignedUrl(a.path, 3600);
          if (error || !data?.signedUrl) return { ...a, error: error?.message || "تعذر تحميل الملف" };
          return { ...a, url: data.signedUrl };
        })
      );
      if (!cancelled) setResolved(out);
    })();
    return () => { cancelled = true; };
  }, [atts]);

  const downloadFile = async (a: ResolvedAtt) => {
    const { data, error } = await supabase.storage.from("proofs").createSignedUrl(a.path, 300, { download: a.name });
    if (error || !data?.signedUrl) { toast.error(`تعذر تنزيل الملف: ${error?.message || ""}`); return; }
    window.open(data.signedUrl, "_blank");
  };

  return (
    <div className={`grid gap-2 ${compact ? "grid-cols-1" : "sm:grid-cols-2"}`}>
      {resolved.map((a, i) => {
        const isImg = isImageType(a.name, a.type);
        const isPdf = isPdfType(a.name, a.type);
        return (
          <div key={i} className="flex items-center gap-2 border border-border rounded-md bg-background p-2">
            <div className="h-12 w-12 rounded bg-muted flex items-center justify-center shrink-0 overflow-hidden">
              {isImg && a.url
                ? <img src={a.url} alt={a.name} className="h-full w-full object-cover" loading="lazy" />
                : isPdf
                  ? <FileText className="h-5 w-5 text-destructive" />
                  : <FileText className="h-5 w-5 text-muted-foreground" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-foreground truncate" title={a.name}>{a.name}</div>
              <div className="text-[10px] text-muted-foreground truncate">
                {humanSize(a.size)}{a.type ? ` • ${a.type}` : isPdf ? " • PDF" : ""}
              </div>
              {a.error && <div className="text-[10px] text-destructive mt-0.5">{a.error}</div>}
            </div>
            <div className="flex items-center gap-1 shrink-0">
              {(isImg || isPdf) && a.url && (
                <Button size="sm" variant="ghost" className="h-7 px-2"
                  onClick={() => isImg ? onPreview(a.url!) : window.open(a.url!, "_blank")}
                  title={isImg ? "معاينة" : "فتح"}>
                  <Eye className="h-3.5 w-3.5" />
                </Button>
              )}
              <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]"
                disabled={!!a.error}
                onClick={() => downloadFile(a)}>
                <Download className="h-3 w-3 ml-1" />تنزيل
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default NotificationsPage;
