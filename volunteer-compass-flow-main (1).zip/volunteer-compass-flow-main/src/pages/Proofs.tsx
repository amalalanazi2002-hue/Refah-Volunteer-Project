import { useState, useEffect, useCallback, useMemo } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, FileText, ImageIcon, Download, ExternalLink, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { notifyProofDecision } from "@/lib/notifications";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { formatDate } from "@/lib/format-date";

const reviewStatusMap: Record<string, string> = { pending: "قيد المراجعة", approved: "مقبول", rejected: "مرفوض", needs_completion: "يحتاج استكمال" };
const statusVariant = (s: string) => s === "approved" ? "success" : s === "rejected" ? "danger" : "warning";

const isImageProof = (p: any) => {
  if (p?.file_type?.startsWith?.("image/")) return true;
  return /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(p?.file_name || "");
};
const isPdfProof = (p: any) => {
  if (p?.file_type?.includes?.("pdf")) return true;
  return /\.pdf$/i.test(p?.file_name || "");
};

// Aggregate group: one row per participation, containing all related proof attachments
type ProofGroup = {
  id: string; // participation_id
  participation_id: string;
  volunteer_id: string;
  volunteers: any;
  participations: any;
  uploaded_at: string;
  review_status: string;
  reviewer_notes: string | null;
  attachments: any[]; // raw proof rows
};

const Proofs = () => {
  const [data, setData] = useState<any[]>([]);
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [openGroupId, setOpenGroupId] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewName, setPreviewName] = useState<string>("");
  const { canReview } = useRole();

  const fetchData = useCallback(async () => {
    const { data: rows } = await supabase.from("proofs").select("*, volunteers(full_name), participations(*, opportunities(title))").order("uploaded_at", { ascending: false });
    setData(rows || []);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Group rows by participation_id so each participation appears as a single row
  const groups: ProofGroup[] = useMemo(() => {
    const map = new Map<string, ProofGroup>();
    for (const r of data) {
      const pid = r.participation_id;
      if (!pid) continue;
      const existing = map.get(pid);
      if (!existing) {
        map.set(pid, {
          id: pid,
          participation_id: pid,
          volunteer_id: r.volunteer_id,
          volunteers: r.volunteers,
          participations: r.participations,
          uploaded_at: r.uploaded_at,
          review_status: r.review_status,
          reviewer_notes: r.reviewer_notes,
          attachments: [r],
        });
      } else {
        existing.attachments.push(r);
        // Most recent upload wins for top-level fields
        if (r.uploaded_at && (!existing.uploaded_at || r.uploaded_at > existing.uploaded_at)) {
          existing.uploaded_at = r.uploaded_at;
        }
        // Status priority: pending > needs_completion > rejected > approved (so reviewer sees actionable first)
        const order = (s: string) => s === "pending" ? 4 : s === "needs_completion" ? 3 : s === "rejected" ? 2 : 1;
        if (order(r.review_status) > order(existing.review_status)) {
          existing.review_status = r.review_status;
          existing.reviewer_notes = r.reviewer_notes;
        }
      }
    }
    return Array.from(map.values()).sort((a, b) => (b.uploaded_at || "").localeCompare(a.uploaded_at || ""));
  }, [data]);

  const handleReview = async (group: ProofGroup, decision: "approved" | "rejected" | "needs_completion") => {
    const notes = reviewNotes[group.id] || "";
    // Apply decision to all attachments of the group
    const ids = group.attachments.map(a => a.id);
    const { error: proofError } = await supabase.from("proofs").update({ review_status: decision, reviewer_notes: notes || null }).in("id", ids);
    if (proofError) { toast.error("خطأ في تحديث الإثبات"); return; }
    await supabase.from("participations").update({ approval_status: decision }).eq("id", group.participation_id);
    if (decision === "approved" && group.participations) {
      const participation = group.participations;
      const opp = participation.opportunities;
      const approvedHours = participation.total_minutes > 0
        ? Math.round(((participation.total_minutes || 0) / 60) * 100) / 100
        : Number(opp?.minimum_hours || 0);
      const { data: existing } = await supabase.from("volunteer_hours").select("id").eq("participation_id", group.participation_id).limit(1);
      if (existing && existing.length > 0) {
        await supabase.from("volunteer_hours").update({ approved_hours: approvedHours, approval_date: new Date().toISOString().split("T")[0], status: "approved" }).eq("id", existing[0].id);
      } else {
        await supabase.from("volunteer_hours").insert({ volunteer_id: group.volunteer_id, participation_id: group.participation_id, opportunity_id: participation.opportunity_id, approved_hours: approvedHours, approval_date: new Date().toISOString().split("T")[0], status: "approved" });
      }

      // Certificate is auto-generated by database trigger.
      await supabase.from("generated_certificates").select("id").eq("participation_id", group.participation_id).limit(1);
    }
    if (decision === "rejected") {
      const { data: existingHours } = await supabase.from("volunteer_hours").select("id").eq("participation_id", group.participation_id).limit(1);
      if (existingHours && existingHours.length > 0) await supabase.from("volunteer_hours").update({ status: "reversed" }).eq("id", existingHours[0].id);
    }
    notifyProofDecision(group.volunteer_id, group.participations?.opportunities?.title || "", group.attachments[0]?.id || "", decision);
    const msgs: Record<string, string> = { approved: "تم قبول الإثبات واحتساب الساعات", rejected: "تم رفض الإثبات", needs_completion: "تم طلب استكمال الإثبات" };
    toast.success(msgs[decision]);
    setReviewNotes(prev => ({ ...prev, [group.id]: "" }));
    setOpenGroupId(null);
    fetchData();
  };

  const filtered = groups.filter((g) => {
    if (search && !(g.volunteers?.full_name || "").includes(search) && !(g.participations?.opportunities?.title || "").includes(search)) return false;
    if (filterStatus !== "all" && g.review_status !== filterStatus) return false;
    return true;
  });

  const exportData = filtered.map(g => ({
    volunteer: g.volunteers?.full_name || "—",
    opportunity: g.participations?.opportunities?.title || "—",
    attachments_count: g.attachments.length,
    date: formatDate(g.uploaded_at),
    status: reviewStatusMap[g.review_status] || g.review_status,
    notes: g.reviewer_notes || "—",
  }));
  const exportCols = [
    { header: "المتطوع", key: "volunteer" }, { header: "الفرصة", key: "opportunity" },
    { header: "عدد المرفقات", key: "attachments_count" }, { header: "تاريخ الرفع", key: "date" },
    { header: "الحالة", key: "status" }, { header: "ملاحظات", key: "notes" },
  ];

  // Open an attachment: image → in-app preview, others → new tab
  const openAttachment = async (att: any) => {
    if (!att.file_path) return;
    const { data: signedData, error } = await supabase.storage.from("proofs").createSignedUrl(att.file_path, 300);
    if (error || !signedData?.signedUrl) { toast.error("خطأ في فتح الملف"); return; }
    if (isImageProof(att)) {
      setPreviewUrl(signedData.signedUrl);
      setPreviewName(att.file_name || "");
    } else {
      window.open(signedData.signedUrl, "_blank", "noopener");
    }
  };

  const downloadAttachment = async (att: any) => {
    if (!att.file_path) return;
    const { data: signedData, error } = await supabase.storage.from("proofs").createSignedUrl(att.file_path, 300, { download: true });
    if (error || !signedData?.signedUrl) { toast.error("خطأ في تنزيل الملف"); return; }
    const a = document.createElement("a");
    a.href = signedData.signedUrl;
    a.download = att.file_name || "proof";
    document.body.appendChild(a); a.click(); a.remove();
  };

  // Preload signed URLs for image thumbnails when dialog opens
  const [thumbUrls, setThumbUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    if (!openGroupId) return;
    const group = groups.find(g => g.id === openGroupId);
    if (!group) return;
    let cancelled = false;
    (async () => {
      const entries = await Promise.all(
        group.attachments
          .filter(a => isImageProof(a) && a.file_path)
          .map(async (a): Promise<[string, string] | null> => {
            const { data: signed } = await supabase.storage.from("proofs").createSignedUrl(a.file_path, 300);
            if (!signed?.signedUrl) return null;
            return [a.id, signed.signedUrl];
          }),
      );
      if (cancelled) return;
      const map: Record<string, string> = {};
      for (const e of entries) if (e) map[e[0]] = e[1];
      setThumbUrls(map);
    })();
    return () => { cancelled = true; };
  }, [openGroupId, groups]);

  return (
    <div>
      <PageHeader title="الإثباتات" description="مراجعة إثباتات المشاركات التطوعية" actions={
        <ExportButtons data={exportData} columns={exportCols} title="الإثباتات" filename="proofs" />
      } />

      <div className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="بحث بالمتطوع أو الفرصة..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40 h-10"><SelectValue placeholder="حالة المراجعة" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الحالات</SelectItem>
            <SelectItem value="pending">قيد المراجعة</SelectItem>
            <SelectItem value="approved">مقبول</SelectItem>
            <SelectItem value="rejected">مرفوض</SelectItem>
            <SelectItem value="needs_completion">يحتاج استكمال</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable
        columns={[
          { header: "المتطوع", accessor: (g: ProofGroup) => g.volunteers?.full_name || "—" },
          { header: "الفرصة", accessor: (g: ProofGroup) => g.participations?.opportunities?.title || "—" },
          { header: "عدد المرفقات", accessor: (g: ProofGroup) => g.attachments.length },
          { header: "تاريخ الرفع", accessor: (g: ProofGroup) => formatDate(g.uploaded_at) },
          { header: "الحالة", accessor: (g: ProofGroup) => <StatusBadge status={reviewStatusMap[g.review_status] || g.review_status} variant={statusVariant(g.review_status)} /> },
          { header: "إجراءات", accessor: (g: ProofGroup) => (
            <Dialog open={openGroupId === g.id} onOpenChange={(open) => setOpenGroupId(open ? g.id : null)}>
              <DialogTrigger asChild><Button variant="outline" size="sm">معاينة</Button></DialogTrigger>
              <DialogContent dir="rtl" className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader><DialogTitle>معاينة الإثبات</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div className="text-sm space-y-1.5 rounded-lg bg-muted/40 p-3">
                    <p><strong>المتطوع:</strong> {g.volunteers?.full_name || "—"}</p>
                    <p><strong>الفرصة:</strong> {g.participations?.opportunities?.title || "—"}</p>
                    <p><strong>تاريخ الرفع:</strong> {formatDate(g.uploaded_at)}</p>
                    <p><strong>عدد المرفقات:</strong> {g.attachments.length}</p>
                    {g.reviewer_notes && <p><strong>ملاحظات سابقة:</strong> {g.reviewer_notes}</p>}
                  </div>

                  {g.attachments.length === 0 && (
                    <div className="bg-muted rounded-lg p-8 text-center text-sm text-muted-foreground border-2 border-dashed border-border">
                      لا توجد مرفقات
                    </div>
                  )}

                  {/* Images grid */}
                  {g.attachments.some(isImageProof) && (
                    <div>
                      <Label className="text-xs text-muted-foreground">الصور</Label>
                      <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {g.attachments.filter(isImageProof).map(att => (
                          <div key={att.id} className="group relative rounded-lg border border-border bg-background overflow-hidden">
                            <button
                              type="button"
                              onClick={() => openAttachment(att)}
                              className="block w-full aspect-square bg-muted"
                              title={att.file_name}
                            >
                              {thumbUrls[att.id]
                                ? <img src={thumbUrls[att.id]} alt={att.file_name} className="w-full h-full object-cover" />
                                : <div className="w-full h-full flex items-center justify-center"><ImageIcon className="h-6 w-6 text-muted-foreground" /></div>}
                            </button>
                            <div className="flex items-center justify-between gap-1 px-2 py-1 text-[11px] border-t border-border">
                              <span className="truncate" title={att.file_name}>{att.file_name}</span>
                              <button type="button" onClick={() => downloadAttachment(att)} className="text-muted-foreground hover:text-foreground" title="تنزيل">
                                <Download className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* PDFs / other files list */}
                  {g.attachments.some(a => !isImageProof(a)) && (
                    <div>
                      <Label className="text-xs text-muted-foreground">ملفات</Label>
                      <ul className="mt-2 space-y-1.5">
                        {g.attachments.filter(a => !isImageProof(a)).map(att => (
                          <li key={att.id} className="flex items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm">
                            <FileText className={`h-4 w-4 shrink-0 ${isPdfProof(att) ? "text-destructive" : "text-primary"}`} />
                            <span className="truncate flex-1" title={att.file_name}>{att.file_name || "ملف"}</span>
                            <Button variant="outline" size="sm" onClick={() => openAttachment(att)} title="فتح">
                              <ExternalLink className="h-3.5 w-3.5 ml-1" />فتح
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => downloadAttachment(att)} title="تنزيل">
                              <Download className="h-3.5 w-3.5 ml-1" />تنزيل
                            </Button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {canReview && (g.review_status === "pending" || g.review_status === "needs_completion") && (
                    <>
                      <div>
                        <Label>ملاحظات المشرف</Label>
                        <Textarea placeholder="أدخل ملاحظاتك..." className="mt-1.5" value={reviewNotes[g.id] || ""} onChange={e => setReviewNotes(prev => ({ ...prev, [g.id]: e.target.value }))} />
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        <Button className="bg-success hover:bg-success/90 text-success-foreground" onClick={() => handleReview(g, "approved")}>قبول</Button>
                        <Button variant="destructive" onClick={() => handleReview(g, "rejected")}>رفض</Button>
                        <Button variant="outline" onClick={() => handleReview(g, "needs_completion")}>طلب استكمال</Button>
                      </div>
                    </>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          )},
        ]}
        data={filtered}
        emptyMessage="لا توجد إثباتات حاليًا"
        emptyIcon={<FileText className="h-10 w-10 text-muted-foreground/30" />}
      />

      {/* Image lightbox */}
      {previewUrl && (
        <div className="fixed inset-0 z-[60] bg-black/80 flex flex-col items-center justify-center p-4" onClick={() => setPreviewUrl(null)}>
          <div className="absolute top-3 left-3">
            <Button size="sm" variant="secondary" onClick={(e) => { e.stopPropagation(); setPreviewUrl(null); }}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <img src={previewUrl} alt={previewName} className="max-h-[85vh] max-w-[95vw] rounded shadow-lg" onClick={e => e.stopPropagation()} />
          {previewName && <p className="mt-2 text-xs text-white/80">{previewName}</p>}
        </div>
      )}
    </div>
  );
};

export default Proofs;
