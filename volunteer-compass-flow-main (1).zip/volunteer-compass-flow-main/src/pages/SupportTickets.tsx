import { useState, useEffect, useCallback } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { Search, MessageCircle, Send, TicketCheck, Printer } from "lucide-react";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { formatDate, formatDateTime } from "@/lib/format-date";
import { notifyTicketReply, notifyTicketStatusChange } from "@/lib/ticket-notifications";
import { uploadTicketAttachment } from "@/lib/ticket-attachments";
import { AttachmentPickerButton, MessageAttachments, useMessageAttachments } from "@/components/tickets/TicketAttachments";

const printTicket = (ticket: any, messages: any[]) => {
  const win = window.open("", "_blank", "width=800,height=900");
  if (!win) return;
  const rows = messages.map(m => `
    <div style="margin:8px 0;padding:10px;border-radius:6px;background:${m.sender_type === "admin" ? "#f3f0fa" : "#f7f7fa"};border:1px solid #e5e5ea;">
      <div style="font-size:12px;color:#666;margin-bottom:4px;">
        <strong>${m.sender_name}${m.sender_type === "admin" ? " (مسؤول)" : ""}</strong> — ${formatDateTime(m.created_at)}
      </div>
      <div style="white-space:pre-wrap;">${(m.message || "").replace(/</g, "&lt;")}</div>
    </div>`).join("");
  win.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>تذكرة ${ticket.ticket_number || ""}</title>
    <style>body{font-family:'Cairo','Tahoma',sans-serif;padding:30px;color:#222;}h1{border-bottom:2px solid #5E4EA2;padding-bottom:10px;color:#5E4EA2;}
    .meta{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:20px 0;padding:16px;background:#f9f7fc;border-radius:8px;font-size:14px;}
    .meta div strong{color:#5E4EA2;}
    @media print {.no-print{display:none;}}
    </style></head><body>
    <div class="no-print" style="text-align:left;margin-bottom:10px;"><button onclick="window.print()" style="padding:8px 16px;background:#5E4EA2;color:white;border:none;border-radius:6px;cursor:pointer;">طباعة</button></div>
    <h1>منصة رفادة التطوعية — تذكرة دعم</h1>
    <div class="meta">
      <div><strong>رقم التذكرة:</strong> ${ticket.ticket_number || "—"}</div>
      <div><strong>الحالة:</strong> ${({open:"مفتوحة",in_progress:"قيد المعالجة",waiting_reply:"بانتظار الرد",closed:"مغلقة"} as any)[ticket.status] || ticket.status}</div>
      <div><strong>العنوان:</strong> ${ticket.title || ""}</div>
      <div><strong>الأولوية:</strong> ${({low:"منخفضة",medium:"متوسطة",high:"عالية",urgent:"عاجلة"} as any)[ticket.priority] || ticket.priority}</div>
      <div><strong>التصنيف:</strong> ${({general:"عام",technical:"تقني",account:"حسابي",opportunity:"فرصة",hours:"ساعات",other:"أخرى"} as any)[ticket.category] || ticket.category}</div>
      <div><strong>المتطوع:</strong> ${ticket.volunteers?.full_name || "—"}</div>
      <div><strong>تاريخ الإنشاء:</strong> ${formatDateTime(ticket.created_at)}</div>
      <div><strong>آخر تحديث:</strong> ${formatDateTime(ticket.updated_at || ticket.created_at)}</div>
    </div>
    <h3 style="color:#5E4EA2;">وصف التذكرة</h3>
    <div style="padding:12px;background:#fafafa;border-radius:6px;border:1px solid #eee;white-space:pre-wrap;">${(ticket.description || "—").replace(/</g, "&lt;")}</div>
    <h3 style="color:#5E4EA2;margin-top:24px;">المحادثة (${messages.length} رسالة)</h3>
    ${rows || '<div style="color:#888;">لا توجد رسائل</div>'}
    </body></html>`);
  win.document.close();
};

const statusMap: Record<string, string> = { open: "مفتوحة", in_progress: "قيد المعالجة", waiting_reply: "بانتظار الرد", closed: "مغلقة" };
const statusVariant = (s: string) => s === "closed" ? "neutral" : s === "open" ? "warning" : s === "in_progress" ? "primary" : "success";
const categoryMap: Record<string, string> = { general: "عام", technical: "تقني", account: "حسابي", opportunity: "فرصة تطوعية", hours: "ساعات", other: "أخرى" };
const priorityMap: Record<string, string> = { low: "منخفضة", medium: "متوسطة", high: "عالية", urgent: "عاجلة" };
const priorityVariant = (s: string) => s === "urgent" ? "danger" : s === "high" ? "warning" : "neutral";

const SupportTickets = () => {
  const { userName, userId } = useRole();
  const [tickets, setTickets] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [detailTicket, setDetailTicket] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [supervisors, setSupervisors] = useState<any[]>([]);
  const [chatFile, setChatFile] = useState<File | null>(null);
  const [attachmentsRefresh, setAttachmentsRefresh] = useState(0);
  const messageIds = messages.map((m: any) => m.id);
  const attachmentsMap = useMessageAttachments(messageIds, attachmentsRefresh);

  const fetchData = useCallback(async () => {
    const [ticketRes, supRes] = await Promise.all([
      supabase.from("support_tickets").select("*, volunteers(full_name)").order("updated_at", { ascending: false }),
      supabase.from("internal_users").select("id, full_name").eq("status", "active"),
    ]);
    setTickets(ticketRes.data || []);
    setSupervisors(supRes.data || []);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const fetchMessages = async (ticketId: string) => {
    const { data } = await supabase.from("support_ticket_messages").select("*").eq("ticket_id", ticketId).order("created_at", { ascending: true });
    setMessages(data || []);
  };

  const openDetail = async (ticket: any) => {
    setDetailTicket(ticket);
    setChatFile(null);
    await fetchMessages(ticket.id);
  };

  const changeStatus = async (ticket: any, newStatus: string) => {
    await supabase.from("support_tickets").update({ status: newStatus, updated_at: new Date().toISOString() }).eq("id", ticket.id);
    toast.success(`تم تغيير الحالة إلى: ${statusMap[newStatus]}`);
    if (detailTicket?.id === ticket.id) setDetailTicket({ ...detailTicket, status: newStatus });
    // Notify volunteer
    notifyTicketStatusChange(ticket.volunteer_id, ticket.title, ticket.id, newStatus);
    fetchData();
  };

  const assignTicket = async (ticket: any, assignedTo: string) => {
    await supabase.from("support_tickets").update({ assigned_to: assignedTo, updated_at: new Date().toISOString() }).eq("id", ticket.id);
    toast.success("تم إسناد التذكرة");
    fetchData();
  };

  const sendMessage = async () => {
    if (!detailTicket) return;
    if (!newMessage.trim() && !chatFile) return;
    setSending(true);

    const { data: msg, error } = await supabase.from("support_ticket_messages").insert({
      ticket_id: detailTicket.id, sender_type: "admin", sender_name: userName || "مسؤول",
      message: newMessage.trim() || "(مرفق)",
    }).select("id").single();

    if (!error && msg && chatFile) {
      const res = await uploadTicketAttachment({ ticketId: detailTicket.id, messageId: msg.id, file: chatFile });
      if (res.ok === false) toast.error(`تعذر رفع المرفق: ${res.error}`);
    }

    await supabase.from("support_tickets").update({ status: "waiting_reply", updated_at: new Date().toISOString() }).eq("id", detailTicket.id);
    setDetailTicket({ ...detailTicket, status: "waiting_reply" });
    notifyTicketReply(detailTicket.volunteer_id, detailTicket.title, detailTicket.id, "admin");
    setNewMessage("");
    setChatFile(null);
    await fetchMessages(detailTicket.id);
    setAttachmentsRefresh(x => x + 1);
    setSending(false);
    fetchData();
  };

  const filtered = tickets.filter(t => {
    if (search && !t.title.includes(search) && !(t.volunteers?.full_name || "").includes(search) && !(t.ticket_number || "").includes(search)) return false;
    if (filterStatus !== "all" && t.status !== filterStatus) return false;
    return true;
  });

  const openCount = tickets.filter(t => t.status === "open").length;

  return (
    <div>
      <PageHeader title="تذاكر الدعم" description={`إدارة تذاكر الدعم الفني والإداري${openCount > 0 ? ` — ${openCount} تذكرة مفتوحة` : ""}`} />

      <div className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="بحث بالعنوان أو المتطوع أو الرقم..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40 h-10"><SelectValue placeholder="الحالة" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الحالات</SelectItem>
            {Object.entries(statusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <DataTable
        columns={[
          { header: "رقم التذكرة", accessor: (r: any) => <span className="font-mono text-xs">{r.ticket_number || "—"}</span> },
          { header: "العنوان", accessor: "title" },
          { header: "المتطوع", accessor: (r: any) => r.volunteers?.full_name || "—" },
          { header: "التصنيف", accessor: (r: any) => categoryMap[r.category] || r.category },
          { header: "الأولوية", accessor: (r: any) => <StatusBadge status={priorityMap[r.priority] || r.priority} variant={priorityVariant(r.priority)} /> },
          { header: "الحالة", accessor: (r: any) => (
            <Select value={r.status} onValueChange={v => changeStatus(r, v)}>
              <SelectTrigger className="h-8 w-32 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(statusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
          )},
          { header: "آخر تحديث", accessor: (r: any) => formatDateTime(r.updated_at || r.created_at) },
          { header: "تفاصيل", accessor: (r: any) => (
            <Button variant="ghost" size="sm" onClick={() => openDetail(r)}>
              <MessageCircle className="h-4 w-4 text-primary" />
            </Button>
          )},
        ]}
        data={filtered}
        emptyMessage="لا توجد تذاكر دعم"
        emptyIcon={<TicketCheck className="h-10 w-10 text-muted-foreground/30" />}
      />

      {/* Ticket Detail Dialog */}
      <Dialog open={!!detailTicket} onOpenChange={open => { if (!open) setDetailTicket(null); }}>
        <DialogContent className="max-w-lg max-h-[85vh] flex flex-col" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-base flex items-center gap-2">
              {detailTicket?.ticket_number && <span className="font-mono text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">{detailTicket.ticket_number}</span>}
              {detailTicket?.title}
            </DialogTitle>
            <div className="flex gap-2 items-center flex-wrap mt-1">
              <StatusBadge status={statusMap[detailTicket?.status] || ""} variant={statusVariant(detailTicket?.status || "")} />
              <StatusBadge status={priorityMap[detailTicket?.priority] || ""} variant={priorityVariant(detailTicket?.priority || "")} />
              <span className="text-xs text-muted-foreground">{categoryMap[detailTicket?.category] || ""}</span>
              <span className="text-xs text-muted-foreground">• {detailTicket?.volunteers?.full_name}</span>
            </div>
            {/* Assign + Print */}
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Label className="text-xs">إسناد:</Label>
              <Select value={detailTicket?.assigned_to || ""} onValueChange={v => { if (detailTicket) assignTicket(detailTicket, v); }}>
                <SelectTrigger className="h-7 w-40 text-xs"><SelectValue placeholder="اختر" /></SelectTrigger>
                <SelectContent>
                  {supervisors.map(s => <SelectItem key={s.id} value={s.id}>{s.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => detailTicket && printTicket(detailTicket, messages)}>
                <Printer className="h-3.5 w-3.5 ml-1" />
                طباعة التذكرة
              </Button>
            </div>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto space-y-3 py-2 min-h-[200px]">
            {messages.map(msg => (
              <div key={msg.id} className={`rounded-lg p-3 text-sm ${msg.sender_type === "volunteer" ? "bg-primary/5 mr-4" : "bg-muted ml-4"}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-xs">{msg.sender_name} {msg.sender_type === "admin" ? "(مسؤول)" : ""}</span>
                  <span className="text-[10px] text-muted-foreground">{formatDateTime(msg.created_at)}</span>
                </div>
                <p className="whitespace-pre-wrap">{msg.message}</p>
                <MessageAttachments items={attachmentsMap[msg.id] || []} />
              </div>
            ))}
          </div>

          <div className="flex flex-col gap-2 pt-2 border-t border-border">
            <div className="flex gap-2">
              <Textarea className="flex-1 min-h-[40px]" rows={2} placeholder="اكتب ردك..." value={newMessage} onChange={e => setNewMessage(e.target.value)} />
              <Button size="icon" className="shrink-0 self-end" onClick={sendMessage} disabled={sending || (!newMessage.trim() && !chatFile)}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <AttachmentPickerButton
              selectedFile={chatFile}
              onSelect={setChatFile}
              onClear={() => setChatFile(null)}
              disabled={sending}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SupportTickets;
