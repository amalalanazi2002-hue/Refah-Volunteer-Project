import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { DataTable } from "@/components/shared/DataTable";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Copy, Eye, EyeOff, Key, Trash2, ShieldAlert } from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import { formatDate } from "@/lib/format-date";

const scopeOptions = [
  { value: "volunteers:read", label: "قراءة المتطوعين" },
  { value: "volunteers:write", label: "كتابة المتطوعين" },
  { value: "opportunities:read", label: "قراءة الفرص" },
  { value: "opportunities:write", label: "كتابة الفرص" },
  { value: "participations:read", label: "قراءة المشاركات" },
  { value: "participations:write", label: "كتابة المشاركات" },
  { value: "hours:read", label: "قراءة الساعات" },
  { value: "hours:write", label: "كتابة الساعات" },
  { value: "notifications:write", label: "إرسال إشعارات" },
  { value: "reports:read", label: "قراءة التقارير" },
];

const ApiKeysPage = () => {
  const { role } = useRole();
  const isDirector = role === "director";
  const [keys, setKeys] = useState<any[]>([]);
  const [dialog, setDialog] = useState(false);
  const [form, setForm] = useState({ name: "", key_type: "internal", scopes: [] as string[], expires_at: "" });
  const [revealedKeys, setRevealedKeys] = useState<Set<string>>(new Set());
  const [newKeyDialog, setNewKeyDialog] = useState<string | null>(null);

  const fetchKeys = async () => {
    const { data } = await supabase.from("api_keys").select("*").order("created_at", { ascending: false });
    setKeys(data || []);
  };

  useEffect(() => { fetchKeys(); }, []);

  if (!isDirector) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
        <ShieldAlert className="h-12 w-12 text-destructive" />
        <p className="text-lg font-semibold text-foreground">غير مصرح بالوصول</p>
        <p className="text-sm text-muted-foreground">هذه الصفحة متاحة للمدير فقط</p>
      </div>
    );
  }

  const generateApiKey = (type: string) => {
    const prefix = type === "external" ? "rfd_ext_" : "rfd_int_";
    const bytes = new Uint8Array(24);
    (typeof crypto !== "undefined" ? crypto : (window as any).crypto).getRandomValues(bytes);
    const random = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
    return prefix + random;
  };

  const createKey = async () => {
    if (!form.name.trim()) { toast.error("الرجاء إدخال اسم المفتاح"); return; }
    if (form.scopes.length === 0) { toast.error("اختر صلاحية واحدة على الأقل"); return; }
    const newApiKey = generateApiKey(form.key_type);
    const { data, error } = await supabase.from("api_keys").insert({
      name: form.name,
      key_type: form.key_type,
      scopes: form.scopes,
      expires_at: form.expires_at || null,
      api_key: newApiKey,
      is_active: true,
    } as any).select("api_key").single();
    if (error) { toast.error("خطأ في إنشاء المفتاح: " + error.message); return; }
    toast.success("تم إنشاء مفتاح API بنجاح");
    setDialog(false);
    setNewKeyDialog((data as any)?.api_key || newApiKey);
    setForm({ name: "", key_type: "internal", scopes: [], expires_at: "" });
    fetchKeys();
  };

  const toggleKey = async (key: any) => {
    await supabase.from("api_keys").update({ is_active: !key.is_active }).eq("id", key.id);
    toast.success(key.is_active ? "تم تعطيل المفتاح" : "تم تفعيل المفتاح");
    fetchKeys();
  };

  const deleteKey = async (id: string) => {
    await supabase.from("api_keys").delete().eq("id", id);
    toast.success("تم حذف المفتاح");
    fetchKeys();
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast.success("تم نسخ المفتاح");
  };

  const toggleReveal = (id: string) => {
    setRevealedKeys(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const internalKeys = keys.filter(k => k.key_type === "internal");
  const externalKeys = keys.filter(k => k.key_type === "external");

  const KeyTable = ({ data }: { data: any[] }) => (
    <DataTable
      columns={[
        { header: "الاسم", accessor: "name" },
        { header: "المفتاح", accessor: (r: any) => (
          <div className="flex items-center gap-1">
            <span className="text-xs font-mono" dir="ltr">
              {revealedKeys.has(r.id) ? r.api_key : r.api_key?.slice(0, 8) + "••••••••"}
            </span>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => toggleReveal(r.id)}>
              {revealedKeys.has(r.id) ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
            </Button>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => copyKey(r.api_key)}>
              <Copy className="h-3 w-3" />
            </Button>
          </div>
        )},
        { header: "الصلاحيات", accessor: (r: any) => <span className="text-xs">{(r.scopes || []).length} صلاحية</span> },
        { header: "الحالة", accessor: (r: any) => (
          <div className="flex items-center gap-2">
            <Switch checked={r.is_active} onCheckedChange={() => toggleKey(r)} />
            <span className="text-xs">{r.is_active ? "مفعّل" : "معطّل"}</span>
          </div>
        )},
        { header: "آخر استخدام", accessor: (r: any) => r.last_used_at ? formatDate(r.last_used_at) : "—" },
        { header: "الإنشاء", accessor: (r: any) => formatDate(r.created_at) },
        { header: "إجراءات", accessor: (r: any) => (
          <Button variant="ghost" size="sm" className="text-destructive" onClick={() => deleteKey(r.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
        )},
      ]}
      data={data}
      emptyMessage="لا توجد مفاتيح API"
    />
  );

  return (
    <div>
      <PageHeader title="مفاتيح API" description="إنشاء وإدارة مفاتيح الوصول الداخلية والخارجية" actions={
        <Button onClick={() => setDialog(true)}><Plus className="h-4 w-4 ml-1" />إنشاء مفتاح</Button>
      } />

      <Tabs defaultValue="internal" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="internal"><Key className="h-4 w-4 ml-1" />داخلي</TabsTrigger>
          <TabsTrigger value="external"><Key className="h-4 w-4 ml-1" />خارجي</TabsTrigger>
        </TabsList>

        <TabsContent value="internal">
          <div className="bg-card rounded-lg border border-border p-4 mb-4">
            <p className="text-sm text-muted-foreground">مفاتيح داخلية للاستخدام من الأنظمة الداخلية ولوحات التحكم الأخرى.</p>
          </div>
          <KeyTable data={internalKeys} />
        </TabsContent>

        <TabsContent value="external">
          <div className="bg-card rounded-lg border border-border p-4 mb-4">
            <p className="text-sm text-muted-foreground">مفاتيح خارجية للتطبيقات والمنصات الخارجية مثل الموقع العام أو تطبيق الجوال.</p>
          </div>
          <KeyTable data={externalKeys} />
        </TabsContent>
      </Tabs>

      {/* API Endpoints Documentation */}
      <div className="mt-6 bg-card rounded-lg border border-border p-5">
        <h3 className="font-bold text-foreground mb-3">نقاط الوصول المتاحة (API Endpoints)</h3>
        <div className="space-y-2 text-sm font-mono" dir="ltr">
          {[
            { method: "GET", path: "/api/v1/volunteers", desc: "قائمة المتطوعين" },
            { method: "GET", path: "/api/v1/opportunities", desc: "قائمة الفرص" },
            { method: "POST", path: "/api/v1/opportunities/:id/apply", desc: "التقديم على فرصة" },
            { method: "GET", path: "/api/v1/participations", desc: "قائمة المشاركات" },
            { method: "GET", path: "/api/v1/hours", desc: "سجل الساعات" },
            { method: "POST", path: "/api/v1/notifications", desc: "إرسال إشعار" },
            { method: "GET", path: "/api/v1/reports/summary", desc: "ملخص التقارير" },
          ].map((ep, i) => (
            <div key={i} className="flex items-center gap-3 p-2 bg-muted/40 rounded">
              <span className={`text-xs font-bold px-2 py-0.5 rounded ${ep.method === "GET" ? "bg-primary/10 text-primary" : "bg-accent/10 text-accent-foreground"}`}>{ep.method}</span>
              <span className="text-xs flex-1">{ep.path}</span>
              <span className="text-xs text-muted-foreground" dir="rtl">{ep.desc}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground mt-3" dir="rtl">هذه النقاط ستكون متاحة بعد تفعيل Edge Functions. استخدم مفتاح API في Header كـ <code dir="ltr">Authorization: Bearer YOUR_KEY</code></p>
      </div>

      {/* Create Key Dialog */}
      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>إنشاء مفتاح API</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>اسم المفتاح</Label><Input className="mt-1.5" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="مثال: تطبيق الجوال" /></div>
            <div><Label>النوع</Label>
              <Select value={form.key_type} onValueChange={v => setForm(p => ({ ...p, key_type: v }))}>
                <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="internal">داخلي</SelectItem>
                  <SelectItem value="external">خارجي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>الصلاحيات</Label>
              <div className="grid grid-cols-2 gap-2 mt-1.5">
                {scopeOptions.map(s => (
                  <label key={s.value} className="flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={form.scopes.includes(s.value)} onChange={e => {
                      setForm(p => ({ ...p, scopes: e.target.checked ? [...p.scopes, s.value] : p.scopes.filter(x => x !== s.value) }));
                    }} />
                    {s.label}
                  </label>
                ))}
              </div>
            </div>
            <div><Label>تاريخ الانتهاء (اختياري)</Label><Input type="date" className="mt-1.5" value={form.expires_at} onChange={e => setForm(p => ({ ...p, expires_at: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={createKey}>إنشاء</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Key Reveal Dialog (one-time) */}
      <Dialog open={!!newKeyDialog} onOpenChange={(o) => !o && setNewKeyDialog(null)}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>تم إنشاء المفتاح</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">انسخ المفتاح الآن واحفظه في مكان آمن.</p>
            <div className="bg-muted/40 border border-border rounded p-3 font-mono text-xs break-all" dir="ltr">{newKeyDialog}</div>
            <Button onClick={() => { if (newKeyDialog) copyKey(newKeyDialog); }} className="w-full">
              <Copy className="h-4 w-4 ml-1" />نسخ المفتاح
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ApiKeysPage;
