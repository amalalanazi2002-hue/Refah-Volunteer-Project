import { useState, useEffect, useCallback } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Plus, Play, Square, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { notifyParticipationStarted, notifyParticipationEnded, notifyInternalNewProof } from "@/lib/notifications";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { formatDateTime } from "@/lib/format-date";
import { formatMinutes } from "@/lib/hours-format";

// Compute effective duration in minutes for a participation row.
// Falls back to (ended_at - started_at) when total_minutes is missing/zero.
const effectiveMinutes = (r: any): number | null => {
  const stored = Number(r?.total_minutes || 0);
  if (stored > 0) return Math.min(stored, 720);
  if (r?.started_at && r?.ended_at) {
    const diff = Math.round((new Date(r.ended_at).getTime() - new Date(r.started_at).getTime()) / 60000);
    if (diff > 0) return Math.min(diff, 720);
  }
  return null;
};

const formatDuration = (r: any): string => {
  const m = effectiveMinutes(r);
  if (m === null) return r?.started_at && !r?.ended_at ? "قيد التنفيذ" : "—";
  return formatMinutes(m);
};

const proofStatusMap: Record<string, string> = { pending: "قيد المراجعة", submitted: "مرفوع", missing: "مفقود" };
const approvalStatusMap: Record<string, string> = { pending: "قيد الاعتماد", approved: "معتمد", rejected: "مرفوض", needs_completion: "يحتاج استكمال" };
const proofVariant = (s: string) => s === "submitted" ? "success" : s === "missing" ? "danger" : "warning";
const approvalVariant = (s: string) => s === "approved" ? "success" : s === "rejected" ? "danger" : "warning";

const Participations = () => {
  const [search, setSearch] = useState("");
  const [data, setData] = useState<any[]>([]);
  const [volunteers, setVolunteers] = useState<any[]>([]);
  const [opportunities, setOpportunities] = useState<any[]>([]);
  const [addOpen, setAddOpen] = useState(false);
  const [uploadOpen, setUploadOpen] = useState<string | null>(null);
  const [form, setForm] = useState({ volunteer_id: "", opportunity_id: "" });
  const { canManage } = useRole();

  // Filters
  const [filterProof, setFilterProof] = useState("all");
  const [filterApproval, setFilterApproval] = useState("all");
  const [filterOpp, setFilterOpp] = useState("all");

  const fetchData = useCallback(async () => {
    const { data: rows } = await supabase.from("participations").select("*, volunteers(full_name), opportunities(title)").order("created_at", { ascending: false });
    setData(rows || []);
  }, []);

  useEffect(() => {
    fetchData();
    const fetchLists = async () => {
      const [vRes, oRes] = await Promise.all([
        supabase.from("volunteers").select("id, full_name").eq("status", "active"),
        supabase.from("opportunities").select("id, title").eq("status", "active"),
      ]);
      setVolunteers(vRes.data || []);
      setOpportunities(oRes.data || []);
    };
    fetchLists();
  }, [fetchData]);

  const handleCreate = async () => {
    if (!form.volunteer_id || !form.opportunity_id) return;
    const now = new Date().toISOString();
    const { data: inserted, error } = await supabase.from("participations").insert({
      volunteer_id: form.volunteer_id, opportunity_id: form.opportunity_id,
      started_at: now, approval_status: "pending", proof_status: "pending",
    }).select("id").single();
    if (error) { toast.error("خطأ في إنشاء المشاركة"); return; }
    const oppName = opportunities.find((o: any) => o.id === form.opportunity_id)?.title || "";
    if (inserted) notifyParticipationStarted(form.volunteer_id, oppName, inserted.id);
    toast.success("تم بدء المشاركة بنجاح");
    setForm({ volunteer_id: "", opportunity_id: "" });
    setAddOpen(false);
    fetchData();
  };

  const handleStart = async (row: any) => {
    const now = new Date().toISOString();
    const { error } = await supabase.from("participations").update({ started_at: now }).eq("id", row.id);
    if (error) { toast.error("خطأ في بدء المشاركة"); return; }
    notifyParticipationStarted(row.volunteer_id, row.opportunities?.title || "", row.id);
    toast.success("تم بدء المشاركة");
    fetchData();
  };

  const handleEnd = async (row: any) => {
    if (!row.started_at) { toast.error("لا يمكن إنهاء مشاركة لم تبدأ بعد"); return; }
    const now = new Date();
    const start = new Date(row.started_at);
    let totalMinutes = Math.round((now.getTime() - start.getTime()) / 60000);
    if (totalMinutes < 0) { toast.error("خطأ في حساب الوقت"); return; }
    const MAX_MINUTES = 720;
    const exceeds = totalMinutes > MAX_MINUTES;
    if (exceeds) totalMinutes = MAX_MINUTES;
    const { error } = await supabase.from("participations").update({ ended_at: now.toISOString(), total_minutes: totalMinutes, approval_status: "pending" }).eq("id", row.id);
    if (error) { toast.error("خطأ في إنهاء المشاركة"); return; }
    notifyParticipationEnded(row.volunteer_id, row.opportunities?.title || "", row.id, totalMinutes);
    if (exceeds) toast.warning(`المشاركة تجاوزت 12 ساعة — تم تحديدها عند ${MAX_MINUTES} دقيقة`);
    else toast.success(`تم إنهاء المشاركة — ${totalMinutes} دقيقة`);
    fetchData();
  };

  const handleUploadProof = async (participationId: string, volunteerId: string, file: File) => {
    const ext = file.name.split(".").pop();
    const path = `${participationId}/${Date.now()}.${ext}`;
    const { error: uploadError } = await supabase.storage.from("proofs").upload(path, file);
    if (uploadError) { toast.error("خطأ في رفع الملف"); return; }
    const { data: existing } = await supabase.from("proofs").select("id").eq("participation_id", participationId).limit(1);
    if (existing && existing.length > 0) {
      await supabase.from("proofs").update({ file_path: path, file_name: file.name, file_type: file.type, uploaded_at: new Date().toISOString(), review_status: "pending" }).eq("id", existing[0].id);
    } else {
      await supabase.from("proofs").insert({ participation_id: participationId, volunteer_id: volunteerId, file_path: path, file_name: file.name, file_type: file.type, review_status: "pending" });
    }
    await supabase.from("participations").update({ proof_status: "submitted" }).eq("id", participationId);
    const { data: vol } = await supabase.from("volunteers").select("full_name").eq("id", volunteerId).single();
    const { data: part } = await supabase.from("participations").select("opportunity_id, opportunities(title)").eq("id", participationId).single();
    const oppTitle = (part as any)?.opportunities?.title || "";
    const proofRecord = existing && existing.length > 0 ? existing[0] : null;
    if (proofRecord) notifyInternalNewProof(vol?.full_name || "متطوع", oppTitle, proofRecord.id);
    toast.success("تم رفع الإثبات بنجاح");
    setUploadOpen(null);
    fetchData();
  };

  const allOpps = [...new Set(data.map(r => r.opportunities?.title).filter(Boolean))];

  const filtered = data.filter((r: any) => {
    if (search && !(r.volunteers?.full_name || "").includes(search)) return false;
    if (filterProof !== "all" && r.proof_status !== filterProof) return false;
    if (filterApproval !== "all" && r.approval_status !== filterApproval) return false;
    if (filterOpp !== "all" && r.opportunities?.title !== filterOpp) return false;
    return true;
  });

  const exportData = filtered.map(r => ({
    volunteer: r.volunteers?.full_name || "—", opportunity: r.opportunities?.title || "—",
    start: formatDateTime(r.started_at),
    end: formatDateTime(r.ended_at),
    minutes: formatDuration(r), proof: proofStatusMap[r.proof_status] || r.proof_status,
    approval: approvalStatusMap[r.approval_status] || r.approval_status,
  }));
  const exportCols = [
    { header: "المتطوع", key: "volunteer" }, { header: "الفرصة", key: "opportunity" },
    { header: "وقت البدء", key: "start" }, { header: "وقت الإنهاء", key: "end" },
    { header: "المدة", key: "minutes" }, { header: "حالة الإثبات", key: "proof" },
    { header: "حالة الاعتماد", key: "approval" },
  ];

  return (
    <div>
      <PageHeader title="المشاركات" description="عرض وإدارة مشاركات المتطوعين في الفرص" actions={
        <div className="flex gap-2 items-center">
          <ExportButtons data={exportData} columns={exportCols} title="المشاركات" filename="participations" />
          {canManage && (
            <Dialog open={addOpen} onOpenChange={setAddOpen}>
              <DialogTrigger asChild><Button><Plus className="h-4 w-4 ml-2" />مشاركة جديدة</Button></DialogTrigger>
              <DialogContent className="max-w-lg" dir="rtl">
                <DialogHeader><DialogTitle>بدء مشاركة جديدة</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div><Label>المتطوع</Label>
                    <Select onValueChange={v => setForm({ ...form, volunteer_id: v })}>
                      <SelectTrigger className="mt-1.5"><SelectValue placeholder="اختر المتطوع" /></SelectTrigger>
                      <SelectContent>{volunteers.map(v => <SelectItem key={v.id} value={v.id}>{v.full_name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label>الفرصة</Label>
                    <Select onValueChange={v => setForm({ ...form, opportunity_id: v })}>
                      <SelectTrigger className="mt-1.5"><SelectValue placeholder="اختر الفرصة" /></SelectTrigger>
                      <SelectContent>{opportunities.map(o => <SelectItem key={o.id} value={o.id}>{o.title}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <Button className="w-full" onClick={handleCreate}>بدء المشاركة</Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      } />

      <div className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="بحث بالاسم..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
        <Select value={filterProof} onValueChange={setFilterProof}>
          <SelectTrigger className="w-36 h-10"><SelectValue placeholder="حالة الإثبات" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل حالات الإثبات</SelectItem>
            <SelectItem value="pending">قيد المراجعة</SelectItem>
            <SelectItem value="submitted">مرفوع</SelectItem>
            <SelectItem value="missing">مفقود</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterApproval} onValueChange={setFilterApproval}>
          <SelectTrigger className="w-36 h-10"><SelectValue placeholder="حالة الاعتماد" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل حالات الاعتماد</SelectItem>
            <SelectItem value="pending">قيد الاعتماد</SelectItem>
            <SelectItem value="approved">معتمد</SelectItem>
            <SelectItem value="rejected">مرفوض</SelectItem>
            <SelectItem value="needs_completion">يحتاج استكمال</SelectItem>
          </SelectContent>
        </Select>
        {allOpps.length > 0 && (
          <Select value={filterOpp} onValueChange={setFilterOpp}>
            <SelectTrigger className="w-40 h-10"><SelectValue placeholder="الفرصة" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الفرص</SelectItem>
              {allOpps.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
            </SelectContent>
          </Select>
        )}
      </div>

      <DataTable columns={[
        { header: "المتطوع", accessor: (r: any) => r.volunteers?.full_name || "—" },
        { header: "الفرصة", accessor: (r: any) => r.opportunities?.title || "—" },
        { header: "وقت البدء", accessor: (r: any) => formatDateTime(r.started_at) },
        { header: "وقت الإنهاء", accessor: (r: any) => formatDateTime(r.ended_at) },
        { header: "المدة", accessor: (r: any) => formatDuration(r) },
        { header: "حالة الإثبات", accessor: (r: any) => <StatusBadge status={proofStatusMap[r.proof_status] || r.proof_status} variant={proofVariant(r.proof_status)} /> },
        { header: "حالة الاعتماد", accessor: (r: any) => <StatusBadge status={approvalStatusMap[r.approval_status] || r.approval_status} variant={approvalVariant(r.approval_status)} /> },
        { header: "إجراءات", accessor: (r: any) => (
          <div className="flex gap-1.5 flex-wrap">
            {!r.started_at && canManage && <Button variant="outline" size="sm" onClick={() => handleStart(r)}><Play className="h-3.5 w-3.5 ml-1" />بدء</Button>}
            {r.started_at && !r.ended_at && canManage && <Button variant="outline" size="sm" onClick={() => handleEnd(r)}><Square className="h-3.5 w-3.5 ml-1" />إنهاء</Button>}
            {r.ended_at && r.proof_status !== "submitted" && (
              <Dialog open={uploadOpen === r.id} onOpenChange={open => setUploadOpen(open ? r.id : null)}>
                <DialogTrigger asChild><Button variant="outline" size="sm"><Upload className="h-3.5 w-3.5 ml-1" />رفع إثبات</Button></DialogTrigger>
                <DialogContent dir="rtl">
                  <DialogHeader><DialogTitle>رفع إثبات المشاركة</DialogTitle></DialogHeader>
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">المتطوع: {r.volunteers?.full_name} — الفرصة: {r.opportunities?.title}</p>
                    <Input type="file" accept="image/*,.pdf,.doc,.docx" onChange={e => { const file = e.target.files?.[0]; if (file) handleUploadProof(r.id, r.volunteer_id, file); }} />
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>
        )},
      ]} data={filtered} />
    </div>
  );
};

export default Participations;
