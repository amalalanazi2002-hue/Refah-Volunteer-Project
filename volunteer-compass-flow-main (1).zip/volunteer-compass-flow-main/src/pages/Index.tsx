import PublicPage from "@/pages/Public";

const Index = () => <PublicPage />;

export default Index;
