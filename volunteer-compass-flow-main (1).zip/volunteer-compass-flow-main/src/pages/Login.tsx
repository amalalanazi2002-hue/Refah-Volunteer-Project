import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import logo from "@/assets/logo.png";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { session, role, loading: roleLoading } = useRole();

  // Redirect if already logged in
  useEffect(() => {
    if (roleLoading || !session) return;
    const redirect = searchParams.get("redirect");
    if (redirect) {
      navigate(redirect, { replace: true });
      return;
    }
    if (role === "volunteer") {
      navigate("/volunteer", { replace: true });
    } else {
      navigate("/dashboard", { replace: true });
    }
  }, [session, role, roleLoading]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("الرجاء إدخال البريد وكلمة المرور");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      toast.error("خطأ في تسجيل الدخول: " + (error.message.includes("Invalid") ? "بيانات غير صحيحة" : error.message));
      return;
    }
    toast.success("تم تسجيل الدخول بنجاح");
    // Redirect will happen via useEffect after role resolves
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="bg-card rounded-xl border border-border p-6 md:p-8 shadow-sm">
          <div className="flex flex-col items-center mb-6">
            <img src={logo} alt="رفادة" className="h-16 w-16 rounded-xl bg-primary/10 object-contain p-2 mb-3" />
            <h1 className="text-xl font-bold text-foreground">منصة رفادة التطوعية</h1>
            <p className="text-sm text-muted-foreground mt-1">تسجيل الدخول</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label>البريد الإلكتروني</Label>
              <Input
                type="email"
                placeholder="example@rafah.org"
                className="mt-1.5"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                dir="ltr"
              />
            </div>
            <div>
              <Label>كلمة المرور</Label>
              <Input
                type="password"
                placeholder="••••••••"
                className="mt-1.5"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                dir="ltr"
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "جارٍ الدخول..." : "تسجيل الدخول"}
            </Button>
            <button
              type="button"
              className="w-full text-center text-sm text-primary hover:underline"
              onClick={() => navigate("/forgot-password")}
            >
              نسيت كلمة المرور؟
            </button>
          </form>
        </div>
        <p className="text-center text-[11px] text-muted-foreground mt-4">
          جمعية رفاه للأرامل والمطلقات
        </p>
      </div>
    </div>
  );
};

export default Login;
