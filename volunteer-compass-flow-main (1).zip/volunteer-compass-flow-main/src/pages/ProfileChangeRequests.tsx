import { useState, useEffect, useCallback } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { Check, X, Eye, UserCog } from "lucide-react";
import { formatDate, formatDateTime } from "@/lib/format-date";
import { notifyProfileChangeDecision } from "@/lib/ticket-notifications";

const statusMap: Record<string, string> = { pending: "قيد المراجعة", approved: "مقبول", rejected: "مرفوض" };
const statusVariant = (s: string) => s === "approved" ? "success" : s === "rejected" ? "danger" : "warning";
const fieldLabels: Record<string, string> = { full_name: "الاسم الكامل", mobile: "الجوال", email: "البريد", national_id: "الهوية", city: "المدينة" };

const ProfileChangeRequests = () => {
  const { userId } = useRole();
  const [requests, setRequests] = useState<any[]>([]);
  const [detailReq, setDetailReq] = useState<any>(null);
  const [reviewNote, setReviewNote] = useState("");
  const [processing, setProcessing] = useState(false);

  const fetchData = useCallback(async () => {
    const { data } = await supabase.from("volunteer_profile_change_requests")
      .select("*, volunteers(full_name), reviewer:reviewed_by(full_name)")
      .order("created_at", { ascending: false });
    setRequests(data || []);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleDecision = async (decision: "approved" | "rejected") => {
    if (!detailReq) return;
    setProcessing(true);

    if (decision === "approved") {
      const rawChanges = detailReq.changes || {};
      const { __previous_values, ...changes } = rawChanges as any;
      const { error: updateError } = await supabase.from("volunteers").update(changes).eq("id", detailReq.volunteer_id);
      if (updateError) {
        toast.error(`خطأ في تحديث بيانات المتطوع: ${updateError.message}`);
        setProcessing(false);
        return;
      }
    }

    await supabase.from("volunteer_profile_change_requests").update({
      status: decision, review_note: reviewNote.trim() || null, reviewed_by: userId, reviewed_at: new Date().toISOString(),
    }).eq("id", detailReq.id);

    // Notify volunteer
    notifyProfileChangeDecision(detailReq.volunteer_id, decision, detailReq.id);

    toast.success(decision === "approved" ? "تم قبول طلب التعديل وتحديث البيانات" : "تم رفض طلب التعديل");
    setDetailReq(null);
    setReviewNote("");
    setProcessing(false);
    fetchData();
  };

  const pendingCount = requests.filter(r => r.status === "pending").length;

  return (
    <div>
      <PageHeader title="طلبات تعديل البيانات" description={`مراجعة طلبات تعديل بيانات المتطوعين${pendingCount > 0 ? ` — ${pendingCount} طلب معلق` : ""}`} />

      <DataTable
        columns={[
          { header: "المتطوع", accessor: (r: any) => r.volunteers?.full_name || "—" },
          { header: "الحقول المطلوب تعديلها", accessor: (r: any) => {
            const changes = r.changes || {};
            return Object.keys(changes).filter(k => k !== "__previous_values").map(k => fieldLabels[k] || k).join("، ");
          }},
          { header: "التاريخ", accessor: (r: any) => formatDate(r.created_at) },
          { header: "الحالة", accessor: (r: any) => <StatusBadge status={statusMap[r.status] || r.status} variant={statusVariant(r.status)} /> },
          { header: "المراجع", accessor: (r: any) => {
            if (!r.reviewed_by) return "—";
            const reviewerName = (r.reviewer as any)?.full_name || "—";
            return (
              <div className="text-xs">
                <p className="font-medium">{reviewerName}</p>
                {r.reviewed_at && <p className="text-muted-foreground">{formatDateTime(r.reviewed_at)}</p>}
              </div>
            );
          }},
          { header: "إجراءات", accessor: (r: any) => (
            <Button variant="ghost" size="sm" onClick={() => { setDetailReq(r); setReviewNote(""); }}>
              <Eye className="h-4 w-4 text-primary" />
            </Button>
          )},
        ]}
        data={requests}
        emptyMessage="لا توجد طلبات تعديل"
        emptyIcon={<UserCog className="h-10 w-10 text-muted-foreground/30" />}
      />

      <Dialog open={!!detailReq} onOpenChange={open => { if (!open) setDetailReq(null); }}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>تفاصيل طلب التعديل</DialogTitle></DialogHeader>
          {detailReq && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">المتطوع: <strong className="text-foreground">{detailReq.volunteers?.full_name}</strong></p>
              <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                <p className="text-xs font-semibold text-muted-foreground mb-2">التعديلات المطلوبة:</p>
                {Object.entries(detailReq.changes || {}).filter(([k]) => k !== "__previous_values").map(([key, value]) => {
                  const prevFromChanges = (detailReq.changes && (detailReq.changes as any).__previous_values) || {};
                  const before = prevFromChanges[key];
                  return (
                    <div key={key} className="text-sm border-b border-border/50 last:border-0 pb-1.5 last:pb-0">
                      <p className="text-xs text-muted-foreground mb-0.5">{fieldLabels[key] || key}</p>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs px-2 py-0.5 rounded bg-destructive/10 text-destructive line-through">{before ? String(before) : "—"}</span>
                        <span className="text-muted-foreground">←</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-success/10 text-success font-medium">{String(value)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="text-xs text-muted-foreground">تاريخ الطلب: {formatDateTime(detailReq.created_at)}</p>

              {detailReq.reviewed_by && detailReq.status !== "pending" && (
                <div className="bg-muted/30 rounded-lg p-3 text-xs space-y-1">
                  <p>المراجع: <strong>{(detailReq.reviewer as any)?.full_name || "—"}</strong></p>
                  <p>وقت المراجعة: {formatDateTime(detailReq.reviewed_at)}</p>
                  {detailReq.review_note && <p>ملاحظة: {detailReq.review_note}</p>}
                </div>
              )}

              {detailReq.status === "pending" && (
                <>
                  <div>
                    <Label>ملاحظة (اختياري)</Label>
                    <Textarea className="mt-1.5" rows={2} placeholder="ملاحظة للمتطوع..." value={reviewNote} onChange={e => setReviewNote(e.target.value)} />
                  </div>
                  <div className="flex gap-2">
                    <Button className="flex-1" onClick={() => handleDecision("approved")} disabled={processing}>
                      <Check className="h-4 w-4 ml-1" />قبول وتطبيق
                    </Button>
                    <Button variant="destructive" className="flex-1" onClick={() => handleDecision("rejected")} disabled={processing}>
                      <X className="h-4 w-4 ml-1" />رفض
                    </Button>
                  </div>
                </>
              )}
              {detailReq.status !== "pending" && !detailReq.reviewed_by && (
                <div className="text-sm">
                  <StatusBadge status={statusMap[detailReq.status]} variant={statusVariant(detailReq.status)} />
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProfileChangeRequests;
