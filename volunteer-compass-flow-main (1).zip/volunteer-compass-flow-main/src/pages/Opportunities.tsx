import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Plus, Search, Eye, Check, X, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { notifyNewOpportunity, notifyApplicationDecision, notifyInternalOpportunityEnded } from "@/lib/notifications";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { formatDate } from "@/lib/format-date";

const statusMap: Record<string, string> = { draft: "مسودة", active: "نشطة", closed: "منتهية", archived: "مؤرشفة" };
const statusVariant = (s: string) => s === "active" ? "success" : s === "draft" ? "warning" : "neutral";
const appStatusMap: Record<string, string> = { pending: "قيد المراجعة", approved: "مقبول", rejected: "مرفوض" };
const appStatusVariant = (s: string) => s === "approved" ? "success" : s === "rejected" ? "danger" : "warning";
// Convert any digit string to Latin digits
const toLatin = (s: string) => String(s ?? "").replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d).toString())
  .replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d).toString());

// Allow only digits + decimal point in numeric form fields
const handleNumeric = (raw: string, allowDecimal = false): string => {
  const s = toLatin(raw);
  return allowDecimal ? s.replace(/[^0-9.]/g, "") : s.replace(/\D/g, "");
};

const OpportunityFormFields = ({ values, onChange, departments, supervisors, templates }: {
  values: any; onChange: (v: any) => void; departments: any[]; supervisors: any[]; templates?: any[];
}) => {
  // Parse stored datetime → wall-clock components in Riyadh timezone (UTC+3).
  // If the stored value already includes a +03:00 offset we use the literal hh:mm.
  // Otherwise we shift UTC → Asia/Riyadh.
  const parseDT = (v: string) => {
    if (!v) return { date: "", time: "" };
    // Stored with explicit Riyadh offset → use literal components
    const localMatch = v.match(/^(\d{4}-\d{2}-\d{2})[T\s](\d{2}):(\d{2})(?::\d{2})?(?:\.\d+)?\+03:00$/);
    if (localMatch) return { date: localMatch[1], time: `${localMatch[2]}:${localMatch[3]}` };
    // Other ISO strings (e.g. UTC "Z" or any TZ) → convert via Intl with Asia/Riyadh
    const d = new Date(v);
    if (!Number.isNaN(d.getTime())) {
      const parts = new Intl.DateTimeFormat("en-GB", {
        timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit",
        hour: "2-digit", minute: "2-digit", hour12: false,
      } as any).formatToParts(d);
      const get = (t: string) => parts.find(p => p.type === t)?.value || "";
      const date = `${get("year")}-${get("month")}-${get("day")}`;
      let hh = get("hour"); if (hh === "24") hh = "00";
      const time = `${hh}:${get("minute")}`;
      if (get("year")) return { date, time };
    }
    // Fallback: pull date/time directly from string
    const m = v.match(/^(\d{4}-\d{2}-\d{2})[T\s](\d{2}):(\d{2})/);
    if (m) return { date: m[1], time: `${m[2]}:${m[3]}` };
    return { date: v.slice(0, 10), time: "" };
  };
  const { date: startDate, time: startTime } = parseDT(values.start_at || "");
  const { date: endDate, time: endTime } = parseDT(values.end_at || "");

  // Build local-time ISO string with Riyadh offset (+03:00) so DB stores the exact wall-clock time
  const setDateTime = (field: "start_at" | "end_at", date: string, time: string) => {
    const d = toLatin(date);
    const t = toLatin(time);
    const dt = d ? (t ? `${d}T${t}:00+03:00` : `${d}T00:00:00+03:00`) : "";
    onChange({ ...values, [field]: dt });
  };

  // Get the current wall-clock date+time in Asia/Riyadh as { date: yyyy-MM-dd, time: HH:mm }
  const nowInRiyadh = () => {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", hour12: false,
      // @ts-ignore
      numberingSystem: "latn",
    } as any).formatToParts(new Date());
    const get = (t: string) => parts.find(p => p.type === t)?.value || "";
    let hh = get("hour"); if (hh === "24") hh = "00";
    return { date: `${get("year")}-${get("month")}-${get("day")}`, time: `${hh}:${get("minute")}` };
  };

  const setNow = (field: "start_at" | "end_at", currentDate: string) => {
    const n = nowInRiyadh();
    // Preserve existing date if user already picked one; otherwise use today (Riyadh)
    setDateTime(field, currentDate || n.date, n.time);
  };

  return (
    <div className="space-y-5 max-h-[70vh] overflow-y-auto pl-1" dir="rtl">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div><Label>اسم الفرصة *</Label><Input placeholder="أدخل اسم الفرصة" className="mt-1.5 text-right" dir="rtl" value={values.title} onChange={e => onChange({ ...values, title: e.target.value })} /></div>
        <div><Label>الإدارة *</Label>
          <Select value={values.department_id} onValueChange={v => onChange({ ...values, department_id: v })}>
            <SelectTrigger className="mt-1.5 text-right"><SelectValue placeholder="اختر الإدارة" /></SelectTrigger>
            <SelectContent>{departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>المشرف</Label>
          <Select value={values.supervisor_id || ""} onValueChange={v => onChange({ ...values, supervisor_id: v })}>
            <SelectTrigger className="mt-1.5 text-right"><SelectValue placeholder="اختر المشرف" /></SelectTrigger>
            <SelectContent>
              {supervisors.length === 0 ? <div className="px-3 py-2 text-sm text-muted-foreground">لا يوجد مشرفون</div>
                : supervisors.map(s => <SelectItem key={s.id} value={s.id}>{s.full_name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div><Label>الحد الأدنى (ساعات)</Label><Input inputMode="decimal" placeholder="مثال: 4" className="mt-1.5 text-right" dir="ltr" value={values.minimum_hours} onChange={e => onChange({ ...values, minimum_hours: handleNumeric(e.target.value, true) })} /></div>
        <div><Label>عدد المقاعد (0 = غير محدود)</Label><Input inputMode="numeric" placeholder="مثال: 20" className="mt-1.5 text-right" dir="ltr" value={values.capacity} onChange={e => onChange({ ...values, capacity: handleNumeric(e.target.value) })} /></div>
        <div><Label>السماح برفع الإثبات بعد (ساعات من البداية)</Label>
          <Input inputMode="numeric" placeholder="0 = من بدء الفرصة مباشرة" className="mt-1.5 text-right" dir="ltr"
            value={values.proof_unlock_after_hours ?? ""}
            onChange={e => onChange({ ...values, proof_unlock_after_hours: handleNumeric(e.target.value) })} />
        </div>
        <div><Label>مهلة رفع الإثبات بعد النهاية (ساعات)</Label>
          <Input inputMode="numeric" placeholder="افتراضي: 168 (7 أيام)" className="mt-1.5 text-right" dir="ltr"
            value={values.proof_window_hours ?? ""}
            onChange={e => onChange({ ...values, proof_window_hours: handleNumeric(e.target.value) })} />
        </div>
        <div><Label>نوع الإشراف على الطلبات</Label>
          <Select value={values.review_type} onValueChange={v => onChange({ ...values, review_type: v })}>
            <SelectTrigger className="mt-1.5 text-right"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="assigned_supervisor">المشرف المحدد فقط</SelectItem>
              <SelectItem value="any_supervisor">أي مشرف</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>تاريخ البداية</Label><Input type="date" dir="ltr" lang="en" className="mt-1.5" value={startDate} onChange={e => setDateTime("start_at", e.target.value, startTime)} /></div>
        <div>
          <Label>وقت البداية (توقيت الرياض)</Label>
          <div className="mt-1.5 flex gap-2">
            <Input type="time" dir="ltr" lang="en" value={startTime} onChange={e => setDateTime("start_at", startDate, e.target.value)} />
            <Button type="button" variant="outline" size="sm" className="shrink-0" onClick={() => setNow("start_at", startDate)}>الآن</Button>
          </div>
        </div>
        <div><Label>تاريخ النهاية</Label><Input type="date" dir="ltr" lang="en" className="mt-1.5" value={endDate} onChange={e => setDateTime("end_at", e.target.value, endTime)} /></div>
        <div>
          <Label>وقت النهاية (توقيت الرياض)</Label>
          <div className="mt-1.5 flex gap-2">
            <Input type="time" dir="ltr" lang="en" value={endTime} onChange={e => setDateTime("end_at", endDate, e.target.value)} />
            <Button type="button" variant="outline" size="sm" className="shrink-0" onClick={() => setNow("end_at", endDate)}>الآن</Button>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
        <Switch checked={values.is_public_visible} onCheckedChange={v => onChange({ ...values, is_public_visible: v })} />
        <Label className="cursor-pointer">إظهار في الصفحة العامة</Label>
      </div>
      <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
        <Switch checked={values.enable_certificate ?? false} onCheckedChange={v => onChange({ ...values, enable_certificate: v })} />
        <Label className="cursor-pointer">تفعيل الشهادة لهذه الفرصة</Label>
      </div>
      {values.enable_certificate && templates && templates.length > 0 && (
        <div><Label>قالب الشهادة</Label>
          <Select value={values.certificate_template_id || ""} onValueChange={v => onChange({ ...values, certificate_template_id: v })}>
            <SelectTrigger className="mt-1.5 text-right"><SelectValue placeholder="القالب الافتراضي" /></SelectTrigger>
            <SelectContent>
              {templates.map(t => <SelectItem key={t.id} value={t.id}>{t.name}{t.is_default ? " (افتراضي)" : ""}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
};

const Opportunities = () => {
  const [search, setSearch] = useState("");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [data, setData] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [supervisors, setSupervisors] = useState<any[]>([]);
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { role, userId, canManage } = useRole();
  const isDirector = role === "director";
  const isSupervisor = role === "supervisor";

  const [filterStatus, setFilterStatus] = useState("all");
  const [filterDept, setFilterDept] = useState("all");
  const [filterSupervisor, setFilterSupervisor] = useState("all");

  const [rejectingApp, setRejectingApp] = useState<any>(null);
  const [rejectNote, setRejectNote] = useState("");
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);

  // Edit dialog state
  const [editOpp, setEditOpp] = useState<any>(null);
  const [editOpen, setEditOpen] = useState(false);

  const [certTemplates, setCertTemplates] = useState<any[]>([]);

  const fetchData = async () => {
    setLoading(true);
    const [oppRes, deptRes, supRes, appRes, tplRes] = await Promise.all([
      supabase.from("opportunities").select("*, departments(name), internal_users(full_name)").order("created_at", { ascending: false }),
      supabase.from("departments").select("*"),
      supabase.from("internal_users").select("id, full_name, role").eq("status", "active").in("role", ["supervisor", "director"]),
      supabase.from("opportunity_applications").select("*, volunteers(full_name), opportunities(title, supervisor_id, review_type)").order("created_at", { ascending: false }),
      supabase.from("certificate_templates").select("*").eq("is_active", true).order("created_at"),
    ]);
    setData(oppRes.data || []);
    setDepartments(deptRes.data || []);
    setSupervisors(supRes.data || []);
    setApplications(appRes.data || []);
    setCertTemplates(tplRes.data || []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  // Detect opportunities whose end_at has passed but are still marked "active",
  // and notify directors / assigned supervisor once per opportunity (deduped via localStorage).
  useEffect(() => {
    if (!data || data.length === 0) return;
    const now = new Date();
    const KEY = "rafadah:opp_ended_notified";
    let notified: string[] = [];
    try { notified = JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { notified = []; }
    const newly = data.filter((o: any) =>
      o.status === "active" &&
      o.end_at && new Date(o.end_at) < now &&
      !notified.includes(o.id),
    );
    if (newly.length === 0) return;
    (async () => {
      for (const o of newly) {
        try { await notifyInternalOpportunityEnded(o.title, o.id, o.supervisor_id || null); } catch (e) { console.error("notifyInternalOpportunityEnded failed:", e); }
      }
      const updated = [...notified, ...newly.map((o: any) => o.id)];
      try { localStorage.setItem(KEY, JSON.stringify(updated)); } catch {}
    })();
  }, [data]);

  const [form, setForm] = useState({
    title: "", department_id: "", supervisor_id: "", minimum_hours: "",
    start_at: "", end_at: "", capacity: "", is_public_visible: true,
    review_type: "assigned_supervisor", enable_certificate: false, certificate_template_id: "",
    proof_unlock_after_hours: "", proof_window_hours: "",
  });

  const handleAdd = async () => {
    if (!form.title || !form.department_id) {
      toast.error("الرجاء إدخال اسم الفرصة واختيار الإدارة");
      return;
    }
    const insertData: Record<string, any> = {
      title: form.title,
      department_id: form.department_id,
      supervisor_id: form.supervisor_id || null,
      minimum_hours: Number(form.minimum_hours) || 0,
      start_at: form.start_at || null,
      end_at: form.end_at || null,
      status: "draft",
    };
    if (form.capacity) insertData.capacity = Number(form.capacity);
    if (form.review_type) insertData.review_type = form.review_type;
    insertData.is_public_visible = form.is_public_visible;
    insertData.enable_certificate = form.enable_certificate;
    if (form.certificate_template_id) insertData.certificate_template_id = form.certificate_template_id;
    if (form.proof_unlock_after_hours !== "") insertData.proof_unlock_after_hours = Number(form.proof_unlock_after_hours);
    if (form.proof_window_hours !== "") insertData.proof_window_hours = Number(form.proof_window_hours);

    const { error } = await supabase.from("opportunities").insert(insertData);
    if (error) {
      console.error("Opportunity insert error:", error);
      // If error is about unknown columns, retry without them
      if (error.message?.includes("capacity") || error.message?.includes("is_public_visible") || error.message?.includes("review_type")) {
        const fallbackData: Record<string, any> = {
          title: form.title,
          department_id: form.department_id,
          supervisor_id: form.supervisor_id || null,
          minimum_hours: Number(form.minimum_hours) || 0,
          start_at: form.start_at || null,
          end_at: form.end_at || null,
          status: "draft",
        };
        const { error: err2 } = await supabase.from("opportunities").insert(fallbackData);
        if (err2) {
          toast.error(`خطأ في إضافة الفرصة: ${err2.message}`);
          return;
        }
        toast.success("تم إضافة الفرصة بنجاح (بدون الحقول الإضافية — يرجى تنفيذ migration أولاً)");
      } else {
        toast.error(`خطأ في إضافة الفرصة: ${error.message}`);
        return;
      }
    } else {
      toast.success("تم إضافة الفرصة بنجاح");
    }
    setForm({ title: "", department_id: "", supervisor_id: "", minimum_hours: "", start_at: "", end_at: "", capacity: "", is_public_visible: true, review_type: "assigned_supervisor", enable_certificate: false, certificate_template_id: "", proof_unlock_after_hours: "", proof_window_hours: "" });
    setAddDialogOpen(false);
    fetchData();
  };

  const changeStatus = async (opp: any, newStatus: string) => {
    const { error } = await supabase.from("opportunities").update({ status: newStatus }).eq("id", opp.id);
    if (error) { toast.error(`خطأ في تحديث الحالة: ${error.message}`); return; }
    toast.success(`تم تغيير الحالة إلى: ${statusMap[newStatus]}`);
    if (newStatus === "active") notifyNewOpportunity(opp.title, opp.id);
    fetchData();
  };

  const handleApprove = async (app: any) => {
    const { error } = await supabase.from("opportunity_applications").update({ status: "approved", reviewed_by: userId, reviewed_at: new Date().toISOString() }).eq("id", app.id);
    if (error) { toast.error(`حدث خطأ: ${error.message}`); return; }

    // Update participant_count on the opportunity
    const { data: oppData } = await supabase.from("opportunities").select("participant_count").eq("id", app.opportunity_id).single();
    if (oppData) {
      await supabase.from("opportunities").update({
        participant_count: (oppData.participant_count || 0) + 1,
      }).eq("id", app.opportunity_id);
    }

    // Create participation record — skip if already exists
    const { data: existingPart } = await supabase.from("participations")
      .select("id").eq("volunteer_id", app.volunteer_id).eq("opportunity_id", app.opportunity_id).limit(1);
    if (!existingPart || existingPart.length === 0) {
      await supabase.from("participations").insert({
        volunteer_id: app.volunteer_id,
        opportunity_id: app.opportunity_id,
        approval_status: "pending",
        proof_status: "pending",
      });
    }

    toast.success("تم قبول الطلب وتحديث السعة");
    notifyApplicationDecision(app.volunteer_id, app.opportunities?.title || "", app.id, "approved");
    fetchData();
  };

  const openRejectDialog = (app: any) => { setRejectingApp(app); setRejectNote(""); setRejectDialogOpen(true); };

  const confirmReject = async () => {
    if (!rejectingApp) return;
    const { error } = await supabase.from("opportunity_applications").update({
      status: "rejected", reviewed_by: userId, reviewed_at: new Date().toISOString(), review_note: rejectNote.trim() || null,
    }).eq("id", rejectingApp.id);
    if (error) { toast.error(`حدث خطأ: ${error.message}`); return; }
    toast.success("تم رفض الطلب");
    notifyApplicationDecision(rejectingApp.volunteer_id, rejectingApp.opportunities?.title || "", rejectingApp.id, "rejected", rejectNote.trim() || undefined);
    setRejectDialogOpen(false);
    setRejectingApp(null);
    setRejectNote("");
    fetchData();
  };

  // Edit opportunity
  const openEditDialog = (opp: any) => {
    setEditOpp({
      ...opp,
      is_public_visible: opp.is_public_visible ?? true,
      capacity: opp.capacity ?? 0,
      review_type: opp.review_type ?? "assigned_supervisor",
    });
    setEditOpen(true);
  };

  // Duplicate opportunity → open the "add" dialog prefilled with the source opportunity's
  // reusable fields. Does NOT modify the original record.
  const duplicateOpportunity = (opp: any) => {
    setForm({
      title: opp.title ? `${opp.title} (نسخة)` : "",
      department_id: opp.department_id || "",
      supervisor_id: opp.supervisor_id || "",
      minimum_hours: opp.minimum_hours != null ? String(opp.minimum_hours) : "",
      start_at: opp.start_at || "",
      end_at: opp.end_at || "",
      capacity: opp.capacity != null ? String(opp.capacity) : "",
      is_public_visible: opp.is_public_visible ?? true,
      review_type: opp.review_type ?? "assigned_supervisor",
      enable_certificate: opp.enable_certificate ?? false,
      certificate_template_id: opp.certificate_template_id || "",
      proof_unlock_after_hours: opp.proof_unlock_after_hours != null ? String(opp.proof_unlock_after_hours) : "",
      proof_window_hours: opp.proof_window_hours != null ? String(opp.proof_window_hours) : "",
    });
    setAddDialogOpen(true);
  };

  const handleEditSave = async () => {
    if (!editOpp) return;
    const updateData: Record<string, any> = {
      title: editOpp.title,
      department_id: editOpp.department_id,
      supervisor_id: editOpp.supervisor_id || null,
      minimum_hours: Number(editOpp.minimum_hours) || 0,
      start_at: editOpp.start_at || null,
      end_at: editOpp.end_at || null,
    };
    updateData.is_public_visible = editOpp.is_public_visible;
    updateData.capacity = Number(editOpp.capacity) || 0;
    updateData.review_type = editOpp.review_type;
    updateData.enable_certificate = editOpp.enable_certificate ?? false;
    updateData.certificate_template_id = editOpp.certificate_template_id || null;
    if (editOpp.proof_unlock_after_hours !== "" && editOpp.proof_unlock_after_hours !== undefined && editOpp.proof_unlock_after_hours !== null)
      updateData.proof_unlock_after_hours = Number(editOpp.proof_unlock_after_hours);
    if (editOpp.proof_window_hours !== "" && editOpp.proof_window_hours !== undefined && editOpp.proof_window_hours !== null)
      updateData.proof_window_hours = Number(editOpp.proof_window_hours);

    const { error } = await supabase.from("opportunities").update(updateData).eq("id", editOpp.id);
    if (error) {
      console.error("Edit error:", error);
      // Fallback without new fields
      if (error.message?.includes("capacity") || error.message?.includes("is_public_visible") || error.message?.includes("review_type")) {
        const fallback = { title: editOpp.title, department_id: editOpp.department_id, supervisor_id: editOpp.supervisor_id || null, minimum_hours: Number(editOpp.minimum_hours) || 0, start_at: editOpp.start_at || null, end_at: editOpp.end_at || null };
        const { error: err2 } = await supabase.from("opportunities").update(fallback).eq("id", editOpp.id);
        if (err2) { toast.error(`خطأ في التحديث: ${err2.message}`); return; }
        toast.success("تم تحديث الفرصة (بدون الحقول الإضافية)");
      } else {
        toast.error(`خطأ في التحديث: ${error.message}`);
        return;
      }
    } else {
      toast.success("تم تحديث الفرصة بنجاح");
    }
    setEditOpen(false);
    setEditOpp(null);
    fetchData();
  };

  const visibleApplications = applications.filter(a => {
    if (isDirector) return true;
    if (isSupervisor && userId) {
      const reviewType = a.opportunities?.review_type || "assigned_supervisor";
      if (reviewType === "any_supervisor") return true;
      return a.opportunities?.supervisor_id === userId;
    }
    return true;
  });

  const filtered = data.filter((o: any) => {
    if (search && !o.title.includes(search)) return false;
    if (filterStatus !== "all" && o.status !== filterStatus) return false;
    if (filterDept !== "all" && o.department_id !== filterDept) return false;
    if (filterSupervisor !== "all" && o.supervisor_id !== filterSupervisor) return false;
    return true;
  });

  const pendingApps = visibleApplications.filter(a => a.status === "pending");

  const exportData = filtered.map(r => ({
    title: r.title, department: r.departments?.name || "—", supervisor: r.internal_users?.full_name || "—",
    start: r.start_at ? formatDate(r.start_at) : "—",
    end: r.end_at ? formatDate(r.end_at) : "—",
    min_hours: `${r.minimum_hours} ساعات`, status: statusMap[r.status] || r.status,
    participants: r.participant_count, capacity: r.capacity || "∞",
  }));
  const exportCols = [
    { header: "اسم الفرصة", key: "title" }, { header: "الإدارة", key: "department" },
    { header: "المشرف", key: "supervisor" }, { header: "البداية", key: "start" },
    { header: "النهاية", key: "end" }, { header: "الحد الأدنى", key: "min_hours" },
    { header: "الحالة", key: "status" }, { header: "المشاركين", key: "participants" },
    { header: "السعة", key: "capacity" },
  ];

  return (
    <div>
      <PageHeader title="الفرص التطوعية" description="إدارة وعرض الفرص التطوعية" actions={
        <div className="flex gap-2 items-center">
          <ExportButtons data={exportData} columns={exportCols} title="الفرص التطوعية" filename="opportunities" />
          {isDirector && (
            <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
              <DialogTrigger asChild><Button><Plus className="h-4 w-4 ml-2" />إضافة فرصة</Button></DialogTrigger>
              <DialogContent className="max-w-lg" dir="rtl">
                <DialogHeader><DialogTitle>إضافة فرصة جديدة</DialogTitle></DialogHeader>
                <OpportunityFormFields values={form} onChange={setForm} departments={departments} supervisors={supervisors} templates={certTemplates} />
                <Button className="w-full sm:w-auto" onClick={handleAdd}>إضافة</Button>
              </DialogContent>
            </Dialog>
          )}
        </div>
      } />

      <Tabs defaultValue="opportunities" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="opportunities">الفرص</TabsTrigger>
          {canManage && (
            <TabsTrigger value="applications" className="relative">
              طلبات الانضمام
              {pendingApps.length > 0 && <span className="mr-1.5 inline-flex items-center justify-center h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold">{pendingApps.length}</span>}
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="opportunities">
          <div dir="rtl" className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="بحث بالاسم..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32 h-10"><SelectValue placeholder="الحالة" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الحالات</SelectItem>
                <SelectItem value="draft">مسودة</SelectItem>
                <SelectItem value="active">نشطة</SelectItem>
                <SelectItem value="closed">منتهية</SelectItem>
                <SelectItem value="archived">مؤرشفة</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterDept} onValueChange={setFilterDept}>
              <SelectTrigger className="w-36 h-10"><SelectValue placeholder="الإدارة" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الإدارات</SelectItem>
                {departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterSupervisor} onValueChange={setFilterSupervisor}>
              <SelectTrigger className="w-36 h-10"><SelectValue placeholder="المشرف" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل المشرفين</SelectItem>
                {supervisors.map(s => <SelectItem key={s.id} value={s.id}>{s.full_name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <DataTable columns={[
            { header: "اسم الفرصة", accessor: "title" },
            { header: "الإدارة", accessor: (r: any) => r.departments?.name || "—" },
            { header: "المشرف", accessor: (r: any) => r.internal_users?.full_name || "—" },
            { header: "البداية", accessor: (r: any) => r.start_at ? formatDate(r.start_at) : "—" },
            { header: "السعة", accessor: (r: any) => {
              const cap = r.capacity || 0;
              const count = r.participant_count || 0;
              if (cap === 0) return <span className="text-muted-foreground text-xs">غير محدود</span>;
              const full = count >= cap;
              return (
                <span className={`text-xs font-medium ${full ? "text-destructive" : "text-foreground"}`}>
                  {count}/{cap} {full ? "(ممتلئة)" : ""}
                </span>
              );
            }},
            { header: "العامة", accessor: (r: any) => (
              <span className={`text-xs font-medium ${r.is_public_visible ? "text-success" : "text-muted-foreground"}`}>
                {r.is_public_visible ? "ظاهرة" : "مخفية"}
              </span>
            )},
            { header: "الحالة", accessor: (r: any) => (
              canManage ? (
                <Select value={r.status} onValueChange={v => changeStatus(r, v)}>
                  <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">مسودة</SelectItem>
                    <SelectItem value="active">نشطة</SelectItem>
                    <SelectItem value="closed">منتهية</SelectItem>
                    <SelectItem value="archived">مؤرشفة</SelectItem>
                  </SelectContent>
                </Select>
              ) : <StatusBadge status={statusMap[r.status] || r.status} variant={statusVariant(r.status)} />
            )},
            { header: "إجراءات", accessor: (r: any) => (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" onClick={() => openEditDialog(r)} title="تعديل / تفاصيل">
                  <Eye className="h-4 w-4 text-primary" />
                </Button>
                {isDirector && (
                  <Button variant="ghost" size="sm" onClick={() => duplicateOpportunity(r)} title="تكرار الفرصة">
                    <Copy className="h-4 w-4 text-primary" />
                  </Button>
                )}
              </div>
            )},
          ]} data={filtered} />
        </TabsContent>

        {canManage && (
          <TabsContent value="applications">
            <DataTable columns={[
              { header: "المتطوع", accessor: (r: any) => r.volunteers?.full_name || "—" },
              { header: "الفرصة", accessor: (r: any) => r.opportunities?.title || "—" },
              { header: "تاريخ الطلب", accessor: (r: any) => formatDate(r.created_at) },
              { header: "الحالة", accessor: (r: any) => (
                <div>
                  <StatusBadge status={appStatusMap[r.status] || r.status} variant={appStatusVariant(r.status)} />
                  {r.status === "rejected" && r.review_note && <p className="text-xs text-muted-foreground mt-1">السبب: {r.review_note}</p>}
                </div>
              )},
              { header: "إجراءات", accessor: (r: any) => {
                if (r.status !== "pending") return <span className="text-xs text-muted-foreground">{appStatusMap[r.status]}</span>;
                return (
                  <div className="flex gap-1">
                    <Button size="sm" variant="default" onClick={() => handleApprove(r)}><Check className="h-4 w-4 ml-1" />قبول</Button>
                    <Button size="sm" variant="destructive" onClick={() => openRejectDialog(r)}><X className="h-4 w-4 ml-1" />رفض</Button>
                  </div>
                );
              }},
            ]} data={visibleApplications} emptyMessage="لا توجد طلبات انضمام حاليًا" />
          </TabsContent>
        )}
      </Tabs>

      {/* Reject Dialog */}
      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>سبب الرفض</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">هل تريد رفض طلب <strong>{rejectingApp?.volunteers?.full_name}</strong> للفرصة <strong>{rejectingApp?.opportunities?.title}</strong>؟</p>
            <div><Label>ملاحظة (اختياري)</Label><Textarea className="mt-1.5" placeholder="اكتب سبب الرفض إن وُجد..." value={rejectNote} onChange={e => setRejectNote(e.target.value)} rows={3} /></div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button variant="destructive" onClick={confirmReject}>تأكيد الرفض</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Opportunity Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>تعديل الفرصة</DialogTitle></DialogHeader>
          {editOpp && (
            <>
              <OpportunityFormFields values={editOpp} onChange={setEditOpp} departments={departments} supervisors={supervisors} templates={certTemplates} />
              <DialogFooter className="gap-2 sm:gap-0 mt-4">
                <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
                <Button onClick={handleEditSave}>حفظ التعديلات</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Opportunities;
