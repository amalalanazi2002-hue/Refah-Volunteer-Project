import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CalendarCheck, Mail, Phone, LogIn, Send, Clock, Users, MapPin, UserPlus, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import fallbackLogo from "@/assets/logo.png";
import { formatDate } from "@/lib/format-date";
import { validateContactForm, normalizeMobile, normalizeNationalId, normalizeEmail, handleMobileInput, handleNationalIdInput, handleEmailInput } from "@/lib/validators";
import { notifyInternalNewRegistration } from "@/lib/notifications";

interface PublicOpp {
  id: string;
  title: string;
  start_at: string | null;
  end_at: string | null;
  minimum_hours: number;
  participant_count: number;
  capacity: number;
  departments: { name: string } | null;
}

interface BrandingInfo {
  platform_name: string;
  org_name: string;
  org_description: string;
  contact_email: string;
  contact_phone: string;
  logo_url: string;
}

type RegistrationField = "full_name" | "mobile" | "email" | "national_id" | "city";
type RegistrationErrors = Partial<Record<RegistrationField, string>>;

const defaults: BrandingInfo = {
  platform_name: "منصة رفادة التطوعية",
  org_name: "جمعية رفاه للأرامل والمطلقات",
  org_description: "منصة تطوعية تهدف إلى تمكين المتطوعين وربطهم بالفرص التطوعية المتنوعة لخدمة المجتمع.",
  contact_email: "info@rafah.org",
  contact_phone: "920001234",
  logo_url: "",
};

const PublicPage = () => {
  const navigate = useNavigate();
  const [opportunities, setOpportunities] = useState<PublicOpp[]>([]);
  const [branding, setBranding] = useState<BrandingInfo>(defaults);
  const [loading, setLoading] = useState(true);
  const [regOpen, setRegOpen] = useState(false);
  const [regForm, setRegForm] = useState({ full_name: "", mobile: "", email: "", national_id: "", city: "" });
  const [regErrors, setRegErrors] = useState<RegistrationErrors>({});
  const [regLoading, setRegLoading] = useState(false);
  const [cities, setCities] = useState<string[]>([]);

  useEffect(() => {
    const load = async () => {
      const [oppRes, settingsRes] = await Promise.all([
        supabase.from("opportunities").select("id, title, start_at, end_at, minimum_hours, participant_count, capacity, departments(name)").eq("status", "active").eq("is_public_visible", true).order("created_at", { ascending: false }).limit(6),
        supabase.from("system_settings").select("key, value").in("key", ["platform_name", "org_name", "org_description", "contact_email", "contact_phone", "logo_url", "cities"]),
      ]);
      setOpportunities((oppRes.data as unknown as PublicOpp[]) || []);
      if (settingsRes.data) {
        const map: Record<string, string> = {};
        settingsRes.data.forEach((r: any) => { map[r.key] = r.value; });
        setBranding({
          platform_name: map.platform_name || defaults.platform_name,
          org_name: map.org_name || defaults.org_name,
          org_description: map.org_description || defaults.org_description,
          contact_email: map.contact_email || defaults.contact_email,
          contact_phone: map.contact_phone || defaults.contact_phone,
          logo_url: map.logo_url || defaults.logo_url,
        });
        if (map.cities) {
          try { setCities(JSON.parse(map.cities)); } catch {}
        }
      }
      setLoading(false);
    };
    load();
  }, []);

  const handleApply = (oppId: string) => {
    navigate(`/login?redirect=/volunteer/opportunities&opp=${oppId}`);
  };

  const updateRegField = (field: RegistrationField, value: string) => {
    setRegForm((prev) => ({ ...prev, [field]: value }));
    setRegErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleRegister = async () => {
    const normalizedForm = {
      full_name: regForm.full_name.trim(),
      mobile: normalizeMobile(regForm.mobile),
      email: normalizeEmail(regForm.email),
      national_id: normalizeNationalId(regForm.national_id),
      city: regForm.city,
    };

    const errs = validateContactForm({
      full_name: normalizedForm.full_name,
      mobile: normalizedForm.mobile,
      national_id: normalizedForm.national_id,
      email: normalizedForm.email,
    }) as RegistrationErrors;
    if (!normalizedForm.city) (errs as any).city = "المدينة مطلوبة";

    if (Object.keys(errs).length > 0) {
      setRegErrors(errs);
      toast.error("الرجاء تصحيح الحقول المظلّلة");
      return;
    }

    setRegLoading(true);
    setRegErrors({});

    // Public endpoint (verify_jwt = false): do not send an Authorization header.
    // A publishable key in Authorization is not a JWT and the gateway rejects it
    // before the request reaches the function.
    const SUPABASE_URL = "https://zrvzxlpokekenneiovvt.supabase.co";
    const SUPABASE_ANON_KEY = "sb_publishable_Xy6ZNvZT-uYzkm8QQjG47Q_0C9n5k8K";
    let fnRes: any = null;
    let fnError: { message: string } | null = null;
    try {
      const resp = await fetch(
        `${SUPABASE_URL}/functions/v1/public-volunteer-registration`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            full_name: normalizedForm.full_name,
            mobile: normalizedForm.mobile,
            email: normalizedForm.email || null,
            national_id: normalizedForm.national_id,
            city: normalizedForm.city || null,
          }),
        },
      );
      const text = await resp.text();
      try { fnRes = text ? JSON.parse(text) : null; } catch { fnRes = { raw: text }; }
      if (!resp.ok) {
        fnError = {
          message:
            (fnRes && (fnRes.error || fnRes.message || fnRes.msg || fnRes.code)) ||
            `HTTP ${resp.status}: ${text || resp.statusText}`,
        };
      } else if (fnRes && fnRes.ok === false) {
        fnError = { message: fnRes.error || fnRes.message || "حدث خطأ غير معروف" };
      }
    } catch (e: any) {
      fnError = { message: e?.message || "تعذّر الاتصال بالخادم" };
    }
    setRegLoading(false);
    const inserted = fnRes?.id ? { id: fnRes.id } : null;
    if (fnError) {
      console.error("Registration error:", fnError);
      const msg = fnError.message || "";
      const fieldErrors: RegistrationErrors = {};
      if (msg.includes("mobile") || msg.includes("الجوال")) fieldErrors.mobile = "رقم الجوال غير صالح";
      else if (msg.includes("national_id") || msg.includes("الهوية")) fieldErrors.national_id = "رقم الهوية غير صالح";
      else if (msg.includes("email") || msg.includes("البريد")) fieldErrors.email = "البريد الإلكتروني غير صالح";
      setRegErrors(fieldErrors);
      toast.error(msg || "حدث خطأ أثناء التسجيل");
      return;
    }
    // Fire-and-forget internal notification
    if (inserted?.id) {
      notifyInternalNewRegistration(normalizedForm.full_name, inserted.id).catch(err =>
        console.error("notifyInternalNewRegistration failed:", err),
      );
    }
    toast.success("تم إرسال طلب التسجيل بنجاح، سيتم مراجعته من قبل الإدارة");
    setRegForm({ full_name: "", mobile: "", email: "", national_id: "", city: "" });
    setRegOpen(false);
  };

  const isFull = (opp: PublicOpp) => opp.capacity > 0 && opp.participant_count >= opp.capacity;
  const seatsLeft = (opp: PublicOpp) => opp.capacity > 0 ? Math.max(0, opp.capacity - opp.participant_count) : null;
  const isEnded = (opp: PublicOpp) => !!(opp.end_at && new Date(opp.end_at) < new Date());

  const logoSrc = branding.logo_url || fallbackLogo;

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/95 backdrop-blur border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={logoSrc} alt={branding.platform_name} className="h-10 w-10 rounded-lg object-contain bg-primary/10 p-1" onError={(e) => { (e.target as HTMLImageElement).src = fallbackLogo; }} />
            <div>
              <h1 className="text-sm font-bold text-foreground leading-tight">{branding.platform_name}</h1>
              <p className="text-[11px] text-muted-foreground">{branding.org_name}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Dialog open={regOpen} onOpenChange={setRegOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm"><UserPlus className="h-4 w-4 ml-1" />الانضمام كمتطوع</Button>
              </DialogTrigger>
              <DialogContent className="max-w-md" dir="rtl">
                <DialogHeader><DialogTitle>طلب تسجيل متطوع</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>الاسم الكامل *</Label>
                    <Input
                      placeholder="أدخل الاسم الكامل"
                      className={`mt-1.5 ${regErrors.full_name ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      value={regForm.full_name}
                      aria-invalid={!!regErrors.full_name}
                      onChange={e => updateRegField("full_name", e.target.value)}
                    />
                    {regErrors.full_name && <p className="mt-1 text-xs text-destructive">{regErrors.full_name}</p>}
                  </div>
                  <div>
                    <Label>رقم الجوال *</Label>
                    <Input
                      placeholder="05xxxxxxxx"
                      className={`mt-1.5 ${regErrors.mobile ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      dir="ltr"
                      inputMode="numeric"
                      maxLength={10}
                      value={regForm.mobile}
                      aria-invalid={!!regErrors.mobile}
                      onChange={e => updateRegField("mobile", handleMobileInput(e.target.value))}
                    />
                    {regErrors.mobile && <p className="mt-1 text-xs text-destructive">{regErrors.mobile}</p>}
                  </div>
                  <div>
                    <Label>البريد الإلكتروني</Label>
                    <Input
                      type="email"
                      placeholder="example@email.com"
                      className={`mt-1.5 ${regErrors.email ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      dir="ltr"
                      maxLength={254}
                      value={regForm.email}
                      aria-invalid={!!regErrors.email}
                      onChange={e => updateRegField("email", handleEmailInput(e.target.value))}
                      onBlur={e => { const v = e.target.value; if (v && !/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(v)) setRegErrors(p => ({ ...p, email: "صيغة البريد الإلكتروني غير صحيحة" })); }}
                    />
                    {regErrors.email && <p className="mt-1 text-xs text-destructive">{regErrors.email}</p>}
                  </div>
                  <div>
                    <Label>رقم الهوية *</Label>
                    <Input
                      placeholder="أدخل رقم الهوية"
                      className={`mt-1.5 ${regErrors.national_id ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      dir="ltr"
                      inputMode="numeric"
                      maxLength={10}
                      value={regForm.national_id}
                      aria-invalid={!!regErrors.national_id}
                      onChange={e => updateRegField("national_id", handleNationalIdInput(e.target.value))}
                    />
                    {regErrors.national_id && <p className="mt-1 text-xs text-destructive">{regErrors.national_id}</p>}
                  </div>
                  <div>
                    <Label>المدينة *</Label>
                    <Select value={regForm.city} onValueChange={v => updateRegField("city", v)}>
                      <SelectTrigger className={`mt-1.5 ${regErrors.city ? "border-destructive focus-visible:ring-destructive" : ""}`}>
                        <SelectValue placeholder="اختر المدينة" />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.length > 0
                          ? cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)
                          : <SelectItem value="__no_cities__" disabled>لا توجد مدن — أضف مدنًا من الإعدادات</SelectItem>
                        }
                      </SelectContent>
                    </Select>
                    {regErrors.city && <p className="mt-1 text-xs text-destructive">{regErrors.city}</p>}
                  </div>
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                    <span>سيتم مراجعة طلبك من قبل الإدارة وإبلاغك بالنتيجة</span>
                  </div>
                  <Button className="w-full" onClick={handleRegister} disabled={regLoading}>
                    {regLoading ? "جارٍ الإرسال..." : "إرسال الطلب"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            <Button size="sm" onClick={() => navigate("/login")}>
              <LogIn className="h-4 w-4 ml-1" />تسجيل الدخول
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-b from-primary/10 to-background py-16 md:py-24">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <img src={logoSrc} alt={branding.platform_name} className="h-20 w-20 mx-auto rounded-2xl object-contain bg-card p-3 shadow-md mb-6" onError={(e) => { (e.target as HTMLImageElement).src = fallbackLogo; }} />
          <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-4">{branding.platform_name}</h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">{branding.org_description}</p>
          <div className="flex justify-center gap-3 mt-8">
            <Button size="lg" onClick={() => navigate("/login")}><LogIn className="h-5 w-5 ml-2" />ابدأ التطوع الآن</Button>
            <Button size="lg" variant="outline" onClick={() => setRegOpen(true)}><UserPlus className="h-5 w-5 ml-2" />سجّل كمتطوع</Button>
          </div>
        </div>
      </section>

      {/* Opportunities */}
      <section className="py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-10">
            <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">الفرص التطوعية المتاحة</h3>
            <p className="text-sm text-muted-foreground">انضم إلينا وساهم في خدمة المجتمع</p>
          </div>

          {loading ? (
            <p className="text-center text-muted-foreground text-sm">جارٍ التحميل...</p>
          ) : opportunities.length === 0 ? (
            <div className="bg-card rounded-xl border border-border p-12 text-center">
              <CalendarCheck className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
              <p className="text-muted-foreground font-medium">لا توجد فرص متاحة حاليًا</p>
              <p className="text-xs text-muted-foreground/60 mt-1">تابعنا لمعرفة الفرص الجديدة</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {opportunities.map((opp) => {
                const full = isFull(opp);
                const ended = isEnded(opp);
                const seats = seatsLeft(opp);
                const disabled = full || ended;
                return (
                  <div key={opp.id} className={`relative bg-card rounded-xl border border-border p-5 hover:shadow-md transition-shadow ${disabled ? "opacity-75" : ""}`}>
                    <div className="flex items-start justify-between mb-2 gap-2">
                      <h4 className="font-bold text-foreground">{opp.title}</h4>
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        {ended && <span className="text-[10px] bg-destructive/10 text-destructive px-2 py-0.5 rounded-full font-semibold">انتهت فترة التقديم</span>}
                        {!ended && full && <span className="text-[10px] bg-destructive/10 text-destructive px-2 py-0.5 rounded-full font-semibold">ممتلئة</span>}
                      </div>
                    </div>
                    <div className="space-y-1.5 text-sm text-muted-foreground mb-4">
                      {opp.departments?.name && (
                        <div className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /><span>{opp.departments.name}</span></div>
                      )}
                      <div className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /><span>الحد الأدنى: {opp.minimum_hours} ساعات</span></div>
                      {opp.start_at && (
                        <div className="flex items-center gap-1.5">
                          <CalendarCheck className="h-3.5 w-3.5" />
                          <span>{formatDate(opp.start_at)}</span>
                          {opp.end_at && <span>— {formatDate(opp.end_at)}</span>}
                        </div>
                      )}
                      <div className="flex items-center gap-1.5">
                        <Users className="h-3.5 w-3.5" />
                        <span>{opp.participant_count || 0} مشارك{seats !== null ? ` · ${seats} مقعد متبقي` : ""}</span>
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => handleApply(opp.id)} disabled={disabled}>
                      <Send className="h-4 w-4 ml-1" />
                      {ended ? "انتهت فترة التقديم" : full ? "ممتلئة" : "التقديم على الفرصة"}
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Contact */}
      <section className="py-12 md:py-16 bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-xl md:text-2xl font-bold text-foreground mb-6">تواصل معنا</h3>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            {branding.contact_email && (
              <a href={`mailto:${branding.contact_email}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                <Mail className="h-5 w-5 text-primary" /><span dir="ltr">{branding.contact_email}</span>
              </a>
            )}
            {branding.contact_phone && (
              <a href={`tel:${branding.contact_phone}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                <Phone className="h-5 w-5 text-primary" /><span dir="ltr">{branding.contact_phone}</span>
              </a>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-6">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-xs text-muted-foreground">{branding.org_name} — {branding.platform_name}</p>
        </div>
      </footer>
    </div>
  );
};

export default PublicPage;
