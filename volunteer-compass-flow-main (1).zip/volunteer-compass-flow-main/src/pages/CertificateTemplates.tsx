import { useState, useEffect, useCallback } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Edit, Star, Award, Eye, Trash2 } from "lucide-react";

const defaultPlaceholders = [
  { key: "{{volunteer_name}}", label: "اسم المتطوع", x: 50, y: 45, fontSize: 22, fontWeight: "bold", color: "#1A1A2E", align: "center" },
  { key: "{{opportunity_title}}", label: "اسم الفرصة", x: 50, y: 55, fontSize: 15, fontWeight: "bold", color: "#5E4EA2", align: "center" },
  { key: "{{approved_hours}}", label: "الساعات المعتمدة", x: 50, y: 63, fontSize: 13, fontWeight: "normal", color: "#555555", align: "center" },
  { key: "{{completion_date}}", label: "تاريخ الإنجاز", x: 50, y: 70, fontSize: 12, fontWeight: "normal", color: "#555555", align: "center" },
  { key: "{{certificate_number}}", label: "رقم الشهادة", x: 15, y: 92, fontSize: 10, fontWeight: "normal", color: "#999999", align: "left" },
  { key: "{{organization_name}}", label: "اسم الجهة", x: 50, y: 20, fontSize: 16, fontWeight: "bold", color: "#A86DA8", align: "center" },
  { key: "{{department_name}}", label: "الإدارة", x: 50, y: 76, fontSize: 12, fontWeight: "normal", color: "#555555", align: "center" },
  { key: "{{issue_date}}", label: "تاريخ الإصدار", x: 85, y: 92, fontSize: 10, fontWeight: "normal", color: "#999999", align: "right" },
];

const CertificateTemplates = () => {
  const [templates, setTemplates] = useState<any[]>([]);
  const [editTemplate, setEditTemplate] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [enableCertificates, setEnableCertificates] = useState(true);
  const [selectedPlaceholder, setSelectedPlaceholder] = useState<number | null>(null);

  const fetchData = useCallback(async () => {
    const [tplRes, settingsRes] = await Promise.all([
      supabase.from("certificate_templates").select("*").order("created_at", { ascending: true }),
      supabase.from("system_settings").select("value").eq("key", "enable_certificates").limit(1),
    ]);
    setTemplates(tplRes.data || []);
    setEnableCertificates(settingsRes.data?.[0]?.value !== "false");
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const toggleGlobalCertificates = async (enabled: boolean) => {
    const val = enabled ? "true" : "false";
    const { data: existing } = await supabase.from("system_settings").select("id").eq("key", "enable_certificates").limit(1);
    if (existing && existing.length > 0) {
      await supabase.from("system_settings").update({ value: val }).eq("key", "enable_certificates");
    } else {
      await supabase.from("system_settings").insert({ key: "enable_certificates", value: val });
    }
    setEnableCertificates(enabled);
    toast.success(enabled ? "تم تفعيل الشهادات" : "تم تعطيل الشهادات");
  };

  const openNew = () => {
    setEditTemplate({
      name: "", description: "", is_active: true, is_default: false,
      design_config: {
        bg_color: "#FAFAFA", border_color: "#5E4EA2", text_color: "#1A1A2E", accent_color: "#A86DA8",
        layout: "classic", bg_image_url: "",
        placeholders: defaultPlaceholders.map(p => ({ ...p })),
      },
    });
    setSelectedPlaceholder(null);
    setDialogOpen(true);
  };

  const openEdit = (tpl: any) => {
    const config = tpl.design_config || {};
    if (!config.placeholders) {
      config.placeholders = defaultPlaceholders.map(p => ({ ...p }));
    }
    setEditTemplate({ ...tpl, design_config: config });
    setSelectedPlaceholder(null);
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!editTemplate?.name?.trim()) { toast.error("الرجاء إدخال اسم القالب"); return; }
    if (editTemplate.id) {
      await supabase.from("certificate_templates").update({
        name: editTemplate.name, description: editTemplate.description, is_active: editTemplate.is_active,
        is_default: editTemplate.is_default, design_config: editTemplate.design_config, updated_at: new Date().toISOString(),
      }).eq("id", editTemplate.id);
      toast.success("تم تحديث القالب");
    } else {
      await supabase.from("certificate_templates").insert({
        name: editTemplate.name, description: editTemplate.description, is_active: editTemplate.is_active,
        is_default: editTemplate.is_default, design_config: editTemplate.design_config,
      });
      toast.success("تم إنشاء القالب");
    }
    if (editTemplate.is_default) {
      await supabase.from("certificate_templates").update({ is_default: false }).neq("id", editTemplate.id || "");
    }
    setDialogOpen(false);
    setEditTemplate(null);
    fetchData();
  };

  const config = editTemplate?.design_config || {};
  const setConfig = (key: string, val: any) => {
    setEditTemplate({ ...editTemplate, design_config: { ...config, [key]: val } });
  };

  const placeholders: any[] = config.placeholders || [];
  const updatePlaceholder = (index: number, key: string, val: any) => {
    const updated = [...placeholders];
    updated[index] = { ...updated[index], [key]: val };
    setConfig("placeholders", updated);
  };

  const sp = selectedPlaceholder !== null ? placeholders[selectedPlaceholder] : null;

  return (
    <div>
      <PageHeader title="قوالب الشهادات" description="إدارة قوالب شهادات التطوع" actions={
        <Button onClick={openNew}><Plus className="h-4 w-4 ml-2" />قالب جديد</Button>
      } />

      <div className="flex items-center gap-3 mb-5 p-3 rounded-lg bg-card border border-border">
        <Switch checked={enableCertificates} onCheckedChange={toggleGlobalCertificates} />
        <Label>تفعيل نظام الشهادات عالميًا</Label>
      </div>

      <DataTable
        columns={[
          { header: "اسم القالب", accessor: (r: any) => (
            <div className="flex items-center gap-2">
              <span>{r.name}</span>
              {r.is_default && <Star className="h-3 w-3 text-warning fill-warning" />}
            </div>
          )},
          { header: "الوصف", accessor: (r: any) => r.description || "—" },
          { header: "الحالة", accessor: (r: any) => <StatusBadge status={r.is_active ? "مفعل" : "معطل"} variant={r.is_active ? "success" : "neutral"} /> },
          { header: "إجراءات", accessor: (r: any) => (
            <Button variant="ghost" size="sm" onClick={() => openEdit(r)}><Edit className="h-4 w-4 text-primary" /></Button>
          )},
        ]}
        data={templates}
        emptyMessage="لا توجد قوالب شهادات"
        emptyIcon={<Award className="h-10 w-10 text-muted-foreground/30" />}
      />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[92vh] overflow-hidden p-0" dir="rtl">
          <DialogHeader className="px-6 pt-6"><DialogTitle>{editTemplate?.id ? "تعديل القالب" : "إنشاء قالب جديد"}</DialogTitle></DialogHeader>
          {editTemplate && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 px-6 pb-2 max-h-[75vh] overflow-hidden">
              {/* Left: Settings (scrollable) */}
              <div className="space-y-4 overflow-y-auto pl-2 -ml-2 pr-1">
                <div><Label>اسم القالب *</Label><Input className="mt-1.5" value={editTemplate.name} onChange={e => setEditTemplate({ ...editTemplate, name: e.target.value })} /></div>
                <div><Label>الوصف</Label><Textarea className="mt-1.5" rows={2} value={editTemplate.description || ""} onChange={e => setEditTemplate({ ...editTemplate, description: e.target.value })} /></div>
                <div className="flex items-center gap-3">
                  <Switch checked={editTemplate.is_active} onCheckedChange={v => setEditTemplate({ ...editTemplate, is_active: v })} />
                  <Label>مفعل</Label>
                </div>
                <div className="flex items-center gap-3">
                  <Switch checked={editTemplate.is_default} onCheckedChange={v => setEditTemplate({ ...editTemplate, is_default: v })} />
                  <Label>القالب الافتراضي</Label>
                </div>

                <div className="border-t border-border pt-3 space-y-3">
                  <p className="text-xs font-semibold text-muted-foreground">ألوان القالب</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div><Label className="text-xs">لون الإطار</Label><Input type="color" className="mt-1 h-9" value={config.border_color || "#5E4EA2"} onChange={e => setConfig("border_color", e.target.value)} /></div>
                    <div><Label className="text-xs">لون الخلفية</Label><Input type="color" className="mt-1 h-9" value={config.bg_color || "#FAFAFA"} onChange={e => setConfig("bg_color", e.target.value)} /></div>
                    <div><Label className="text-xs">لون النص</Label><Input type="color" className="mt-1 h-9" value={config.text_color || "#1A1A2E"} onChange={e => setConfig("text_color", e.target.value)} /></div>
                    <div><Label className="text-xs">لون التمييز</Label><Input type="color" className="mt-1 h-9" value={config.accent_color || "#A86DA8"} onChange={e => setConfig("accent_color", e.target.value)} /></div>
                  </div>
                </div>

                <div className="border-t border-border pt-3">
                  <Label className="text-xs">صورة خلفية الشهادة (رابط)</Label>
                  <Input className="mt-1.5" placeholder="https://example.com/bg.jpg" value={config.bg_image_url || ""} onChange={e => setConfig("bg_image_url", e.target.value)} />
                </div>

                <div className="border-t border-border pt-3 space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground">المتغيرات (Placeholders) — فعّل/عطّل أي متغير من القالب، واضغط لتعديل الموضع</p>
                  <div className="space-y-1">
                    {placeholders.map((p, i) => {
                      const enabled = p.enabled !== false;
                      return (
                        <div key={i}
                          className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-colors ${selectedPlaceholder === i ? "border-primary bg-primary/5" : "border-border hover:bg-muted/50"} ${!enabled ? "opacity-60" : ""}`}>
                          <Switch checked={enabled} onCheckedChange={v => updatePlaceholder(i, "enabled", v)} aria-label={enabled ? "إخفاء من القالب" : "إضافة إلى القالب"} />
                          <button type="button" onClick={() => setSelectedPlaceholder(i)}
                            className="flex-1 text-right text-xs">
                            <span className="font-medium">{p.label}</span>
                            <span className="text-muted-foreground mr-2">({p.key})</span>
                            {!enabled && <span className="text-[10px] text-muted-foreground mr-2">— مخفي</span>}
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {sp && selectedPlaceholder !== null && (
                    <div className="bg-muted/50 rounded-lg p-3 space-y-2 border border-primary/20">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold">{sp.label}</p>
                        <div className="flex items-center gap-2">
                          <Label className="text-[10px] text-muted-foreground">مفعل في القالب</Label>
                          <Switch checked={sp.enabled !== false} onCheckedChange={v => updatePlaceholder(selectedPlaceholder, "enabled", v)} />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><Label className="text-[10px]">X (%) — أفقي</Label><Input type="number" min={0} max={100} className="h-8 text-xs" value={sp.x} onChange={e => updatePlaceholder(selectedPlaceholder, "x", Number(e.target.value))} /></div>
                        <div><Label className="text-[10px]">Y (%) — عمودي</Label><Input type="number" min={0} max={100} className="h-8 text-xs" value={sp.y} onChange={e => updatePlaceholder(selectedPlaceholder, "y", Number(e.target.value))} /></div>
                        <div><Label className="text-[10px]">حجم الخط</Label><Input type="number" min={8} max={48} className="h-8 text-xs" value={sp.fontSize} onChange={e => updatePlaceholder(selectedPlaceholder, "fontSize", Number(e.target.value))} /></div>
                        <div><Label className="text-[10px]">لون الخط</Label><Input type="color" className="h-8" value={sp.color} onChange={e => updatePlaceholder(selectedPlaceholder, "color", e.target.value)} /></div>
                        <div><Label className="text-[10px]">الوزن</Label>
                          <Select value={sp.fontWeight} onValueChange={v => updatePlaceholder(selectedPlaceholder, "fontWeight", v)}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="normal">عادي</SelectItem>
                              <SelectItem value="bold">عريض</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div><Label className="text-[10px]">المحاذاة</Label>
                          <Select value={sp.align} onValueChange={v => updatePlaceholder(selectedPlaceholder, "align", v)}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="center">وسط</SelectItem>
                              <SelectItem value="right">يمين</SelectItem>
                              <SelectItem value="left">يسار</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Right: Preview (sticky, always visible) */}
              <div className="lg:sticky lg:top-0 self-start">
                <p className="text-xs font-semibold text-muted-foreground mb-2">معاينة القالب (مباشرة)</p>
                <div className="relative border-2 rounded-lg overflow-hidden" style={{
                  backgroundColor: config.bg_color || "#FAFAFA",
                  borderColor: config.border_color || "#5E4EA2",
                  aspectRatio: "297/210",
                }}>
                  {config.bg_image_url && (
                    <img src={config.bg_image_url} alt="خلفية" className="absolute inset-0 w-full h-full object-cover" onError={e => (e.currentTarget.style.display = "none")} />
                  )}
                  {/* Placeholders preview — only enabled ones */}
                  {placeholders.map((p, i) => {
                    if (p.enabled === false) return null;
                    return (
                      <div key={i} className={`absolute cursor-pointer transition-all ${selectedPlaceholder === i ? "ring-2 ring-primary ring-offset-1" : ""}`}
                        style={{
                          left: `${p.x}%`, top: `${p.y}%`,
                          transform: `translate(${p.align === "center" ? "-50%" : p.align === "right" ? "-100%" : "0"}, -50%)`,
                          fontSize: `${Math.max(8, p.fontSize * 0.5)}px`,
                          fontWeight: p.fontWeight, color: p.color,
                          textAlign: p.align as any,
                        }}
                        onClick={() => setSelectedPlaceholder(i)}
                      >
                        {p.label}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="px-6 pb-6 pt-2 border-t border-border">
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={handleSave}>حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CertificateTemplates;
