import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatCard } from "@/components/shared/StatCard";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { isAnomalousHours, roundHours } from "@/lib/hours-utils";
import { formatHours, formatHoursNumber } from "@/lib/hours-format";
import { Users, Award, Building2, FileCheck } from "lucide-react";

const Reports = () => {
  const [topVolunteers, setTopVolunteers] = useState<any[]>([]);
  const [topOpportunities, setTopOpportunities] = useState<any[]>([]);
  const [departmentSummary, setDepartmentSummary] = useState<any[]>([]);
  const [proofStats, setProofStats] = useState({ approved: 0, rejected: 0, pending: 0, total: 0 });
  const [departments, setDepartments] = useState<any[]>([]);
  const [supervisors, setSupervisors] = useState<any[]>([]);

  // Filters
  const [filterDept, setFilterDept] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterSupervisor, setFilterSupervisor] = useState("all");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");

  const [totalVolunteers, setTotalVolunteers] = useState(0);
  const [totalHours, setTotalHours] = useState(0);
  const [totalOpps, setTotalOpps] = useState(0);

  useEffect(() => {
    const loadFilters = async () => {
      const [dRes, sRes] = await Promise.all([
        supabase.from("departments").select("id, name"),
        supabase.from("internal_users").select("id, full_name").in("role", ["supervisor", "director"]),
      ]);
      setDepartments(dRes.data || []);
      setSupervisors(sRes.data || []);
    };
    loadFilters();
  }, []);

  useEffect(() => {
    const fetchReports = async () => {
      // Build opportunity filter
      let oppQuery = supabase.from("opportunities").select("id, title, department_id, supervisor_id, participant_count, status, departments(name)");
      if (filterDept !== "all") oppQuery = oppQuery.eq("department_id", filterDept);
      if (filterStatus !== "all") oppQuery = oppQuery.eq("status", filterStatus);
      if (filterSupervisor !== "all") oppQuery = oppQuery.eq("supervisor_id", filterSupervisor);
      const { data: allOpps } = await oppQuery;
      const oppIds = (allOpps || []).map(o => o.id);

      setTotalOpps((allOpps || []).length);

      // Top opportunities
      const sortedOpps = [...(allOpps || [])].sort((a: any, b: any) => (b.participant_count || 0) - (a.participant_count || 0)).slice(0, 5);
      setTopOpportunities(sortedOpps.map((o: any) => ({ name: o.title, participants: o.participant_count || 0 })));

      // Department summary
      const deptMap: Record<string, { name: string; opps: number; participants: number }> = {};
      (allOpps || []).forEach((o: any) => {
        const name = o.departments?.name || "—";
        if (!deptMap[name]) deptMap[name] = { name, opps: 0, participants: 0 };
        deptMap[name].opps++;
        deptMap[name].participants += o.participant_count || 0;
      });
      setDepartmentSummary(Object.values(deptMap));

      // Volunteer hours — filter by opportunity_id if filtered
      let hoursQuery = supabase.from("volunteer_hours").select("volunteer_id, approved_hours, opportunity_id, volunteers(full_name)").eq("status", "approved");
      if (filterDateFrom) hoursQuery = hoursQuery.gte("approval_date", filterDateFrom);
      if (filterDateTo) hoursQuery = hoursQuery.lte("approval_date", filterDateTo);
      const { data: hours } = await hoursQuery;

      const filteredHours = oppIds.length > 0 && (filterDept !== "all" || filterStatus !== "all" || filterSupervisor !== "all")
        ? (hours || []).filter((h: any) => !h.opportunity_id || oppIds.includes(h.opportunity_id))
        : hours || [];

      const volMap: Record<string, { name: string; hours: number }> = {};
      let total = 0;
      filteredHours.forEach((h: any) => {
        const hrs = Number(h.approved_hours);
        if (isAnomalousHours(hrs)) return;
        const id = h.volunteer_id;
        if (!volMap[id]) volMap[id] = { name: h.volunteers?.full_name || "—", hours: 0 };
        volMap[id].hours += hrs;
        total += hrs;
      });
      setTotalHours(roundHours(total));
      setTotalVolunteers(Object.keys(volMap).length);

      const sorted = Object.values(volMap).map(v => ({ ...v, hours: roundHours(v.hours) })).sort((a, b) => b.hours - a.hours).slice(0, 5).map((v, i) => ({ rank: i + 1, name: v.name, hours: formatHours(v.hours) }));
      setTopVolunteers(sorted);

      // Proof stats — filtered by opportunity IDs through participations
      const hasOppFilter = filterDept !== "all" || filterStatus !== "all" || filterSupervisor !== "all";
      let filteredProofs: any[] = [];

      if (hasOppFilter && oppIds.length > 0) {
        // Get participation IDs linked to filtered opportunities
        const { data: parts } = await supabase.from("participations").select("id").in("opportunity_id", oppIds);
        const partIds = (parts || []).map(p => p.id);
        if (partIds.length > 0) {
          const { data: proofs } = await supabase.from("proofs").select("review_status, participation_id").in("participation_id", partIds);
          filteredProofs = proofs || [];
        }
      } else if (hasOppFilter && oppIds.length === 0) {
        filteredProofs = [];
      } else {
        // No opp filter — get all proofs, optionally filtered by date through participations
        if (filterDateFrom || filterDateTo) {
          let pQuery = supabase.from("participations").select("id");
          if (filterDateFrom) pQuery = pQuery.gte("started_at", filterDateFrom);
          if (filterDateTo) pQuery = pQuery.lte("started_at", filterDateTo);
          const { data: parts } = await pQuery;
          const partIds = (parts || []).map(p => p.id);
          if (partIds.length > 0) {
            const { data: proofs } = await supabase.from("proofs").select("review_status, participation_id").in("participation_id", partIds);
            filteredProofs = proofs || [];
          }
        } else {
          const { data: proofs } = await supabase.from("proofs").select("review_status, participation_id");
          filteredProofs = proofs || [];
        }
      }

      const totalP = filteredProofs.length || 1;
      const approved = filteredProofs.filter((p: any) => p.review_status === "approved").length;
      const rejected = filteredProofs.filter((p: any) => p.review_status === "rejected").length;
      const pending = filteredProofs.filter((p: any) => p.review_status === "pending").length;
      setProofStats({
        approved: filteredProofs.length === 0 ? 0 : Math.round((approved / totalP) * 100),
        rejected: filteredProofs.length === 0 ? 0 : Math.round((rejected / totalP) * 100),
        pending: filteredProofs.length === 0 ? 0 : Math.round((pending / totalP) * 100),
        total: filteredProofs.length,
      });
    };
    fetchReports();
  }, [filterDept, filterStatus, filterSupervisor, filterDateFrom, filterDateTo]);

  return (
    <div>
      <PageHeader title="التقارير" description="عرض تقارير المنصة التطوعية" />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-6">
        <StatCard title="المتطوعون النشطون" value={totalVolunteers} icon={Users} color="primary" />
        <StatCard title="إجمالي الساعات" value={formatHoursNumber(totalHours)} icon={Award} color="success" />
        <StatCard title="الفرص" value={totalOpps} icon={Building2} color="accent" />
        <StatCard title="الإثباتات" value={proofStats.total} icon={FileCheck} color="warning" />
      </div>

      {/* Filters */}
      <div className="bg-card rounded-lg border border-border p-4 mb-6">
        <h4 className="text-sm font-bold text-foreground mb-3">فلاتر التقارير</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div>
            <Label className="text-xs">الإدارة</Label>
            <Select value={filterDept} onValueChange={setFilterDept}>
              <SelectTrigger className="mt-1 h-9 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                {departments.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">حالة الفرصة</Label>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="mt-1 h-9 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                <SelectItem value="active">نشطة</SelectItem>
                <SelectItem value="closed">منتهية</SelectItem>
                <SelectItem value="draft">مسودة</SelectItem>
                <SelectItem value="archived">مؤرشفة</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">المشرف</Label>
            <Select value={filterSupervisor} onValueChange={setFilterSupervisor}>
              <SelectTrigger className="mt-1 h-9 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                {supervisors.map(s => <SelectItem key={s.id} value={s.id}>{s.full_name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">من تاريخ</Label>
            <Input type="date" className="mt-1 h-9 text-xs" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">إلى تاريخ</Label>
            <Input type="date" className="mt-1 h-9 text-xs" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <div className="bg-card rounded-lg border border-border p-4 md:p-5">
          <h3 className="font-bold text-foreground mb-5 text-sm">نسب القبول والرفض</h3>
          <div className="space-y-5">
            <div>
              <div className="flex justify-between text-sm mb-1.5"><span>مقبول</span><span className="font-semibold text-success">{proofStats.approved}%</span></div>
              <div className="bg-muted rounded-full h-2.5"><div className="bg-success h-2.5 rounded-full transition-all" style={{ width: `${proofStats.approved}%` }} /></div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1.5"><span>مرفوض</span><span className="font-semibold text-destructive">{proofStats.rejected}%</span></div>
              <div className="bg-muted rounded-full h-2.5"><div className="bg-destructive h-2.5 rounded-full transition-all" style={{ width: `${proofStats.rejected}%` }} /></div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1.5"><span>قيد المراجعة</span><span className="font-semibold text-warning">{proofStats.pending}%</span></div>
              <div className="bg-muted rounded-full h-2.5"><div className="bg-warning h-2.5 rounded-full transition-all" style={{ width: `${proofStats.pending}%` }} /></div>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-lg border border-border p-4 md:p-5">
          <h3 className="font-bold text-foreground mb-4 text-sm">أفضل المتطوعين</h3>
          <DataTable columns={[
            { header: "#", accessor: "rank" },
            { header: "الاسم", accessor: "name" },
            { header: "الساعات", accessor: "hours" },
          ]} data={topVolunteers} />
        </div>

        <div className="bg-card rounded-lg border border-border p-4 md:p-5">
          <h3 className="font-bold text-foreground mb-4 text-sm">الفرص الأكثر مشاركة</h3>
          <DataTable columns={[
            { header: "الفرصة", accessor: "name" },
            { header: "المشاركين", accessor: "participants" },
          ]} data={topOpportunities} />
        </div>

        <div className="bg-card rounded-lg border border-border p-4 md:p-5">
          <h3 className="font-bold text-foreground mb-4 text-sm">ملخص حسب الإدارة</h3>
          <DataTable columns={[
            { header: "الإدارة", accessor: "name" },
            { header: "الفرص", accessor: "opps" },
            { header: "المشاركين", accessor: "participants" },
          ]} data={departmentSummary} />
        </div>
      </div>
    </div>
  );
};

export default Reports;
