import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowRight, Mail } from "lucide-react";
import logo from "@/assets/logo.png";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const navigate = useNavigate();

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      toast.error("الرجاء إدخال البريد الإلكتروني");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) {
      toast.error("حدث خطأ: " + error.message);
      return;
    }
    setSent(true);
    toast.success("تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-sm">
        <div className="bg-card rounded-xl border border-border p-6 md:p-8 shadow-sm">
          <div className="flex flex-col items-center mb-6">
            <img src={logo} alt="رفادة" className="h-16 w-16 rounded-xl bg-primary/10 object-contain p-2 mb-3" />
            <h1 className="text-xl font-bold text-foreground">نسيت كلمة المرور</h1>
            <p className="text-sm text-muted-foreground mt-1">أدخل بريدك الإلكتروني لإعادة تعيين كلمة المرور</p>
          </div>

          {!sent ? (
            <form onSubmit={handleReset} className="space-y-4">
              <div>
                <Label>البريد الإلكتروني</Label>
                <Input
                  type="email"
                  placeholder="example@email.com"
                  className="mt-1.5"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  dir="ltr"
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "جارٍ الإرسال..." : "إرسال رابط إعادة التعيين"}
              </Button>
              <Button type="button" variant="ghost" className="w-full" onClick={() => navigate("/login")}>
                <ArrowRight className="h-4 w-4 ml-1" />
                العودة لتسجيل الدخول
              </Button>
            </form>
          ) : (
            <div className="text-center space-y-4">
              <div className="bg-primary/10 rounded-full h-16 w-16 flex items-center justify-center mx-auto">
                <Mail className="h-8 w-8 text-primary" />
              </div>
              <p className="text-sm text-foreground">تم إرسال رابط إعادة تعيين كلمة المرور إلى:</p>
              <p className="text-sm font-semibold text-foreground" dir="ltr">{email}</p>
              <p className="text-xs text-muted-foreground">تحقق من بريدك الإلكتروني واتبع الرابط لإعادة تعيين كلمة المرور</p>
              <Button variant="outline" className="w-full" onClick={() => navigate("/login")}>
                العودة لتسجيل الدخول
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
