import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import logo from "@/assets/logo.png";

const ResetPassword = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [ready, setReady] = useState(false);
  const navigate = useNavigate();
  const { recoveryMode, clearRecoveryMode, session } = useRole();

  useEffect(() => {
    // Recovery flow can be detected in two ways:
    // 1) Hash contains type=recovery (initial click on the link)
    // 2) RoleContext flagged recoveryMode after PASSWORD_RECOVERY event
    // 3) User already has a session reached via the link
    const hash = window.location.hash;
    if (hash.includes("type=recovery") || recoveryMode) {
      setReady(true);
      return;
    }
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setReady(true);
    });
    return () => subscription.unsubscribe();
  }, [recoveryMode]);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || password.length < 6) {
      toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }
    if (password !== confirmPassword) {
      toast.error("كلمتا المرور غير متطابقتين");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    if (error) {
      setLoading(false);
      toast.error("حدث خطأ: " + error.message);
      return;
    }
    // Clear the recovery flag and sign the user out so they MUST log in again
    // with the new password — never auto-route them into the app silently.
    clearRecoveryMode();
    await supabase.auth.signOut();
    setLoading(false);
    toast.success("تم تعيين كلمة المرور الجديدة بنجاح — سجّل الدخول الآن");
    navigate("/login", { replace: true });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-sm">
        <div className="bg-card rounded-xl border border-border p-6 md:p-8 shadow-sm">
          <div className="flex flex-col items-center mb-6">
            <img src={logo} alt="رفادة" className="h-16 w-16 rounded-xl bg-primary/10 object-contain p-2 mb-3" />
            <h1 className="text-xl font-bold text-foreground">تعيين كلمة مرور جديدة</h1>
            <p className="text-xs text-muted-foreground mt-2 text-center">يجب تعيين كلمة مرور جديدة قبل الدخول إلى النظام</p>
          </div>

          {ready || session ? (
            <form onSubmit={handleUpdate} className="space-y-4">
              <div>
                <Label>كلمة المرور الجديدة</Label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  className="mt-1.5"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  dir="ltr"
                />
              </div>
              <div>
                <Label>تأكيد كلمة المرور</Label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  className="mt-1.5"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  dir="ltr"
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "جارٍ الحفظ..." : "حفظ كلمة المرور الجديدة"}
              </Button>
            </form>
          ) : (
            <div className="text-center space-y-3">
              <p className="text-sm text-muted-foreground">جارٍ التحقق من الرابط...</p>
              <p className="text-xs text-muted-foreground">إذا لم يعمل الرابط، يرجى طلب رابط جديد من صفحة تسجيل الدخول</p>
              <Button variant="outline" className="w-full" onClick={() => navigate("/login")}>
                العودة لتسجيل الدخول
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
