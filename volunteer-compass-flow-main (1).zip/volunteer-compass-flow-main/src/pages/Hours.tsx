import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { StatCard } from "@/components/shared/StatCard";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, CheckCircle, Calendar, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { isAnomalousHours, sumValidHours, countValidHours, avgValidHours } from "@/lib/hours-utils";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { formatDate } from "@/lib/format-date";
import { formatHours, formatTotalHours } from "@/lib/hours-format";

const statusMap: Record<string, string> = { approved: "معتمد", reversed: "ملغي" };

const Hours = () => {
  const [data, setData] = useState<any[]>([]);
  const [totalHours, setTotalHours] = useState(0);
  const [totalApproved, setTotalApproved] = useState(0);
  const [avgHrs, setAvgHrs] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    const fetchAndClean = async () => {
      const { data: rows } = await supabase
        .from("volunteer_hours")
        .select("*, volunteers(full_name), opportunities(title, minimum_hours), participations(total_minutes, started_at, ended_at)")
        .order("created_at", { ascending: false });
      const anomalousIds = (rows || []).filter((r: any) => r.status === "approved" && isAnomalousHours(Number(r.approved_hours))).map((r: any) => r.id);
      if (anomalousIds.length > 0) await supabase.from("volunteer_hours").update({ status: "reversed" }).in("id", anomalousIds);
      const list = (rows || []).map((r: any) => {
        const stored = Number(r.approved_hours);
        if (isAnomalousHours(stored)) return { ...r, status: "reversed", _anomaly: true };
        // Fallback if approved_hours is 0/missing but participation has duration
        if (!stored || stored <= 0) {
          let mins = Number(r?.participations?.total_minutes || 0);
          if ((!mins || mins <= 0) && r?.participations?.started_at && r?.participations?.ended_at) {
            const diff = Math.round((new Date(r.participations.ended_at).getTime() - new Date(r.participations.started_at).getTime()) / 60000);
            if (diff > 0) mins = Math.min(diff, 720);
          }
          if (mins > 0) return { ...r, approved_hours: Math.round((mins / 60) * 100) / 100 };
          const minH = Number(r?.opportunities?.minimum_hours || 0);
          if (minH > 0) return { ...r, approved_hours: minH };
        }
        return r;
      });
      setData(list);
      setTotalHours(sumValidHours(list));
      setTotalApproved(countValidHours(list));
      setAvgHrs(avgValidHours(list));
      setLoading(false);
    };
    fetchAndClean();
  }, []);

  const filtered = data.filter((r: any) => {
    if (search && !(r.volunteers?.full_name || "").includes(search) && !(r.opportunities?.title || "").includes(search)) return false;
    if (filterStatus !== "all" && r.status !== filterStatus) return false;
    return true;
  });

  const exportData = filtered.map(r => ({
    volunteer: r.volunteers?.full_name || "—", opportunity: r.opportunities?.title || "—",
    hours: formatHours(r.approved_hours),
    date: r.approval_date ? formatDate(r.approval_date) : "—",
    status: statusMap[r.status] || r.status,
  }));
  const exportCols = [
    { header: "المتطوع", key: "volunteer" }, { header: "الفرصة", key: "opportunity" },
    { header: "الساعات المعتمدة", key: "hours" }, { header: "تاريخ الاعتماد", key: "date" },
    { header: "الحالة", key: "status" },
  ];

  return (
    <div>
      <PageHeader title="الساعات التطوعية" description="عرض وتتبع الساعات المعتمدة" actions={
        <ExportButtons data={exportData} columns={exportCols} title="الساعات التطوعية" filename="volunteer_hours" />
      } />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 mb-8">
        <StatCard title="إجمالي الساعات المعتمدة" value={loading ? "..." : formatTotalHours(totalHours)} icon={Clock} color="primary" />
        <StatCard title="المشاركات المعتمدة" value={loading ? "..." : totalApproved} icon={CheckCircle} color="success" />
        <StatCard title="متوسط الساعات" value={loading ? "..." : formatHours(avgHrs)} icon={Calendar} color="accent" />
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="بحث بالمتطوع أو الفرصة..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-36 h-10"><SelectValue placeholder="الحالة" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الحالات</SelectItem>
            <SelectItem value="approved">معتمد</SelectItem>
            <SelectItem value="reversed">ملغي</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="mb-8">
        <h3 className="font-bold text-foreground mb-4 text-sm">جدول الساعات المعتمدة</h3>
        <DataTable columns={[
          { header: "المتطوع", accessor: (r: any) => r.volunteers?.full_name || "—" },
          { header: "الفرصة", accessor: (r: any) => r.opportunities?.title || "—" },
          { header: "الساعات المعتمدة", accessor: (r: any) => formatHours(r.approved_hours) },
          { header: "تاريخ الاعتماد", accessor: (r: any) => r.approval_date ? formatDate(r.approval_date) : "—" },
          { header: "الحالة", accessor: (r: any) => <StatusBadge status={statusMap[r.status] || r.status} variant={r.status === "approved" ? "success" : "warning"} /> },
        ]} data={filtered} />
      </div>
    </div>
  );
};

export default Hours;
