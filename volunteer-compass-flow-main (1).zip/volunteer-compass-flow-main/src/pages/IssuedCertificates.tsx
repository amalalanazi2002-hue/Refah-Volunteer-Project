import { useState, useEffect, useCallback } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { Search, Award, Eye, Check, X, RefreshCw, Printer } from "lucide-react";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { formatDate } from "@/lib/format-date";
import { formatHours } from "@/lib/hours-format";
import { roundHours } from "@/lib/hours-utils";
import { printCertificate } from "@/lib/print-certificate";

const certStatusMap: Record<string, string> = { draft: "مسودة", pending_review: "بانتظار المراجعة", approved: "معتمدة", rejected: "مرفوضة" };
const certStatusVariant = (s: string) => s === "approved" ? "success" : s === "rejected" ? "danger" : s === "pending_review" ? "warning" : "neutral";

const IssuedCertificates = () => {
  const { userId } = useRole();
  const [certs, setCerts] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [detailCert, setDetailCert] = useState<any>(null);
  const [reviewNote, setReviewNote] = useState("");
  const [processing, setProcessing] = useState(false);
  const [templates, setTemplates] = useState<any[]>([]);
  const [orgName, setOrgName] = useState<string>("منصة رفادة التطوعية");

  const fetchData = useCallback(async () => {
    const [certRes, tplRes, settingsRes] = await Promise.all([
      supabase.from("generated_certificates").select("*, certificate_templates(id, name, design_config)").order("issued_at", { ascending: false }),
      supabase.from("certificate_templates").select("id, name, design_config").eq("is_active", true),
      supabase.from("system_settings").select("value").eq("key", "organization_name").limit(1),
    ]);
    const rawCerts = certRes.data || [];

    // Enrich hours from related rows when cert row stored 0/missing.
    const partIds = Array.from(new Set(rawCerts.map((c: any) => c.participation_id).filter(Boolean)));
    const hourIds = Array.from(new Set(rawCerts.map((c: any) => c.volunteer_hours_id).filter(Boolean)));
    const [partsRes, hoursRes] = await Promise.all([
      partIds.length
        ? supabase.from("participations").select("id, total_minutes, opportunities(minimum_hours)").in("id", partIds)
        : Promise.resolve({ data: [] as any[] }),
      hourIds.length
        ? supabase.from("volunteer_hours").select("id, approved_hours").in("id", hourIds)
        : Promise.resolve({ data: [] as any[] }),
    ]);
    const partsMap = new Map((partsRes.data || []).map((p: any) => [p.id, p]));
    const hoursMap = new Map((hoursRes.data || []).map((h: any) => [h.id, h]));
    const enriched = rawCerts.map((c: any) => {
      const stored = Number(c.approved_hours);
      if (stored > 0) return c;
      const vh = Number(hoursMap.get(c.volunteer_hours_id)?.approved_hours || 0);
      if (vh > 0) return { ...c, approved_hours: roundHours(vh) };
      const part: any = partsMap.get(c.participation_id);
      const minutes = Number(part?.total_minutes || 0);
      if (minutes > 0) return { ...c, approved_hours: roundHours(minutes / 60) };
      const minH = Number(part?.opportunities?.minimum_hours || 0);
      if (minH > 0) return { ...c, approved_hours: roundHours(minH) };
      return c;
    });

    setCerts(enriched);
    setTemplates(tplRes.data || []);
    const v = settingsRes.data?.[0]?.value;
    if (v) setOrgName(v);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handlePrint = (cert: any) => {
    // Prefer the embedded template (joined), fallback to templates list lookup
    const tpl = cert.certificate_templates || templates.find(t => t.id === cert.template_id) || null;
    printCertificate({ cert, template: tpl, organizationName: orgName });
  };

  const handleDecision = async (decision: "approved" | "rejected") => {
    if (!detailCert) return;
    setProcessing(true);
    await supabase.from("generated_certificates").update({
      status: decision, reviewed_by: userId, reviewed_at: new Date().toISOString(), review_note: reviewNote.trim() || null,
    }).eq("id", detailCert.id);
    // Notify volunteer
    await supabase.from("notifications").insert({
      user_type: "volunteer", user_id: detailCert.volunteer_id,
      title: decision === "approved" ? "تم اعتماد شهادتك" : "تم رفض شهادتك",
      message: decision === "approved"
        ? `شهادتك عن فرصة ${detailCert.opportunity_title} متاحة الآن`
        : `تم رفض شهادتك عن فرصة ${detailCert.opportunity_title}`,
      type: decision === "approved" ? "application_approved" : "application_rejected",
      related_entity_type: "certificate", related_entity_id: detailCert.id,
      is_read: false, action_url: "/volunteer/certificates",
      action_label: "عرض شهاداتي", requires_action: false,
    });
    toast.success(decision === "approved" ? "تم اعتماد الشهادة" : "تم رفض الشهادة");
    setDetailCert(null);
    setReviewNote("");
    setProcessing(false);
    fetchData();
  };

  const changeTemplate = async (certId: string, templateId: string) => {
    await supabase.from("generated_certificates").update({ template_id: templateId }).eq("id", certId);
    toast.success("تم تغيير القالب");
    fetchData();
  };

  const filtered = certs.filter(c => {
    if (search && !c.volunteer_name?.includes(search) && !c.opportunity_title?.includes(search) && !c.certificate_number?.includes(search)) return false;
    if (filterStatus !== "all" && c.status !== filterStatus) return false;
    return true;
  });

  const exportData = filtered.map(c => ({
    volunteer: c.volunteer_name, opportunity: c.opportunity_title, cert_number: c.certificate_number,
    hours: formatHours(c.approved_hours), status: certStatusMap[c.status] || c.status, template: c.certificate_templates?.name || "—",
    issued: formatDate(c.issued_at),
  }));
  const exportCols = [
    { header: "المتطوع", key: "volunteer" }, { header: "الفرصة", key: "opportunity" },
    { header: "رقم الشهادة", key: "cert_number" }, { header: "الساعات", key: "hours" },
    { header: "الحالة", key: "status" }, { header: "القالب", key: "template" }, { header: "تاريخ الإصدار", key: "issued" },
  ];

  return (
    <div>
      <PageHeader title="الشهادات الصادرة" description="إدارة ومراجعة الشهادات التطوعية الصادرة" actions={
        <ExportButtons data={exportData} columns={exportCols} title="الشهادات الصادرة" filename="certificates" />
      } />

      <div className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="بحث بالمتطوع أو الفرصة أو رقم الشهادة..." value={search} onChange={e => setSearch(e.target.value)} className="pr-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-44 h-10"><SelectValue placeholder="الحالة" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الحالات</SelectItem>
            {Object.entries(certStatusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-x-auto -mx-2 sm:mx-0 px-2 sm:px-0">
        <DataTable
          columns={[
            { header: "المتطوع", accessor: "volunteer_name" },
            { header: "الفرصة", accessor: "opportunity_title" },
            { header: "رقم الشهادة", accessor: "certificate_number" },
            { header: "الساعات", accessor: (r: any) => formatHours(r.approved_hours) },
            { header: "القالب", accessor: (r: any) => r.certificate_templates?.name || "—" },
            { header: "الحالة", accessor: (r: any) => <StatusBadge status={certStatusMap[r.status] || r.status} variant={certStatusVariant(r.status)} /> },
            { header: "تاريخ الإصدار", accessor: (r: any) => formatDate(r.issued_at) },
            { header: "إجراءات", accessor: (r: any) => (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" onClick={() => { setDetailCert(r); setReviewNote(""); }} title="عرض التفاصيل">
                  <Eye className="h-4 w-4 text-primary" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handlePrint(r)} title="طباعة الشهادة">
                  <Printer className="h-4 w-4 text-primary" />
                </Button>
              </div>
            )},
          ]}
          data={filtered}
          emptyMessage="لا توجد شهادات صادرة"
          emptyIcon={<Award className="h-10 w-10 text-muted-foreground/30" />}
        />
      </div>

      <Dialog open={!!detailCert} onOpenChange={open => { if (!open) setDetailCert(null); }}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>تفاصيل الشهادة</DialogTitle></DialogHeader>
          {detailCert && (
            <div className="space-y-4">
              <div className="bg-muted/50 rounded-lg p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">المتطوع:</span><strong>{detailCert.volunteer_name}</strong></div>
                <div className="flex justify-between"><span className="text-muted-foreground">الفرصة:</span><strong>{detailCert.opportunity_title}</strong></div>
                <div className="flex justify-between"><span className="text-muted-foreground">رقم الشهادة:</span><strong dir="ltr">{detailCert.certificate_number}</strong></div>
                <div className="flex justify-between"><span className="text-muted-foreground">الساعات:</span><strong>{formatHours(detailCert.approved_hours)}</strong></div>
                <div className="flex justify-between"><span className="text-muted-foreground">الإدارة:</span><strong>{detailCert.department_name || "—"}</strong></div>
                <div className="flex justify-between"><span className="text-muted-foreground">تاريخ الإنجاز:</span><strong>{formatDate(detailCert.completion_date)}</strong></div>
              </div>

              {/* Change template before approval */}
              {(detailCert.status === "draft" || detailCert.status === "pending_review") && templates.length > 0 && (
                <div>
                  <Label>تغيير القالب</Label>
                  <Select value={detailCert.template_id || ""} onValueChange={v => changeTemplate(detailCert.id, v)}>
                    <SelectTrigger className="mt-1.5"><SelectValue placeholder="اختر قالب" /></SelectTrigger>
                    <SelectContent>
                      {templates.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {(detailCert.status === "draft" || detailCert.status === "pending_review") && (
                <>
                  <div>
                    <Label>ملاحظة (اختياري)</Label>
                    <Textarea className="mt-1.5" rows={2} placeholder="ملاحظات..." value={reviewNote} onChange={e => setReviewNote(e.target.value)} />
                  </div>
                  <div className="flex gap-2">
                    <Button className="flex-1" onClick={() => handleDecision("approved")} disabled={processing}>
                      <Check className="h-4 w-4 ml-1" />اعتماد
                    </Button>
                    <Button variant="destructive" className="flex-1" onClick={() => handleDecision("rejected")} disabled={processing}>
                      <X className="h-4 w-4 ml-1" />رفض
                    </Button>
                  </div>
                </>
              )}

              {/* Print button always available */}
              <Button variant="outline" className="w-full" onClick={() => handlePrint(detailCert)}>
                <Printer className="h-4 w-4 ml-1" />
                طباعة الشهادة
              </Button>

              {detailCert.status === "approved" && (
                <div className="text-center">
                  <StatusBadge status="معتمدة" variant="success" />
                  {detailCert.review_note && <p className="text-xs text-muted-foreground mt-2">{detailCert.review_note}</p>}
                </div>
              )}
              {detailCert.status === "rejected" && (
                <div className="text-center">
                  <StatusBadge status="مرفوضة" variant="danger" />
                  {detailCert.review_note && <p className="text-xs text-muted-foreground mt-2">{detailCert.review_note}</p>}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default IssuedCertificates;
