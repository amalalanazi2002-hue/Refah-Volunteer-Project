import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable } from "@/components/shared/DataTable";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Plus,
  Search,
  Users,
  Check,
  X,
  UserPlus,
  Eye,
  Clock,
  Award,
  FileCheck,
  KeyRound,
  UserX,
  Pencil,
  UserCog,
  Send,
  Copy,
  Loader2,
  Filter,
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ImportVolunteers } from "@/components/volunteers/ImportVolunteers";
import { supabase } from "@/integrations/supabase/client";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import type { Volunteer } from "@/integrations/supabase/db-types";
import { formatDate, formatDateTime } from "@/lib/format-date";
import { formatHours, formatTotalHours } from "@/lib/hours-format";
import { roundHours, isAnomalousHours } from "@/lib/hours-utils";

// Local helper (scoped to this page only): compute effective approved hours
// for a volunteer_hours row, using participation minutes or opportunity
// minimum_hours as a fallback when approved_hours is 0/missing. Mirrors the
// logic already used in the volunteer's "ملفي" page so both views match.
const effectiveRowHours = (r: any): number => {
  const stored = Number(r?.approved_hours);
  if (!Number.isNaN(stored) && stored > 0 && !isAnomalousHours(stored)) {
    return roundHours(stored);
  }
  const minutes = Number(r?.participations?.total_minutes || 0);
  if (minutes > 0) return roundHours(minutes / 60);
  const minH = Number(r?.opportunities?.minimum_hours || 0);
  if (minH > 0) return roundHours(minH);
  return 0;
};
import {
  validateContactForm,
  normalizeMobile,
  normalizeNationalId,
  normalizeEmail,
  handleMobileInput,
  handleNationalIdInput,
  handleEmailInput,
} from "@/lib/validators";
import { sendSms } from "@/lib/sms";

const statusMap: Record<string, string> = { active: "نشط", suspended: "معلق", inactive: "غير نشط", archived: "مؤرشف" };
const statusVariant = (s: string) =>
  s === "active" ? "success" : s === "suspended" ? "warning" : s === "archived" ? "neutral" : "danger";
const ALL_STATUSES = ["active", "suspended", "inactive", "archived"] as const;
// subtle row tint per status (left border accent only — keeps RTL & layout intact)
const statusRowAccent: Record<string, string> = {
  active: "border-r-4 border-r-success/60",
  suspended: "border-r-4 border-r-warning/60",
  inactive: "border-r-4 border-r-destructive/50",
  archived: "border-r-4 border-r-muted-foreground/40",
};
const regStatusMap: Record<string, string> = { pending: "قيد المراجعة", approved: "مقبول", rejected: "مرفوض" };
const regStatusVariant = (s: string) => (s === "approved" ? "success" : s === "rejected" ? "danger" : "warning");

const Volunteers = () => {
  const [search, setSearch] = useState("");
  const [data, setData] = useState<Volunteer[]>([]);
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [reviewers, setReviewers] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [cities, setCities] = useState<string[]>([]);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterCity, setFilterCity] = useState("all");
  const [rejSearch, setRejSearch] = useState("");
  const [activeTab, setActiveTab] = useState("volunteers");
  const { role, userId } = useRole();
  const isDirector = role === "director";

  // Volunteer details modal state
  const [detailVol, setDetailVol] = useState<Volunteer | null>(null);
  const [detailStats, setDetailStats] = useState<{
    hours: number;
    opps: number;
    participations: number;
    proofs: number;
    lastParticipation: string | null;
  }>({ hours: 0, opps: 0, participations: 0, proofs: 0, lastParticipation: null });
  const [detailOpen, setDetailOpen] = useState(false);

  // Volunteer password reset state
  const [volPwOpen, setVolPwOpen] = useState(false);
  const [volPwTarget, setVolPwTarget] = useState<Volunteer | null>(null);
  const [volPwForm, setVolPwForm] = useState({ password: "", confirm: "" });
  const [volPwLoading, setVolPwLoading] = useState(false);

  // Reject dialog state
  const [rejectTarget, setRejectTarget] = useState<any>(null);
  const [rejectNote, setRejectNote] = useState("");
  const [sendSmsOnReject, setSendSmsOnReject] = useState(false);

  // Edit volunteer dialog state (admin direct edit, not the volunteer change-request flow)
  const [editOpen, setEditOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Volunteer | null>(null);
  const [editForm, setEditForm] = useState({
    full_name: "",
    mobile: "",
    national_id: "",
    email: "",
    city: "",
    status: "active",
  });
  const [editErrors, setEditErrors] = useState<Record<string, string>>({});
  const [editSaving, setEditSaving] = useState(false);

  const openEditVolunteer = (vol: Volunteer) => {
    setEditTarget(vol);
    setEditForm({
      full_name: vol.full_name || "",
      mobile: vol.mobile || "",
      national_id: vol.national_id || "",
      email: (vol as any).email || "",
      city: vol.city || "",
      status: vol.status || "active",
    });
    setEditErrors({});
    setEditOpen(true);
  };

  // ───── Account creation / send credentials ─────
  const [creatingAccountFor, setCreatingAccountFor] = useState<string | null>(null);
  const [credsDialog, setCredsDialog] = useState<{
    open: boolean;
    volunteerId: string | null;
    fullName: string;
    email: string | null;
    mobile: string | null;
    password: string | null; // present only right after creation
  }>({ open: false, volunteerId: null, fullName: "", email: null, mobile: null, password: null });
  const [sendChannelChoice, setSendChannelChoice] = useState<"email" | "sms" | "both">("email");
  const [sendingCreds, setSendingCreds] = useState(false);
  // Track which channels are actually enabled in integrations (refreshed when dialog opens)
  const [channelStatus, setChannelStatus] = useState<{ email: boolean; sms: boolean; loaded: boolean }>({
    email: false,
    sms: false,
    loaded: false,
  });
  useEffect(() => {
    if (!credsDialog.open) return;
    let alive = true;
    (async () => {
      const { data } = await supabase
        .from("integration_configs")
        .select("channel, is_enabled")
        .in("channel", ["email", "sms"]);
      if (!alive) return;
      const rows = (data || []) as any[];
      setChannelStatus({
        email: rows.some((r) => r.channel === "email" && r.is_enabled),
        sms: rows.some((r) => r.channel === "sms" && r.is_enabled),
        loaded: true,
      });
    })();
    return () => {
      alive = false;
    };
  }, [credsDialog.open]);

  // ───── Send temporary reset link (forces password change) ─────
  const [resetLinkOpen, setResetLinkOpen] = useState(false);
  const [resetLinkTarget, setResetLinkTarget] = useState<Volunteer | null>(null);
  const [resetLinkChannels, setResetLinkChannels] = useState<{ email: boolean; sms: boolean }>({ email: true, sms: false });
  const [resetLinkSending, setResetLinkSending] = useState(false);

  const sendResetLink = async () => {
    if (!resetLinkTarget) return;
    const channels: string[] = [];
    if (resetLinkChannels.email) channels.push("email");
    if (resetLinkChannels.sms) channels.push("sms");
    if (channels.length === 0) {
      toast.error("اختر قناة إرسال واحدة على الأقل");
      return;
    }
    if (!resetLinkTarget.auth_id) {
      toast.error("هذا المتطوع غير مربوط بحساب دخول");
      return;
    }
    if (resetLinkChannels.email && !(resetLinkTarget as any).email) {
      toast.error("لا يوجد بريد إلكتروني للمتطوع");
      return;
    }
    if (resetLinkChannels.sms && !resetLinkTarget.mobile) {
      toast.error("لا يوجد رقم جوال للمتطوع");
      return;
    }
    setResetLinkSending(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-volunteer-reset-link", {
        body: {
          volunteer_id: resetLinkTarget.id,
          channels,
          redirect_origin: window.location.origin,
        },
      });
      if (error) {
        toast.error(`فشل: ${error.message}. تأكد من نشر دالة send-volunteer-reset-link.`);
        return;
      }
      const res = data as any;
      const errMap: Record<string, string> = {
        missing_service_role_secret: "ينقص SUPABASE_SERVICE_ROLE_KEY في إعدادات الدالة",
        forbidden_not_admin: "صلاحياتك لا تسمح بإرسال الرابط",
        volunteer_has_no_account: "المتطوع غير مربوط بحساب دخول",
        volunteer_has_no_email: "المتطوع لا يملك بريدًا إلكترونيًا (مطلوب لتوليد رابط الاستعادة)",
      };
      if (!res?.results) {
        toast.error(errMap[res?.error] || `فشل: ${res?.error || "خطأ غير معروف"}`);
        return;
      }
      const ok = (res.results as any[]).filter((r) => r.ok).map((r) => (r.channel === "sms" ? "SMS" : "البريد"));
      const failed = (res.results as any[]).filter((r) => !r.ok);
      if (ok.length) toast.success(`تم إرسال رابط تعيين كلمة المرور عبر: ${ok.join(" و ")}`);
      failed.forEach((f) =>
        toast.error(`فشل ${f.channel === "sms" ? "SMS" : "البريد"}: ${f.error || "غير معروف"}`),
      );
      if (ok.length && !failed.length) {
        setResetLinkOpen(false);
      }
    } catch (e: any) {
      toast.error(`خطأ: ${e?.message || "تعذر الاتصال بالدالة"}`);
    } finally {
      setResetLinkSending(false);
    }
  };

  // ───── Bulk selection / status filtering visibility ─────
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkStatusOpen, setBulkStatusOpen] = useState(false);
  const [bulkStatus, setBulkStatus] = useState<string>("active");
  const [bulkApplying, setBulkApplying] = useState(false);
  const [visibleStatuses, setVisibleStatuses] = useState<Set<string>>(
    new Set(["active", "suspended", "inactive"]), // archived hidden by default (matches existing behavior)
  );

  const toggleVisibleStatus = (s: string) => {
    setVisibleStatuses((prev) => {
      const next = new Set(prev);
      if (next.has(s)) next.delete(s);
      else next.add(s);
      return next;
    });
  };

  const createVolunteerAccount = async (vol: Volunteer) => {
    const email = (vol as any).email as string | undefined;
    if (!email) {
      toast.error("لا يمكن إنشاء حساب: البريد الإلكتروني غير موجود لهذا المتطوع");
      return;
    }
    if (vol.auth_id) {
      toast.message("هذا المتطوع لديه حساب دخول مرتبط مسبقًا");
      return;
    }
    setCreatingAccountFor(vol.id);
    try {
      const { data, error } = await supabase.functions.invoke("create-volunteer-account", {
        body: { volunteer_id: vol.id },
      });
      if (error) {
        toast.error(
          `تعذر إنشاء الحساب: ${error.message}. تأكد من نشر دالة create-volunteer-account وإضافة SUPABASE_SERVICE_ROLE_KEY.`,
        );
        return;
      }
      const res = data as any;
      if (res?.already_linked) {
        toast.message("الحساب موجود ومرتبط مسبقًا");
        await fetchData();
        return;
      }
      if (!res?.ok) {
        const errMap: Record<string, string> = {
          invalid_or_missing_email: "البريد الإلكتروني غير صالح أو غير موجود",
          forbidden_not_admin: "صلاحياتك لا تسمح بإنشاء حسابات",
          missing_service_role_secret: "ينقص SUPABASE_SERVICE_ROLE_KEY في إعدادات الدالة",
          email_exists_but_user_not_found: "البريد مسجّل لدى مستخدم آخر — تعذر الربط تلقائيًا",
        };
        toast.error(errMap[res?.error] || `فشل: ${res?.error || "خطأ غير معروف"}`);
        return;
      }
      toast.success(res.linked_existing ? "تم ربط حساب الدخول الموجود" : "تم إنشاء حساب الدخول بنجاح");
      // Open credentials dialog so admin can send/copy
      setCredsDialog({
        open: true,
        volunteerId: vol.id,
        fullName: vol.full_name,
        email: res.email,
        mobile: vol.mobile || null,
        password: res.password || null,
      });
      await fetchData();
    } catch (e: any) {
      toast.error(`خطأ: ${e?.message || "تعذر الاتصال بالدالة"}`);
    } finally {
      setCreatingAccountFor(null);
    }
  };

  const openSendCredentials = (vol: Volunteer) => {
    if (!vol.auth_id) {
      toast.error("لا يوجد حساب دخول مرتبط بهذا المتطوع");
      return;
    }
    setCredsDialog({
      open: true,
      volunteerId: vol.id,
      fullName: vol.full_name,
      email: (vol as any).email || null,
      mobile: vol.mobile || null,
      password: null, // password not stored — admin must reset it first
    });
    setSendChannelChoice("email");
  };

  const sendCredentials = async () => {
    const { email, mobile, password, fullName } = credsDialog;
    const wantEmail = sendChannelChoice === "email" || sendChannelChoice === "both";
    const wantSms = sendChannelChoice === "sms" || sendChannelChoice === "both";

    if (!password) {
      toast.error("لا توجد كلمة مرور للإرسال. أعد تعيين كلمة المرور أولًا، ثم استخدم الإرسال مباشرة من نفس النافذة.");
      return;
    }
    if (wantEmail && !email) {
      toast.error("لا يوجد بريد إلكتروني للمتطوع");
      return;
    }
    if (wantSms && !mobile) {
      toast.error("لا يوجد رقم جوال للمتطوع");
      return;
    }

    setSendingCreds(true);
    const messageText = `مرحبًا ${fullName}،\nبيانات دخولك إلى منصة رفادة التطوعية:\nالبريد: ${email || "—"}\nكلمة المرور: ${password}\nيرجى تغيير كلمة المرور بعد أول تسجيل دخول.`;
    const subject = "بيانات دخولك إلى منصة رفادة";

    const tasks: Array<Promise<{ ch: string; ok: boolean; err?: string }>> = [];

    const invokeChannel = async (channel: "sms" | "email", to: string) => {
      const { data: cfg } = await supabase
        .from("integration_configs")
        .select("provider, config, is_enabled")
        .eq("channel", channel)
        .eq("is_enabled", true)
        .limit(1)
        .maybeSingle();
      if (!cfg || !(cfg as any).provider) {
        return {
          ch: channel,
          ok: false,
          err: `قناة ${channel === "sms" ? "الرسائل النصية" : "البريد"} غير مفعّلة في التكاملات`,
        };
      }
      const { data, error } = await supabase.functions.invoke("dispatch-message", {
        body: {
          channel,
          provider: (cfg as any).provider,
          event: "send_login_credentials",
          to,
          subject: channel === "email" ? subject : null,
          body: messageText,
          providerConfig: (cfg as any).config || null,
          templateId: null,
        },
      });
      if (error) return { ch: channel, ok: false, err: error.message };
      const r = data as any;
      return { ch: channel, ok: !!r?.ok, err: r?.error };
    };

    if (wantEmail && email) tasks.push(invokeChannel("email", email));
    if (wantSms && mobile) tasks.push(invokeChannel("sms", mobile));

    const results = await Promise.all(tasks);
    setSendingCreds(false);

    const okChannels = results.filter((r) => r.ok).map((r) => (r.ch === "sms" ? "SMS" : "البريد"));
    const failed = results.filter((r) => !r.ok);
    if (okChannels.length) toast.success(`تم الإرسال عبر: ${okChannels.join(" و ")}`);
    failed.forEach((f) => toast.error(`فشل ${f.ch === "sms" ? "SMS" : "البريد"}: ${f.err || "غير معروف"}`));
    if (okChannels.length && !failed.length) {
      setCredsDialog((prev) => ({ ...prev, open: false }));
    }
  };

  const applyBulkStatus = async () => {
    if (selectedIds.size === 0) return;
    setBulkApplying(true);
    const ids = Array.from(selectedIds);
    const { error } = await supabase.from("volunteers").update({ status: bulkStatus }).in("id", ids);
    setBulkApplying(false);
    if (error) {
      toast.error(`فشل تغيير الحالة: ${error.message}`);
      return;
    }
    toast.success(`تم تغيير حالة ${ids.length} متطوع إلى: ${statusMap[bulkStatus]}`);
    setSelectedIds(new Set());
    setBulkStatusOpen(false);
    fetchData();
  };

  const handleEditSave = async () => {
    if (!editTarget) return;
    const errs = validateContactForm({
      full_name: editForm.full_name,
      mobile: editForm.mobile,
      national_id: editForm.national_id,
      email: editForm.email,
    });
    setEditErrors(errs);
    if (Object.keys(errs).length > 0) {
      toast.error("الرجاء تصحيح الحقول المظلّلة");
      return;
    }
    setEditSaving(true);
    const payload: Record<string, any> = {
      full_name: editForm.full_name.trim(),
      mobile: normalizeMobile(editForm.mobile),
      national_id: normalizeNationalId(editForm.national_id),
      email: normalizeEmail(editForm.email) || null,
      city: editForm.city || null,
      status: editForm.status,
    };
    const { error } = await supabase.from("volunteers").update(payload).eq("id", editTarget.id);
    setEditSaving(false);
    if (error) {
      toast.error(`فشل حفظ التعديلات: ${error.message}`);
      return;
    }
    toast.success("تم حفظ التعديلات بنجاح");
    setEditOpen(false);
    setEditTarget(null);
    fetchData();
  };

  const handleVolPasswordReset = async () => {
    if (!volPwForm.password || volPwForm.password.length < 6) {
      toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }
    if (volPwForm.password !== volPwForm.confirm) {
      toast.error("كلمة المرور وتأكيدها غير متطابقين");
      return;
    }
    if (!volPwTarget?.auth_id) {
      toast.error("هذا المتطوع غير مربوط بحساب تسجيل دخول");
      return;
    }
    setVolPwLoading(true);
    const { data: result, error } = await supabase.functions.invoke("admin-update-password", {
      body: { p_auth_id: volPwTarget.auth_id, p_new_password: volPwForm.password },
    });
    setVolPwLoading(false);
    if (error) {
      toast.error(`خطأ: ${error.message}`);
      return;
    }
    const res = result as any;
    if (res?.success) {
      toast.success("تم تغيير كلمة المرور بنجاح");
      // Feed new password into credentials dialog so admin can immediately
      // send it via SMS/Email if they want.
      if (volPwTarget) {
        setCredsDialog({
          open: false,
          volunteerId: volPwTarget.id,
          fullName: volPwTarget.full_name,
          email: (volPwTarget as any).email || null,
          mobile: volPwTarget.mobile || null,
          password: volPwForm.password,
        });
      }
      setVolPwOpen(false);
      setVolPwForm({ password: "", confirm: "" });
    } else {
      toast.error(res?.error || "فشل في تغيير كلمة المرور");
    }
  };

  const fetchData = async () => {
    setLoading(true);
    const [volRes, regRes] = await Promise.all([
      supabase.from("volunteers").select("*").order("created_at", { ascending: false }),
      supabase.from("volunteer_registrations").select("*").order("created_at", { ascending: false }),
    ]);
    setData(volRes.data || []);
    const regs = regRes.data || [];
    setRegistrations(regs);

    // Resolve reviewer names (best-effort; failures left as id fragments)
    const reviewerIds = Array.from(new Set(regs.map((r: any) => r.reviewed_by).filter(Boolean)));
    if (reviewerIds.length > 0) {
      const { data: usersRows } = await supabase
        .from("internal_users")
        .select("id, full_name")
        .in("id", reviewerIds as string[]);
      const map: Record<string, string> = {};
      (usersRows || []).forEach((u: any) => {
        map[u.id] = u.full_name;
      });
      setReviewers(map);
    } else {
      setReviewers({});
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
    const loadCities = async () => {
      const { data: s } = await supabase.from("system_settings").select("value").eq("key", "cities").limit(1);
      if (s?.[0]?.value) setCities(JSON.parse(s[0].value));
    };
    loadCities();
  }, []);

  const VolunteerForm = ({ title, onSubmit }: { title: string; onSubmit: (data: any) => void }) => {
    const [form, setForm] = useState({ full_name: "", mobile: "", national_id: "", email: "", city: "" });
    const [errors, setErrors] = useState<Record<string, string>>({});

    const submit = () => {
      const errs = validateContactForm({
        full_name: form.full_name,
        mobile: form.mobile,
        national_id: form.national_id,
        email: form.email,
      });
      setErrors(errs);
      if (Object.keys(errs).length > 0) {
        toast.error("الرجاء تصحيح الحقول المظلّلة");
        return;
      }
      onSubmit({
        ...form,
        mobile: normalizeMobile(form.mobile),
        national_id: normalizeNationalId(form.national_id),
        email: normalizeEmail(form.email) || null,
      });
    };

    return (
      <div className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label>الاسم الكامل</Label>
            <Input
              placeholder="أدخل الاسم"
              className={`mt-1.5 ${errors.full_name ? "border-destructive" : ""}`}
              value={form.full_name}
              onChange={(e) => {
                setForm({ ...form, full_name: e.target.value });
                setErrors((p) => ({ ...p, full_name: "" }));
              }}
            />
            {errors.full_name && <p className="mt-1 text-xs text-destructive">{errors.full_name}</p>}
          </div>
          <div>
            <Label>رقم الجوال</Label>
            <Input
              placeholder="05xxxxxxxx"
              dir="ltr"
              inputMode="numeric"
              maxLength={10}
              className={`mt-1.5 ${errors.mobile ? "border-destructive" : ""}`}
              value={form.mobile}
              onChange={(e) => {
                setForm({ ...form, mobile: handleMobileInput(e.target.value) });
                setErrors((p) => ({ ...p, mobile: "" }));
              }}
            />
            {errors.mobile && <p className="mt-1 text-xs text-destructive">{errors.mobile}</p>}
          </div>
          <div>
            <Label>رقم الهوية</Label>
            <Input
              placeholder="1xxxxxxxxx أو 2xxxxxxxxx"
              dir="ltr"
              inputMode="numeric"
              maxLength={10}
              className={`mt-1.5 ${errors.national_id ? "border-destructive" : ""}`}
              value={form.national_id}
              onChange={(e) => {
                setForm({ ...form, national_id: handleNationalIdInput(e.target.value) });
                setErrors((p) => ({ ...p, national_id: "" }));
              }}
            />
            {errors.national_id && <p className="mt-1 text-xs text-destructive">{errors.national_id}</p>}
          </div>
          <div>
            <Label>البريد الإلكتروني (اختياري)</Label>
            <Input
              type="email"
              placeholder="example@email.com"
              dir="ltr"
              maxLength={254}
              className={`mt-1.5 ${errors.email ? "border-destructive" : ""}`}
              value={form.email}
              onChange={(e) => {
                setForm({ ...form, email: handleEmailInput(e.target.value) });
                setErrors((p) => ({ ...p, email: "" }));
              }}
              onBlur={(e) => {
                const r = e.target.value ? null : null;
                const v = e.target.value;
                if (v && !/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(v))
                  setErrors((p) => ({ ...p, email: "صيغة البريد الإلكتروني غير صحيحة" }));
              }}
            />
            {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
          </div>
          <div>
            <Label>المدينة</Label>
            <Select onValueChange={(v) => setForm({ ...form, city: v })}>
              <SelectTrigger className="mt-1.5">
                <SelectValue placeholder="اختر المدينة" />
              </SelectTrigger>
              <SelectContent>
                {cities.length > 0 ? (
                  cities.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value="__no_cities__" disabled>
                    لا توجد مدن — أضف مدنًا من الإعدادات
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button className="w-full sm:w-auto" onClick={submit}>
          {title}
        </Button>
      </div>
    );
  };

  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [regActionLoading, setRegActionLoading] = useState<string | null>(null);

  const handleAdd = async (form: any) => {
    const { error } = await supabase.from("volunteers").insert(form);
    if (error) {
      toast.error(`خطأ في إضافة المتطوع: ${error.message}`);
      return;
    }
    toast.success("تم إضافة المتطوع بنجاح");
    setAddDialogOpen(false);
    fetchData();
  };

  const changeVolunteerStatus = async (vol: Volunteer, newStatus: string) => {
    const { error } = await supabase.from("volunteers").update({ status: newStatus }).eq("id", vol.id);
    if (error) {
      toast.error(`خطأ في تحديث الحالة: ${error.message}`);
      return;
    }
    toast.success(`تم تغيير الحالة إلى: ${statusMap[newStatus]}`);
    fetchData();
  };

  const processRegistration = async (
    reg: any,
    action: "approved" | "rejected",
    reviewNote?: string,
    notifyBySms?: boolean,
  ) => {
    if (regActionLoading) return;
    const registrationId = reg.id;
    setRegActionLoading(registrationId);

    const rpcAction = action === "approved" ? "approve" : "reject";

    // Optimistic UI: remove from pending immediately
    const previousState = registrations;
    setRegistrations((prev) =>
      prev.map((r) =>
        r.id === registrationId
          ? {
              ...r,
              status: action,
              review_note: reviewNote || null,
              reviewed_by: userId,
              reviewed_at: new Date().toISOString(),
            }
          : r,
      ),
    );

    try {
      const payload = {
        p_registration_id: registrationId,
        p_action: rpcAction,
        p_reviewed_by: userId,
        p_review_note: reviewNote || null,
      };
      const { data, error } = await supabase.rpc("handle_volunteer_registration", payload);

      if (error) {
        setRegistrations(previousState);
        toast.error(error.message);
        return;
      }

      const res = data as any;
      if (res && res.success === false) {
        setRegistrations(previousState);
        toast.error(res.message || res.error || "فشل في معالجة الطلب");
        return;
      }

      if (action === "rejected" && notifyBySms && reg.mobile) {
        // Best-effort: do not block UI on SMS provider state
        sendSms({
          to: reg.mobile,
          message: `عذرًا ${reg.full_name}، تم رفض طلب تسجيلك في منصة رفادة التطوعية.${reviewNote ? ` السبب: ${reviewNote}` : ""}`,
          context: { kind: "registration_rejected", registrationId },
        }).then((r) => {
          if (!r.ok && r.reason !== "sms-provider-not-configured") {
            toast.message("تم الرفض، لكن تعذر إرسال الرسالة النصية");
          }
        });
      }

      toast.success(action === "approved" ? "تم قبول الطلب بنجاح" : "تم رفض الطلب");
      await fetchData();
    } catch (e: any) {
      setRegistrations(previousState);
      toast.error(`خطأ: ${e?.message || "تعذر تنفيذ العملية"}`);
    } finally {
      setRegActionLoading(null);
    }
  };

  const approveRegistration = (reg: any) => processRegistration(reg, "approved");
  const openRejectDialog = (reg: any) => {
    setRejectTarget(reg);
    setRejectNote("");
    setSendSmsOnReject(false);
  };
  const confirmReject = async () => {
    if (!rejectTarget) return;
    const target = rejectTarget;
    const note = rejectNote.trim();
    const sms = sendSmsOnReject;
    setRejectTarget(null);
    setRejectNote("");
    setSendSmsOnReject(false);
    await processRegistration(target, "rejected", note || undefined, sms);
  };

  const openVolunteerDetails = async (vol: Volunteer) => {
    setDetailVol(vol);
    setDetailOpen(true);
    const [hRes, pRes, prRes] = await Promise.all([
      supabase
        .from("volunteer_hours")
        .select("approved_hours, status, opportunities(minimum_hours), participations(total_minutes)")
        .eq("volunteer_id", vol.id),
      supabase
        .from("participations")
        .select("id, opportunity_id, created_at")
        .eq("volunteer_id", vol.id)
        .order("created_at", { ascending: false }),
      supabase.from("proofs").select("id").eq("volunteer_id", vol.id),
    ]);
    const totalHours = roundHours(
      (hRes.data || [])
        .filter((h: any) => {
          const s = String(h?.status || "").toLowerCase();
          return s !== "reversed" && s !== "cancelled" && s !== "rejected";
        })
        .reduce((sum: number, h: any) => sum + effectiveRowHours(h), 0),
    );
    const uniqueOpps = new Set((pRes.data || []).map((p: any) => p.opportunity_id)).size;
    const lastP = pRes.data?.[0]?.created_at ? formatDate(pRes.data[0].created_at) : null;
    setDetailStats({
      hours: totalHours,
      opps: uniqueOpps,
      participations: pRes.data?.length || 0,
      proofs: prRes.data?.length || 0,
      lastParticipation: lastP,
    });
  };

  const filtered = data.filter((v) => {
    if (search && !v.full_name.includes(search) && !v.national_id.includes(search)) return false;
    if (filterStatus === "all") {
      // honor admin's display-only visibility toggles
      if (!visibleStatuses.has(v.status)) return false;
    } else if (v.status !== filterStatus) return false;
    if (filterCity !== "all" && v.city !== filterCity) return false;
    return true;
  });

  // keep selection in sync with filtered set (drop ids no longer visible)
  const filteredIds = filtered.map((v) => v.id);
  const allFilteredSelected = filteredIds.length > 0 && filteredIds.every((id) => selectedIds.has(id));
  const toggleSelectAllFiltered = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allFilteredSelected) filteredIds.forEach((id) => next.delete(id));
      else filteredIds.forEach((id) => next.add(id));
      return next;
    });
  };
  const toggleSelectOne = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const [hoursCounts, setHoursCounts] = useState<Record<string, { hours: number; opps: number }>>({});
  useEffect(() => {
    const fetchCounts = async () => {
      const [hRes, pRes] = await Promise.all([
        supabase
          .from("volunteer_hours")
          .select("volunteer_id, approved_hours, status, opportunities(minimum_hours), participations(total_minutes)"),
        supabase.from("participations").select("volunteer_id, opportunity_id"),
      ]);
      const map: Record<string, { hours: number; opps: Set<string> }> = {};
      (hRes.data || []).forEach((h: any) => {
        const s = String(h?.status || "").toLowerCase();
        if (s === "reversed" || s === "cancelled" || s === "rejected") return;
        if (!map[h.volunteer_id]) map[h.volunteer_id] = { hours: 0, opps: new Set() };
        map[h.volunteer_id].hours += effectiveRowHours(h);
      });
      (pRes.data || []).forEach((p: any) => {
        if (!map[p.volunteer_id]) map[p.volunteer_id] = { hours: 0, opps: new Set() };
        map[p.volunteer_id].opps.add(p.opportunity_id);
      });
      const result: Record<string, { hours: number; opps: number }> = {};
      Object.entries(map).forEach(([k, v]) => {
        result[k] = { hours: roundHours(v.hours), opps: v.opps.size };
      });
      setHoursCounts(result);
    };
    fetchCounts();
  }, [data]);

  const allCities = [...new Set(data.map((v) => v.city).filter(Boolean))] as string[];
  const pendingRegs = registrations.filter((r) => r.status === "pending");
  const rejectedRegs = registrations
    .filter((r) => r.status === "rejected")
    .filter((r: any) => {
      if (!rejSearch) return true;
      const q = rejSearch;
      return (r.full_name || "").includes(q) || (r.national_id || "").includes(q) || (r.mobile || "").includes(q);
    });

  const volunteersExportData = filtered.map((v) => ({
    full_name: v.full_name,
    mobile: v.mobile,
    national_id: v.national_id,
    city: v.city || "—",
    status: statusMap[v.status] || v.status,
    hours: hoursCounts[v.id]?.hours || 0,
    opps: hoursCounts[v.id]?.opps || 0,
    date: formatDate(v.created_at),
  }));
  const volunteersExportCols = [
    { header: "الاسم الكامل", key: "full_name" },
    { header: "رقم الجوال", key: "mobile" },
    { header: "رقم الهوية", key: "national_id" },
    { header: "المدينة", key: "city" },
    { header: "الحالة", key: "status" },
    { header: "الساعات", key: "hours" },
    { header: "الفرص", key: "opps" },
    { header: "تاريخ التسجيل", key: "date" },
  ];

  const pendingExportData = pendingRegs.map((r: any) => ({
    full_name: r.full_name,
    mobile: r.mobile,
    national_id: r.national_id,
    email: r.email || "—",
    city: r.city || "—",
    date: formatDate(r.created_at),
  }));
  const pendingExportCols = [
    { header: "الاسم الكامل", key: "full_name" },
    { header: "الجوال", key: "mobile" },
    { header: "الهوية", key: "national_id" },
    { header: "البريد", key: "email" },
    { header: "المدينة", key: "city" },
    { header: "تاريخ الطلب", key: "date" },
  ];

  const rejectedExportData = rejectedRegs.map((r: any) => ({
    full_name: r.full_name,
    mobile: r.mobile,
    email: r.email || "—",
    national_id: r.national_id,
    city: r.city || "—",
    date: formatDate(r.created_at),
    reviewed_at: r.reviewed_at ? formatDateTime(r.reviewed_at) : "—",
    reviewer: r.reviewed_by ? reviewers[r.reviewed_by] || "—" : "—",
    note: r.review_note || "—",
  }));
  const rejectedExportCols = [
    { header: "الاسم الكامل", key: "full_name" },
    { header: "الجوال", key: "mobile" },
    { header: "البريد", key: "email" },
    { header: "الهوية", key: "national_id" },
    { header: "المدينة", key: "city" },
    { header: "تاريخ الطلب", key: "date" },
    { header: "وقت الرفض", key: "reviewed_at" },
    { header: "المراجع", key: "reviewer" },
    { header: "سبب الرفض", key: "note" },
  ];

  // Active-tab-aware export payload
  const exportData =
    activeTab === "registrations"
      ? pendingExportData
      : activeTab === "rejected"
        ? rejectedExportData
        : volunteersExportData;
  const exportCols =
    activeTab === "registrations"
      ? pendingExportCols
      : activeTab === "rejected"
        ? rejectedExportCols
        : volunteersExportCols;
  const exportTitle =
    activeTab === "registrations" ? "طلبات التسجيل" : activeTab === "rejected" ? "الطلبات المرفوضة" : "المتطوعون";
  const exportFilename =
    activeTab === "registrations"
      ? "registrations_pending"
      : activeTab === "rejected"
        ? "registrations_rejected"
        : "volunteers";

  return (
    <div>
      <PageHeader
        title="المتطوعون"
        description="إدارة وعرض بيانات المتطوعين"
        actions={
          <div className="flex gap-2 items-center">
            <ExportButtons data={exportData} columns={exportCols} title={exportTitle} filename={exportFilename} />
            <ImportVolunteers onComplete={fetchData} />
            <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 ml-2" />
                  إضافة متطوع
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg" dir="rtl">
                <DialogHeader>
                  <DialogTitle>إضافة متطوع جديد</DialogTitle>
                </DialogHeader>
                <VolunteerForm title="إضافة" onSubmit={handleAdd} />
              </DialogContent>
            </Dialog>
          </div>
        }
      />

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="volunteers">المتطوعون</TabsTrigger>
          <TabsTrigger value="registrations" className="relative">
            طلبات التسجيل
            {pendingRegs.length > 0 && (
              <span className="mr-1.5 inline-flex items-center justify-center h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold">
                {pendingRegs.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="rejected">
            الطلبات المرفوضة
            {rejectedRegs.length > 0 && (
              <span className="mr-1.5 text-[10px] text-muted-foreground">({rejectedRegs.length})</span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="volunteers">
          <div dir="rtl" className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث بالاسم أو رقم الهوية..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-9"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-36 h-10">
                <SelectValue placeholder="الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل (بدون المؤرشف)</SelectItem>
                <SelectItem value="active">نشط</SelectItem>
                <SelectItem value="suspended">معلق</SelectItem>
                <SelectItem value="inactive">غير نشط</SelectItem>
                <SelectItem value="archived">مؤرشف</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterCity} onValueChange={setFilterCity}>
              <SelectTrigger className="w-36 h-10">
                <SelectValue placeholder="المدينة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل المدن</SelectItem>
                {allCities.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Display-only status visibility (hide/show statuses in current view) */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="h-10 gap-2">
                  <Filter className="h-4 w-4" />
                  عرض الحالات
                  <span className="text-[10px] text-muted-foreground">
                    ({visibleStatuses.size}/{ALL_STATUSES.length})
                  </span>
                </Button>
              </PopoverTrigger>
              <PopoverContent dir="rtl" className="w-56">
                <p className="text-xs text-muted-foreground mb-2">
                  إظهار/إخفاء على مستوى العرض فقط (لا يحذف من قاعدة البيانات).
                </p>
                <div className="space-y-2">
                  {ALL_STATUSES.map((s) => (
                    <label key={s} className="flex items-center gap-2 cursor-pointer text-sm">
                      <Checkbox checked={visibleStatuses.has(s)} onCheckedChange={() => toggleVisibleStatus(s)} />
                      <span
                        className={`inline-block h-2 w-2 rounded-full ${
                          s === "active"
                            ? "bg-success"
                            : s === "suspended"
                              ? "bg-warning"
                              : s === "inactive"
                                ? "bg-destructive/70"
                                : "bg-muted-foreground/60"
                        }`}
                      />
                      {statusMap[s]}
                    </label>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground mt-3">يعمل فقط عند اختيار "الكل".</p>
              </PopoverContent>
            </Popover>
          </div>

          {/* Bulk actions toolbar */}
          {selectedIds.size > 0 && (
            <div
              dir="rtl"
              className="mb-4 flex flex-wrap items-center gap-3 rounded-lg border border-primary/30 bg-primary/5 p-3"
            >
              <span className="text-sm font-medium">
                محدد: <span className="text-primary">{selectedIds.size}</span> متطوع
              </span>
              <Button size="sm" variant="default" onClick={() => setBulkStatusOpen(true)}>
                <UserCog className="h-4 w-4 ml-1" />
                تغيير الحالة جماعيًا
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setSelectedIds(new Set())}>
                إلغاء التحديد
              </Button>
            </div>
          )}

          <DataTable
            columns={[
              {
                header: "",
                className: "w-10",
                accessor: (r: any) => (
                  <Checkbox
                    checked={selectedIds.has(r.id)}
                    onCheckedChange={() => toggleSelectOne(r.id)}
                    onClick={(e) => e.stopPropagation()}
                    aria-label="تحديد"
                  />
                ),
              },
              {
                header: "الاسم الكامل",
                accessor: (r: any) => (
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-block h-2.5 w-2.5 rounded-full shrink-0 ${
                        r.status === "active"
                          ? "bg-success"
                          : r.status === "suspended"
                            ? "bg-warning"
                            : r.status === "inactive"
                              ? "bg-destructive/70"
                              : "bg-muted-foreground/60"
                      }`}
                      title={statusMap[r.status]}
                    />
                    <span>{r.full_name}</span>
                    {!r.auth_id && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-warning/10 text-warning border border-warning/20">
                        بدون حساب
                      </span>
                    )}
                  </div>
                ),
              },
              { header: "الجوال", accessor: (r: any) => <span dir="ltr">{r.mobile}</span> },
              { header: "الهوية", accessor: (r: any) => <span dir="ltr">{r.national_id}</span> },
              { header: "المدينة", accessor: (r: any) => r.city || "—" },
              {
                header: "الحالة",
                accessor: (r: any) =>
                  isDirector ? (
                    <Select value={r.status} onValueChange={(v) => changeVolunteerStatus(r, v)}>
                      <SelectTrigger className="h-8 w-28 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">نشط</SelectItem>
                        <SelectItem value="suspended">معلق</SelectItem>
                        <SelectItem value="inactive">غير نشط</SelectItem>
                        <SelectItem value="archived">مؤرشف</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <StatusBadge status={statusMap[r.status] || r.status} variant={statusVariant(r.status)} />
                  ),
              },
              {
                header: "الساعات",
                accessor: (r: any) => (
                  <span className="font-medium">{formatTotalHours(hoursCounts[r.id]?.hours || 0)}</span>
                ),
              },
              { header: "الفرص", accessor: (r: any) => hoursCounts[r.id]?.opps || 0 },
              { header: "التسجيل", accessor: (r: any) => formatDate(r.created_at) },
              {
                header: "تفاصيل",
                accessor: (r: any) => (
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => openVolunteerDetails(r)} title="عرض التفاصيل">
                      <Eye className="h-4 w-4 text-primary" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => openEditVolunteer(r)} title="تعديل البيانات">
                      <Pencil className="h-4 w-4 text-primary" />
                    </Button>
                  </div>
                ),
              },
            ]}
            data={filtered}
            emptyMessage="لا يوجد متطوعون مسجلون"
            emptyIcon={<Users className="h-10 w-10 text-muted-foreground/30" />}
          />

          {/* Select-all helper (small bar above empty space — works for filtered set) */}
          {filtered.length > 0 && (
            <div dir="rtl" className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <Checkbox checked={allFilteredSelected} onCheckedChange={toggleSelectAllFiltered} />
              <span className="cursor-pointer" onClick={toggleSelectAllFiltered}>
                {allFilteredSelected ? "إلغاء تحديد الكل في هذه الصفحة" : "تحديد كل المتطوعين الظاهرين"}
              </span>
            </div>
          )}
        </TabsContent>

        <TabsContent value="registrations">
          <DataTable
            columns={[
              { header: "الاسم الكامل", accessor: "full_name" },
              { header: "الجوال", accessor: (r: any) => <span dir="ltr">{r.mobile}</span> },
              { header: "الهوية", accessor: (r: any) => <span dir="ltr">{r.national_id}</span> },
              { header: "البريد", accessor: (r: any) => (r.email ? <span dir="ltr">{r.email}</span> : "—") },
              { header: "المدينة", accessor: (r: any) => r.city || "—" },
              { header: "تاريخ الطلب", accessor: (r: any) => formatDate(r.created_at) },
              {
                header: "إجراءات",
                accessor: (r: any) => {
                  const isLoading = regActionLoading === r.id;
                  return (
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="default"
                        disabled={!!regActionLoading}
                        onClick={() => approveRegistration(r)}
                      >
                        {isLoading ? (
                          "جارٍ..."
                        ) : (
                          <>
                            <Check className="h-4 w-4 ml-1" />
                            قبول
                          </>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        disabled={!!regActionLoading}
                        onClick={() => openRejectDialog(r)}
                      >
                        <X className="h-4 w-4 ml-1" />
                        رفض
                      </Button>
                    </div>
                  );
                },
              },
            ]}
            data={pendingRegs}
            emptyMessage="لا توجد طلبات تسجيل قيد المراجعة"
            emptyIcon={<UserPlus className="h-10 w-10 text-muted-foreground/30" />}
          />
        </TabsContent>

        <TabsContent value="rejected">
          <div dir="rtl" className="flex flex-col sm:flex-row gap-3 mb-5 flex-wrap">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث بالاسم أو الجوال أو الهوية..."
                value={rejSearch}
                onChange={(e) => setRejSearch(e.target.value)}
                className="pr-9"
              />
            </div>
          </div>
          <DataTable
            columns={[
              { header: "الاسم الكامل", accessor: "full_name" },
              { header: "الجوال", accessor: (r: any) => <span dir="ltr">{r.mobile}</span> },
              { header: "البريد", accessor: (r: any) => (r.email ? <span dir="ltr">{r.email}</span> : "—") },
              { header: "الهوية", accessor: (r: any) => <span dir="ltr">{r.national_id}</span> },
              { header: "المدينة", accessor: (r: any) => r.city || "—" },
              { header: "تاريخ الطلب", accessor: (r: any) => formatDate(r.created_at) },
              { header: "وقت الرفض", accessor: (r: any) => (r.reviewed_at ? formatDateTime(r.reviewed_at) : "—") },
              { header: "المراجع", accessor: (r: any) => (r.reviewed_by ? reviewers[r.reviewed_by] || "—" : "—") },
              {
                header: "سبب الرفض",
                accessor: (r: any) => r.review_note || <span className="text-muted-foreground text-xs">بدون سبب</span>,
              },
            ]}
            data={rejectedRegs}
            emptyMessage="لا توجد طلبات مرفوضة"
            emptyIcon={<UserX className="h-10 w-10 text-muted-foreground/30" />}
          />
        </TabsContent>
      </Tabs>

      {/* Reject Registration Dialog */}
      <Dialog
        open={!!rejectTarget}
        onOpenChange={(open) => {
          if (!open) setRejectTarget(null);
        }}
      >
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>رفض طلب التسجيل</DialogTitle>
          </DialogHeader>
          {rejectTarget && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                هل تريد رفض طلب <strong className="text-foreground">{rejectTarget.full_name}</strong>؟
              </p>
              <div>
                <Label>سبب الرفض (اختياري)</Label>
                <Textarea
                  className="mt-1.5"
                  rows={3}
                  placeholder="اكتب سبب الرفض إن وُجد..."
                  value={rejectNote}
                  onChange={(e) => setRejectNote(e.target.value)}
                />
              </div>
              <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/40">
                <Switch id="sms-toggle" checked={sendSmsOnReject} onCheckedChange={setSendSmsOnReject} />
                <div className="flex-1">
                  <Label htmlFor="sms-toggle" className="cursor-pointer">
                    إرسال رسالة إلى جوال المتطوع
                  </Label>
                  <p className="text-[11px] text-muted-foreground mt-1">
                    سيتم تجهيز الرسالة مع طلب الرفض. التكامل الفعلي مع مزود SMS غير مفعّل بعد.
                  </p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline">إلغاء</Button>
            </DialogClose>
            <Button variant="destructive" disabled={!!regActionLoading} onClick={confirmReject}>
              تأكيد الرفض
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Volunteer Details Modal */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>تفاصيل المتطوع</DialogTitle>
          </DialogHeader>
          {detailVol && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-muted/40 rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">الاسم الكامل</p>
                  <p className="font-semibold text-foreground">{detailVol.full_name}</p>
                </div>
                <div className="bg-muted/40 rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">رقم الجوال</p>
                  <p className="font-semibold text-foreground" dir="ltr">
                    {detailVol.mobile}
                  </p>
                </div>
                <div className="bg-muted/40 rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">رقم الهوية</p>
                  <p className="font-semibold text-foreground" dir="ltr">
                    {detailVol.national_id}
                  </p>
                </div>
                <div className="bg-muted/40 rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">المدينة</p>
                  <p className="font-semibold text-foreground">{detailVol.city || "—"}</p>
                </div>
                {(detailVol as any).email && (
                  <div className="bg-muted/40 rounded-lg p-3 col-span-2">
                    <p className="text-xs text-muted-foreground mb-1">البريد الإلكتروني</p>
                    <p className="font-semibold text-foreground" dir="ltr">
                      {(detailVol as any).email}
                    </p>
                  </div>
                )}
                <div className="bg-muted/40 rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">الحالة</p>
                  <StatusBadge
                    status={statusMap[detailVol.status] || detailVol.status}
                    variant={statusVariant(detailVol.status)}
                  />
                </div>
                <div className="bg-muted/40 rounded-lg p-3">
                  <p className="text-xs text-muted-foreground mb-1">تاريخ التسجيل</p>
                  <p className="font-semibold text-foreground">{formatDate(detailVol.created_at)}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-primary/5 rounded-lg p-3 text-center">
                  <Clock className="h-5 w-5 mx-auto text-primary mb-1" />
                  <p className="text-lg font-bold text-foreground">{formatTotalHours(detailStats.hours)}</p>
                  <p className="text-[11px] text-muted-foreground">معتمدة</p>
                </div>
                <div className="bg-primary/5 rounded-lg p-3 text-center">
                  <Award className="h-5 w-5 mx-auto text-primary mb-1" />
                  <p className="text-lg font-bold text-foreground">{detailStats.opps}</p>
                  <p className="text-[11px] text-muted-foreground">فرصة</p>
                </div>
                <div className="bg-primary/5 rounded-lg p-3 text-center">
                  <Users className="h-5 w-5 mx-auto text-primary mb-1" />
                  <p className="text-lg font-bold text-foreground">{detailStats.participations}</p>
                  <p className="text-[11px] text-muted-foreground">مشاركة</p>
                </div>
                <div className="bg-primary/5 rounded-lg p-3 text-center">
                  <FileCheck className="h-5 w-5 mx-auto text-primary mb-1" />
                  <p className="text-lg font-bold text-foreground">{detailStats.proofs}</p>
                  <p className="text-[11px] text-muted-foreground">إثبات</p>
                </div>
              </div>

              {detailStats.lastParticipation && (
                <p className="text-xs text-muted-foreground text-center">آخر مشاركة: {detailStats.lastParticipation}</p>
              )}

              {isDirector && detailVol && (
                <div className="pt-2 border-t border-border space-y-2">
                  <div className="flex flex-wrap gap-2">
                    {!detailVol.auth_id ? (
                      <Button
                        variant="default"
                        size="sm"
                        disabled={creatingAccountFor === detailVol.id || !(detailVol as any).email}
                        onClick={() => createVolunteerAccount(detailVol)}
                      >
                        {creatingAccountFor === detailVol.id ? (
                          <>
                            <Loader2 className="h-4 w-4 ml-1 animate-spin" />
                            جاري الإنشاء...
                          </>
                        ) : (
                          <>
                            <UserPlus className="h-4 w-4 ml-1" />
                            إنشاء حساب دخول
                          </>
                        )}
                      </Button>
                    ) : (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setVolPwTarget(detailVol);
                            setVolPwForm({ password: "", confirm: "" });
                            setVolPwOpen(true);
                          }}
                        >
                          <KeyRound className="h-4 w-4 ml-1" />
                          إعادة تعيين كلمة المرور
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => openSendCredentials(detailVol)}>
                          <Send className="h-4 w-4 ml-1" />
                          إرسال بيانات الدخول
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setResetLinkTarget(detailVol);
                            setResetLinkChannels({ email: !!(detailVol as any).email, sms: false });
                            setResetLinkOpen(true);
                          }}
                        >
                          <KeyRound className="h-4 w-4 ml-1" />
                          إرسال رابط تعيين كلمة مرور
                        </Button>
                      </>
                    )}
                  </div>
                  {!detailVol.auth_id && (
                    <p className="text-xs text-warning">
                      هذا المتطوع غير مربوط بحساب تسجيل دخول.
                      {!(detailVol as any).email && " يجب إضافة بريد إلكتروني صالح أولًا."}
                    </p>
                  )}
                  {detailVol.auth_id && (
                    <p className="text-xs text-success flex items-center gap-1">
                      <Check className="h-3 w-3" />
                      مربوط بحساب دخول
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Volunteer Password Reset Dialog */}
      <Dialog open={volPwOpen} onOpenChange={setVolPwOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>تغيير كلمة مرور المتطوع</DialogTitle>
          </DialogHeader>
          {volPwTarget && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                تغيير كلمة مرور: <span className="font-semibold text-foreground">{volPwTarget.full_name}</span>
              </p>
              {!volPwTarget.auth_id && (
                <div className="bg-destructive/10 text-destructive text-xs rounded-lg p-3">
                  هذا المتطوع غير مربوط بحساب تسجيل دخول (auth_id غير موجود)
                </div>
              )}
              <div>
                <Label>كلمة المرور الجديدة</Label>
                <Input
                  type="password"
                  className="mt-1.5"
                  value={volPwForm.password}
                  onChange={(e) => setVolPwForm({ ...volPwForm, password: e.target.value })}
                  placeholder="6 أحرف على الأقل"
                />
              </div>
              <div>
                <Label>تأكيد كلمة المرور</Label>
                <Input
                  type="password"
                  className="mt-1.5"
                  value={volPwForm.confirm}
                  onChange={(e) => setVolPwForm({ ...volPwForm, confirm: e.target.value })}
                  placeholder="أعد إدخال كلمة المرور"
                />
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">إلغاء</Button>
                </DialogClose>
                <Button onClick={handleVolPasswordReset} disabled={volPwLoading || !volPwTarget.auth_id}>
                  {volPwLoading ? "جارٍ التحديث..." : "تغيير كلمة المرور"}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Volunteer Dialog (admin direct edit) */}
      <Dialog
        open={editOpen}
        onOpenChange={(open) => {
          setEditOpen(open);
          if (!open) setEditTarget(null);
        }}
      >
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>تعديل بيانات المتطوع</DialogTitle>
          </DialogHeader>
          {editTarget && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>الاسم الكامل</Label>
                  <Input
                    className={`mt-1.5 ${editErrors.full_name ? "border-destructive" : ""}`}
                    value={editForm.full_name}
                    onChange={(e) => {
                      setEditForm({ ...editForm, full_name: e.target.value });
                      setEditErrors((p) => ({ ...p, full_name: "" }));
                    }}
                  />
                  {editErrors.full_name && <p className="mt-1 text-xs text-destructive">{editErrors.full_name}</p>}
                </div>
                <div>
                  <Label>رقم الجوال</Label>
                  <Input
                    dir="ltr"
                    inputMode="numeric"
                    maxLength={10}
                    placeholder="05xxxxxxxx"
                    className={`mt-1.5 ${editErrors.mobile ? "border-destructive" : ""}`}
                    value={editForm.mobile}
                    onChange={(e) => {
                      setEditForm({ ...editForm, mobile: handleMobileInput(e.target.value) });
                      setEditErrors((p) => ({ ...p, mobile: "" }));
                    }}
                  />
                  {editErrors.mobile && <p className="mt-1 text-xs text-destructive">{editErrors.mobile}</p>}
                </div>
                <div>
                  <Label>رقم الهوية</Label>
                  <Input
                    dir="ltr"
                    inputMode="numeric"
                    maxLength={10}
                    placeholder="1xxxxxxxxx أو 2xxxxxxxxx"
                    className={`mt-1.5 ${editErrors.national_id ? "border-destructive" : ""}`}
                    value={editForm.national_id}
                    onChange={(e) => {
                      setEditForm({ ...editForm, national_id: handleNationalIdInput(e.target.value) });
                      setEditErrors((p) => ({ ...p, national_id: "" }));
                    }}
                  />
                  {editErrors.national_id && <p className="mt-1 text-xs text-destructive">{editErrors.national_id}</p>}
                </div>
                <div>
                  <Label>البريد الإلكتروني</Label>
                  <Input
                    type="email"
                    dir="ltr"
                    maxLength={254}
                    placeholder="example@email.com"
                    className={`mt-1.5 ${editErrors.email ? "border-destructive" : ""}`}
                    value={editForm.email}
                    onChange={(e) => {
                      setEditForm({ ...editForm, email: handleEmailInput(e.target.value) });
                      setEditErrors((p) => ({ ...p, email: "" }));
                    }}
                    onBlur={(e) => {
                      const v = e.target.value;
                      if (v && !/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(v))
                        setEditErrors((p) => ({ ...p, email: "صيغة البريد الإلكتروني غير صحيحة" }));
                    }}
                  />
                  {editErrors.email && <p className="mt-1 text-xs text-destructive">{editErrors.email}</p>}
                </div>
                <div>
                  <Label>المدينة</Label>
                  <Select
                    value={editForm.city || undefined}
                    onValueChange={(v) => setEditForm({ ...editForm, city: v })}
                  >
                    <SelectTrigger className="mt-1.5">
                      <SelectValue placeholder="اختر المدينة" />
                    </SelectTrigger>
                    <SelectContent>
                      {cities.length > 0 ? (
                        cities.map((c) => (
                          <SelectItem key={c} value={c}>
                            {c}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="__no_cities__" disabled>
                          لا توجد مدن
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>الحالة</Label>
                  <Select value={editForm.status} onValueChange={(v) => setEditForm({ ...editForm, status: v })}>
                    <SelectTrigger className="mt-1.5">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">نشط</SelectItem>
                      <SelectItem value="suspended">معلق</SelectItem>
                      <SelectItem value="inactive">غير نشط</SelectItem>
                      <SelectItem value="archived">مؤرشف</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline" disabled={editSaving}>
                إلغاء
              </Button>
            </DialogClose>
            <Button onClick={handleEditSave} disabled={editSaving}>
              {editSaving ? "جاري الحفظ..." : "حفظ التعديلات"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send Login Credentials Dialog */}
      <Dialog open={credsDialog.open} onOpenChange={(o) => setCredsDialog((prev) => ({ ...prev, open: o }))}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>إرسال بيانات الدخول — {credsDialog.fullName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-2 text-sm">
              <div className="bg-muted/40 rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">البريد الإلكتروني</p>
                <p className="font-mono text-foreground" dir="ltr">
                  {credsDialog.email || "— غير موجود —"}
                </p>
              </div>
              <div className="bg-muted/40 rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">رقم الجوال</p>
                <p className="font-mono text-foreground" dir="ltr">
                  {credsDialog.mobile || "— غير موجود —"}
                </p>
              </div>
              <div className="bg-muted/40 rounded-lg p-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">كلمة المرور</p>
                  {credsDialog.password && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      onClick={() => {
                        navigator.clipboard.writeText(credsDialog.password!);
                        toast.success("تم نسخ كلمة المرور");
                      }}
                    >
                      <Copy className="h-3 w-3 ml-1" />
                      نسخ
                    </Button>
                  )}
                </div>
                <p className="font-mono text-foreground mt-1" dir="ltr">
                  {credsDialog.password || (
                    <span className="text-xs text-warning">
                      لا توجد كلمة مرور للإرسال — استخدم "إعادة تعيين كلمة المرور" أولًا.
                    </span>
                  )}
                </p>
              </div>
            </div>

            <div>
              <Label className="mb-2 block">قناة الإرسال</Label>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    { v: "email", label: "البريد" },
                    { v: "sms", label: "SMS" },
                    { v: "both", label: "الاثنان" },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.v}
                    type="button"
                    onClick={() => setSendChannelChoice(opt.v)}
                    className={`rounded-md border p-2 text-sm transition-colors ${
                      sendChannelChoice === opt.v
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background hover:bg-muted border-input"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground mt-2">يستخدم القنوات المفعلة في صفحة التكاملات.</p>
            </div>

            {/* Gating reasons */}
            {(() => {
              const wantEmail = sendChannelChoice === "email" || sendChannelChoice === "both";
              const wantSms = sendChannelChoice === "sms" || sendChannelChoice === "both";
              const reasons: string[] = [];
              if (!credsDialog.password) reasons.push("لا توجد كلمة مرور حالية للإرسال — أعد تعيين كلمة المرور أولًا.");
              if (channelStatus.loaded) {
                if (wantEmail && !channelStatus.email) reasons.push("قناة البريد غير مفعّلة في صفحة التكاملات.");
                if (wantSms && !channelStatus.sms) reasons.push("قناة الرسائل النصية غير مفعّلة في صفحة التكاملات.");
              }
              if (wantEmail && !credsDialog.email) reasons.push("لا يوجد بريد إلكتروني لهذا الحساب.");
              if (wantSms && !credsDialog.mobile) reasons.push("لا يوجد رقم جوال لهذا الحساب.");
              if (reasons.length === 0) return null;
              return (
                <div className="rounded-md border border-warning/40 bg-warning/10 p-3 text-xs space-y-1">
                  {reasons.map((r, i) => (
                    <p key={i} className="text-warning-foreground/90">
                      • {r}
                    </p>
                  ))}
                </div>
              );
            })()}
          </div>
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline" disabled={sendingCreds}>
                إغلاق
              </Button>
            </DialogClose>
            {(() => {
              const wantEmail = sendChannelChoice === "email" || sendChannelChoice === "both";
              const wantSms = sendChannelChoice === "sms" || sendChannelChoice === "both";
              const channelOk =
                channelStatus.loaded && (!wantEmail || channelStatus.email) && (!wantSms || channelStatus.sms);
              const dataOk = (!wantEmail || !!credsDialog.email) && (!wantSms || !!credsDialog.mobile);
              const canSend = !!credsDialog.password && channelOk && dataOk;
              return (
                <Button onClick={sendCredentials} disabled={sendingCreds || !canSend}>
                  {sendingCreds ? (
                    <>
                      <Loader2 className="h-4 w-4 ml-1 animate-spin" />
                      جاري الإرسال...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 ml-1" />
                      إرسال
                    </>
                  )}
                </Button>
              );
            })()}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send Password Reset Link Dialog */}
      <Dialog open={resetLinkOpen} onOpenChange={setResetLinkOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>إرسال رابط تعيين كلمة مرور — {resetLinkTarget?.full_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-md border border-primary/30 bg-primary/5 p-3 text-xs space-y-1">
              <p className="font-semibold text-foreground">رابط مؤقت آمن</p>
              <p className="text-muted-foreground">
                سيُرسل للمتطوع رابط استعادة من Supabase Auth. عند فتحه يجب عليه تعيين كلمة مرور جديدة قبل الدخول — لن يدخل النظام مباشرة.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-2 text-sm">
              <div className="bg-muted/40 rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">البريد الإلكتروني</p>
                <p className="font-mono text-foreground" dir="ltr">
                  {(resetLinkTarget as any)?.email || "— غير موجود —"}
                </p>
              </div>
              <div className="bg-muted/40 rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">رقم الجوال</p>
                <p className="font-mono text-foreground" dir="ltr">
                  {resetLinkTarget?.mobile || "— غير موجود —"}
                </p>
              </div>
            </div>
            <div>
              <Label className="mb-2 block">قنوات الإرسال</Label>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={resetLinkChannels.email}
                    onCheckedChange={(v) => setResetLinkChannels((p) => ({ ...p, email: !!v }))}
                    disabled={!(resetLinkTarget as any)?.email}
                  />
                  البريد
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox
                    checked={resetLinkChannels.sms}
                    onCheckedChange={(v) => setResetLinkChannels((p) => ({ ...p, sms: !!v }))}
                    disabled={!resetLinkTarget?.mobile}
                  />
                  SMS
                </label>
              </div>
              <p className="text-[11px] text-muted-foreground mt-2">
                يستخدم القنوات المفعلة في صفحة التكاملات. إذا فشلت قناة سيظهر السبب الدقيق.
              </p>
            </div>
            {!(resetLinkTarget as any)?.email && (
              <div className="rounded-md border border-warning/40 bg-warning/10 p-3 text-xs text-warning-foreground/90">
                • هذا المتطوع لا يملك بريدًا إلكترونيًا — لا يمكن توليد رابط استعادة (Supabase Auth يتطلب بريدًا).
              </div>
            )}
          </div>
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline" disabled={resetLinkSending}>
                إغلاق
              </Button>
            </DialogClose>
            <Button
              onClick={sendResetLink}
              disabled={
                resetLinkSending ||
                !resetLinkTarget?.auth_id ||
                !(resetLinkTarget as any)?.email ||
                (!resetLinkChannels.email && !resetLinkChannels.sms)
              }
            >
              {resetLinkSending ? (
                <>
                  <Loader2 className="h-4 w-4 ml-1 animate-spin" />
                  جاري الإرسال...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 ml-1" />
                  إرسال الرابط
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Status Change Dialog */}
      <Dialog open={bulkStatusOpen} onOpenChange={setBulkStatusOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>تغيير حالة {selectedIds.size} متطوع</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              سيتم تطبيق الحالة الجديدة على جميع المتطوعين المحددين. لا يمكن التراجع تلقائيًا.
            </p>
            <div>
              <Label className="mb-1.5 block">الحالة الجديدة</Label>
              <Select value={bulkStatus} onValueChange={setBulkStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ALL_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {statusMap[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <DialogClose asChild>
              <Button variant="outline" disabled={bulkApplying}>
                إلغاء
              </Button>
            </DialogClose>
            <Button onClick={applyBulkStatus} disabled={bulkApplying}>
              {bulkApplying ? (
                <>
                  <Loader2 className="h-4 w-4 ml-1 animate-spin" />
                  جاري التطبيق...
                </>
              ) : (
                "تأكيد"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Volunteers;
