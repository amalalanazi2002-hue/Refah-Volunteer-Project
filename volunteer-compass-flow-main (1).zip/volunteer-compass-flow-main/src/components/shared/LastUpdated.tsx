import { Clock } from "lucide-react";
import { formatDateTime } from "@/lib/format-date";

export const LastUpdated = ({ at }: { at: string | null }) => {
  if (!at) return null;
  return (
    <div className="flex items-center justify-end gap-1.5 text-[11px] text-muted-foreground mb-3">
      <Clock className="h-3 w-3" />
      <span>آخر تحديث: {formatDateTime(at)}</span>
    </div>
  );
};
