import { useRef, useEffect, useCallback, useState } from "react";
import { Bold, Italic, Underline, List, ListOrdered, Link as LinkIcon, Image as ImageIcon, AlignRight, AlignCenter, AlignLeft, Palette, Type } from "lucide-react";
import { cn } from "@/lib/utils";

interface RichTextEditorProps {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  className?: string;
}

const COLORS = ["#1f2937", "#5E4EA2", "#A86DA8", "#dc2626", "#16a34a", "#2563eb", "#f59e0b"];
const SIZES = [
  { label: "صغير", value: "2" },
  { label: "عادي", value: "3" },
  { label: "كبير", value: "5" },
  { label: "ضخم", value: "6" },
];

export const RichTextEditor = ({ value, onChange, placeholder, className }: RichTextEditorProps) => {
  const ref = useRef<HTMLDivElement>(null);
  const [showColors, setShowColors] = useState(false);
  const [showSizes, setShowSizes] = useState(false);

  useEffect(() => {
    if (ref.current && ref.current.innerHTML !== value) {
      ref.current.innerHTML = value || "";
    }
  }, [value]);

  const exec = useCallback((cmd: string, val?: string) => {
    document.execCommand(cmd, false, val);
    if (ref.current) onChange(ref.current.innerHTML);
    ref.current?.focus();
  }, [onChange]);

  const insertLink = () => {
    const url = window.prompt("أدخل الرابط:", "https://");
    if (!url) return;
    exec("createLink", url);
  };

  const insertImage = () => {
    const url = window.prompt("أدخل رابط الصورة:", "https://");
    if (!url) return;
    exec("insertImage", url);
  };

  const Btn = ({ onClick, title, children }: any) => (
    <button type="button" onMouseDown={e => e.preventDefault()} onClick={onClick} title={title}
      className="p-1.5 rounded hover:bg-muted text-foreground/80 hover:text-foreground transition-colors">
      {children}
    </button>
  );

  return (
    <div className={cn("border border-input rounded-md bg-background", className)}>
      <div className="flex items-center gap-0.5 flex-wrap border-b border-border px-2 py-1.5 bg-muted/30 relative">
        <Btn onClick={() => exec("bold")} title="عريض"><Bold className="h-3.5 w-3.5" /></Btn>
        <Btn onClick={() => exec("italic")} title="مائل"><Italic className="h-3.5 w-3.5" /></Btn>
        <Btn onClick={() => exec("underline")} title="تسطير"><Underline className="h-3.5 w-3.5" /></Btn>
        <span className="w-px h-4 bg-border mx-1" />
        <div className="relative">
          <Btn onClick={() => { setShowSizes(s => !s); setShowColors(false); }} title="حجم النص"><Type className="h-3.5 w-3.5" /></Btn>
          {showSizes && (
            <div className="absolute z-20 top-full mt-1 right-0 bg-popover border border-border rounded-md shadow-md p-1 min-w-[100px]">
              {SIZES.map(s => (
                <button key={s.value} type="button" onMouseDown={e => e.preventDefault()}
                  onClick={() => { exec("fontSize", s.value); setShowSizes(false); }}
                  className="w-full text-right px-2 py-1 text-xs rounded hover:bg-muted">
                  {s.label}
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="relative">
          <Btn onClick={() => { setShowColors(c => !c); setShowSizes(false); }} title="لون النص"><Palette className="h-3.5 w-3.5" /></Btn>
          {showColors && (
            <div className="absolute z-20 top-full mt-1 right-0 bg-popover border border-border rounded-md shadow-md p-2 flex gap-1">
              {COLORS.map(c => (
                <button key={c} type="button" onMouseDown={e => e.preventDefault()}
                  onClick={() => { exec("foreColor", c); setShowColors(false); }}
                  style={{ background: c }} className="h-5 w-5 rounded border border-border" />
              ))}
            </div>
          )}
        </div>
        <span className="w-px h-4 bg-border mx-1" />
        <Btn onClick={() => exec("justifyRight")} title="محاذاة يمين"><AlignRight className="h-3.5 w-3.5" /></Btn>
        <Btn onClick={() => exec("justifyCenter")} title="توسيط"><AlignCenter className="h-3.5 w-3.5" /></Btn>
        <Btn onClick={() => exec("justifyLeft")} title="محاذاة يسار"><AlignLeft className="h-3.5 w-3.5" /></Btn>
        <span className="w-px h-4 bg-border mx-1" />
        <Btn onClick={() => exec("insertUnorderedList")} title="تعداد نقطي"><List className="h-3.5 w-3.5" /></Btn>
        <Btn onClick={() => exec("insertOrderedList")} title="تعداد رقمي"><ListOrdered className="h-3.5 w-3.5" /></Btn>
        <span className="w-px h-4 bg-border mx-1" />
        <Btn onClick={insertLink} title="إدراج رابط"><LinkIcon className="h-3.5 w-3.5" /></Btn>
        <Btn onClick={insertImage} title="إدراج صورة"><ImageIcon className="h-3.5 w-3.5" /></Btn>
      </div>
      <div
        ref={ref}
        contentEditable
        dir="rtl"
        onInput={() => onChange(ref.current?.innerHTML || "")}
        data-placeholder={placeholder}
        className="min-h-[140px] max-h-[400px] overflow-y-auto p-3 text-sm focus:outline-none prose prose-sm max-w-none [&_img]:max-w-full [&_img]:rounded [&_a]:text-primary [&_a]:underline empty:before:content-[attr(data-placeholder)] empty:before:text-muted-foreground"
      />
    </div>
  );
};
