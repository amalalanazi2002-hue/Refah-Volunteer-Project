import { LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  color?: "primary" | "secondary" | "accent" | "success" | "warning";
  to?: string;
}

const colorMap = {
  primary: "bg-primary/10 text-primary",
  secondary: "bg-secondary/10 text-secondary",
  accent: "bg-accent/10 text-accent",
  success: "bg-success/10 text-success",
  warning: "bg-warning/10 text-warning",
};

export const StatCard = ({ title, value, icon: Icon, color = "primary", to }: StatCardProps) => {
  const inner = (
    <>
      <div className={`p-3 rounded-xl ${colorMap[color]} transition-transform group-hover:scale-110`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium text-muted-foreground leading-relaxed">{title}</p>
        <p className="text-2xl font-bold text-foreground mt-1 tabular-nums">{value}</p>
      </div>
    </>
  );

  const baseCls =
    "group bg-card rounded-lg border border-border p-5 flex items-center gap-4 min-h-[100px] transition-all duration-200";

  if (to) {
    return (
      <Link
        to={to}
        className={`${baseCls} hover:border-primary/40 hover:shadow-md hover:-translate-y-0.5 cursor-pointer`}
        aria-label={title}
      >
        {inner}
      </Link>
    );
  }

  return <div className={baseCls}>{inner}</div>;
};
