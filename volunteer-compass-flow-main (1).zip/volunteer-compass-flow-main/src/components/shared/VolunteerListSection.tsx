import { ReactNode, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";

interface SummaryChip {
  label: string;
  value: number | string;
  variant?: "success" | "warning" | "danger" | "primary" | "neutral";
}

interface VolunteerListSectionProps {
  title: string;
  icon?: ReactNode;
  total: number;
  summary?: SummaryChip[];
  initialLimit?: number;
  /**
   * Render-prop receives the active limit (number = take first N, undefined = show all)
   * so the caller can slice its data accordingly.
   */
  children: (limit: number | undefined) => ReactNode;
  className?: string;
}

const chipColor = (v?: SummaryChip["variant"]) => {
  switch (v) {
    case "success": return "bg-success/10 text-success border-success/20";
    case "warning": return "bg-warning/10 text-warning border-warning/20";
    case "danger": return "bg-destructive/10 text-destructive border-destructive/20";
    case "primary": return "bg-primary/10 text-primary border-primary/20";
    default: return "bg-muted text-muted-foreground border-border";
  }
};

export const VolunteerListSection = ({
  title,
  icon,
  total,
  summary,
  initialLimit = 5,
  children,
  className,
}: VolunteerListSectionProps) => {
  const [expanded, setExpanded] = useState(false);
  const hasMore = total > initialLimit;
  const limit = expanded || !hasMore ? undefined : initialLimit;

  return (
    <section className={`bg-card rounded-lg border border-border p-4 md:p-5 ${className || ""}`}>
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
        <div className="flex items-center gap-2 flex-wrap">
          {icon && <span className="text-primary shrink-0">{icon}</span>}
          <h3 className="font-bold text-foreground text-sm">{title}</h3>
          <span className="text-xs text-muted-foreground bg-muted/60 rounded-full px-2 py-0.5">
            {total} {total === 1 ? "عنصر" : "عناصر"}
          </span>
        </div>
        {summary && summary.length > 0 && (
          <div className="flex items-center gap-1.5 flex-wrap">
            {summary.filter(s => Number(s.value) > 0).map((s, i) => (
              <span
                key={i}
                className={`text-[11px] px-2 py-0.5 rounded-full border ${chipColor(s.variant)}`}
              >
                {s.label}: {s.value}
              </span>
            ))}
          </div>
        )}
      </header>

      <div>{children(limit)}</div>

      {hasMore && (
        <div className="mt-3 flex justify-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(e => !e)}
            className="text-xs text-primary hover:text-primary"
          >
            {expanded ? (
              <>
                <ChevronUp className="h-3.5 w-3.5 ml-1" />
                عرض أقل
              </>
            ) : (
              <>
                <ChevronDown className="h-3.5 w-3.5 ml-1" />
                عرض الكل ({total})
              </>
            )}
          </Button>
        </div>
      )}
    </section>
  );
};
