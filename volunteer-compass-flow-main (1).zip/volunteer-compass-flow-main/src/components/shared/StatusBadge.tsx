interface StatusBadgeProps {
  status: string;
  variant?: "success" | "warning" | "danger" | "neutral" | "primary";
}

const variantMap = {
  success: "bg-success/10 text-success border-success/20",
  warning: "bg-warning/10 text-warning border-warning/20",
  danger: "bg-destructive/10 text-destructive border-destructive/20",
  neutral: "bg-muted text-muted-foreground border-border",
  primary: "bg-primary/10 text-primary border-primary/20",
};

export const StatusBadge = ({ status, variant = "neutral" }: StatusBadgeProps) => {
  return (
    <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold border ${variantMap[variant]}`}>
      {status}
    </span>
  );
};
