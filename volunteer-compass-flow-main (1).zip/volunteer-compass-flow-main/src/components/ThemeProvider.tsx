import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

// Convert HEX to HSL string "H S% L%"
function hexToHSL(hex: string): string | null {
  hex = hex.replace("#", "");
  if (hex.length === 3) hex = hex.split("").map(c => c + c).join("");
  if (hex.length !== 6) return null;

  const r = parseInt(hex.substring(0, 2), 16) / 255;
  const g = parseInt(hex.substring(2, 4), 16) / 255;
  const b = parseInt(hex.substring(4, 6), 16) / 255;

  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }

  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

const COLOR_MAP: Record<string, string[]> = {
  color_primary: ["--primary", "--ring", "--sidebar-background"],
  color_secondary: ["--secondary"],
  color_accent: ["--accent"],
  color_background: ["--background"],
  color_card: ["--card", "--popover"],
  color_text: ["--foreground", "--card-foreground", "--popover-foreground"],
  color_button_primary: ["--primary"],
  color_button_secondary: ["--secondary"],
};

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const applyTheme = async () => {
      const { data } = await supabase
        .from("system_settings")
        .select("key, value")
        .like("key", "color_%");

      if (data && data.length > 0) {
        const root = document.documentElement;
        // Track which CSS vars have been set to avoid double-setting
        const applied = new Set<string>();

        data.forEach((row: any) => {
          if (!row.value || !row.value.startsWith("#")) return;
          const hsl = hexToHSL(row.value);
          if (!hsl) return;

          const cssVars = COLOR_MAP[row.key];
          if (!cssVars) return;

          cssVars.forEach(v => {
            // color_button_primary maps to --primary same as color_primary
            // only apply if not already set by a more specific key
            if (row.key === "color_button_primary" && applied.has("--primary")) return;
            if (row.key === "color_button_secondary" && applied.has("--secondary")) return;

            root.style.setProperty(v, hsl);
            applied.add(v);
          });
        });

        // Derive sidebar accent from primary if primary was set
        const primaryRow = data.find((r: any) => r.key === "color_primary" || r.key === "color_button_primary");
        if (primaryRow?.value) {
          const hsl = hexToHSL(primaryRow.value);
          if (hsl) {
            const parts = hsl.split(" ");
            const h = parseInt(parts[0]);
            const s = parseInt(parts[1]);
            const l = Math.max(parseInt(parts[2]) - 7, 10);
            root.style.setProperty("--sidebar-accent", `${h} ${s}% ${l}%`);
            root.style.setProperty("--sidebar-border", `${h} ${Math.max(s - 5, 0)}% ${Math.min(l + 8, 90)}%`);
          }
        }
      }

      setLoaded(true);
    };

    applyTheme();
  }, []);

  if (!loaded) return null;
  return <>{children}</>;
};
