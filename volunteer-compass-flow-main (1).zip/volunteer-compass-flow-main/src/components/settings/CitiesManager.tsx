import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface CitiesManagerProps {
  cities: string[];
  onRefresh: () => void;
}

export const CitiesManager = ({ cities, onRefresh }: CitiesManagerProps) => {
  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [newCity, setNewCity] = useState("");
  const [editingCity, setEditingCity] = useState("");
  const [editingOriginal, setEditingOriginal] = useState("");

  const addCity = async () => {
    if (!newCity.trim()) return;
    const { data: existing } = await supabase.from("system_settings").select("id, value").eq("key", "cities").limit(1);
    const current = existing?.[0]?.value ? JSON.parse(existing[0].value) : [];
    if (current.includes(newCity.trim())) { toast.error("المدينة موجودة بالفعل"); return; }
    current.push(newCity.trim());
    if (existing && existing.length > 0) {
      await supabase.from("system_settings").update({ value: JSON.stringify(current) }).eq("key", "cities");
    } else {
      await supabase.from("system_settings").insert({ key: "cities", value: JSON.stringify(current) });
    }
    toast.success("تم إضافة المدينة");
    setNewCity("");
    setAddOpen(false);
    onRefresh();
  };

  const editCity = async () => {
    if (!editingCity.trim()) return;
    const { data: existing } = await supabase.from("system_settings").select("id, value").eq("key", "cities").limit(1);
    const current = existing?.[0]?.value ? JSON.parse(existing[0].value) : [];
    const idx = current.indexOf(editingOriginal);
    if (idx >= 0) current[idx] = editingCity.trim();
    await supabase.from("system_settings").update({ value: JSON.stringify(current) }).eq("key", "cities");
    toast.success("تم تعديل المدينة");
    setEditOpen(false);
    onRefresh();
  };

  const deleteCity = async (city: string) => {
    const { data: existing } = await supabase.from("system_settings").select("id, value").eq("key", "cities").limit(1);
    const current = existing?.[0]?.value ? JSON.parse(existing[0].value) : [];
    const updated = current.filter((c: string) => c !== city);
    await supabase.from("system_settings").update({ value: JSON.stringify(updated) }).eq("key", "cities");
    toast.success("تم حذف المدينة");
    onRefresh();
  };

  return (
    <div className="bg-card rounded-lg border border-border p-5 md:p-6 space-y-5">
      <h3 className="font-bold text-foreground">إدارة المدن</h3>
      <Separator />
      <div className="space-y-2">
        {cities.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center p-4">لا توجد مدن بعد</p>
        ) : cities.map(city => (
          <div key={city} className="flex items-center justify-between p-3 bg-muted/60 rounded-lg">
            <span className="text-sm font-medium">{city}</span>
            <div className="flex gap-1">
              <Button variant="ghost" size="sm" onClick={() => { setEditingOriginal(city); setEditingCity(city); setEditOpen(true); }}>
                <Pencil className="h-3.5 w-3.5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => deleteCity(city)}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ))}
      </div>
      <Button variant="outline" onClick={() => setAddOpen(true)}>
        <Plus className="h-4 w-4 ml-1" />إضافة مدينة
      </Button>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle>إضافة مدينة</DialogTitle></DialogHeader>
          <div><Label>اسم المدينة</Label><Input className="mt-1.5" value={newCity} onChange={e => setNewCity(e.target.value)} /></div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={addCity}>إضافة</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle>تعديل المدينة</DialogTitle></DialogHeader>
          <div><Label>اسم المدينة</Label><Input className="mt-1.5" value={editingCity} onChange={e => setEditingCity(e.target.value)} /></div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={editCity}>حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
