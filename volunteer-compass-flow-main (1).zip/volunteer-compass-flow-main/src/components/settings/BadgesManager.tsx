import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const badgeIcons = [
  { value: "🌱", label: "🌱 بذرة" },
  { value: "⭐", label: "⭐ نجمة" },
  { value: "🏅", label: "🏅 ميدالية" },
  { value: "🏆", label: "🏆 كأس" },
  { value: "💎", label: "💎 ماسة" },
  { value: "👑", label: "👑 تاج" },
  { value: "🔥", label: "🔥 شعلة" },
  { value: "🎖️", label: "🎖️ وسام" },
];

interface Badge { id?: string; name: string; icon: string; min_hours: number; sort_order: number; }

interface BadgesManagerProps {
  badges: Badge[];
  onRefresh: () => void;
}

export const BadgesManager = ({ badges, onRefresh }: BadgesManagerProps) => {
  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState<Badge>({ name: "", icon: "⭐", min_hours: 0, sort_order: 0 });
  const [editForm, setEditForm] = useState<Badge & { id: string }>({ id: "", name: "", icon: "⭐", min_hours: 0, sort_order: 0 });

  const addBadge = async () => {
    if (!form.name || form.min_hours < 0) return;
    const { error } = await supabase.from("badge_levels").insert({
      name: form.name, icon: form.icon, min_hours: form.min_hours, sort_order: form.sort_order || badges.length + 1,
    });
    if (error) { toast.error("خطأ في إضافة الوسام"); return; }
    toast.success("تم إضافة الوسام");
    setForm({ name: "", icon: "⭐", min_hours: 0, sort_order: 0 });
    setAddOpen(false);
    onRefresh();
  };

  const editBadge = async () => {
    if (!editForm.name) return;
    const { error } = await supabase.from("badge_levels").update({
      name: editForm.name, icon: editForm.icon, min_hours: editForm.min_hours, sort_order: editForm.sort_order,
    }).eq("id", editForm.id);
    if (error) { toast.error("خطأ في التعديل"); return; }
    toast.success("تم تعديل الوسام");
    setEditOpen(false);
    onRefresh();
  };

  const deleteBadge = async (id: string) => {
    await supabase.from("badge_levels").delete().eq("id", id);
    toast.success("تم حذف الوسام");
    onRefresh();
  };

  const BadgeForm = ({ data, onChange, onSubmit, submitLabel }: { data: Badge; onChange: (d: any) => void; onSubmit: () => void; submitLabel: string }) => (
    <div className="space-y-4">
      <div><Label>اسم الوسام</Label><Input className="mt-1.5" placeholder="مثال: وسام المتطوع الذهبي" value={data.name} onChange={e => onChange({ ...data, name: e.target.value })} /></div>
      <div><Label>الأيقونة</Label>
        <Select value={data.icon} onValueChange={v => onChange({ ...data, icon: v })}>
          <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
          <SelectContent>{badgeIcons.map(i => <SelectItem key={i.value} value={i.value}>{i.label}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div><Label>الحد الأدنى من الساعات</Label><Input type="number" className="mt-1.5" value={data.min_hours} onChange={e => onChange({ ...data, min_hours: Number(e.target.value) })} /></div>
      <div><Label>الترتيب</Label><Input type="number" className="mt-1.5" value={data.sort_order} onChange={e => onChange({ ...data, sort_order: Number(e.target.value) })} /></div>
      <DialogFooter>
        <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
        <Button onClick={onSubmit}>{submitLabel}</Button>
      </DialogFooter>
    </div>
  );

  return (
    <div className="bg-card rounded-lg border border-border p-5 md:p-6 space-y-5">
      <h3 className="font-bold text-foreground">إدارة الأوسمة</h3>
      <Separator />
      <div className="space-y-2">
        {badges.length === 0 ? (
          <p className="text-sm text-muted-foreground p-4 text-center">لا توجد أوسمة بعد</p>
        ) : badges.map(badge => (
          <div key={badge.id} className="flex items-center justify-between p-3 bg-muted/60 rounded-lg">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{badge.icon}</span>
              <div>
                <p className="text-sm font-medium">{badge.name}</p>
                <p className="text-xs text-muted-foreground">{badge.min_hours} ساعة — الترتيب: {badge.sort_order}</p>
              </div>
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="sm" onClick={() => { setEditForm({ id: badge.id!, ...badge }); setEditOpen(true); }}>
                <Pencil className="h-3.5 w-3.5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => badge.id && deleteBadge(badge.id)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
      <Button variant="outline" onClick={() => setAddOpen(true)}>
        <Plus className="h-4 w-4 ml-1" />إضافة وسام
      </Button>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>إضافة وسام جديد</DialogTitle></DialogHeader>
          <BadgeForm data={form} onChange={setForm} onSubmit={addBadge} submitLabel="إضافة" />
        </DialogContent>
      </Dialog>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>تعديل الوسام</DialogTitle></DialogHeader>
          <BadgeForm data={editForm} onChange={setEditForm} onSubmit={editBadge} submitLabel="حفظ التعديلات" />
        </DialogContent>
      </Dialog>
    </div>
  );
};
