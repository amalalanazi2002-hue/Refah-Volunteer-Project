import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Dept { id: string; name: string; code: string | null; is_active: boolean; }

interface DepartmentsManagerProps {
  departments: Dept[];
  onRefresh: () => void;
}

export const DepartmentsManager = ({ departments, onRefresh }: DepartmentsManagerProps) => {
  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState({ name: "", code: "" });
  const [editForm, setEditForm] = useState({ id: "", name: "", code: "" });

  const addDept = async () => {
    if (!form.name.trim()) return;
    const { error } = await supabase.from("departments").insert({ name: form.name.trim(), code: form.code.trim() || null });
    if (error) { toast.error("خطأ في الإضافة"); return; }
    toast.success("تم إضافة الإدارة");
    setForm({ name: "", code: "" });
    setAddOpen(false);
    onRefresh();
  };

  const editDept = async () => {
    if (!editForm.name.trim()) return;
    await supabase.from("departments").update({ name: editForm.name.trim(), code: editForm.code.trim() || null }).eq("id", editForm.id);
    toast.success("تم تعديل الإدارة");
    setEditOpen(false);
    onRefresh();
  };

  const toggleActive = async (dept: Dept) => {
    await supabase.from("departments").update({ is_active: !dept.is_active }).eq("id", dept.id);
    toast.success(dept.is_active ? "تم تعطيل الإدارة" : "تم تفعيل الإدارة");
    onRefresh();
  };

  return (
    <div className="bg-card rounded-lg border border-border p-5 md:p-6 space-y-5">
      <h3 className="font-bold text-foreground">إدارة الإدارات</h3>
      <Separator />
      <div className="space-y-2">
        {departments.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center p-4">لا توجد إدارات بعد</p>
        ) : departments.map(dept => (
          <div key={dept.id} className="flex items-center justify-between p-3 bg-muted/60 rounded-lg">
            <div>
              <p className="text-sm font-medium">{dept.name}</p>
              {dept.code && <p className="text-xs text-muted-foreground">الرمز: {dept.code}</p>}
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={dept.is_active} onCheckedChange={() => toggleActive(dept)} />
              <Button variant="ghost" size="sm" onClick={() => { setEditForm({ id: dept.id, name: dept.name, code: dept.code || "" }); setEditOpen(true); }}>
                <Pencil className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ))}
      </div>
      <Button variant="outline" onClick={() => setAddOpen(true)}>
        <Plus className="h-4 w-4 ml-1" />إضافة إدارة
      </Button>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle>إضافة إدارة</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>اسم الإدارة</Label><Input className="mt-1.5" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label>الرمز (اختياري)</Label><Input className="mt-1.5" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={addDept}>إضافة</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle>تعديل الإدارة</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>اسم الإدارة</Label><Input className="mt-1.5" value={editForm.name} onChange={e => setEditForm({ ...editForm, name: e.target.value })} /></div>
            <div><Label>الرمز</Label><Input className="mt-1.5" value={editForm.code} onChange={e => setEditForm({ ...editForm, code: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={editDept}>حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
