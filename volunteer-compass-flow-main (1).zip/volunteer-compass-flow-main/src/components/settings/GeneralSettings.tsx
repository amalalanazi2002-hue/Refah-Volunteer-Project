import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save } from "lucide-react";
import { timezoneOptions } from "@/lib/format-date";

interface GeneralSettingsProps {
  settings: {
    platform_name: string;
    org_name: string;
    org_description: string;
    contact_email: string;
    contact_phone: string;
    enable_notifications: boolean;
    default_min_hours: string;
    logo_url: string;
    timezone: string;
  };
  onChange: (settings: any) => void;
  onSave: () => void;
}

export const GeneralSettings = ({ settings, onChange, onSave }: GeneralSettingsProps) => (
  <div className="bg-card rounded-lg border border-border p-5 md:p-6 space-y-5">
    <h3 className="font-bold text-foreground">الإعدادات العامة</h3>
    <Separator />
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div>
        <Label>اسم المنصة</Label>
        <Input className="mt-1.5" value={settings.platform_name} onChange={e => onChange({ ...settings, platform_name: e.target.value })} />
      </div>
      <div>
        <Label>اسم الجهة</Label>
        <Input className="mt-1.5" value={settings.org_name} onChange={e => onChange({ ...settings, org_name: e.target.value })} />
      </div>
      <div className="sm:col-span-2">
        <Label>وصف مختصر</Label>
        <Textarea className="mt-1.5" value={settings.org_description} onChange={e => onChange({ ...settings, org_description: e.target.value })} placeholder="وصف مختصر عن الجهة..." />
      </div>
      <div>
        <Label>البريد الرسمي</Label>
        <Input type="email" className="mt-1.5" value={settings.contact_email} onChange={e => onChange({ ...settings, contact_email: e.target.value })} />
      </div>
      <div>
        <Label>رقم التواصل</Label>
        <Input className="mt-1.5" value={settings.contact_phone} onChange={e => onChange({ ...settings, contact_phone: e.target.value })} />
      </div>
      <div>
        <Label>الحد الأدنى الافتراضي للساعات (عند إنشاء فرصة)</Label>
        <Input type="number" className="mt-1.5" value={settings.default_min_hours} onChange={e => onChange({ ...settings, default_min_hours: e.target.value })} placeholder="4" />
      </div>
      <div>
        <Label>رابط شعار الجهة</Label>
        <Input className="mt-1.5" value={settings.logo_url} onChange={e => onChange({ ...settings, logo_url: e.target.value })} placeholder="https://example.com/logo.png" />
        {settings.logo_url && (
          <div className="mt-2 flex items-center gap-2">
            <img src={settings.logo_url} alt="شعار" className="h-10 w-10 object-contain rounded border border-border" onError={e => (e.currentTarget.style.display = "none")} />
            <span className="text-xs text-muted-foreground">معاينة الشعار</span>
          </div>
        )}
      </div>
      <div>
        <Label>المنطقة الزمنية</Label>
        <Select value={settings.timezone || "Asia/Riyadh"} onValueChange={v => onChange({ ...settings, timezone: v })}>
          <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
          <SelectContent>
            {timezoneOptions.map(tz => <SelectItem key={tz.value} value={tz.value}>{tz.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
    </div>
    <div className="flex items-center gap-3 pt-2">
      <Switch checked={settings.enable_notifications} onCheckedChange={v => onChange({ ...settings, enable_notifications: v })} />
      <Label>تفعيل التنبيهات الداخلية</Label>
    </div>
    <Button onClick={onSave}>
      <Save className="h-4 w-4 ml-1" />
      حفظ الإعدادات
    </Button>
  </div>
);
