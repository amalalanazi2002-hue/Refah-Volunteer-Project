import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Save } from "lucide-react";

interface ColorSetting {
  key: string;
  label: string;
  value: string;
}

interface BrandingSettingsProps {
  colors: ColorSetting[];
  onChange: (key: string, value: string) => void;
  onSave: () => void;
}

export const BrandingSettings = ({ colors, onChange, onSave }: BrandingSettingsProps) => (
  <div className="bg-card rounded-lg border border-border p-5 md:p-6 space-y-5">
    <h3 className="font-bold text-foreground">الهوية البصرية</h3>
    <Separator />
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {colors.map(c => (
        <div key={c.key} className="flex items-center gap-3">
          <div className="flex-1">
            <Label className="text-xs">{c.label}</Label>
            <Input className="mt-1" value={c.value} onChange={e => onChange(c.key, e.target.value)} placeholder="#5E4EA2" />
          </div>
          <div className="w-10 h-10 rounded-lg border border-border shrink-0 mt-5" style={{ backgroundColor: c.value || "#ccc" }} />
        </div>
      ))}
    </div>
    <p className="text-xs text-muted-foreground">أدخل القيم بصيغة HEX (مثال: #5E4EA2). بعد الحفظ، أعد تحميل الصفحة لرؤية التغييرات.</p>
    <Button onClick={onSave}>
      <Save className="h-4 w-4 ml-1" />
      حفظ الألوان
    </Button>
  </div>
);
