import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Upload, Download, FileSpreadsheet, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ImportResult {
  accepted: number;
  rejected: number;
  errors: { row: number; name?: string; reason: string }[];
}

const TEMPLATE_HEADERS = ["full_name", "mobile", "national_id", "email", "city"];
const TEMPLATE_HEADERS_AR = ["الاسم الكامل", "رقم الجوال", "رقم الهوية", "البريد الإلكتروني", "المدينة"];

const toLatinDigits = (v: string) =>
  v.replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
   .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));

const normalizeMobile = (v: string) => {
  const digits = toLatinDigits(v).replace(/\D/g, "");
  if (!digits) return "";
  if (digits.startsWith("00966")) return `0${digits.slice(5)}`;
  if (digits.startsWith("966")) return `0${digits.slice(3)}`;
  if (digits.startsWith("5") && digits.length === 9) return `0${digits}`;
  return digits;
};

/**
 * Smart CSV parser that handles:
 * - Tab-separated files (common from Excel copy-paste)
 * - Semicolon-separated files (common in some locales)
 * - Comma-separated files
 * - Quoted fields with commas inside
 * - BOM characters
 */
const detectDelimiter = (headerLine: string): string => {
  // Remove BOM
  const clean = headerLine.replace(/^\uFEFF/, "");
  // Count occurrences of common delimiters in the header
  const tabCount = (clean.match(/\t/g) || []).length;
  const semiCount = (clean.match(/;/g) || []).length;
  const commaCount = (clean.match(/,/g) || []).length;

  if (tabCount >= 2 && tabCount >= commaCount && tabCount >= semiCount) return "\t";
  if (semiCount >= 2 && semiCount >= commaCount) return ";";
  return ",";
};

const splitCSVLine = (line: string, delimiter: string): string[] => {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      result.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
};

const parseCSV = (text: string): { rows: Record<string, string>[]; error?: string } => {
  // Remove BOM
  const clean = text.replace(/^\uFEFF/, "");
  const lines = clean.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return { rows: [], error: "الملف لا يحتوي على بيانات كافية (يجب أن يحتوي على هيدر وصف واحد على الأقل)" };

  const delimiter = detectDelimiter(lines[0]);
  const headers = splitCSVLine(lines[0], delimiter).map(h => h.replace(/^"|"$/g, "").trim());

  // Map headers (Arabic or English)
  const headerMap: Record<number, string> = {};
  let matchedCount = 0;
  headers.forEach((h, i) => {
    const arIdx = TEMPLATE_HEADERS_AR.indexOf(h);
    if (arIdx !== -1) {
      headerMap[i] = TEMPLATE_HEADERS[arIdx];
      matchedCount++;
    } else if (TEMPLATE_HEADERS.includes(h)) {
      headerMap[i] = h;
      matchedCount++;
    }
  });

  if (matchedCount < 2) {
    return {
      rows: [],
      error: `لم يتم التعرف على أعمدة كافية (تم التعرف على ${matchedCount} فقط). تأكد أن الهيدر يحتوي على: ${TEMPLATE_HEADERS_AR.join("، ")}`
    };
  }

  const rows = lines.slice(1).map(line => {
    const values = splitCSVLine(line, delimiter).map(v => v.replace(/^"|"$/g, "").trim());
    const row: Record<string, string> = {};
    values.forEach((v, i) => {
      const key = headerMap[i];
      if (key) row[key] = v;
    });
    return row;
  }).filter(r => Object.values(r).some(v => v));

  return { rows };
};

export const ImportVolunteers = ({ onComplete }: { onComplete: () => void }) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [parsedRows, setParsedRows] = useState<Record<string, string>[]>([]);
  const [parseError, setParseError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const downloadTemplate = () => {
    const BOM = "\uFEFF";
    const csv = BOM + TEMPLATE_HEADERS_AR.join(",") + "\n" + "أحمد محمد,0512345678,1234567890,ahmed@example.com,الرياض";
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "volunteer_import_template.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setResult(null);
    setParseError(null);

    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const { rows, error } = parseCSV(text);

      if (error) {
        setParseError(error);
        setParsedRows([]);
        return;
      }

      // Normalize
      const normalized = rows.map(r => ({
        ...r,
        mobile: r.mobile ? normalizeMobile(r.mobile) : "",
        national_id: r.national_id ? toLatinDigits(r.national_id).replace(/\D/g, "") : "",
        email: (r.email || "").trim().toLowerCase(),
      }));
      setParsedRows(normalized);
    };
    reader.readAsText(file, "UTF-8");
  };

  const handleImport = async () => {
    if (parsedRows.length === 0) {
      toast.error("لا توجد بيانات للاستيراد");
      return;
    }
    setLoading(true);

    const importResult: ImportResult = { accepted: 0, rejected: 0, errors: [] };

    for (let i = 0; i < parsedRows.length; i++) {
      const row = parsedRows[i];
      const rowNum = i + 2; // +2 for header + 0-index

      if (!row.full_name || !row.mobile || !row.national_id) {
        importResult.rejected++;
        importResult.errors.push({ row: rowNum, name: row.full_name || "—", reason: "حقول مطلوبة ناقصة (الاسم، الجوال، الهوية)" });
        continue;
      }

      const { error } = await supabase.from("volunteers").insert({
        full_name: row.full_name,
        mobile: row.mobile,
        national_id: row.national_id,
        email: row.email || null,
        city: row.city || null,
        status: "active",
      });

      if (error) {
        importResult.rejected++;
        let reason = error.message;
        if (error.code === "23505") reason = "مكرر — الجوال أو الهوية موجودة مسبقًا";
        else if (error.message.includes("الجوال")) reason = error.message;
        else if (error.message.includes("الهوية")) reason = error.message;
        importResult.errors.push({ row: rowNum, name: row.full_name, reason });
      } else {
        importResult.accepted++;
      }
    }

    setLoading(false);
    setResult(importResult);

    if (importResult.accepted > 0) {
      toast.success(`تم استيراد ${importResult.accepted} متطوع بنجاح`);
      onComplete();
    }
    if (importResult.rejected > 0) {
      toast.warning(`تم رفض ${importResult.rejected} سجل`);
    }
  };

  const resetState = () => {
    setResult(null);
    setParsedRows([]);
    setParseError(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetState(); }}>
      <DialogTrigger asChild>
        <Button variant="outline"><Upload className="h-4 w-4 ml-2" />استيراد متطوعين</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg" dir="rtl">
        <DialogHeader><DialogTitle>استيراد قائمة متطوعين</DialogTitle></DialogHeader>

        {!result ? (
          <div className="space-y-4">
            <div className="bg-muted/50 rounded-lg p-4 text-sm space-y-2">
              <p className="font-semibold text-foreground">الأعمدة المطلوبة:</p>
              <ul className="list-disc list-inside text-muted-foreground text-xs space-y-1">
                <li><span className="font-medium text-foreground">الاسم الكامل</span> (مطلوب)</li>
                <li><span className="font-medium text-foreground">رقم الجوال</span> (مطلوب)</li>
                <li><span className="font-medium text-foreground">رقم الهوية</span> (مطلوب)</li>
                <li><span className="font-medium text-foreground">البريد الإلكتروني</span> (اختياري)</li>
                <li><span className="font-medium text-foreground">المدينة</span> (اختياري)</li>
              </ul>
              <p className="text-xs text-muted-foreground">يدعم ملفات CSV مفصولة بفاصلة أو فاصلة منقوطة أو Tab</p>
              <Button variant="link" size="sm" className="p-0 h-auto text-primary" onClick={downloadTemplate}>
                <Download className="h-3.5 w-3.5 ml-1" />تحميل قالب CSV
              </Button>
            </div>

            <div>
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.txt,.tsv"
                onChange={handleFileChange}
                className="block w-full text-sm file:ml-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-primary file:text-primary-foreground hover:file:bg-primary/90 cursor-pointer"
              />
            </div>

            {parseError && (
              <div className="bg-destructive/10 rounded-lg p-3 text-sm flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                <p className="text-destructive text-xs">{parseError}</p>
              </div>
            )}

            {parsedRows.length > 0 && (
              <div className="bg-muted/30 rounded-lg p-3 text-sm space-y-2">
                <p className="text-foreground font-medium flex items-center gap-1.5">
                  <FileSpreadsheet className="h-4 w-4 text-primary" />
                  تم قراءة {parsedRows.length} سجل
                </p>
                {/* Preview first 3 rows */}
                <div className="max-h-32 overflow-auto border rounded text-xs">
                  <table className="w-full">
                    <thead className="bg-muted sticky top-0">
                      <tr>
                        <th className="p-1.5 text-right">الاسم</th>
                        <th className="p-1.5 text-right">الجوال</th>
                        <th className="p-1.5 text-right">الهوية</th>
                        <th className="p-1.5 text-right">المدينة</th>
                      </tr>
                    </thead>
                    <tbody>
                      {parsedRows.slice(0, 3).map((r, i) => (
                        <tr key={i} className="border-t">
                          <td className="p-1.5">{r.full_name || "—"}</td>
                          <td className="p-1.5" dir="ltr">{r.mobile || "—"}</td>
                          <td className="p-1.5" dir="ltr">{r.national_id || "—"}</td>
                          <td className="p-1.5">{r.city || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-muted-foreground">سيتم فحص التكرار تلقائيًا قبل الإدخال</p>
              </div>
            )}

            <DialogFooter>
              <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
              <Button onClick={handleImport} disabled={loading || parsedRows.length === 0}>
                {loading ? "جارٍ الاستيراد..." : "بدء الاستيراد"}
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-4 text-center">
                <CheckCircle className="h-6 w-6 mx-auto text-green-600 mb-1" />
                <p className="text-2xl font-bold text-green-700 dark:text-green-400">{result.accepted}</p>
                <p className="text-xs text-green-600">تم استيرادهم بنجاح</p>
              </div>
              <div className="bg-red-50 dark:bg-red-950/20 rounded-lg p-4 text-center">
                <XCircle className="h-6 w-6 mx-auto text-red-500 mb-1" />
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">{result.rejected}</p>
                <p className="text-xs text-red-500">تم رفضهم</p>
              </div>
            </div>

            {result.errors.length > 0 && (
              <div className="max-h-48 overflow-y-auto border rounded-lg">
                <table className="w-full text-xs">
                  <thead className="bg-muted sticky top-0">
                    <tr>
                      <th className="p-2 text-right">الصف</th>
                      <th className="p-2 text-right">الاسم</th>
                      <th className="p-2 text-right">السبب</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.errors.map((err, i) => (
                      <tr key={i} className="border-t">
                        <td className="p-2">{err.row}</td>
                        <td className="p-2">{err.name || "—"}</td>
                        <td className="p-2 text-destructive">{err.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <DialogFooter>
              <Button onClick={() => { setOpen(false); resetState(); }}>إغلاق</Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
