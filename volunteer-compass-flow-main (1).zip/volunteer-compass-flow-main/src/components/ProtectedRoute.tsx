import { Navigate } from "react-router-dom";
import { useRole } from "@/contexts/RoleContext";

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: string[];
}

const ProtectedRoute = ({ children, allowedRoles }: ProtectedRouteProps) => {
  const { session, role, loading, recoveryMode } = useRole();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground text-sm">جارٍ التحميل...</p>
      </div>
    );
  }

  // Force password reset before allowing access to any protected page.
  if (recoveryMode) {
    return <Navigate to="/reset-password" replace />;
  }

  if (!session) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(role)) {
    // Redirect volunteer to their portal, internal to admin
    if (role === "volunteer") {
      return <Navigate to="/volunteer" replace />;
    }
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
