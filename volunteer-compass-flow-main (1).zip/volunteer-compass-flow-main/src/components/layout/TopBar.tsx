import { Menu, User, LogOut } from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import { useBranding } from "@/hooks/use-branding";
import NotificationBell from "@/components/NotificationBell";

const roleLabels: Record<string, string> = { director: "مدير الجهة", supervisor: "مشرف", observer: "مراقب" };

interface TopBarProps {
  onToggleSidebar: () => void;
}

export const TopBar = ({ onToggleSidebar }: TopBarProps) => {
  const { role, setRole, userName, logout } = useRole();
  const { platform_name } = useBranding();

  return (
    <header className="sticky top-0 z-20 bg-card/95 backdrop-blur-sm border-b border-border px-4 md:px-6 py-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors"
        >
          <Menu className="h-5 w-5 text-foreground" />
        </button>
        <h2 className="text-base md:text-lg font-bold text-foreground">{platform_name}</h2>
      </div>
      <div className="flex items-center gap-2">
        {/* Role indicator — shows current role from auth */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/5 border border-primary/10">
          <User className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-foreground hidden sm:inline">
            {userName || roleLabels[role] || role}
          </span>
          <span className="text-xs text-muted-foreground hidden md:inline">
            ({roleLabels[role]})
          </span>
        </div>
        <NotificationBell />
        <button
          onClick={logout}
          className="p-2 rounded-lg hover:bg-muted transition-colors"
          title="تسجيل الخروج"
        >
          <LogOut className="h-[18px] w-[18px] text-muted-foreground" />
        </button>
      </div>
    </header>
  );
};
