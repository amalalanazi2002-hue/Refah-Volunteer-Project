import { useState } from "react";
import { Outlet, NavLink } from "react-router-dom";
import { User, ClipboardList, FileCheck, Clock, LogOut, X, Menu, CalendarCheck, Bell, TicketCheck, Award } from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import NotificationBell from "@/components/NotificationBell";
import logo from "@/assets/logo.png";

const navItems = [
  { to: "/volunteer", label: "ملفي", icon: User },
  { to: "/volunteer/opportunities", label: "الفرص المتاحة", icon: CalendarCheck },
  { to: "/volunteer/participations", label: "مشاركاتي", icon: ClipboardList },
  { to: "/volunteer/proofs", label: "إثباتاتي", icon: FileCheck },
  { to: "/volunteer/hours", label: "ساعاتي", icon: Clock },
  { to: "/volunteer/certificates", label: "شهاداتي", icon: Award },
  { to: "/volunteer/tickets", label: "تذاكر الدعم", icon: TicketCheck },
  { to: "/volunteer/notifications", label: "التنبيهات", icon: Bell },
];

const VolunteerLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { userName, logout } = useRole();

  return (
    <div className="flex min-h-screen bg-background">
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-foreground/30 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <aside className={`fixed top-0 right-0 z-40 h-full w-64 bg-sidebar text-sidebar-foreground flex flex-col transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "translate-x-full"} lg:translate-x-0`}>
        <div className="flex items-center justify-between p-5 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <img src={logo} alt="رفادة" className="h-9 w-9 rounded-lg bg-sidebar-foreground/10 object-contain p-1" />
            <div>
              <h1 className="text-sm font-bold leading-tight">بوابة المتطوع</h1>
              <p className="text-[11px] opacity-60">{userName || "متطوع"}</p>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-1.5 rounded-lg hover:bg-sidebar-accent transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 py-3 overflow-y-auto scrollbar-thin">
          <ul className="space-y-0.5 px-3">
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  end={item.to === "/volunteer"}
                  onClick={() => setSidebarOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      isActive ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm" : "hover:bg-sidebar-accent/50 text-sidebar-foreground/75"
                    }`
                  }
                >
                  <item.icon className="h-[18px] w-[18px] shrink-0" />
                  <span>{item.label}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-3 border-t border-sidebar-border">
          <button onClick={logout} className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-medium text-sidebar-foreground/75 hover:bg-sidebar-accent/50 transition-colors">
            <LogOut className="h-[18px] w-[18px] shrink-0" />
            <span>تسجيل الخروج</span>
          </button>
        </div>

        <div className="p-4 border-t border-sidebar-border text-[11px] opacity-50 text-center">
          جمعية رفاه للأرامل والمطلقات
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-h-screen lg:mr-64">
        <header className="sticky top-0 z-20 bg-card/95 backdrop-blur-sm border-b border-border px-4 md:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors">
              <Menu className="h-5 w-5 text-foreground" />
            </button>
            <h2 className="text-base md:text-lg font-bold text-foreground">بوابة المتطوع</h2>
          </div>
          <div className="flex items-center gap-2">
            <NotificationBell />
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/5 border border-primary/10">
              <User className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground hidden sm:inline">{userName || "متطوع"}</span>
            </div>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default VolunteerLayout;
