import { useEffect, useState } from "react";
import { Paperclip, ImageIcon, Download, FileText, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fetchAttachmentsForMessages, getAttachmentUrl, isImageAttachment, TicketAttachment } from "@/lib/ticket-attachments";

interface Props {
  messageIds: string[];
  // Optional: refresh trigger when a new message is sent
  refreshKey?: number;
}

// Map from message_id -> attachments
export function useMessageAttachments(messageIds: string[], refreshKey = 0) {
  const [map, setMap] = useState<Record<string, TicketAttachment[]>>({});
  useEffect(() => {
    let cancelled = false;
    if (messageIds.length === 0) { setMap({}); return; }
    fetchAttachmentsForMessages(messageIds).then(res => { if (!cancelled) setMap(res); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messageIds.join("|"), refreshKey]);
  return map;
}

export function MessageAttachments({ items }: { items: TicketAttachment[] }) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewName, setPreviewName] = useState<string>("");

  if (!items?.length) return null;

  const open = async (att: TicketAttachment, download = false) => {
    const url = await getAttachmentUrl(att.file_path, download);
    if (!url) return;
    if (download) {
      const a = document.createElement("a");
      a.href = url; a.download = att.file_name || "attachment";
      document.body.appendChild(a); a.click(); a.remove();
    } else if (isImageAttachment(att)) {
      setPreviewUrl(url); setPreviewName(att.file_name);
    } else {
      window.open(url, "_blank", "noopener");
    }
  };

  return (
    <>
      <div className="mt-2 flex flex-wrap gap-2">
        {items.map(att => (
          <div key={att.id} className="flex items-center gap-1.5 rounded-md border border-border bg-background/60 px-2 py-1 text-xs">
            {isImageAttachment(att)
              ? <ImageIcon className="h-3.5 w-3.5 text-primary" />
              : <FileText className="h-3.5 w-3.5 text-primary" />}
            <button type="button" className="hover:underline truncate max-w-[160px]" onClick={() => open(att, false)} title={att.file_name}>
              {att.file_name}
            </button>
            <button type="button" className="text-muted-foreground hover:text-foreground" onClick={() => open(att, true)} title="تنزيل">
              <Download className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>

      {previewUrl && (
        <div className="fixed inset-0 z-[60] bg-black/80 flex flex-col items-center justify-center p-4" onClick={() => setPreviewUrl(null)}>
          <div className="absolute top-3 right-3 flex gap-2">
            <Button size="sm" variant="secondary" onClick={(e) => { e.stopPropagation(); setPreviewUrl(null); }}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <img src={previewUrl} alt={previewName} className="max-h-[85vh] max-w-[95vw] rounded shadow-lg" onClick={e => e.stopPropagation()} />
          <p className="mt-2 text-xs text-white/80">{previewName}</p>
        </div>
      )}
    </>
  );
}

export function AttachmentPickerButton({
  selectedFile,
  onSelect,
  onClear,
  disabled,
}: {
  selectedFile: File | null;
  onSelect: (f: File) => void;
  onClear: () => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center gap-2">
      <label className={`inline-flex items-center justify-center h-9 w-9 rounded-md border border-input bg-background hover:bg-accent cursor-pointer ${disabled ? "opacity-50 pointer-events-none" : ""}`} title="إرفاق ملف">
        <Paperclip className="h-4 w-4 text-muted-foreground" />
        <input type="file" className="hidden" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
          onChange={e => {
            const f = e.target.files?.[0];
            if (f) onSelect(f);
            e.target.value = "";
          }}
        />
      </label>
      {selectedFile && (
        <div className="flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs bg-muted/40 max-w-[180px]">
          <span className="truncate" title={selectedFile.name}>{selectedFile.name}</span>
          <button type="button" onClick={onClear} className="text-muted-foreground hover:text-destructive">
            <X className="h-3 w-3" />
          </button>
        </div>
      )}
    </div>
  );
}
