import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://zrvzxlpokekenneiovvt.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Xy6ZNvZT-uYzkm8QQjG47Q_0C9n5k8K';

// IMPORTANT: capture recovery flag BEFORE createClient runs.
// supabase-js processes the URL hash on construction and strips
// `type=recovery` away. If we don't snapshot it first, RoleContext
// will mount with a cleaned URL and miss the recovery flow,
// allowing the user to be auto-routed into the dashboard.
if (typeof window !== 'undefined') {
  try {
    const h = window.location.hash || '';
    const q = window.location.search || '';
    if (h.includes('type=recovery') || q.includes('type=recovery')) {
      (window as unknown as { __isRecoveryFlow?: boolean }).__isRecoveryFlow = true;
    }
  } catch { /* noop */ }
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
