export interface Database {
  public: {
    Tables: {
      volunteers: {
        Row: {
          id: string;
          full_name: string;
          mobile: string;
          national_id: string;
          city: string | null;
          email: string | null;
          auth_id: string | null;
          status: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['volunteers']['Row']> & {
          full_name: string;
          mobile: string;
          national_id: string;
        };
        Update: Partial<Database['public']['Tables']['volunteers']['Row']>;
      };
      internal_users: {
        Row: {
          id: string;
          full_name: string;
          mobile: string | null;
          email: string | null;
          role: string;
          status: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['internal_users']['Row']> & {
          id: string;
          full_name: string;
          role: string;
        };
        Update: Partial<Database['public']['Tables']['internal_users']['Row']>;
      };
      departments: {
        Row: {
          id: string;
          name: string;
          code: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: Partial<Database['public']['Tables']['departments']['Row']> & {
          name: string;
        };
        Update: Partial<Database['public']['Tables']['departments']['Row']>;
      };
      opportunities: {
        Row: {
          id: string;
          title: string;
          department_id: string;
          supervisor_id: string | null;
          start_at: string | null;
          end_at: string | null;
          minimum_hours: number;
          status: string;
          participant_count: number;
          capacity: number;
          is_public_visible: boolean;
          review_type: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['opportunities']['Row']> & {
          title: string;
          department_id: string;
        };
        Update: Partial<Database['public']['Tables']['opportunities']['Row']>;
      };
      participations: {
        Row: {
          id: string;
          volunteer_id: string;
          opportunity_id: string;
          started_at: string | null;
          ended_at: string | null;
          total_minutes: number;
          proof_status: string;
          approval_status: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['participations']['Row']> & {
          volunteer_id: string;
          opportunity_id: string;
        };
        Update: Partial<Database['public']['Tables']['participations']['Row']>;
      };
      proofs: {
        Row: {
          id: string;
          participation_id: string;
          volunteer_id: string;
          file_path: string | null;
          file_name: string | null;
          file_type: string | null;
          uploaded_at: string;
          review_status: string;
          reviewer_notes: string | null;
        };
        Insert: Partial<Database['public']['Tables']['proofs']['Row']> & {
          participation_id: string;
          volunteer_id: string;
        };
        Update: Partial<Database['public']['Tables']['proofs']['Row']>;
      };
      volunteer_hours: {
        Row: {
          id: string;
          volunteer_id: string;
          participation_id: string | null;
          opportunity_id: string | null;
          approved_hours: number;
          approval_date: string | null;
          status: string;
          created_at: string;
        };
        Insert: Partial<Database['public']['Tables']['volunteer_hours']['Row']> & {
          volunteer_id: string;
        };
        Update: Partial<Database['public']['Tables']['volunteer_hours']['Row']>;
      };
      notifications: {
        Row: {
          id: string;
          user_type: string;
          user_id: string;
          title: string;
          message: string;
          type: string;
          related_entity_type: string | null;
          related_entity_id: string | null;
          is_read: boolean;
          created_at: string;
          action_url: string | null;
          action_label: string | null;
          requires_action: boolean;
          read_at: string | null;
          action_type: string | null;
        };
        Insert: Partial<Database['public']['Tables']['notifications']['Row']> & {
          user_type: string;
          user_id: string;
          title: string;
          message: string;
          type: string;
        };
        Update: Partial<Database['public']['Tables']['notifications']['Row']>;
      };
      opportunity_applications: {
        Row: {
          id: string;
          volunteer_id: string;
          opportunity_id: string;
          status: string;
          created_at: string;
          reviewed_by: string | null;
          reviewed_at: string | null;
          review_note: string | null;
        };
        Insert: Partial<Database['public']['Tables']['opportunity_applications']['Row']> & {
          volunteer_id: string;
          opportunity_id: string;
        };
        Update: Partial<Database['public']['Tables']['opportunity_applications']['Row']>;
      };
      system_settings: {
        Row: {
          id: string;
          key: string;
          value: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['system_settings']['Row']> & {
          key: string;
          value: string;
        };
        Update: Partial<Database['public']['Tables']['system_settings']['Row']>;
      };
      badge_levels: {
        Row: {
          id: string;
          name: string;
          icon: string;
          min_hours: number;
          sort_order: number;
          created_at: string;
        };
        Insert: Partial<Database['public']['Tables']['badge_levels']['Row']> & {
          name: string;
          min_hours: number;
        };
        Update: Partial<Database['public']['Tables']['badge_levels']['Row']>;
      };
      volunteer_registrations: {
        Row: {
          id: string;
          full_name: string;
          mobile: string;
          email: string | null;
          national_id: string;
          city: string | null;
          status: string;
          review_note: string | null;
          reviewed_by: string | null;
          reviewed_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['volunteer_registrations']['Row']> & {
          full_name: string;
          mobile: string;
          national_id: string;
        };
        Update: Partial<Database['public']['Tables']['volunteer_registrations']['Row']>;
      };
    };
  };
}

export type Volunteer = Database['public']['Tables']['volunteers']['Row'];
export type InternalUser = Database['public']['Tables']['internal_users']['Row'];
export type Department = Database['public']['Tables']['departments']['Row'];
export type Opportunity = Database['public']['Tables']['opportunities']['Row'];
export type Participation = Database['public']['Tables']['participations']['Row'];
export type Proof = Database['public']['Tables']['proofs']['Row'];
export type VolunteerHour = Database['public']['Tables']['volunteer_hours']['Row'];
export type BadgeLevel = Database['public']['Tables']['badge_levels']['Row'];
export type SystemSetting = Database['public']['Tables']['system_settings']['Row'];
export type VolunteerRegistration = Database['public']['Tables']['volunteer_registrations']['Row'];
