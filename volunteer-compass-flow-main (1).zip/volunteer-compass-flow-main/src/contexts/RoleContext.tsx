import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";

type Role = "director" | "observer" | "supervisor" | "volunteer";

interface RoleContextType {
  role: Role;
  setRole: (role: Role) => void;
  userId: string | null;
  volunteerId: string | null;
  userName: string | null;
  session: Session | null;
  authUser: User | null;
  canReview: boolean;
  canManage: boolean;
  isVolunteer: boolean;
  isInternal: boolean;
  loading: boolean;
  recoveryMode: boolean;
  clearRecoveryMode: () => void;
  logout: () => Promise<void>;
}

const RoleContext = createContext<RoleContextType>({
  role: "director",
  setRole: () => {},
  userId: null,
  volunteerId: null,
  userName: null,
  session: null,
  authUser: null,
  canReview: true,
  canManage: true,
  isVolunteer: false,
  isInternal: true,
  loading: true,
  recoveryMode: false,
  clearRecoveryMode: () => {},
  logout: async () => {},
});

export const useRole = () => useContext(RoleContext);

export const RoleProvider = ({ children }: { children: ReactNode }) => {
  const [role, setRoleState] = useState<Role>("director");
  const [userId, setUserId] = useState<string | null>(null);
  const [volunteerId, setVolunteerId] = useState<string | null>(null);
  const [userName, setUserName] = useState<string | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  // Detect recovery flow as early as possible — the URL hash from the email
  // link contains type=recovery BEFORE the SDK fires PASSWORD_RECOVERY. This
  // prevents a brief window where the app could route the user into the
  // dashboard before the event handler runs.
  const [recoveryMode, setRecoveryMode] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    const h = window.location.hash || "";
    const q = window.location.search || "";
    const flagged = (window as unknown as { __isRecoveryFlow?: boolean }).__isRecoveryFlow === true;
    const onResetPath = window.location.pathname === "/reset-password";
    return flagged || onResetPath || h.includes("type=recovery") || q.includes("type=recovery");
  });

  const resolveRole = async (user: User) => {
    const email = user.email;
    if (!email) {
      setLoading(false);
      return;
    }

    // Check internal_users first
    const { data: internalUser } = await supabase
      .from("internal_users")
      .select("id, full_name, role")
      .eq("email", email)
      .eq("status", "active")
      .limit(1)
      .single();

    if (internalUser) {
      setRoleState(internalUser.role as Role);
      setUserId(internalUser.id);
      setUserName(internalUser.full_name);
      setVolunteerId(null);
      setLoading(false);
      return;
    }

    // Check volunteers
    const { data: volunteer } = await supabase
      .from("volunteers")
      .select("id, full_name")
      .eq("email", email)
      .eq("status", "active")
      .limit(1)
      .single();

    if (volunteer) {
      setRoleState("volunteer");
      setUserId(null);
      setVolunteerId(volunteer.id);
      setUserName(volunteer.full_name);
      setLoading(false);
      return;
    }

    // Unknown user — default to volunteer with no data
    setRoleState("volunteer");
    setUserName(email);
    setLoading(false);
  };

  useEffect(() => {
    // Listen to auth changes FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      // When the user clicks a recovery link, Supabase fires PASSWORD_RECOVERY
      // and creates a session. We MUST NOT let the app route them into the
      // dashboard — flag recovery mode so the route guard forces /reset-password.
      if (event === "PASSWORD_RECOVERY") {
        setRecoveryMode(true);
      }
      setSession(session);
      setAuthUser(session?.user ?? null);
      if (session?.user) {
        // Use setTimeout to avoid Supabase deadlock
        setTimeout(() => resolveRole(session.user), 0);
      } else {
        setRoleState("director");
        setUserId(null);
        setVolunteerId(null);
        setUserName(null);
        setLoading(false);
      }
    });

    // Then check existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setAuthUser(session?.user ?? null);
      if (session?.user) {
        resolveRole(session.user);
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const setRole = (r: Role) => {
    // Only allow manual role switching for development
    setRoleState(r);
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setAuthUser(null);
    setUserId(null);
    setVolunteerId(null);
    setUserName(null);
    setRoleState("director");
  };

  const canReview = role === "director" || role === "supervisor" || role === "observer";
  const canManage = role === "director" || role === "supervisor";
  const isVolunteer = role === "volunteer";
  const isInternal = !isVolunteer;

  return (
    <RoleContext.Provider value={{
      role, setRole, userId, volunteerId, userName,
      session, authUser, canReview, canManage,
      isVolunteer, isInternal, loading,
      recoveryMode, clearRecoveryMode: () => setRecoveryMode(false),
      logout,
    }}>
      {children}
    </RoleContext.Provider>
  );
};
