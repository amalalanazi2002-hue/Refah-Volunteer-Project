-- ============================================
-- Migration: Operations Improvements
-- ============================================

-- 1) Add new columns to opportunities
ALTER TABLE opportunities ADD COLUMN IF NOT EXISTS capacity integer DEFAULT 0;
ALTER TABLE opportunities ADD COLUMN IF NOT EXISTS is_public_visible boolean DEFAULT true;
ALTER TABLE opportunities ADD COLUMN IF NOT EXISTS review_type text DEFAULT 'assigned_supervisor' CHECK (review_type IN ('assigned_supervisor', 'any_supervisor'));

-- 2) Create volunteer_registrations table for public sign-ups
CREATE TABLE IF NOT EXISTS volunteer_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  mobile text NOT NULL,
  email text,
  national_id text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  review_note text,
  reviewed_by uuid REFERENCES internal_users(id),
  reviewed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Index
CREATE INDEX IF NOT EXISTS idx_volunteer_registrations_status ON volunteer_registrations(status);

-- RLS
ALTER TABLE volunteer_registrations ENABLE ROW LEVEL SECURITY;

-- Allow anonymous inserts (public registration)
CREATE POLICY "Anyone can register" ON volunteer_registrations FOR INSERT WITH CHECK (true);

-- Only internal users can read
CREATE POLICY "Authenticated can read registrations" ON volunteer_registrations FOR SELECT TO authenticated USING (true);

-- Only internal users can update
CREATE POLICY "Authenticated can update registrations" ON volunteer_registrations FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
