-- ============================================================
-- Notifications: enforce per-recipient access at the DATABASE
-- level via RLS. Each notification row already represents ONE
-- recipient (user_type + user_id). This migration guarantees
-- that no client can read or mutate notifications belonging to
-- another user, regardless of UI filtering.
--
-- Safe to run multiple times (uses CREATE OR REPLACE / IF NOT EXISTS).
-- Does NOT touch volunteers, internal_users, opportunities, etc.
-- ============================================================

-- 1) Helper: resolve the current authenticated user into either
--    an internal_users.id or volunteers.id, based on email match.
--    SECURITY DEFINER avoids recursive RLS on the lookup tables.
CREATE OR REPLACE FUNCTION public.current_internal_user_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT iu.id
  FROM public.internal_users iu
  JOIN auth.users au ON lower(au.email) = lower(iu.email)
  WHERE au.id = auth.uid()
    AND iu.status = 'active'
  LIMIT 1
$$;

CREATE OR REPLACE FUNCTION public.current_volunteer_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT v.id
  FROM public.volunteers v
  JOIN auth.users au ON lower(au.email) = lower(v.email)
  WHERE au.id = auth.uid()
    AND v.status = 'active'
  LIMIT 1
$$;

-- 2) Enable RLS on notifications
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- 3) Drop any prior open policies so we can re-create cleanly
DROP POLICY IF EXISTS "Users can view their own notifications"   ON public.notifications;
DROP POLICY IF EXISTS "Users can update their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Internal users can insert notifications"  ON public.notifications;
DROP POLICY IF EXISTS "Users can delete their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "notifications_select_own"                 ON public.notifications;
DROP POLICY IF EXISTS "notifications_update_own"                 ON public.notifications;
DROP POLICY IF EXISTS "notifications_insert_internal"            ON public.notifications;
DROP POLICY IF EXISTS "notifications_insert_volunteer_replies"   ON public.notifications;
DROP POLICY IF EXISTS "notifications_delete_own"                 ON public.notifications;

-- 4) SELECT: a row is visible only to its actual recipient
CREATE POLICY "notifications_select_own"
ON public.notifications
FOR SELECT
TO authenticated
USING (
  (user_type = 'internal'  AND user_id = public.current_internal_user_id())
  OR
  (user_type = 'volunteer' AND user_id = public.current_volunteer_id())
);

-- 5) UPDATE: only the recipient can mark their own row read / change read_at
CREATE POLICY "notifications_update_own"
ON public.notifications
FOR UPDATE
TO authenticated
USING (
  (user_type = 'internal'  AND user_id = public.current_internal_user_id())
  OR
  (user_type = 'volunteer' AND user_id = public.current_volunteer_id())
)
WITH CHECK (
  (user_type = 'internal'  AND user_id = public.current_internal_user_id())
  OR
  (user_type = 'volunteer' AND user_id = public.current_volunteer_id())
);

-- 6) INSERT: any authenticated user (internal OR volunteer) may create
--    notification rows. Internal users send broadcasts to many recipients;
--    volunteers send replies addressed to a single internal user.
--    Sensitive payload columns are bounded by the existing app code.
CREATE POLICY "notifications_insert_authenticated"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (
  public.current_internal_user_id() IS NOT NULL
  OR
  public.current_volunteer_id() IS NOT NULL
);

-- 7) DELETE: recipient only (kept restrictive; UI does not delete today)
CREATE POLICY "notifications_delete_own"
ON public.notifications
FOR DELETE
TO authenticated
USING (
  (user_type = 'internal'  AND user_id = public.current_internal_user_id())
  OR
  (user_type = 'volunteer' AND user_id = public.current_volunteer_id())
);

-- 8) Helpful indexes for the hot lookup paths (idempotent)
CREATE INDEX IF NOT EXISTS idx_notifications_recipient
  ON public.notifications (user_type, user_id, is_read, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_related_entity
  ON public.notifications (related_entity_type, related_entity_id);
