import { Button } from "@/components/ui/button";
import { FileSpreadsheet, FileText } from "lucide-react";
import { exportToExcel, exportToPDF } from "@/lib/export-utils";

interface ExportColumn {
  header: string;
  key: string;
}

interface ExportButtonsProps {
  data: Record<string, any>[];
  columns: ExportColumn[];
  title: string;
  filename: string;
}

export const ExportButtons = ({ data, columns, title, filename }: ExportButtonsProps) => {
  const dateStr = new Date().toISOString().split("T")[0];
  const fullFilename = `${filename}_${dateStr}`;

  return (
    <div className="flex gap-1.5 flex-wrap">
      <Button
        variant="outline"
        size="sm"
        onClick={() => exportToExcel(data, columns, fullFilename)}
        className="text-xs flex-1 sm:flex-none min-w-[88px]"
      >
        <FileSpreadsheet className="h-3.5 w-3.5 ml-1" />
        Excel
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={() => exportToPDF(data, columns, title, fullFilename)}
        className="text-xs flex-1 sm:flex-none min-w-[88px]"
      >
        <FileText className="h-3.5 w-3.5 ml-1" />
        PDF
      </Button>
    </div>
  );
};
