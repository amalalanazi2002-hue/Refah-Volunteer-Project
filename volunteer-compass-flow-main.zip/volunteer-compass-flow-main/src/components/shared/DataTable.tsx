import { CalendarCheck } from "lucide-react";

interface Column<T> {
  header: string;
  accessor: keyof T | ((row: T) => React.ReactNode);
  className?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (row: T) => void;
  emptyMessage?: string;
  emptyIcon?: React.ReactNode;
}

export function DataTable<T>({ columns, data, onRowClick, emptyMessage, emptyIcon }: DataTableProps<T>) {
  return (
    <div className="max-w-full rounded-lg border border-border bg-card">
      <div className="table-scroll-x" dir="ltr">
      <table className="w-full text-sm min-w-[640px]" dir="rtl">
        <thead>
          <tr className="bg-primary/5 border-b border-border">
            {columns.map((col, i) => (
              <th key={i} className={`px-3 sm:px-4 py-3 sm:py-3.5 text-right font-semibold text-foreground whitespace-nowrap text-xs ${col.className || ""}`}>
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="px-4 py-12 text-center">
                <div className="flex flex-col items-center gap-2">
                  {emptyIcon || <CalendarCheck className="h-10 w-10 text-muted-foreground/30" />}
                  <p className="text-sm text-muted-foreground">{emptyMessage || "لا توجد بيانات"}</p>
                </div>
              </td>
            </tr>
          ) : data.map((row, rowIndex) => (
            <tr
              key={rowIndex}
              onClick={() => onRowClick?.(row)}
              className={`border-t border-border hover:bg-muted/40 transition-colors ${onRowClick ? "cursor-pointer" : ""}`}
            >
              {columns.map((col, colIndex) => (
                <td key={colIndex} className={`px-3 sm:px-4 py-3 sm:py-3.5 text-right text-sm whitespace-nowrap ${col.className || ""}`}>
                  {typeof col.accessor === "function"
                    ? col.accessor(row)
                    : (row[col.accessor] as React.ReactNode)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
}
