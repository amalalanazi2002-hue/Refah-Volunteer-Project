interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}

export const PageHeader = ({ title, description, actions }: PageHeaderProps) => {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 mb-6 sm:mb-8">
      <div className="min-w-0">
        <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-foreground break-words">{title}</h1>
        {description && <p className="text-xs sm:text-sm text-muted-foreground mt-1 sm:mt-1.5 break-words">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2 sm:shrink-0 [&>*]:flex-1 sm:[&>*]:flex-none">{actions}</div>}
    </div>
  );
};
