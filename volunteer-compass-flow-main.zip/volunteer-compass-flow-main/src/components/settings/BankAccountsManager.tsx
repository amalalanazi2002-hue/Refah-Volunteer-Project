import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2, Eye, EyeOff, Landmark } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface BankAccount {
  id: string;
  bank_name: string;
  holder_name: string;
  account_number: string;
  iban: string;
  note?: string;
  active: boolean;
}

const MAX_ACCOUNTS = 5;
const SETTINGS_KEY = "bank_accounts";

const empty: BankAccount = {
  id: "",
  bank_name: "",
  holder_name: "",
  account_number: "",
  iban: "",
  note: "",
  active: true,
};

export const BankAccountsManager = () => {
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<BankAccount>(empty);
  const [isNew, setIsNew] = useState(true);

  const load = async () => {
    const { data } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", SETTINGS_KEY)
      .limit(1);
    const raw = data?.[0]?.value;
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setAccounts(parsed);
      } catch {
        setAccounts([]);
      }
    } else {
      setAccounts([]);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const persist = async (next: BankAccount[]) => {
    const value = JSON.stringify(next);
    const { data: existing } = await supabase
      .from("system_settings")
      .select("id")
      .eq("key", SETTINGS_KEY)
      .limit(1);
    if (existing && existing.length > 0) {
      await supabase.from("system_settings").update({ value }).eq("key", SETTINGS_KEY);
    } else {
      await supabase.from("system_settings").insert({ key: SETTINGS_KEY, value });
    }
    setAccounts(next);
  };

  const openAdd = () => {
    if (accounts.length >= MAX_ACCOUNTS) {
      toast.error(`الحد الأقصى ${MAX_ACCOUNTS} حسابات بنكية`);
      return;
    }
    setEditing({ ...empty, id: crypto.randomUUID() });
    setIsNew(true);
    setOpen(true);
  };

  const openEdit = (acc: BankAccount) => {
    setEditing({ ...acc });
    setIsNew(false);
    setOpen(true);
  };

  const save = async () => {
    if (!editing.bank_name.trim() || !editing.holder_name.trim() || !editing.account_number.trim() || !editing.iban.trim()) {
      toast.error("الرجاء تعبئة جميع الحقول المطلوبة");
      return;
    }
    let next: BankAccount[];
    if (isNew) {
      if (accounts.length >= MAX_ACCOUNTS) {
        toast.error(`الحد الأقصى ${MAX_ACCOUNTS} حسابات بنكية`);
        return;
      }
      next = [...accounts, editing];
    } else {
      next = accounts.map(a => (a.id === editing.id ? editing : a));
    }
    await persist(next);
    toast.success(isNew ? "تم إضافة الحساب البنكي" : "تم تحديث الحساب البنكي");
    setOpen(false);
  };

  const remove = async (id: string) => {
    await persist(accounts.filter(a => a.id !== id));
    toast.success("تم حذف الحساب");
  };

  const toggleActive = async (id: string) => {
    await persist(accounts.map(a => (a.id === id ? { ...a, active: !a.active } : a)));
  };

  const limitReached = accounts.length >= MAX_ACCOUNTS;

  return (
    <div className="bg-card rounded-lg border border-border p-5 md:p-6 space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="font-bold text-foreground flex items-center gap-2">
          <Landmark className="h-4 w-4 text-primary" />
          الحسابات البنكية
        </h3>
        <span className="text-xs text-muted-foreground">{accounts.length} / {MAX_ACCOUNTS}</span>
      </div>
      <Separator />

      {accounts.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center p-4">لا توجد حسابات بنكية بعد</p>
      ) : (
        <div className="space-y-2">
          {accounts.map(acc => (
            <div key={acc.id} className="flex items-start justify-between gap-3 p-3 bg-muted/60 rounded-lg flex-wrap">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm">{acc.bank_name}</span>
                  {acc.active ? (
                    <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full">مفعّل</span>
                  ) : (
                    <span className="text-[10px] bg-muted-foreground/15 text-muted-foreground px-2 py-0.5 rounded-full">مخفي</span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground mt-1">{acc.holder_name}</div>
                <div className="text-xs text-muted-foreground mt-0.5" dir="ltr">IBAN: {acc.iban}</div>
              </div>
              <div className="flex gap-1 shrink-0">
                <Button variant="ghost" size="sm" onClick={() => toggleActive(acc.id)} title={acc.active ? "إخفاء" : "تفعيل"}>
                  {acc.active ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </Button>
                <Button variant="ghost" size="sm" onClick={() => openEdit(acc)}>
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => remove(acc.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Button variant="outline" onClick={openAdd} disabled={limitReached}>
        <Plus className="h-4 w-4 ml-1" />
        {limitReached ? `تم بلوغ الحد الأقصى (${MAX_ACCOUNTS})` : "إضافة حساب بنكي"}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{isNew ? "إضافة حساب بنكي" : "تعديل الحساب البنكي"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>اسم البنك *</Label>
              <Input className="mt-1.5" value={editing.bank_name} onChange={e => setEditing({ ...editing, bank_name: e.target.value })} />
            </div>
            <div>
              <Label>اسم صاحب الحساب *</Label>
              <Input className="mt-1.5" value={editing.holder_name} onChange={e => setEditing({ ...editing, holder_name: e.target.value })} />
            </div>
            <div>
              <Label>رقم الحساب *</Label>
              <Input className="mt-1.5" dir="ltr" value={editing.account_number} onChange={e => setEditing({ ...editing, account_number: e.target.value })} />
            </div>
            <div>
              <Label>رقم الآيبان *</Label>
              <Input className="mt-1.5" dir="ltr" value={editing.iban} onChange={e => setEditing({ ...editing, iban: e.target.value.toUpperCase() })} />
            </div>
            <div>
              <Label>ملاحظة (اختياري)</Label>
              <Textarea className="mt-1.5" value={editing.note || ""} onChange={e => setEditing({ ...editing, note: e.target.value })} />
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={editing.active} onCheckedChange={v => setEditing({ ...editing, active: v })} />
              <Label>تفعيل وعرض الحساب في الصفحة العامة</Label>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={save}>حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
