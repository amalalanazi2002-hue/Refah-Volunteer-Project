import { useEffect, useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Sparkles, Plus, Trash2, Settings2, ArrowUp, ArrowDown, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import {
  PublicFeatures, defaultPublicFeatures, loadPublicFeatures, savePublicFeatures,
  FaqItem, TestimonialItem, SectionKey, DEFAULT_SECTION_ORDER, DEFAULT_SECTION_BG, DEFAULT_SECTION_FG, normalizeSectionOrder,
} from "@/lib/public-features";

type FeatureKey = keyof PublicFeatures;

interface FeatureMeta {
  key: FeatureKey;
  label: string;
  desc: string;
  hasContent?: boolean;
}

const groups: { title: string; items: FeatureMeta[] }[] = [
  {
    title: "مكوّنات تفاعلية",
    items: [
      { key: "counters", label: "عدّادات الإنجازات المتحركة", desc: "عرض إحصائيات حية مع تأثير العد التصاعدي + عنوان قابل للتخصيص", hasContent: true },
      { key: "qr_bank", label: "QR للحسابات البنكية", desc: "رمز QR لكل حساب لتسهيل التحويل من الجوال" },
      { key: "opp_filters", label: "بحث وفلترة الفرص", desc: "بحث فوري + فلترة حسب القسم والترتيب" },
      { key: "opp_quiz", label: "اختبار: أي فرصة تناسبك؟", desc: "أسئلة تفاعلية تقترح نوع التطوع المناسب" },
      { key: "impact_calc", label: "حاسبة أثر التطوع", desc: "احسب الأثر بناءً على المستوى وعدد الساعات والأيام", hasContent: true },
    ],
  },
  {
    title: "محتوى إضافي",
    items: [
      { key: "faq", label: "الأسئلة الشائعة (FAQ)", desc: "Accordion مع بحث فوري", hasContent: true },
      { key: "testimonials", label: "قصص المتطوعين", desc: "Carousel للشهادات والقصص الملهمة", hasContent: true },
      { key: "gallery", label: "معرض صور الفعاليات", desc: "شبكة صور مع معاينة كبيرة", hasContent: true },
      { key: "news_ticker", label: "شريط الإعلانات", desc: "نص متحرك أعلى الصفحة", hasContent: true },
      { key: "whatsapp", label: "زر واتساب عائم", desc: "زر تواصل سريع في أسفل الصفحة", hasContent: true },
    ],
  },
  {
    title: "تحسينات تجربة الاستخدام",
    items: [
      { key: "dark_mode", label: "زر الوضع الليلي", desc: "السماح للزائر بتبديل الوضع" },
      { key: "font_size", label: "تكبير/تصغير الخط (A- A+)", desc: "للمساعدة على القراءة" },
      { key: "back_to_top", label: "زر العودة للأعلى", desc: "يظهر بعد التمرير لأسفل" },
      { key: "scroll_progress", label: "شريط تقدّم القراءة", desc: "خط رفيع أعلى الصفحة يوضح موضعك" },
      { key: "smooth_scroll", label: "تمرير ناعم بين الأقسام", desc: "Smooth scroll behavior" },
      { key: "schema_seo", label: "Schema.org + Open Graph", desc: "تحسين الظهور في محركات البحث" },
      { key: "skeleton_loaders", label: "Skeleton أثناء التحميل", desc: "بدائل بصرية بدلًا من spinner" },
      { key: "lazy_images", label: "تحميل الصور الكسول", desc: "Lazy loading لجميع الصور" },
    ],
  },
];

export const PublicFeaturesManager = () => {
  const [features, setFeatures] = useState<PublicFeatures>(defaultPublicFeatures);
  const [loaded, setLoaded] = useState(false);
  const [contentOpen, setContentOpen] = useState<FeatureKey | null>(null);

  useEffect(() => { loadPublicFeatures().then(f => { setFeatures(f); setLoaded(true); }); }, []);

  const persist = async (next: PublicFeatures) => {
    setFeatures(next);
    await savePublicFeatures(next);
  };

  const toggle = async (key: FeatureKey, v: boolean) => {
    const next = { ...features, [key]: { ...(features[key] as any), enabled: v } };
    await persist(next);
    toast.success(v ? "تم التفعيل" : "تم الإخفاء");
  };

  if (!loaded) return null;

  return (
    <div className="bg-card rounded-lg border border-border p-5 md:p-6 space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="font-bold text-foreground flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          ميزات الصفحة العامة
        </h3>
        <span className="text-xs text-muted-foreground">تحكّم بكل ميزة على حدة</span>
      </div>
      <Separator />

      <Tabs defaultValue="0">
        <TabsList className="w-full justify-start flex-wrap h-auto gap-1">
          {groups.map((g, i) => <TabsTrigger key={i} value={String(i)}>{g.title}</TabsTrigger>)}
          <TabsTrigger value="order">ترتيب الأقسام</TabsTrigger>
          <TabsTrigger value="bg">ألوان الأقسام</TabsTrigger>
        </TabsList>
        {groups.map((g, i) => (
          <TabsContent key={i} value={String(i)} className="space-y-2 mt-4">
            {g.items.map(it => {
              const f: any = features[it.key];
              return (
                <div key={it.key} className="flex items-start justify-between gap-3 p-3 bg-muted/40 rounded-lg flex-wrap">
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-sm">{it.label}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{it.desc}</div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {it.hasContent && (
                      <Button variant="outline" size="sm" onClick={() => setContentOpen(it.key)}>
                        <Settings2 className="h-3.5 w-3.5 ml-1" />إدارة المحتوى
                      </Button>
                    )}
                    <Switch checked={!!f?.enabled} onCheckedChange={v => toggle(it.key, v)} />
                  </div>
                </div>
              );
            })}
          </TabsContent>
        ))}
        <TabsContent value="order" className="space-y-2 mt-4">
          <SectionOrderEditor features={features} onSave={persist} />
        </TabsContent>
        <TabsContent value="bg" className="space-y-2 mt-4">
          <SectionBgEditor features={features} onSave={persist} />
        </TabsContent>
      </Tabs>

      <ContentDialogs openKey={contentOpen} onClose={() => setContentOpen(null)} features={features} onSave={persist} />
    </div>
  );
};

// ===== Content management dialogs =====
const ContentDialogs = ({ openKey, onClose, features, onSave }: {
  openKey: FeatureKey | null; onClose: () => void; features: PublicFeatures;
  onSave: (next: PublicFeatures) => Promise<void>;
}) => {
  return (
    <>
      <FaqDialog open={openKey === "faq"} onClose={onClose} items={features.faq.items}
        onSave={async items => { await onSave({ ...features, faq: { ...features.faq, items } }); toast.success("تم الحفظ"); onClose(); }} />
      <TestimonialsDialog open={openKey === "testimonials"} onClose={onClose} items={features.testimonials.items}
        onSave={async items => { await onSave({ ...features, testimonials: { ...features.testimonials, items } }); toast.success("تم الحفظ"); onClose(); }} />
      <GalleryDialog open={openKey === "gallery"} onClose={onClose} images={features.gallery.images}
        onSave={async images => { await onSave({ ...features, gallery: { ...features.gallery, images } }); toast.success("تم الحفظ"); onClose(); }} />
      <NewsDialog open={openKey === "news_ticker"} onClose={onClose} text={features.news_ticker.text}
        onSave={async text => { await onSave({ ...features, news_ticker: { ...features.news_ticker, text } }); toast.success("تم الحفظ"); onClose(); }} />
      <WhatsappDialog open={openKey === "whatsapp"} onClose={onClose} number={features.whatsapp.number}
        onSave={async number => { await onSave({ ...features, whatsapp: { ...features.whatsapp, number } }); toast.success("تم الحفظ"); onClose(); }} />
      <CountersTitleDialog open={openKey === "counters"} onClose={onClose} title={features.counters.title || ""}
        onSave={async title => { await onSave({ ...features, counters: { ...features.counters, title } }); toast.success("تم الحفظ"); onClose(); }} />
      <ImpactRatesDialog open={openKey === "impact_calc"} onClose={onClose} features={features}
        onSave={async (g, s, p) => { await onSave({ ...features, impact_calc: { ...features.impact_calc, rate_general: g, rate_skilled: s, rate_professional: p } }); toast.success("تم الحفظ"); onClose(); }} />
    </>
  );
};

const ImpactRatesDialog = ({ open, onClose, features, onSave }: { open: boolean; onClose: () => void; features: PublicFeatures; onSave: (g: number, s: number, p: number) => Promise<void> }) => {
  const [g, setG] = useState<number>(features.impact_calc.rate_general ?? 30);
  const [s, setS] = useState<number>(features.impact_calc.rate_skilled ?? 60);
  const [p, setP] = useState<number>(features.impact_calc.rate_professional ?? 100);
  useEffect(() => {
    if (open) {
      setG(features.impact_calc.rate_general ?? 30);
      setS(features.impact_calc.rate_skilled ?? 60);
      setP(features.impact_calc.rate_professional ?? 100);
    }
  }, [open, features]);
  return (
    <Dialog open={open} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader><DialogTitle>قيمة الساعة لكل مستوى تطوع</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>عام (ر.س / ساعة)</Label>
            <Input type="number" min={0} value={g} onChange={e => setG(Math.max(0, Number(e.target.value) || 0))} />
          </div>
          <div>
            <Label>مهاري (ر.س / ساعة)</Label>
            <Input type="number" min={0} value={s} onChange={e => setS(Math.max(0, Number(e.target.value) || 0))} />
          </div>
          <div>
            <Label>احترافي (ر.س / ساعة)</Label>
            <Input type="number" min={0} value={p} onChange={e => setP(Math.max(0, Number(e.target.value) || 0))} />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
          <Button onClick={() => onSave(g, s, p)}>حفظ</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const FaqDialog = ({ open, onClose, items, onSave }: { open: boolean; onClose: () => void; items: FaqItem[]; onSave: (i: FaqItem[]) => Promise<void> }) => {
  const [list, setList] = useState<FaqItem[]>(items);
  useEffect(() => { if (open) setList(items); }, [open, items]);
  const add = () => setList(p => [...p, { q: "", a: "" }]);
  const remove = (i: number) => setList(p => p.filter((_, k) => k !== i));
  const update = (i: number, k: "q" | "a", v: string) => setList(p => p.map((it, k2) => k2 === i ? { ...it, [k]: v } : it));
  return (
    <Dialog open={open} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader><DialogTitle>إدارة الأسئلة الشائعة</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {list.map((it, i) => (
            <div key={i} className="p-3 bg-muted/40 rounded-lg space-y-2 relative">
              <Input placeholder="السؤال" value={it.q} onChange={e => update(i, "q", e.target.value)} />
              <Textarea placeholder="الإجابة" value={it.a} onChange={e => update(i, "a", e.target.value)} />
              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => remove(i)}><Trash2 className="h-3.5 w-3.5 ml-1" />حذف</Button>
            </div>
          ))}
          <Button variant="outline" onClick={add}><Plus className="h-4 w-4 ml-1" />إضافة سؤال</Button>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
          <Button onClick={() => onSave(list.filter(it => it.q.trim() && it.a.trim()))}>حفظ</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const TestimonialsDialog = ({ open, onClose, items, onSave }: { open: boolean; onClose: () => void; items: TestimonialItem[]; onSave: (i: TestimonialItem[]) => Promise<void> }) => {
  const [list, setList] = useState<TestimonialItem[]>(items);
  useEffect(() => { if (open) setList(items); }, [open, items]);
  const add = () => setList(p => [...p, { name: "", text: "", role: "", image: "" }]);
  const remove = (i: number) => setList(p => p.filter((_, k) => k !== i));
  const update = (i: number, k: keyof TestimonialItem, v: string) => setList(p => p.map((it, k2) => k2 === i ? { ...it, [k]: v } : it));
  return (
    <Dialog open={open} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader><DialogTitle>إدارة قصص المتطوعين</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {list.map((it, i) => (
            <div key={i} className="p-3 bg-muted/40 rounded-lg space-y-2">
              <Input placeholder="الاسم" value={it.name} onChange={e => update(i, "name", e.target.value)} />
              <Input placeholder="الدور (اختياري)" value={it.role || ""} onChange={e => update(i, "role", e.target.value)} />
              <Textarea placeholder="نص القصة" value={it.text} onChange={e => update(i, "text", e.target.value)} />
              <Input placeholder="رابط الصورة (اختياري)" value={it.image || ""} onChange={e => update(i, "image", e.target.value)} dir="ltr" />
              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => remove(i)}><Trash2 className="h-3.5 w-3.5 ml-1" />حذف</Button>
            </div>
          ))}
          <Button variant="outline" onClick={add}><Plus className="h-4 w-4 ml-1" />إضافة قصة</Button>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
          <Button onClick={() => onSave(list.filter(it => it.name.trim() && it.text.trim()))}>حفظ</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const GalleryDialog = ({ open, onClose, images, onSave }: { open: boolean; onClose: () => void; images: string[]; onSave: (i: string[]) => Promise<void> }) => {
  const [text, setText] = useState(images.join("\n"));
  useEffect(() => { if (open) setText(images.join("\n")); }, [open, images]);
  return (
    <Dialog open={open} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader><DialogTitle>معرض الصور</DialogTitle></DialogHeader>
        <div className="space-y-2">
          <Label>روابط الصور (رابط لكل سطر)</Label>
          <Textarea rows={8} value={text} onChange={e => setText(e.target.value)} dir="ltr" placeholder="https://..." />
          <p className="text-xs text-muted-foreground">يدعم أي رابط صورة عام (jpg, png, webp).</p>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
          <Button onClick={() => onSave(text.split("\n").map(s => s.trim()).filter(Boolean))}>حفظ</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const NewsDialog = ({ open, onClose, text, onSave }: { open: boolean; onClose: () => void; text: string; onSave: (t: string) => Promise<void> }) => {
  const [v, setV] = useState(text);
  useEffect(() => { if (open) setV(text); }, [open, text]);
  return (
    <Dialog open={open} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader><DialogTitle>شريط الإعلانات</DialogTitle></DialogHeader>
        <div className="space-y-2">
          <Label>نص الإعلان</Label>
          <Textarea rows={3} value={v} onChange={e => setV(e.target.value)} placeholder="اكتب الإعلان هنا..." />
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
          <Button onClick={() => onSave(v.trim())}>حفظ</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const WhatsappDialog = ({ open, onClose, number, onSave }: { open: boolean; onClose: () => void; number: string; onSave: (n: string) => Promise<void> }) => {
  const [v, setV] = useState(number);
  useEffect(() => { if (open) setV(number); }, [open, number]);
  return (
    <Dialog open={open} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader><DialogTitle>رقم واتساب للتواصل</DialogTitle></DialogHeader>
        <div className="space-y-2">
          <Label>الرقم بصيغة دولية (مثل 9665XXXXXXXX)</Label>
          <Input value={v} onChange={e => setV(e.target.value)} dir="ltr" placeholder="9665XXXXXXXX" />
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
          <Button onClick={() => onSave(v.trim())}>حفظ</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const CountersTitleDialog = ({ open, onClose, title, onSave }: { open: boolean; onClose: () => void; title: string; onSave: (t: string) => Promise<void> }) => {
  const [v, setV] = useState(title);
  useEffect(() => { if (open) setV(title); }, [open, title]);
  return (
    <Dialog open={open} onOpenChange={o => !o && onClose()}>
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader><DialogTitle>عنوان قسم العدّادات</DialogTitle></DialogHeader>
        <div className="space-y-2">
          <Label>العنوان (اتركه فارغًا لإخفائه)</Label>
          <Input value={v} onChange={e => setV(e.target.value)} placeholder="مثال: إنجازاتنا بالأرقام" />
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
          <Button onClick={() => onSave(v.trim())}>حفظ</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const SECTION_LABELS: Record<SectionKey, string> = {
  counters: "عدّادات الإنجازات",
  testimonials: "قصص المتطوعين",
  gallery: "معرض الصور",
  faq: "الأسئلة الشائعة",
  opp_quiz: "اختبار الفرص المناسبة",
  impact_calc: "حاسبة أثر التطوع",
};

const SectionOrderEditor = ({ features, onSave }: { features: PublicFeatures; onSave: (next: PublicFeatures) => Promise<void> }) => {
  const order = normalizeSectionOrder(features.section_order);
  const move = async (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= order.length) return;
    const next = [...order];
    [next[i], next[j]] = [next[j], next[i]];
    await onSave({ ...features, section_order: next });
  };
  const reset = async () => {
    await onSave({ ...features, section_order: DEFAULT_SECTION_ORDER });
    toast.success("تم استعادة الترتيب الافتراضي");
  };
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground mb-2">رتّب ظهور الأقسام في الصفحة العامة من الأعلى للأسفل. الأقسام المعطّلة لن تظهر أصلًا.</p>
      {order.map((key, i) => {
        const enabled = !!(features as any)[key]?.enabled;
        return (
          <div key={key} className="flex items-center justify-between gap-3 p-3 bg-muted/40 rounded-lg">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-xs text-muted-foreground tabular-nums w-6 text-center">{i + 1}</span>
              <span className="font-semibold text-sm">{SECTION_LABELS[key]}</span>
              {!enabled && <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded">معطّل</span>}
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => move(i, -1)} disabled={i === 0} aria-label="للأعلى">
                <ArrowUp className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => move(i, 1)} disabled={i === order.length - 1} aria-label="للأسفل">
                <ArrowDown className="h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      })}
      <div className="pt-2">
        <Button variant="ghost" size="sm" onClick={reset}>
          <RotateCcw className="h-3.5 w-3.5 ml-1" />استعادة الترتيب الافتراضي
        </Button>
      </div>
    </div>
  );
};

const SectionBgEditor = ({ features, onSave }: { features: PublicFeatures; onSave: (next: PublicFeatures) => Promise<void> }) => {
  const bg = { ...DEFAULT_SECTION_BG, ...(features.section_bg || {}) };
  const fg = { ...DEFAULT_SECTION_FG, ...(features.section_fg || {}) };
  const updateBg = async (key: SectionKey, value: string) => {
    await onSave({ ...features, section_bg: { ...bg, [key]: value } });
  };
  const updateFg = async (key: SectionKey, value: string) => {
    await onSave({ ...features, section_fg: { ...fg, [key]: value } });
  };
  const resetOne = async (key: SectionKey) => {
    await onSave({ ...features, section_bg: { ...bg, [key]: "" }, section_fg: { ...fg, [key]: "" } });
  };
  const resetAll = async () => {
    await onSave({ ...features, section_bg: DEFAULT_SECTION_BG, section_fg: DEFAULT_SECTION_FG });
    toast.success("تم استعادة الألوان الافتراضية");
  };
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground mb-2">اختر لون الخلفية ولون النص لكل قسم. اتركه فارغًا لاستخدام التصميم الافتراضي.</p>
      {(Object.keys(SECTION_LABELS) as SectionKey[]).map(key => {
        const bgVal = bg[key] || "";
        const fgVal = fg[key] || "";
        return (
          <div key={key} className="p-3 bg-muted/40 rounded-lg space-y-2">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <span className="font-semibold text-sm">{SECTION_LABELS[key]}</span>
              <Button variant="ghost" size="sm" onClick={() => resetOne(key)} disabled={!bgVal && !fgVal}>
                إعادة
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <Label className="text-xs w-14 shrink-0">الخلفية</Label>
                <input
                  type="color"
                  value={bgVal || "#ffffff"}
                  onChange={e => updateBg(key, e.target.value)}
                  className="h-9 w-12 rounded border border-border cursor-pointer bg-transparent"
                  aria-label={`لون خلفية ${SECTION_LABELS[key]}`}
                />
                <Input value={bgVal} onChange={e => updateBg(key, e.target.value)} placeholder="افتراضي" className="h-9 text-xs" dir="ltr" />
              </div>
              <div className="flex items-center gap-2">
                <Label className="text-xs w-14 shrink-0">النص</Label>
                <input
                  type="color"
                  value={fgVal || "#000000"}
                  onChange={e => updateFg(key, e.target.value)}
                  className="h-9 w-12 rounded border border-border cursor-pointer bg-transparent"
                  aria-label={`لون نص ${SECTION_LABELS[key]}`}
                />
                <Input value={fgVal} onChange={e => updateFg(key, e.target.value)} placeholder="افتراضي" className="h-9 text-xs" dir="ltr" />
              </div>
            </div>
          </div>
        );
      })}
      <div className="pt-2">
        <Button variant="ghost" size="sm" onClick={resetAll}>
          <RotateCcw className="h-3.5 w-3.5 ml-1" />استعادة كل الألوان للافتراضي
        </Button>
      </div>
    </div>
  );
};
