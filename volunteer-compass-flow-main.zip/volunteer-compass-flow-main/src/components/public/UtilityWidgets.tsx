import { useEffect, useState } from "react";
import { ArrowUp, MessageCircle, Moon, Sun, Type } from "lucide-react";

// ===== Scroll progress bar =====
export const ScrollProgress = () => {
  const [p, setP] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setP(h > 0 ? (window.scrollY / h) * 100 : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return <div className="fixed top-0 inset-x-0 h-1 z-[60] bg-transparent"><div className="h-full bg-primary transition-[width] duration-100" style={{ width: `${p}%` }} /></div>;
};

// ===== Back to top =====
export const BackToTop = () => {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!show) return null;
  return (
    <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="العودة للأعلى"
      className="fixed bottom-6 left-6 z-50 h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg hover:scale-105 transition-transform flex items-center justify-center">
      <ArrowUp className="h-5 w-5" />
    </button>
  );
};

// ===== WhatsApp FAB =====
export const WhatsappFab = ({ number }: { number: string }) => {
  if (!number) return null;
  const cleaned = number.replace(/\D/g, "");
  return (
    <a href={`https://wa.me/${cleaned}`} target="_blank" rel="noopener noreferrer" aria-label="تواصل واتساب"
      className="fixed bottom-6 right-6 z-50 h-12 w-12 rounded-full bg-[#25D366] text-white shadow-lg hover:scale-105 transition-transform flex items-center justify-center">
      <MessageCircle className="h-6 w-6" />
    </a>
  );
};

// ===== Dark mode toggle (public scope only) =====
const DARK_KEY = "public_dark_mode";
export const DarkModeToggle = () => {
  const [dark, setDark] = useState(() => {
    if (typeof window === "undefined") return false;
    return localStorage.getItem(DARK_KEY) === "1";
  });
  useEffect(() => {
    const root = document.documentElement;
    const overrideVars = [
      "--background", "--foreground",
      "--card", "--card-foreground",
      "--popover", "--popover-foreground",
      "--muted", "--muted-foreground",
      "--border", "--input",
      "--sidebar-background", "--sidebar-foreground",
      "--sidebar-accent", "--sidebar-border",
    ];
    if (dark) {
      root.classList.add("dark");
      overrideVars.forEach(v => root.style.removeProperty(v));
    } else {
      root.classList.remove("dark");
      // Re-apply branding by reloading is overkill; ThemeProvider already set them on first load.
      // If user toggles back, page may need refresh for branding bg colors. Acceptable trade-off.
    }
    localStorage.setItem(DARK_KEY, dark ? "1" : "0");
  }, [dark]);
  return (
    <button onClick={() => setDark(d => !d)} aria-label="الوضع الليلي"
      className="h-9 w-9 rounded-full border border-border bg-card hover:bg-muted flex items-center justify-center transition-colors">
      {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </button>
  );
};

// ===== Font size toggle =====
const FONT_KEY = "public_font_scale";
export const FontSizeToggle = () => {
  const [scale, setScale] = useState<number>(() => {
    if (typeof window === "undefined") return 1;
    const v = parseFloat(localStorage.getItem(FONT_KEY) || "1");
    return isNaN(v) ? 1 : v;
  });
  useEffect(() => {
    document.documentElement.style.fontSize = `${scale * 100}%`;
    localStorage.setItem(FONT_KEY, String(scale));
    return () => { document.documentElement.style.fontSize = ""; };
  }, [scale]);
  const dec = () => setScale(s => Math.max(0.85, +(s - 0.1).toFixed(2)));
  const inc = () => setScale(s => Math.min(1.3, +(s + 0.1).toFixed(2)));
  return (
    <div className="flex items-center gap-1 border border-border bg-card rounded-full px-1">
      <button onClick={dec} aria-label="تصغير الخط" className="h-8 w-8 flex items-center justify-center text-xs font-bold hover:bg-muted rounded-full">A-</button>
      <Type className="h-3.5 w-3.5 text-muted-foreground" />
      <button onClick={inc} aria-label="تكبير الخط" className="h-8 w-8 flex items-center justify-center text-sm font-bold hover:bg-muted rounded-full">A+</button>
    </div>
  );
};
