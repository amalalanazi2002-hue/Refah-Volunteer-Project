import { useEffect, useRef, useState } from "react";
import { Users, Clock, CalendarCheck, Award } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { sumValidHours, isAnomalousHours, roundHours } from "@/lib/hours-utils";

interface Counts { volunteers: number; hours: number; opportunities: number; participations: number }

const enrichHourRow = (r: any) => {
  const stored = Number(r.approved_hours);
  if (!Number.isNaN(stored) && stored > 0 && !isAnomalousHours(stored)) return r;
  const minutes = Number(r?.participations?.total_minutes || 0);
  if (minutes > 0) return { ...r, approved_hours: roundHours(minutes / 60) };
  const minH = Number(r?.opportunities?.minimum_hours || 0);
  if (minH > 0) return { ...r, approved_hours: roundHours(minH) };
  return r;
};

const useCountUp = (target: number, active: boolean, duration = 1500) => {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!active) return;
    let start: number | null = null;
    let raf = 0;
    const step = (ts: number) => {
      if (start === null) start = ts;
      const p = Math.min(1, (ts - start) / duration);
      setVal(Math.floor(p * target));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, active, duration]);
  return val;
};

export const AnimatedCounters = ({ title, bg }: { title?: string; bg?: string } = {}) => {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [counts, setCounts] = useState<Counts>({ volunteers: 0, hours: 0, opportunities: 0, participations: 0 });

  useEffect(() => {
    const fetchCounts = async () => {
      const [v, o, p, h] = await Promise.all([
        supabase.from("volunteers").select("id", { count: "exact", head: true }),
        supabase.from("opportunities").select("id", { count: "exact", head: true }),
        supabase.from("participations").select("id", { count: "exact", head: true }),
        supabase.from("volunteer_hours").select("approved_hours, status, opportunities(minimum_hours), participations(total_minutes)"),
      ]);
      const enriched = (h.data || []).map(enrichHourRow);
      const totalHours = sumValidHours(enriched);
      setCounts({
        volunteers: v.count || 0,
        opportunities: o.count || 0,
        participations: p.count || 0,
        hours: Math.round(totalHours),
      });
    };
    fetchCounts();
  }, []);

  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.2 },
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  const v = useCountUp(counts.volunteers, visible);
  const h = useCountUp(counts.hours, visible);
  const o = useCountUp(counts.opportunities, visible);
  const p = useCountUp(counts.participations, visible);

  const items = [
    { icon: Users, label: "متطوع", value: v },
    { icon: Clock, label: "ساعة تطوعية", value: h },
    { icon: CalendarCheck, label: "فرصة تطوعية", value: o },
    { icon: Award, label: "مشاركة", value: p },
  ];

  return (
    <section ref={ref} className={`py-12 md:py-16 ${bg ? "" : "bg-gradient-to-br from-primary/5 to-secondary/5"}`} style={bg ? { backgroundColor: bg } : undefined}>
      <div className="max-w-6xl mx-auto px-4">
        {title && title.trim() && (
          <h2 className="text-xl md:text-2xl font-bold text-foreground text-center mb-6">{title}</h2>
        )}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {items.map((it, i) => (
            <div key={i} className="bg-card rounded-xl border border-border p-5 text-center hover:shadow-md transition-shadow">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-primary/10 text-primary mb-3">
                <it.icon className="h-6 w-6" />
              </div>
              <div className="text-2xl md:text-3xl font-bold text-foreground tabular-nums">{it.value.toLocaleString("en-US")}</div>
              <div className="text-xs md:text-sm text-muted-foreground mt-1">{it.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AnimatedCounters;
