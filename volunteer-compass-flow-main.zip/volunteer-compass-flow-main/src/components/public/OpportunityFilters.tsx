import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

interface Props {
  search: string;
  onSearch: (v: string) => void;
  department: string;
  onDepartment: (v: string) => void;
  departments: string[];
  sort: string;
  onSort: (v: string) => void;
}

export const OpportunityFilters = ({ search, onSearch, department, onDepartment, departments, sort, onSort }: Props) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input value={search} onChange={e => onSearch(e.target.value)} placeholder="ابحث في الفرص..." className="pr-9 h-10" />
      </div>
      <Select value={department} onValueChange={onDepartment}>
        <SelectTrigger className="h-10"><SelectValue placeholder="القسم" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="__all__">جميع الأقسام</SelectItem>
          {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
        </SelectContent>
      </Select>
      <Select value={sort} onValueChange={onSort}>
        <SelectTrigger className="h-10"><SelectValue placeholder="الترتيب" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="newest">الأحدث</SelectItem>
          <SelectItem value="ending_soon">تنتهي قريبًا</SelectItem>
          <SelectItem value="most_seats">الأكثر مقاعد</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default OpportunityFilters;
