import { useEffect } from "react";

interface Props { orgName: string; description: string; email?: string; phone?: string; logoUrl?: string }

export const SchemaTags = ({ orgName, description, email, phone, logoUrl }: Props) => {
  useEffect(() => {
    const data = {
      "@context": "https://schema.org",
      "@type": "NGO",
      name: orgName,
      description,
      ...(email && { email }),
      ...(phone && { telephone: phone }),
      ...(logoUrl && { logo: logoUrl }),
      url: typeof window !== "undefined" ? window.location.href : "",
    };
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.text = JSON.stringify(data);
    script.id = "ldjson-public";
    document.querySelector("#ldjson-public")?.remove();
    document.head.appendChild(script);

    const setMeta = (prop: string, content: string) => {
      let m = document.querySelector(`meta[property="${prop}"]`) as HTMLMetaElement | null;
      if (!m) { m = document.createElement("meta"); m.setAttribute("property", prop); document.head.appendChild(m); }
      m.content = content;
    };
    setMeta("og:title", orgName);
    setMeta("og:description", description);
    setMeta("og:type", "website");
    if (logoUrl) setMeta("og:image", logoUrl);

    return () => { document.querySelector("#ldjson-public")?.remove(); };
  }, [orgName, description, email, phone, logoUrl]);
  return null;
};

export default SchemaTags;
