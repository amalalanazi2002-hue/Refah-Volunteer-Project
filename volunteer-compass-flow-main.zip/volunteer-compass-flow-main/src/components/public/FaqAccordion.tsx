import { useState, useMemo } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Search, HelpCircle } from "lucide-react";
import type { FaqItem } from "@/lib/public-features";

export const FaqAccordion = ({ items, bg }: { items: FaqItem[]; bg?: string }) => {
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => {
    const s = search.trim();
    if (!s) return items;
    return items.filter(it => it.q.includes(s) || it.a.includes(s));
  }, [items, search]);

  if (!items.length) return null;
  return (
    <section className="py-12 md:py-16" style={bg ? { backgroundColor: bg } : undefined}>
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-primary/10 text-primary mb-3">
            <HelpCircle className="h-6 w-6" />
          </div>
          <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">الأسئلة الشائعة</h3>
        </div>
        <div className="relative mb-6">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث في الأسئلة..." className="pr-9 h-10" />
        </div>
        {filtered.length === 0 ? (
          <p className="text-center text-muted-foreground text-sm">لا توجد نتائج</p>
        ) : (
          <Accordion type="single" collapsible className="bg-card rounded-xl border border-border">
            {filtered.map((it, i) => (
              <AccordionItem key={i} value={`q-${i}`} className="px-4">
                <AccordionTrigger className="text-right text-sm md:text-base font-semibold">{it.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">{it.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        )}
      </div>
    </section>
  );
};

export default FaqAccordion;
