import { useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Sparkles } from "lucide-react";

type Level = "general" | "skilled" | "professional";

interface Rates {
  general: number;
  skilled: number;
  professional: number;
}

const LEVELS: { key: Level; label: string }[] = [
  { key: "general", label: "عام" },
  { key: "skilled", label: "مهاري" },
  { key: "professional", label: "احترافي" },
];

interface Props {
  bg?: string;
  rates?: Rates;
}

export const ImpactCalculator = ({ bg, rates }: Props) => {
  const effectiveRates: Rates = {
    general: rates?.general ?? 30,
    skilled: rates?.skilled ?? 60,
    professional: rates?.professional ?? 100,
  };

  const [level, setLevel] = useState<Level>("general");
  const [hoursPerDay, setHoursPerDay] = useState(2);
  const [days, setDays] = useState(5);

  const totalHours = hoursPerDay * days;
  const totalValue = totalHours * effectiveRates[level];

  return (
    <section className="py-12 md:py-16" style={bg ? { backgroundColor: bg } : undefined}>
      <div className="max-w-3xl mx-auto px-4">
        <div className="bg-card rounded-2xl border border-border p-6 md:p-8">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-primary/10 text-primary mb-3">
              <Sparkles className="h-6 w-6" />
            </div>
            <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">احسب أثر تطوعك</h3>
            <p className="text-sm text-muted-foreground">اختر مستوى التطوع وعدد الساعات والأيام لمعرفة الإجمالي</p>
          </div>

          <div className="space-y-6">
            {/* Level */}
            <div>
              <div className="text-sm font-medium mb-2">مستوى التطوع</div>
              <div className="grid grid-cols-3 gap-2">
                {LEVELS.map((l) => (
                  <button
                    key={l.key}
                    type="button"
                    onClick={() => setLevel(l.key)}
                    className={`py-2 px-3 rounded-xl text-sm font-medium border transition-all ${
                      level === l.key
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background text-foreground border-border hover:border-primary/50"
                    }`}
                  >
                    <div>{l.label}</div>
                    <div className="text-[11px] opacity-80 tabular-nums mt-0.5">
                      {effectiveRates[l.key].toLocaleString("en-US")} ر.س/ساعة
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Hours per day */}
            <div>
              <div className="flex justify-between mb-2 text-sm font-medium">
                <span className="tabular-nums">{hoursPerDay.toLocaleString("en-US")} ساعة / يوم</span>
                <span className="text-muted-foreground">من 1 إلى 12</span>
              </div>
              <Slider value={[hoursPerDay]} min={1} max={12} step={1} onValueChange={(v) => setHoursPerDay(v[0])} />
            </div>

            {/* Days */}
            <div>
              <div className="flex justify-between mb-2 text-sm font-medium">
                <span className="tabular-nums">{days.toLocaleString("en-US")} يوم</span>
                <span className="text-muted-foreground">من 1 إلى 30</span>
              </div>
              <Slider value={[days]} min={1} max={30} step={1} onValueChange={(v) => setDays(v[0])} />
            </div>

            {/* Results */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-primary/5 rounded-xl p-4 text-center">
                <div className="text-2xl md:text-3xl font-bold text-primary tabular-nums">
                  {totalHours.toLocaleString("en-US")}
                </div>
                <div className="text-xs text-muted-foreground mt-1">إجمالي الساعات</div>
              </div>
              <div className="bg-secondary/10 rounded-xl p-4 text-center">
                <div className="text-2xl md:text-3xl font-bold text-secondary tabular-nums">
                  {totalValue.toLocaleString("en-US")}
                </div>
                <div className="text-xs text-muted-foreground mt-1">القيمة الإجمالية (ر.س)</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImpactCalculator;
