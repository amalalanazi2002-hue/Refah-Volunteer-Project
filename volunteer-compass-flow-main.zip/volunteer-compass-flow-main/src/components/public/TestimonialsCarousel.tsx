import { useState, useEffect } from "react";
import { ChevronRight, ChevronLeft, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { TestimonialItem } from "@/lib/public-features";

export const TestimonialsCarousel = ({ items, bg }: { items: TestimonialItem[]; bg?: string }) => {
  const [i, setI] = useState(0);
  useEffect(() => {
    if (items.length <= 1) return;
    const t = setInterval(() => setI(p => (p + 1) % items.length), 6000);
    return () => clearInterval(t);
  }, [items.length]);

  if (!items.length) return null;
  const cur = items[i];

  return (
    <section className={`py-12 md:py-16 ${bg ? "" : "bg-muted/30"}`} style={bg ? { backgroundColor: bg } : undefined}>
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-primary/10 text-primary mb-3">
            <Quote className="h-6 w-6" />
          </div>
          <h3 className="text-xl md:text-2xl font-bold text-foreground">قصص متطوعينا</h3>
        </div>
        <div className="bg-card rounded-2xl border border-border p-6 md:p-8 text-center animate-fade-in" key={i}>
          {cur.image && <img src={cur.image} alt={cur.name} loading="lazy" className="h-16 w-16 rounded-full object-cover mx-auto mb-4 border border-border" />}
          <p className="text-base md:text-lg text-foreground leading-relaxed mb-4">"{cur.text}"</p>
          <div className="text-sm font-semibold text-primary">{cur.name}</div>
          {cur.role && <div className="text-xs text-muted-foreground mt-0.5">{cur.role}</div>}
        </div>
        {items.length > 1 && (
          <div className="flex justify-center gap-2 mt-4">
            <Button variant="ghost" size="sm" onClick={() => setI(p => (p - 1 + items.length) % items.length)}><ChevronRight className="h-4 w-4" /></Button>
            <div className="flex items-center gap-1.5">
              {items.map((_, k) => (
                <button key={k} aria-label={`شريحة ${k + 1}`} onClick={() => setI(k)} className={`h-2 rounded-full transition-all ${k === i ? "w-6 bg-primary" : "w-2 bg-muted-foreground/30"}`} />
              ))}
            </div>
            <Button variant="ghost" size="sm" onClick={() => setI(p => (p + 1) % items.length)}><ChevronLeft className="h-4 w-4" /></Button>
          </div>
        )}
      </div>
    </section>
  );
};

export default TestimonialsCarousel;
