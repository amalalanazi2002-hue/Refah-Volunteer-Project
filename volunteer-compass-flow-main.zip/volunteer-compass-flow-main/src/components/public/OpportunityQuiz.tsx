import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sparkles, RotateCcw } from "lucide-react";

const questions = [
  { q: "كم وقت تستطيع تخصيصه أسبوعيًا؟", a: ["أقل من 3 ساعات", "3-6 ساعات", "أكثر من 6 ساعات"] },
  { q: "ما النشاط الأقرب لك؟", a: ["تعليمي", "اجتماعي", "تنظيمي / إداري"] },
  { q: "هل تفضل العمل ميدانيًا أم عن بُعد؟", a: ["ميدانيًا", "عن بُعد", "كلاهما"] },
  { q: "ما نوع الفرص التي تفضلها؟", a: ["قصيرة (يوم واحد)", "أسبوعية", "مشاريع طويلة"] },
];

const recommend = (answers: number[]): string => {
  const t = answers[0]; const a = answers[1]; const m = answers[2]; const d = answers[3];
  if (a === 0) return "ننصحك بفرص تعليمية وورش عمل" + (m === 1 ? " عن بُعد" : "");
  if (a === 1) return "ننصحك بفرص اجتماعية ميدانية وزيارات";
  if (t === 2 || d === 2) return "ننصحك بمشاريع تنظيمية طويلة الأمد";
  return "ننصحك بفرص قصيرة متنوعة لتجربتها";
};

export const OpportunityQuiz = ({ bg }: { bg?: string } = {}) => {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const done = step >= questions.length;

  const pick = (i: number) => {
    setAnswers(prev => [...prev, i]);
    setStep(s => s + 1);
  };
  const reset = () => { setStep(0); setAnswers([]); };

  return (
    <section className={`py-12 md:py-16 ${bg ? "" : "bg-gradient-to-br from-secondary/5 to-primary/5"}`} style={bg ? { backgroundColor: bg } : undefined}>
      <div className="max-w-2xl mx-auto px-4">
        <div className="bg-card rounded-2xl border border-border p-6 md:p-8">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-secondary/15 text-secondary mb-3">
              <Sparkles className="h-6 w-6" />
            </div>
            <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">أي فرصة تطوعية تناسبك؟</h3>
            <p className="text-sm text-muted-foreground">{done ? "اقتراحنا لك" : `سؤال ${step + 1} من ${questions.length}`}</p>
          </div>
          {done ? (
            <div className="text-center space-y-4">
              <div className="bg-primary/5 rounded-xl p-5 text-base md:text-lg font-semibold text-primary">{recommend(answers)}</div>
              <Button variant="outline" onClick={reset}><RotateCcw className="h-4 w-4 ml-1" />إعادة الاختبار</Button>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-base md:text-lg font-medium text-foreground text-center">{questions[step].q}</p>
              <div className="grid gap-2">
                {questions[step].a.map((opt, i) => (
                  <Button key={i} variant="outline" className="w-full justify-start h-auto py-3" onClick={() => pick(i)}>{opt}</Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default OpportunityQuiz;
