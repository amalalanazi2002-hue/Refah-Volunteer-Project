import { useEffect, useRef, useState } from "react";
import { Image as ImageIcon, X, ChevronLeft, ChevronRight } from "lucide-react";

export const Gallery = ({ images, bg }: { images: string[]; bg?: string }) => {
  const [open, setOpen] = useState<string | null>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const pausedRef = useRef(false);
  const draggingRef = useRef(false);
  const dragStart = useRef({ x: 0, scroll: 0, moved: false });

  const isMarquee = images.length > 2;
  const loop = isMarquee ? [...images, ...images] : images;

  // Auto-scroll loop (RTL-friendly: scrolls toward the start, wraps seamlessly).
  useEffect(() => {
    if (!isMarquee) return;
    const el = scrollerRef.current;
    if (!el) return;
    let raf = 0;
    let last = performance.now();
    const speed = 40; // px/sec
    const step = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      if (!pausedRef.current && !draggingRef.current && el) {
        // In RTL, scrollLeft goes negative as content scrolls right-to-left.
        el.scrollLeft -= speed * dt;
        const half = el.scrollWidth / 2;
        // Wrap when we've scrolled a full duplicate set
        if (Math.abs(el.scrollLeft) >= half) {
          el.scrollLeft += half;
        }
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [isMarquee, images.length]);

  const scrollByCard = (dir: 1 | -1) => {
    const el = scrollerRef.current;
    if (!el) return;
    const card = el.querySelector<HTMLElement>("[data-card]");
    const delta = (card?.offsetWidth ?? 320) + 16;
    el.scrollBy({ left: dir * delta, behavior: "smooth" });
  };

  const onPointerDown = (e: React.PointerEvent) => {
    const el = scrollerRef.current;
    if (!el) return;
    draggingRef.current = true;
    dragStart.current = { x: e.clientX, scroll: el.scrollLeft, moved: false };
    el.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!draggingRef.current) return;
    const el = scrollerRef.current;
    if (!el) return;
    const dx = e.clientX - dragStart.current.x;
    if (Math.abs(dx) > 4) dragStart.current.moved = true;
    el.scrollLeft = dragStart.current.scroll - dx;
  };
  const onPointerUp = (e: React.PointerEvent) => {
    draggingRef.current = false;
    try { scrollerRef.current?.releasePointerCapture(e.pointerId); } catch {}
  };

  if (!images.length) return null;

  return (
    <section className="py-12 md:py-16" style={bg ? { backgroundColor: bg } : undefined}>
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-primary/10 text-primary mb-3">
            <ImageIcon className="h-6 w-6" />
          </div>
          <h3 className="text-xl md:text-2xl font-bold text-foreground">من فعالياتنا</h3>
        </div>

        {isMarquee ? (
          <div
            className="relative"
            onMouseEnter={() => { pausedRef.current = true; }}
            onMouseLeave={() => { pausedRef.current = false; }}
          >
            <div
              ref={scrollerRef}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              className="overflow-x-auto scrollbar-none cursor-grab active:cursor-grabbing select-none"
              style={{
                maskImage: "linear-gradient(to left, transparent, black 6%, black 94%, transparent)",
                WebkitMaskImage: "linear-gradient(to left, transparent, black 6%, black 94%, transparent)",
                scrollbarWidth: "none",
              }}
            >
              <div className="flex gap-4 w-max">
                {loop.map((src, i) => (
                  <button
                    key={i}
                    data-card
                    onClick={(e) => {
                      if (dragStart.current.moved) { e.preventDefault(); return; }
                      setOpen(src);
                    }}
                    className="shrink-0 w-[calc(70vw-2rem)] sm:w-[300px] md:w-[340px] aspect-square rounded-2xl overflow-hidden bg-muted shadow-sm hover:shadow-md transition-all hover:-translate-y-1"
                    aria-label={`صورة ${(i % images.length) + 1}`}
                  >
                    <img
                      src={src}
                      alt={`صورة ${(i % images.length) + 1}`}
                      loading="lazy"
                      draggable={false}
                      className="h-full w-full object-cover pointer-events-none"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Arrows: in RTL, "previous" visually sits on the right */}
            <button
              type="button"
              onClick={() => scrollByCard(-1)}
              aria-label="السابق"
              className="absolute top-1/2 -translate-y-1/2 right-2 md:right-4 z-10 h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg ring-1 ring-primary/30 hover:scale-110 hover:shadow-xl active:scale-95 transition-all flex items-center justify-center"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => scrollByCard(1)}
              aria-label="التالي"
              className="absolute top-1/2 -translate-y-1/2 left-2 md:left-4 z-10 h-11 w-11 rounded-full bg-primary text-primary-foreground shadow-lg ring-1 ring-primary/30 hover:scale-110 hover:shadow-xl active:scale-95 transition-all flex items-center justify-center"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            <style>{`
              .scrollbar-none::-webkit-scrollbar { display: none; }
            `}</style>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 md:gap-4 max-w-3xl mx-auto">
            {images.map((src, i) => (
              <button
                key={i}
                onClick={() => setOpen(src)}
                className="aspect-square rounded-2xl overflow-hidden bg-muted shadow-sm hover:shadow-md transition-all hover:-translate-y-1"
              >
                <img src={src} alt={`صورة ${i + 1}`} loading="lazy" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {open && (
        <div className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4 animate-fade-in" onClick={() => setOpen(null)}>
          <button className="absolute top-4 left-4 text-white p-2 rounded-full bg-white/10 hover:bg-white/20" onClick={() => setOpen(null)}>
            <X className="h-5 w-5" />
          </button>
          <img src={open} alt="معاينة" className="max-h-[90vh] max-w-full rounded-lg" onClick={e => e.stopPropagation()} />
        </div>
      )}
    </section>
  );
};

export default Gallery;
