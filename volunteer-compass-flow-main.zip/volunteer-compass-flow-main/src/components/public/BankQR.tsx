import { useEffect, useState } from "react";
import QRCode from "qrcode";

interface Props { value: string; size?: number }

export const BankQR = ({ value, size = 120 }: Props) => {
  const [src, setSrc] = useState<string>("");
  useEffect(() => {
    let mounted = true;
    QRCode.toDataURL(value, { margin: 1, width: size, color: { dark: "#5E4EA2", light: "#FFFFFF" } })
      .then(d => { if (mounted) setSrc(d); })
      .catch(() => {});
    return () => { mounted = false; };
  }, [value, size]);
  if (!src) return <div className="bg-muted rounded-lg" style={{ width: size, height: size }} />;
  return <img src={src} alt="QR" width={size} height={size} className="rounded-lg border border-border bg-white" />;
};

export default BankQR;
