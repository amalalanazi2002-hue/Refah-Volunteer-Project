import { Megaphone } from "lucide-react";

export const NewsTicker = ({ text }: { text: string }) => {
  if (!text.trim()) return null;
  return (
    <div className="bg-primary/10 border-b border-primary/20 overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-3">
        <Megaphone className="h-4 w-4 text-primary shrink-0" />
        <div className="overflow-hidden flex-1">
          <div className="whitespace-nowrap animate-[ticker_30s_linear_infinite] text-sm text-foreground">
            {text}
          </div>
        </div>
      </div>
      <style>{`@keyframes ticker { 0%{transform:translateX(100%)} 100%{transform:translateX(-100%)} }`}</style>
    </div>
  );
};

export default NewsTicker;
