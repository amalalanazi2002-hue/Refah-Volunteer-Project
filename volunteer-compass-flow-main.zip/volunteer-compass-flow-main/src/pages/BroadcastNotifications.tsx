import { useState, useEffect, useMemo, useCallback } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { StatCard } from "@/components/shared/StatCard";
import { DataTable } from "@/components/shared/DataTable";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { RichTextEditor } from "@/components/shared/RichTextEditor";
import { sanitizeHtml, htmlToPlainText } from "@/lib/safe-html";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { Send, Megaphone, ShieldAlert, Eye, History, User, Users, AlertCircle, CheckCircle2, Clock, ExternalLink, Printer, Search, Link2, ArrowRightCircle, MessageSquare, Paperclip, Download, FileText, ChevronDown, ChevronUp } from "lucide-react";
import { formatDateTime } from "@/lib/format-date";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { encodeSender, parseSender, parseAttachments, AttachmentMeta } from "@/lib/broadcast-meta";


type Audience = "all_volunteers" | "all_internal" | "everyone" | "specific_volunteers" | "specific_internal" | "mixed";
type ActionType = "none" | "external" | "internal_route" | "reply" | "attachment";

interface BroadcastRow {
  related_entity_id: string;
  title: string;
  message: string;
  cleanMessage: string;
  senderName?: string;
  type: string;
  user_type: string;
  created_at: string;
  total: number;
  read: number;
  requires_action: boolean;
  action_url: string | null;
  action_label: string | null;
  action_type: string | null;
}

interface RecipientRow {
  id: string;
  user_type: string;
  user_id: string;
  is_read: boolean;
  read_at: string | null;
  created_at: string;
  name: string;
}

interface ActionReplyRow {
  id: string;
  created_at: string;
  user_type: string;
  user_id: string; // recipient of reply notification (original sender)
  replierId?: string; // actual responder id (parsed from message)
  senderName?: string;
  cleanText: string;
  attachments: AttachmentMeta[];
}

const typeOptions = [
  { value: "new_opportunity", label: "إعلان عام" },
  { value: "application_submitted", label: "تنبيه إجرائي" },
  { value: "proof_approved", label: "خبر إيجابي" },
  { value: "proof_rejected", label: "تنبيه هام" },
];

const audienceLabel = (a: string) => ({
  all_volunteers: "جميع المتطوعين",
  all_internal: "جميع المستخدمين الداخليين",
  everyone: "الجميع",
  specific_volunteers: "متطوعون محددون",
  specific_internal: "مستخدمون داخليون محددون",
  mixed: "مختلط (متطوعون + داخليون)",
  volunteer: "متطوعون",
  internal: "مستخدمون داخليون",
}[a] || a);

const actionTypeLabel = (t: string | null) => ({
  external: "رابط خارجي",
  internal_route: "صفحة داخلية",
  reply: "الرد على الرسالة",
  attachment: "إرفاق ملف",
}[t || ""] || "");

const BroadcastNotifications = () => {
  const { role, userId, userName } = useRole();
  const isDirector = role === "director";

  const [volunteers, setVolunteers] = useState<any[]>([]);
  const [internals, setInternals] = useState<any[]>([]);
  const [history, setHistory] = useState<BroadcastRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [detail, setDetail] = useState<BroadcastRow | null>(null);
  const [detailRecipients, setDetailRecipients] = useState<RecipientRow[]>([]);
  const [detailTab, setDetailTab] = useState<"all" | "read" | "unread" | "action">("all");
  const [actionReplies, setActionReplies] = useState<ActionReplyRow[]>([]);
  const [expandedRecipient, setExpandedRecipient] = useState<string | null>(null);
  const [searchQ, setSearchQ] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "action" | "info">("all");

  const [form, setForm] = useState({
    title: "",
    message: "",
    type: "new_opportunity",
    audience: "all_volunteers" as Audience,
    selectedVolunteerIds: [] as string[],
    selectedInternalIds: [] as string[],
    requires_action: false,
    action_type: "external" as ActionType,
    action_url: "",
    action_label: "",
  });

  const fetchAll = useCallback(async () => {
    setLoading(true);
    const [v, i, n] = await Promise.all([
      supabase.from("volunteers").select("id, full_name, status").order("full_name"),
      supabase.from("internal_users").select("id, full_name, role, status").order("full_name"),
      supabase
        .from("notifications")
        .select("related_entity_id, title, message, type, user_type, is_read, created_at, requires_action, action_url, action_label, action_type")
        .eq("related_entity_type", "broadcast")
        .order("created_at", { ascending: false })
        .limit(2000),
    ]);
    setVolunteers(v.data || []);
    setInternals(i.data || []);

    const groups = new Map<string, BroadcastRow>();
    (n.data || []).forEach((row: any) => {
      const key = row.related_entity_id;
      if (!key) return;
      const g = groups.get(key);
      if (!g) {
        const parsed = parseSender(row.message || "");
        groups.set(key, {
          related_entity_id: key,
          title: row.title,
          message: row.message,
          cleanMessage: parsed.clean,
          senderName: parsed.name,
          type: row.type,
          user_type: row.user_type,
          created_at: row.created_at,
          total: 1,
          read: row.is_read ? 1 : 0,
          requires_action: !!row.requires_action,
          action_url: row.action_url,
          action_label: row.action_label,
          action_type: row.action_type,
        });
      } else {
        g.total += 1;
        if (row.is_read) g.read += 1;
        if (g.user_type !== row.user_type) g.user_type = "mixed";
      }
    });
    setHistory(Array.from(groups.values()).sort((a, b) => b.created_at.localeCompare(a.created_at)));
    setLoading(false);
  }, []);

  useEffect(() => { if (isDirector) fetchAll(); }, [isDirector, fetchAll]);

  useEffect(() => {
    if (!detail) { setDetailRecipients([]); setActionReplies([]); setExpandedRecipient(null); return; }
    (async () => {
      const [recRes, repRes] = await Promise.all([
        supabase
          .from("notifications")
          .select("id, user_type, user_id, is_read, read_at, created_at, related_entity_type")
          .eq("related_entity_id", detail.related_entity_id)
          .eq("related_entity_type", "broadcast"),
        supabase
          .from("notifications")
          .select("id, message, created_at, user_type, user_id")
          .eq("related_entity_id", detail.related_entity_id)
          .eq("related_entity_type", "broadcast_reply")
          .order("created_at", { ascending: true }),
      ]);
      const rows = (recRes.data || []) as any[];
      const vMap = new Map(volunteers.map(v => [v.id, v.full_name]));
      const iMap = new Map(internals.map(u => [u.id, u.full_name]));
      const enriched: RecipientRow[] = rows.map(r => ({
        id: r.id,
        user_type: r.user_type,
        user_id: r.user_id,
        is_read: r.is_read,
        read_at: r.read_at,
        created_at: r.created_at,
        name: (r.user_type === "volunteer" ? vMap.get(r.user_id) : iMap.get(r.user_id)) || "—",
      }));
      enriched.sort((a, b) => a.name.localeCompare(b.name, "ar"));
      setDetailRecipients(enriched);

      const reps: ActionReplyRow[] = (repRes.data || []).map((r: any) => {
        const ps = parseSender(r.message || "");
        const atts = parseAttachments(r.message || "");
        return {
          id: r.id,
          created_at: r.created_at,
          user_type: r.user_type,
          user_id: r.user_id,
          replierId: ps.id,
          senderName: ps.name,
          cleanText: ps.clean,
          attachments: atts,
        };
      });
      setActionReplies(reps);
    })();
  }, [detail, volunteers, internals]);

  const targetCount = useMemo(() => {
    const activeV = volunteers.filter(v => v.status === "active");
    const activeI = internals.filter(u => u.status === "active");
    switch (form.audience) {
      case "all_volunteers": return activeV.length;
      case "all_internal": return activeI.length;
      case "everyone": return activeV.length + activeI.length;
      case "specific_volunteers": return form.selectedVolunteerIds.length;
      case "specific_internal": return form.selectedInternalIds.length;
      case "mixed": return form.selectedVolunteerIds.length + form.selectedInternalIds.length;
      default: return 0;
    }
  }, [form.audience, form.selectedVolunteerIds, form.selectedInternalIds, volunteers, internals]);

  if (!isDirector) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3">
        <ShieldAlert className="h-12 w-12 text-destructive" />
        <p className="text-lg font-semibold text-foreground">غير مصرح بالوصول</p>
        <p className="text-sm text-muted-foreground">هذه الصفحة متاحة للمدير فقط</p>
      </div>
    );
  }

  const buildRecipients = () => {
    const activeV = volunteers.filter(v => v.status === "active");
    const activeI = internals.filter(u => u.status === "active");
    const rows: { user_type: "volunteer" | "internal"; user_id: string }[] = [];
    if (form.audience === "all_volunteers" || form.audience === "everyone") activeV.forEach(v => rows.push({ user_type: "volunteer", user_id: v.id }));
    if (form.audience === "all_internal" || form.audience === "everyone") activeI.forEach(u => rows.push({ user_type: "internal", user_id: u.id }));
    if (form.audience === "specific_volunteers") form.selectedVolunteerIds.forEach(id => rows.push({ user_type: "volunteer", user_id: id }));
    if (form.audience === "specific_internal") form.selectedInternalIds.forEach(id => rows.push({ user_type: "internal", user_id: id }));
    if (form.audience === "mixed") {
      form.selectedVolunteerIds.forEach(id => rows.push({ user_type: "volunteer", user_id: id }));
      form.selectedInternalIds.forEach(id => rows.push({ user_type: "internal", user_id: id }));
    }
    return rows;
  };

  const validateAction = (): string | null => {
    if (!form.requires_action) return null;
    switch (form.action_type) {
      case "external":
        if (!form.action_url.trim() || !form.action_label.trim()) return "أدخل الرابط الخارجي ونص الزر";
        if (!/^https?:\/\//i.test(form.action_url)) return "رابط خارجي يجب أن يبدأ بـ http(s)://";
        break;
      case "internal_route":
        if (!form.action_url.trim() || !form.action_label.trim()) return "أدخل المسار الداخلي ونص الزر";
        if (!form.action_url.startsWith("/")) return "المسار الداخلي يجب أن يبدأ بـ /";
        break;
      case "reply":
      case "attachment":
        if (!form.action_label.trim()) return "أدخل نص زر الإجراء";
        break;
      default:
        return "اختر نوع الإجراء";
    }
    return null;
  };

  const send = async () => {
    if (!form.title.trim() || !htmlToPlainText(form.message).trim()) {
      toast.error("الرجاء إدخال العنوان والمحتوى");
      return;
    }
    const aerr = validateAction();
    if (aerr) { toast.error(aerr); return; }

    const recipients = buildRecipients();
    if (recipients.length === 0) { toast.error("لا يوجد مستلمون"); return; }

    setSending(true);
    const broadcastId = (typeof crypto !== "undefined" && "randomUUID" in crypto)
      ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const safeMessage = sanitizeHtml(form.message);
    const messageWithSender = encodeSender(safeMessage, userName || "غير معروف", userId || "");
    const rows = recipients.map(r => ({
      user_type: r.user_type,
      user_id: r.user_id,
      title: form.title,
      message: messageWithSender,
      type: form.type,
      related_entity_type: "broadcast",
      related_entity_id: broadcastId,
      is_read: false,
      action_url: form.requires_action ? (form.action_url || null) : null,
      action_label: form.requires_action ? (form.action_label || null) : null,
      action_type: form.requires_action ? form.action_type : null,
      requires_action: !!form.requires_action,
    }));
    const chunkSize = 200;
    let failed = 0;
    for (let k = 0; k < rows.length; k += chunkSize) {
      const slice = rows.slice(k, k + chunkSize);
      const { error } = await supabase.from("notifications").insert(slice);
      if (error) failed += slice.length;
    }
    setSending(false);
    if (failed === 0) toast.success(`تم إرسال الإشعار إلى ${rows.length} مستلم`);
    else if (failed === rows.length) toast.error("فشل الإرسال");
    else toast.warning(`تم الإرسال جزئيًا (${rows.length - failed} من ${rows.length})`);

    setForm(p => ({ ...p, title: "", message: "", action_url: "", action_label: "", requires_action: false, selectedVolunteerIds: [], selectedInternalIds: [] }));
    fetchAll();
  };

  const showVolunteersPicker = form.audience === "specific_volunteers" || form.audience === "mixed";
  const showInternalsPicker = form.audience === "specific_internal" || form.audience === "mixed";

  // history filtering
  const filteredHistory = useMemo(() => history.filter(h => {
    if (filterStatus === "action" && !h.requires_action) return false;
    if (filterStatus === "info" && h.requires_action) return false;
    if (searchQ && !h.title.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [history, filterStatus, searchQ]);

  const totalBroadcasts = history.length;
  const totalRecipients = history.reduce((s, r) => s + r.total, 0);
  const totalRead = history.reduce((s, r) => s + r.read, 0);
  const readRatio = totalRecipients ? Math.round((totalRead / totalRecipients) * 100) : 0;

  const filteredRecipients = detailRecipients.filter(r => {
    if (detailTab === "all") return true;
    if (detailTab === "read") return r.is_read;
    if (detailTab === "unread") return !r.is_read;
    if (detailTab === "action") return !!detail?.requires_action;
    return true;
  });

  const printDetail = () => {
    if (!detail) return;
    const w = window.open("", "_blank");
    if (!w) return;
    const readList = detailRecipients.filter(r => r.is_read);
    const unreadList = detailRecipients.filter(r => !r.is_read);
    w.document.write(`<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>${detail.title}</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
        body{font-family:'Cairo',sans-serif;margin:24px;color:#1f2937;}
        h1{color:#5E4EA2;font-size:20px;margin:0 0 6px;}
        .meta{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:16px 0;font-size:12px;}
        .meta div{border:1px solid #eee;padding:8px;border-radius:6px;}
        .meta b{display:block;color:#666;font-weight:600;font-size:11px;margin-bottom:2px;}
        .body{border:1px solid #eee;padding:14px;border-radius:8px;background:#fafafa;font-size:13px;line-height:1.8;}
        h2{color:#5E4EA2;font-size:14px;margin:18px 0 8px;border-bottom:1px solid #eee;padding-bottom:4px;}
        ul{margin:6px 0;padding-right:18px;font-size:12px;}
        @media print{body{margin:10mm;}}
      </style></head><body>
      <h1>${detail.title}</h1>
      <div style="font-size:12px;color:#666;">إشعار مؤسسي — تاريخ الطباعة: ${formatDateTime(new Date().toISOString())}</div>
      <div class="meta">
        <div><b>المرسل</b>${detail.senderName || "—"}</div>
        <div><b>تاريخ الإرسال</b>${formatDateTime(detail.created_at)}</div>
        <div><b>الجهة المستهدفة</b>${audienceLabel(detail.user_type)}</div>
        <div><b>عدد المستلمين</b>${detail.total}</div>
        <div><b>تمت القراءة</b>${detail.read}</div>
        <div><b>لم تتم القراءة</b>${detail.total - detail.read}</div>
      </div>
      <h2>محتوى الإشعار</h2>
      <div class="body">${sanitizeHtml(detail.cleanMessage)}</div>
      <h2>تمت القراءة (${readList.length})</h2>
      <ul>${readList.map(r => `<li>${r.name} — ${r.user_type === "volunteer" ? "متطوع" : "داخلي"} — ${r.read_at ? formatDateTime(r.read_at) : "—"}</li>`).join("") || "<li>—</li>"}</ul>
      <h2>لم تتم القراءة (${unreadList.length})</h2>
      <ul>${unreadList.map(r => `<li>${r.name} — ${r.user_type === "volunteer" ? "متطوع" : "داخلي"}</li>`).join("") || "<li>—</li>"}</ul>
      </body></html>`);
    w.document.close();
    setTimeout(() => w.print(), 400);
  };

  const exportRows = filteredHistory.map(h => ({
    title: h.title,
    sender: h.senderName || "—",
    audience: audienceLabel(h.user_type),
    total: h.total,
    read: h.read,
    unread: h.total - h.read,
    created_at: formatDateTime(h.created_at),
    status: h.requires_action ? "يتطلب إجراء" : "تم الإرسال",
  }));
  const exportColumns = [
    { header: "العنوان", key: "title" },
    { header: "المرسل", key: "sender" },
    { header: "الجهة", key: "audience" },
    { header: "المستلمون", key: "total" },
    { header: "تمت القراءة", key: "read" },
    { header: "لم تتم", key: "unread" },
    { header: "تاريخ الإرسال", key: "created_at" },
    { header: "الحالة", key: "status" },
  ];

  return (
    <div>
      <PageHeader title="إدارة الإشعارات" description="إنشاء وإرسال الإشعارات للمتطوعين والمستخدمين الداخليين ومتابعة حالة القراءة" />

      <Tabs defaultValue="new" dir="rtl">
        <TabsList className="mb-4">
          <TabsTrigger value="new"><Megaphone className="h-4 w-4 ml-1" />إشعار جديد</TabsTrigger>
          <TabsTrigger value="history"><History className="h-4 w-4 ml-1" />سجل الإرسال</TabsTrigger>
        </TabsList>

        <TabsContent value="new">
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2 bg-card rounded-xl border border-border shadow-sm p-6 space-y-5">
              <div className="flex items-center gap-2 pb-3 border-b border-border">
                <Megaphone className="h-4 w-4 text-primary" />
                <h3 className="font-bold text-foreground text-sm">إنشاء إشعار جديد</h3>
              </div>

              <div>
                <Label className="text-xs font-semibold">عنوان الإشعار</Label>
                <Input className="mt-1.5" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="مثال: تنويه هام" />
              </div>
              <div>
                <Label className="text-xs font-semibold">محتوى الإشعار</Label>
                <RichTextEditor className="mt-1.5" value={form.message} onChange={v => setForm(p => ({ ...p, message: v }))} placeholder="اكتب محتوى الإشعار..." />
                <p className="text-[11px] text-muted-foreground mt-1">يدعم: عريض / مائل / تسطير / لون / حجم / محاذاة / تعداد / روابط / صور</p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs font-semibold">نوع الإشعار</Label>
                  <Select value={form.type} onValueChange={v => setForm(p => ({ ...p, type: v }))}>
                    <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                    <SelectContent>{typeOptions.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs font-semibold">الجهة المستهدفة</Label>
                  <Select value={form.audience} onValueChange={v => setForm(p => ({ ...p, audience: v as Audience, selectedVolunteerIds: [], selectedInternalIds: [] }))}>
                    <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all_volunteers">جميع المتطوعين</SelectItem>
                      <SelectItem value="all_internal">جميع المستخدمين الداخليين</SelectItem>
                      <SelectItem value="everyone">الجميع</SelectItem>
                      <SelectItem value="specific_volunteers">متطوعون محددون</SelectItem>
                      <SelectItem value="specific_internal">مستخدمون داخليون محددون</SelectItem>
                      <SelectItem value="mixed">مختلط (متطوعون + داخليون)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {(showVolunteersPicker || showInternalsPicker) && (
                <div className={`grid gap-4 ${showVolunteersPicker && showInternalsPicker ? "sm:grid-cols-2" : "grid-cols-1"}`}>
                  {showVolunteersPicker && (
                    <PickerList title="متطوعون" items={volunteers} selected={form.selectedVolunteerIds}
                      onChange={ids => setForm(p => ({ ...p, selectedVolunteerIds: ids }))} />
                  )}
                  {showInternalsPicker && (
                    <PickerList title="مستخدمون داخليون" items={internals} selected={form.selectedInternalIds}
                      onChange={ids => setForm(p => ({ ...p, selectedInternalIds: ids }))} />
                  )}
                </div>
              )}

              <label className="flex items-center gap-2 text-sm rounded-md border border-border bg-muted/30 px-3 py-2 cursor-pointer">
                <input type="checkbox" checked={form.requires_action} onChange={e => setForm(p => ({ ...p, requires_action: e.target.checked }))} />
                <span className="font-medium text-foreground">يتطلب إجراء من المستلم</span>
              </label>

              {form.requires_action && (
                <div className="space-y-3 rounded-lg border border-warning/30 bg-warning/5 p-4">
                  <div>
                    <Label className="text-xs font-semibold">نوع الإجراء</Label>
                    <Select value={form.action_type} onValueChange={v => setForm(p => ({ ...p, action_type: v as ActionType, action_url: "" }))}>
                      <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="external">رابط خارجي</SelectItem>
                        <SelectItem value="internal_route">فتح صفحة داخل النظام</SelectItem>
                        <SelectItem value="reply">الرد على الرسالة</SelectItem>
                        <SelectItem value="attachment">إرفاق ملف</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {(form.action_type === "external" || form.action_type === "internal_route") && (
                      <div>
                        <Label className="text-xs font-semibold">{form.action_type === "external" ? "الرابط الخارجي" : "المسار الداخلي"}</Label>
                        <Input className="mt-1.5" value={form.action_url} onChange={e => setForm(p => ({ ...p, action_url: e.target.value }))}
                          placeholder={form.action_type === "external" ? "https://example.com" : "/volunteer/opportunities"} />
                      </div>
                    )}
                    <div className={form.action_type === "reply" || form.action_type === "attachment" ? "sm:col-span-2" : ""}>
                      <Label className="text-xs font-semibold">نص زر الإجراء</Label>
                      <Input className="mt-1.5" value={form.action_label} onChange={e => setForm(p => ({ ...p, action_label: e.target.value }))}
                        placeholder={form.action_type === "reply" ? "الرد" : form.action_type === "attachment" ? "إرفاق ملف" : "عرض"} />
                    </div>
                  </div>
                  {validateAction() && (
                    <div className="flex items-center gap-2 text-xs rounded-md bg-warning/10 text-warning border border-warning/30 px-3 py-2">
                      <AlertCircle className="h-4 w-4" />{validateAction()}
                    </div>
                  )}
                </div>
              )}

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-border">
                <p className="text-xs text-muted-foreground">سيتم الإرسال إلى <span className="font-bold text-foreground">{targetCount}</span> مستلم</p>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setPreviewOpen(true)} disabled={!form.title || !form.message}>
                    <Eye className="h-4 w-4 ml-1" />معاينة
                  </Button>
                  <Button onClick={send} disabled={sending || targetCount === 0}>
                    <Send className="h-4 w-4 ml-1" />{sending ? "جارٍ الإرسال..." : "إرسال"}
                  </Button>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-xl border border-border shadow-sm p-5">
              <h4 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2"><Eye className="h-4 w-4 text-primary" />معاينة سريعة</h4>
              <div className="bg-background rounded-lg border border-border p-4">
                <p className="text-sm font-bold text-foreground mb-1">{form.title || "عنوان الإشعار"}</p>
                <div className="text-sm text-foreground/80 leading-relaxed prose prose-sm max-w-none [&_img]:max-w-full [&_a]:text-primary [&_a]:underline min-h-[40px]"
                  dangerouslySetInnerHTML={{ __html: sanitizeHtml(form.message) || '<span class="text-muted-foreground">نص الإشعار يظهر هنا...</span>' }} />
                {form.requires_action && form.action_label && (
                  <Button size="sm" className="mt-3 text-xs" disabled>
                    <ExternalLink className="h-3 w-3 ml-1" />{form.action_label}
                  </Button>
                )}
                <div className="text-[11px] text-muted-foreground/70 mt-3 pt-2 border-t border-border flex items-center gap-1">
                  <User className="h-3 w-3" /> {userName || "—"}
                </div>
              </div>
              <div className="mt-4 space-y-1.5 text-xs text-muted-foreground">
                <p className="flex items-center gap-1.5"><Users className="h-3 w-3" />الجهة: <span className="font-medium text-foreground">{audienceLabel(form.audience)}</span></p>
                <p>• المستلمون: <span className="font-bold text-foreground">{targetCount}</span></p>
                <p>• المرسل: <span className="font-medium text-foreground">{userName || "—"}</span></p>
                {form.requires_action && (
                  <p>• الإجراء: <span className="font-medium text-foreground">{actionTypeLabel(form.action_type)}</span></p>
                )}
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 mb-4">
            <StatCard title="إجمالي الإشعارات" value={totalBroadcasts} icon={Megaphone} />
            <StatCard title="المستلمون" value={totalRecipients} icon={Users} />
            <StatCard title="تمت القراءة" value={totalRead} icon={CheckCircle2} />
            <StatCard title="نسبة القراءة" value={`${readRatio}%`} icon={Eye} />
          </div>

          <div className="bg-card rounded-xl border border-border shadow-sm p-4 md:p-5">
            <div className="flex items-center justify-between gap-2 mb-4 flex-wrap">
              <h3 className="font-bold text-foreground text-sm">سجل الإشعارات المُرسلة</h3>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="relative">
                  <Search className="h-3.5 w-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="بحث بالعنوان..." className="h-8 text-xs pr-7 w-44" />
                </div>
                <Select value={filterStatus} onValueChange={v => setFilterStatus(v as any)}>
                  <SelectTrigger className="h-8 text-xs w-36"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">كل الحالات</SelectItem>
                    <SelectItem value="action">يتطلب إجراء</SelectItem>
                    <SelectItem value="info">للعرض فقط</SelectItem>
                  </SelectContent>
                </Select>
                <ExportButtons data={exportRows} columns={exportColumns} title="سجل الإشعارات" filename="notifications_log" />
              </div>
            </div>
            <DataTable
              columns={[
                { header: "العنوان", accessor: (r: BroadcastRow) => <span className="font-medium text-foreground">{r.title}</span> },
                { header: "المرسل", accessor: (r: BroadcastRow) => <span className="text-xs flex items-center gap-1"><User className="h-3 w-3 text-muted-foreground" />{r.senderName || "—"}</span> },
                { header: "الجهة", accessor: (r: BroadcastRow) => <span className="text-xs">{audienceLabel(r.user_type)}</span> },
                { header: "المستلمون", accessor: (r: BroadcastRow) => <span className="text-xs font-medium">{r.total}</span> },
                { header: "القراءة", accessor: (r: BroadcastRow) => <span className="text-xs"><span className="text-success font-medium">{r.read}</span><span className="text-muted-foreground"> / {r.total}</span></span> },
                { header: "الحالة", accessor: (r: BroadcastRow) => r.requires_action ? <StatusBadge status="يتطلب إجراء" variant="warning" /> : <StatusBadge status="تم الإرسال" variant="success" /> },
                { header: "التاريخ", accessor: (r: BroadcastRow) => <span className="text-xs">{formatDateTime(r.created_at)}</span> },
                { header: "تفاصيل", accessor: (r: BroadcastRow) => (
                  <Button size="sm" variant="ghost" onClick={() => { setDetail(r); setDetailTab("all"); }}><Eye className="h-3.5 w-3.5" /></Button>
                ) },
              ]}
              data={filteredHistory}
              emptyMessage={loading ? "جارٍ التحميل..." : "لا يوجد سجل إشعارات بعد"}
            />
          </div>
        </TabsContent>
      </Tabs>

      {/* Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle>معاينة الإشعار</DialogTitle>
            <DialogDescription>هكذا سيظهر الإشعار للمستلم</DialogDescription>
          </DialogHeader>
          <div className="bg-background rounded-lg border border-border p-4">
            <p className="text-sm font-bold text-foreground mb-1">{form.title}</p>
            <div className="text-sm text-foreground/80 prose prose-sm max-w-none [&_img]:max-w-full [&_a]:text-primary [&_a]:underline"
              dangerouslySetInnerHTML={{ __html: sanitizeHtml(form.message) }} />
            {form.requires_action && form.action_label && (
              <Button size="sm" className="mt-3 text-xs" disabled>
                <ExternalLink className="h-3 w-3 ml-1" />{form.action_label}
              </Button>
            )}
            <div className="text-[11px] text-muted-foreground mt-3 pt-2 border-t border-border flex items-center gap-1">
              <User className="h-3 w-3" /> {userName || "—"}
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">سيُرسل إلى {targetCount} مستلم — {audienceLabel(form.audience)}</p>
        </DialogContent>
      </Dialog>

      {/* History Detail */}
      <Dialog open={!!detail} onOpenChange={() => setDetail(null)}>
        <DialogContent dir="rtl" className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-3 flex-wrap">
              <span>تفاصيل الإشعار</span>
              <Button size="sm" variant="outline" onClick={printDetail} className="text-xs">
                <Printer className="h-3.5 w-3.5 ml-1" />طباعة
              </Button>
            </DialogTitle>
            <DialogDescription>معلومات كاملة عن الإشعار وقائمة المستلمين</DialogDescription>
          </DialogHeader>
          {detail && (
            <div className="space-y-4 text-sm">
              <div className="bg-gradient-to-l from-primary/5 to-transparent border border-border rounded-lg p-4">
                <div className="flex items-start justify-between gap-3 mb-2 flex-wrap">
                  <h4 className="font-bold text-foreground text-base">{detail.title}</h4>
                  <div className="flex gap-1.5">
                    {detail.requires_action
                      ? <StatusBadge status="يتطلب إجراء" variant="warning" />
                      : <StatusBadge status="عرض فقط" variant="neutral" />}
                    {detail.action_type && <StatusBadge status={actionTypeLabel(detail.action_type)} variant="primary" />}
                  </div>
                </div>
                <div className="text-sm text-foreground/85 leading-relaxed prose prose-sm max-w-none [&_img]:max-w-full [&_a]:text-primary [&_a]:underline"
                  dangerouslySetInnerHTML={{ __html: sanitizeHtml(detail.cleanMessage) }} />
                {detail.requires_action && detail.action_label && (
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <Button size="sm" variant="outline" disabled className="text-xs">
                      <ExternalLink className="h-3 w-3 ml-1" />{detail.action_label}
                    </Button>
                    {detail.action_url && <span className="text-[11px] text-muted-foreground" dir="ltr">{detail.action_url}</span>}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <MetaCell icon={User} label="المرسل" value={detail.senderName || "—"} />
                <MetaCell icon={Users} label="الجهة" value={audienceLabel(detail.user_type)} />
                <MetaCell icon={Clock} label="التاريخ" value={formatDateTime(detail.created_at)} />
                <MetaCell icon={CheckCircle2} label="القراءة" value={`${detail.read} / ${detail.total}`} />
              </div>

              <div>
                <h5 className="text-sm font-bold text-foreground mb-2 flex items-center gap-2"><Users className="h-4 w-4 text-primary" />المستلمون</h5>
                <Tabs value={detailTab} onValueChange={(v) => { setDetailTab(v as any); setExpandedRecipient(null); }} dir="rtl">
                  <TabsList className="w-full">
                    <TabsTrigger value="all" className="flex-1">الكل ({detailRecipients.length})</TabsTrigger>
                    <TabsTrigger value="read" className="flex-1">تمت القراءة ({detailRecipients.filter(r => r.is_read).length})</TabsTrigger>
                    <TabsTrigger value="unread" className="flex-1">لم تتم ({detailRecipients.filter(r => !r.is_read).length})</TabsTrigger>
                    {detail.requires_action && (() => {
                      const isReplyish = detail.action_type === "reply" || detail.action_type === "attachment";
                      const repliedSet = new Set(actionReplies.map(r => r.replierId).filter(Boolean) as string[]);
                      const executedCount = isReplyish
                        ? detailRecipients.filter(r => repliedSet.has(r.user_id)).length
                        : detailRecipients.filter(r => r.is_read).length;
                      return (
                        <TabsTrigger value="action" className="flex-1">الإجراءات ({executedCount}/{detailRecipients.length})</TabsTrigger>
                      );
                    })()}
                  </TabsList>
                  <TabsContent value={detailTab}>
                    {detailTab === "action" ? (
                      !detail.requires_action ? (
                        <div className="border border-border rounded-md p-6 text-center text-xs text-muted-foreground mt-2">
                          لا توجد إجراءات لهذا الإشعار
                        </div>
                      ) : (() => {
                        const isReply = detail.action_type === "reply";
                        const isAttach = detail.action_type === "attachment";
                        const isReplyish = isReply || isAttach;
                        const repliesByUser = new Map<string, ActionReplyRow[]>();
                        actionReplies.forEach(r => {
                          const key = r.replierId;
                          if (!key) return;
                          const arr = repliesByUser.get(key) || [];
                          arr.push(r);
                          repliesByUser.set(key, arr);
                        });
                        return (
                          <div className="mt-2 space-y-3">
                            <div className="bg-primary/5 border border-primary/20 rounded-md p-2.5 text-[11px] text-foreground/80 flex items-center gap-2">
                              <AlertCircle className="h-3.5 w-3.5 text-primary shrink-0" />
                              <span>
                                نوع الإجراء المطلوب: <strong>{actionTypeLabel(detail.action_type) || "—"}</strong>
                                {detail.action_label && <span className="text-muted-foreground"> — {detail.action_label}</span>}
                              </span>
                            </div>
                            <div className="border border-border rounded-md max-h-[420px] overflow-y-auto divide-y divide-border bg-background">
                              {detailRecipients.length === 0 && <p className="text-xs text-muted-foreground p-4 text-center">لا يوجد مستلمون</p>}
                              {detailRecipients.map(r => {
                                const userReplies = repliesByUser.get(r.user_id) || [];
                                let executed = false;
                                let execLabel = "تم التنفيذ";
                                if (isReply) {
                                  executed = userReplies.some(rep => (rep.cleanText && rep.cleanText.replace(/<[^>]+>/g, "").trim().length > 0) || rep.attachments.length > 0);
                                  execLabel = "تم الرد";
                                } else if (isAttach) {
                                  executed = userReplies.some(rep => rep.attachments.length > 0);
                                  execLabel = "تم الإرفاق";
                                } else {
                                  executed = r.is_read;
                                }
                                const lastExec = isReplyish
                                  ? (userReplies.length ? userReplies[userReplies.length - 1].created_at : null)
                                  : r.read_at;
                                const isOpen = expandedRecipient === r.id;
                                const canExpand = isReplyish && userReplies.length > 0;
                                return (
                                  <div key={r.id} className="text-xs">
                                    <div className="flex items-center justify-between gap-2 px-3 py-2">
                                      <div className="flex items-center gap-2 min-w-0">
                                        <span className={`h-2 w-2 rounded-full shrink-0 ${executed ? "bg-success" : "bg-muted-foreground/40"}`} />
                                        <span className="font-medium text-foreground truncate">{r.name}</span>
                                        <span className="text-[10px] text-muted-foreground shrink-0 bg-muted px-1.5 py-0.5 rounded">
                                          {r.user_type === "volunteer" ? "متطوع" : "داخلي"}
                                        </span>
                                        {executed
                                          ? <StatusBadge status={execLabel} variant="success" />
                                          : <StatusBadge status="لم يتم بعد" variant="neutral" />}
                                      </div>
                                      <div className="flex items-center gap-2 shrink-0 text-[11px]">
                                        {executed && lastExec && (
                                          <span className="text-muted-foreground flex items-center gap-1">
                                            <Clock className="h-3 w-3" />{formatDateTime(lastExec)}
                                          </span>
                                        )}
                                        {canExpand && (
                                          <Button size="sm" variant="ghost" className="h-6 px-2"
                                            onClick={() => setExpandedRecipient(isOpen ? null : r.id)}>
                                            {isOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                                          </Button>
                                        )}
                                      </div>
                                    </div>
                                    {isOpen && canExpand && (
                                      <div className="bg-muted/20 px-3 py-2 space-y-2 border-t border-border">
                                        {userReplies.map(rep => (
                                          <div key={rep.id} className="bg-background border border-border rounded p-2.5">
                                            <div className="flex items-center justify-between gap-2 mb-1.5 flex-wrap">
                                              <span className="text-[11px] font-semibold text-foreground flex items-center gap-1">
                                                <User className="h-3 w-3 text-primary" />{rep.senderName || r.name}
                                              </span>
                                              <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                                <Clock className="h-2.5 w-2.5" />{formatDateTime(rep.created_at)}
                                              </span>
                                            </div>
                                            {rep.cleanText && (
                                              <div className="text-[12px] text-foreground/90 leading-relaxed prose prose-sm max-w-none [&_a]:text-primary [&_a]:underline"
                                                dangerouslySetInnerHTML={{ __html: sanitizeHtml(rep.cleanText) }} />
                                            )}
                                            {rep.attachments.length > 0 && (
                                              <div className="mt-2 space-y-1.5">
                                                {rep.attachments.map((a, idx) => (
                                                  <ActionAttachmentRow key={idx} att={a} />
                                                ))}
                                              </div>
                                            )}
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                    {!executed && !canExpand && (
                                      <div className="px-3 pb-2 text-[11px] text-muted-foreground">لم يتم تنفيذ الإجراء بعد</div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      <div className="border border-border rounded-md max-h-80 overflow-y-auto divide-y divide-border bg-background mt-2">
                        {filteredRecipients.length === 0 && <p className="text-xs text-muted-foreground p-4 text-center">لا يوجد</p>}
                        {filteredRecipients.map(r => (
                          <div key={r.id} className="flex items-center justify-between gap-2 px-3 py-2 text-xs">
                            <div className="flex items-center gap-2 min-w-0">
                              <span className={`h-2 w-2 rounded-full shrink-0 ${r.is_read ? "bg-success" : "bg-warning"}`} />
                              <span className="font-medium text-foreground truncate">{r.name}</span>
                              <span className="text-[10px] text-muted-foreground shrink-0 bg-muted px-1.5 py-0.5 rounded">
                                {r.user_type === "volunteer" ? "متطوع" : "داخلي"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-[11px] shrink-0">
                              {r.is_read ? (
                                <>
                                  <span className="text-success font-medium">قُرئ</span>
                                  <span className="text-muted-foreground" title="تاريخ القراءة">
                                    {r.read_at ? formatDateTime(r.read_at) : "—"}
                                  </span>
                                </>
                              ) : <span className="text-warning">لم يُقرأ</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

const PickerList = ({ title, items, selected, onChange }: {
  title: string; items: any[]; selected: string[]; onChange: (ids: string[]) => void;
}) => {
  const [q, setQ] = useState("");
  const filtered = items.filter(u => !q || (u.full_name || "").toLowerCase().includes(q.toLowerCase()));
  const toggleAll = () => {
    const activeIds = items.filter(u => u.status === "active").map(u => u.id);
    onChange(selected.length === activeIds.length ? [] : activeIds);
  };
  return (
    <div className="border border-border rounded-md bg-background">
      <div className="flex items-center justify-between gap-2 px-2 py-1.5 border-b border-border">
        <span className="text-xs font-semibold text-foreground">{title} ({selected.length})</span>
        <button type="button" onClick={toggleAll} className="text-[11px] text-primary hover:underline">
          {selected.length > 0 ? "مسح" : "تحديد الكل"}
        </button>
      </div>
      <div className="px-2 pt-2">
        <Input value={q} onChange={e => setQ(e.target.value)} placeholder="بحث..." className="h-7 text-xs" />
      </div>
      <div className="max-h-44 overflow-y-auto p-2 space-y-0.5">
        {filtered.length === 0 && <p className="text-[11px] text-muted-foreground p-2">لا يوجد</p>}
        {filtered.map((u: any) => (
          <label key={u.id} className="flex items-center gap-2 text-xs px-2 py-1 rounded hover:bg-muted/40 cursor-pointer">
            <input type="checkbox" checked={selected.includes(u.id)}
              onChange={e => onChange(e.target.checked ? [...selected, u.id] : selected.filter(x => x !== u.id))} />
            <span className="flex-1 truncate">{u.full_name}</span>
            {u.role && <span className="text-[10px] text-muted-foreground">{u.role}</span>}
            {u.status && u.status !== "active" && <span className="text-[10px] text-warning">{u.status}</span>}
          </label>
        ))}
      </div>
    </div>
  );
};

const MetaCell = ({ icon: Icon, label, value }: { icon: any; label: string; value: string }) => (
  <div className="bg-background border border-border rounded-md p-2.5">
    <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-1"><Icon className="h-3 w-3" />{label}</div>
    <div className="text-xs font-medium text-foreground truncate">{value}</div>
  </div>
);

const isImageAtt = (a: AttachmentMeta) =>
  (a.type?.startsWith("image/") || /\.(png|jpe?g|gif|webp|svg|bmp)$/i.test(a.name || ""));
const isPdfAtt = (a: AttachmentMeta) =>
  (a.type === "application/pdf" || /\.pdf$/i.test(a.name || ""));
const humanFileSize = (n?: number) => {
  if (!n) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
};

const ActionAttachmentRow = ({ att }: { att: AttachmentMeta }) => {
  const [url, setUrl] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const isImg = isImageAtt(att);
  const isPdf = isPdfAtt(att);

  useEffect(() => {
    let cancel = false;
    (async () => {
      const { data, error } = await supabase.storage.from("proofs").createSignedUrl(att.path, 3600);
      if (cancel) return;
      if (error || !data?.signedUrl) setErr(error?.message || "تعذر تحميل الملف");
      else setUrl(data.signedUrl);
    })();
    return () => { cancel = true; };
  }, [att.path]);

  const download = async () => {
    const { data, error } = await supabase.storage.from("proofs").createSignedUrl(att.path, 300, { download: att.name });
    if (error || !data?.signedUrl) { toast.error(`تعذر التنزيل: ${error?.message || ""}`); return; }
    window.open(data.signedUrl, "_blank");
  };

  return (
    <div className="flex items-center gap-2 border border-border rounded bg-background p-2">
      <div className="h-10 w-10 rounded bg-muted flex items-center justify-center shrink-0 overflow-hidden">
        {isImg && url
          ? <img src={url} alt={att.name} className="h-full w-full object-cover" loading="lazy" />
          : <FileText className={`h-4 w-4 ${isPdf ? "text-destructive" : "text-muted-foreground"}`} />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[11px] font-medium text-foreground truncate" title={att.name}>{att.name}</div>
        <div className="text-[10px] text-muted-foreground truncate">
          {humanFileSize(att.size)}{att.type ? ` • ${att.type}` : isPdf ? " • PDF" : ""}
        </div>
        {err && <div className="text-[10px] text-destructive">{err}</div>}
      </div>
      <div className="flex items-center gap-1 shrink-0">
        {url && (isImg || isPdf) && (
          <Button size="sm" variant="ghost" className="h-7 px-2"
            onClick={() => window.open(url, "_blank")} title="معاينة">
            <Eye className="h-3.5 w-3.5" />
          </Button>
        )}
        <Button size="sm" variant="outline" className="h-7 px-2 text-[11px]" disabled={!!err} onClick={download}>
          <Download className="h-3 w-3 ml-1" />تنزيل
        </Button>
      </div>
    </div>
  );
};

export default BroadcastNotifications;
