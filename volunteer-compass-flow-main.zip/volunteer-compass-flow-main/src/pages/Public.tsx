import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CalendarCheck, Mail, Phone, LogIn, Send, Clock, Users, MapPin, UserPlus, AlertCircle, Landmark, Copy, User as UserIcon, Hash } from "lucide-react";
import { toast } from "sonner";
import fallbackLogo from "@/assets/logo.png";
import { formatDate } from "@/lib/format-date";
import { validateContactForm, normalizeMobile, normalizeNationalId, normalizeEmail, handleMobileInput, handleNationalIdInput, handleEmailInput } from "@/lib/validators";
import { notifyInternalNewRegistration } from "@/lib/notifications";
import { parsePublicFeatures, defaultPublicFeatures, PublicFeatures } from "@/lib/public-features";
import { ScrollProgress, BackToTop, WhatsappFab, DarkModeToggle, FontSizeToggle } from "@/components/public/UtilityWidgets";
import SchemaTags from "@/components/public/SchemaTags";
import NewsTicker from "@/components/public/NewsTicker";
import OpportunityFilters from "@/components/public/OpportunityFilters";
import BankQR from "@/components/public/BankQR";

const AnimatedCounters = lazy(() => import("@/components/public/AnimatedCounters"));
const ImpactCalculator = lazy(() => import("@/components/public/ImpactCalculator"));
const OpportunityQuiz = lazy(() => import("@/components/public/OpportunityQuiz"));
const FaqAccordion = lazy(() => import("@/components/public/FaqAccordion"));
const TestimonialsCarousel = lazy(() => import("@/components/public/TestimonialsCarousel"));
const Gallery = lazy(() => import("@/components/public/Gallery"));

interface PublicOpp {
  id: string;
  title: string;
  start_at: string | null;
  end_at: string | null;
  minimum_hours: number;
  participant_count: number;
  capacity: number;
  departments: { name: string } | null;
}

interface BrandingInfo {
  platform_name: string;
  org_name: string;
  org_description: string;
  contact_email: string;
  contact_phone: string;
  logo_url: string;
}

type RegistrationField = "full_name" | "mobile" | "email" | "national_id" | "city";
type RegistrationErrors = Partial<Record<RegistrationField, string>>;

interface PublicBankAccount {
  id: string;
  bank_name: string;
  holder_name: string;
  account_number: string;
  iban: string;
  note?: string;
  active: boolean;
}

const defaults: BrandingInfo = {
  platform_name: "منصة رفادة التطوعية",
  org_name: "جمعية رفاه للأرامل والمطلقات",
  org_description: "منصة تطوعية تهدف إلى تمكين المتطوعين وربطهم بالفرص التطوعية المتنوعة لخدمة المجتمع.",
  contact_email: "info@rafah.org",
  contact_phone: "920001234",
  logo_url: "",
};

const PublicPage = () => {
  const navigate = useNavigate();
  const [opportunities, setOpportunities] = useState<PublicOpp[]>([]);
  const [branding, setBranding] = useState<BrandingInfo>(defaults);
  const [loading, setLoading] = useState(true);
  const [regOpen, setRegOpen] = useState(false);
  const [regForm, setRegForm] = useState({ full_name: "", mobile: "", email: "", national_id: "", city: "" });
  const [regErrors, setRegErrors] = useState<RegistrationErrors>({});
  const [regLoading, setRegLoading] = useState(false);
  const [cities, setCities] = useState<string[]>([]);
  const [bankAccounts, setBankAccounts] = useState<PublicBankAccount[]>([]);
  const [features, setFeatures] = useState<PublicFeatures>(defaultPublicFeatures);
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("__all__");
  const [sortBy, setSortBy] = useState("newest");
  const [showAllOpps, setShowAllOpps] = useState(false);
  const INITIAL_OPPS = 3;

  useEffect(() => {
    const load = async () => {
      const [oppRes, settingsRes] = await Promise.all([
        supabase.from("opportunities").select("id, title, start_at, end_at, minimum_hours, participant_count, capacity, departments(name)").eq("status", "active").eq("is_public_visible", true).order("created_at", { ascending: false }).limit(24),
        supabase.from("system_settings").select("key, value").in("key", ["platform_name", "org_name", "org_description", "contact_email", "contact_phone", "logo_url", "cities", "bank_accounts", "public_features"]),
      ]);
      setOpportunities((oppRes.data as unknown as PublicOpp[]) || []);
      if (settingsRes.data) {
        const map: Record<string, string> = {};
        settingsRes.data.forEach((r: any) => { map[r.key] = r.value; });
        setBranding({
          platform_name: map.platform_name || defaults.platform_name,
          org_name: map.org_name || defaults.org_name,
          org_description: map.org_description || defaults.org_description,
          contact_email: map.contact_email || defaults.contact_email,
          contact_phone: map.contact_phone || defaults.contact_phone,
          logo_url: map.logo_url || defaults.logo_url,
        });
        if (map.cities) {
          try { setCities(JSON.parse(map.cities)); } catch {}
        }
        if (map.bank_accounts) {
          try {
            const parsed = JSON.parse(map.bank_accounts);
            if (Array.isArray(parsed)) {
              setBankAccounts(parsed.filter((a: PublicBankAccount) => a && a.active));
            }
          } catch {}
        }
        setFeatures(parsePublicFeatures(map.public_features));
      }
      setLoading(false);
    };
    load();
  }, []);

  const handleApply = (oppId: string) => {
    navigate(`/login?redirect=/volunteer/opportunities&opp=${oppId}`);
  };

  const updateRegField = (field: RegistrationField, value: string) => {
    setRegForm((prev) => ({ ...prev, [field]: value }));
    setRegErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleRegister = async () => {
    const normalizedForm = {
      full_name: regForm.full_name.trim(),
      mobile: normalizeMobile(regForm.mobile),
      email: normalizeEmail(regForm.email),
      national_id: normalizeNationalId(regForm.national_id),
      city: regForm.city,
    };

    const errs = validateContactForm({
      full_name: normalizedForm.full_name,
      mobile: normalizedForm.mobile,
      national_id: normalizedForm.national_id,
      email: normalizedForm.email,
    }) as RegistrationErrors;
    if (!normalizedForm.city) (errs as any).city = "المدينة مطلوبة";

    if (Object.keys(errs).length > 0) {
      setRegErrors(errs);
      toast.error("الرجاء تصحيح الحقول المظلّلة");
      return;
    }

    setRegLoading(true);
    setRegErrors({});

    // Public endpoint (verify_jwt = false): do not send an Authorization header.
    // A publishable key in Authorization is not a JWT and the gateway rejects it
    // before the request reaches the function.
    const SUPABASE_URL = "https://zrvzxlpokekenneiovvt.supabase.co";
    const SUPABASE_ANON_KEY = "sb_publishable_Xy6ZNvZT-uYzkm8QQjG47Q_0C9n5k8K";
    let fnRes: any = null;
    let fnError: { message: string } | null = null;
    try {
      const resp = await fetch(
        `${SUPABASE_URL}/functions/v1/public-volunteer-registration`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({
            full_name: normalizedForm.full_name,
            mobile: normalizedForm.mobile,
            email: normalizedForm.email || null,
            national_id: normalizedForm.national_id,
            city: normalizedForm.city || null,
          }),
        },
      );
      const text = await resp.text();
      try { fnRes = text ? JSON.parse(text) : null; } catch { fnRes = { raw: text }; }
      if (!resp.ok) {
        fnError = {
          message:
            (fnRes && (fnRes.error || fnRes.message || fnRes.msg || fnRes.code)) ||
            `HTTP ${resp.status}: ${text || resp.statusText}`,
        };
      } else if (fnRes && fnRes.ok === false) {
        fnError = { message: fnRes.error || fnRes.message || "حدث خطأ غير معروف" };
      }
    } catch (e: any) {
      fnError = { message: e?.message || "تعذّر الاتصال بالخادم" };
    }
    setRegLoading(false);
    const inserted = fnRes?.id ? { id: fnRes.id } : null;
    if (fnError) {
      console.error("Registration error:", fnError);
      const msg = fnError.message || "";
      const fieldErrors: RegistrationErrors = {};
      if (msg.includes("mobile") || msg.includes("الجوال")) fieldErrors.mobile = "رقم الجوال غير صالح";
      else if (msg.includes("national_id") || msg.includes("الهوية")) fieldErrors.national_id = "رقم الهوية غير صالح";
      else if (msg.includes("email") || msg.includes("البريد")) fieldErrors.email = "البريد الإلكتروني غير صالح";
      setRegErrors(fieldErrors);
      toast.error(msg || "حدث خطأ أثناء التسجيل");
      return;
    }
    // Fire-and-forget internal notification
    if (inserted?.id) {
      notifyInternalNewRegistration(normalizedForm.full_name, inserted.id).catch(err =>
        console.error("notifyInternalNewRegistration failed:", err),
      );
    }
    toast.success("تم إرسال طلب التسجيل بنجاح، سيتم مراجعته من قبل الإدارة");
    setRegForm({ full_name: "", mobile: "", email: "", national_id: "", city: "" });
    setRegOpen(false);
  };

  const isFull = (opp: PublicOpp) => opp.capacity > 0 && opp.participant_count >= opp.capacity;
  const seatsLeft = (opp: PublicOpp) => opp.capacity > 0 ? Math.max(0, opp.capacity - opp.participant_count) : null;
  const isEnded = (opp: PublicOpp) => !!(opp.end_at && new Date(opp.end_at) < new Date());

  const logoSrc = branding.logo_url || fallbackLogo;
  const imgLoading: "lazy" | "eager" = features.lazy_images.enabled ? "lazy" : "eager";

  useEffect(() => {
    if (features.smooth_scroll.enabled) {
      const prev = document.documentElement.style.scrollBehavior;
      document.documentElement.style.scrollBehavior = "smooth";
      return () => { document.documentElement.style.scrollBehavior = prev; };
    }
  }, [features.smooth_scroll.enabled]);

  const departmentNames = useMemo(() => {
    const set = new Set<string>();
    opportunities.forEach(o => { if (o.departments?.name) set.add(o.departments.name); });
    return Array.from(set);
  }, [opportunities]);

  const displayedOpps = useMemo(() => {
    let list = opportunities;
    if (features.opp_filters.enabled) {
      const s = search.trim();
      if (s) list = list.filter(o => o.title.includes(s) || o.departments?.name?.includes(s));
      if (deptFilter !== "__all__") list = list.filter(o => o.departments?.name === deptFilter);
      if (sortBy === "ending_soon") list = [...list].sort((a, b) => (a.end_at || "").localeCompare(b.end_at || ""));
      else if (sortBy === "most_seats") list = [...list].sort((a, b) => (b.capacity - b.participant_count) - (a.capacity - a.participant_count));
    }
    return list;
  }, [opportunities, features.opp_filters.enabled, search, deptFilter, sortBy]);

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {features.schema_seo.enabled && (
        <SchemaTags orgName={branding.org_name} description={branding.org_description} email={branding.contact_email} phone={branding.contact_phone} logoUrl={branding.logo_url} />
      )}
      {features.scroll_progress.enabled && <ScrollProgress />}
      {features.news_ticker.enabled && features.news_ticker.text && <NewsTicker text={features.news_ticker.text} />}
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/95 backdrop-blur border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <img src={logoSrc} alt={branding.platform_name} className="h-10 w-10 shrink-0 rounded-lg object-contain bg-primary/10 p-1" onError={(e) => { (e.target as HTMLImageElement).src = fallbackLogo; }} />
            <div className="min-w-0">
              <h1 className="text-sm font-bold text-foreground leading-tight truncate">{branding.platform_name}</h1>
              <p className="text-[11px] text-muted-foreground truncate">{branding.org_name}</p>
            </div>
          </div>
          <div className="flex gap-2 items-center flex-wrap justify-end">
            {features.font_size.enabled && <FontSizeToggle />}
            {features.dark_mode.enabled && <DarkModeToggle />}
            <Dialog open={regOpen} onOpenChange={setRegOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm"><UserPlus className="h-4 w-4 ml-1" />الانضمام كمتطوع</Button>
              </DialogTrigger>
              <DialogContent className="max-w-md" dir="rtl">
                <DialogHeader><DialogTitle>طلب تسجيل متطوع</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>الاسم الكامل *</Label>
                    <Input
                      placeholder="أدخل الاسم الكامل"
                      className={`mt-1.5 ${regErrors.full_name ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      value={regForm.full_name}
                      aria-invalid={!!regErrors.full_name}
                      onChange={e => updateRegField("full_name", e.target.value)}
                    />
                    {regErrors.full_name && <p className="mt-1 text-xs text-destructive">{regErrors.full_name}</p>}
                  </div>
                  <div>
                    <Label>رقم الجوال *</Label>
                    <Input
                      placeholder="05xxxxxxxx"
                      className={`mt-1.5 ${regErrors.mobile ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      dir="ltr"
                      inputMode="numeric"
                      maxLength={10}
                      value={regForm.mobile}
                      aria-invalid={!!regErrors.mobile}
                      onChange={e => updateRegField("mobile", handleMobileInput(e.target.value))}
                    />
                    {regErrors.mobile && <p className="mt-1 text-xs text-destructive">{regErrors.mobile}</p>}
                  </div>
                  <div>
                    <Label>البريد الإلكتروني</Label>
                    <Input
                      type="email"
                      placeholder="example@email.com"
                      className={`mt-1.5 ${regErrors.email ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      dir="ltr"
                      maxLength={254}
                      value={regForm.email}
                      aria-invalid={!!regErrors.email}
                      onChange={e => updateRegField("email", handleEmailInput(e.target.value))}
                      onBlur={e => { const v = e.target.value; if (v && !/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(v)) setRegErrors(p => ({ ...p, email: "صيغة البريد الإلكتروني غير صحيحة" })); }}
                    />
                    {regErrors.email && <p className="mt-1 text-xs text-destructive">{regErrors.email}</p>}
                  </div>
                  <div>
                    <Label>رقم الهوية *</Label>
                    <Input
                      placeholder="أدخل رقم الهوية"
                      className={`mt-1.5 ${regErrors.national_id ? "border-destructive focus-visible:ring-destructive" : ""}`}
                      dir="ltr"
                      inputMode="numeric"
                      maxLength={10}
                      value={regForm.national_id}
                      aria-invalid={!!regErrors.national_id}
                      onChange={e => updateRegField("national_id", handleNationalIdInput(e.target.value))}
                    />
                    {regErrors.national_id && <p className="mt-1 text-xs text-destructive">{regErrors.national_id}</p>}
                  </div>
                  <div>
                    <Label>المدينة *</Label>
                    <Select value={regForm.city} onValueChange={v => updateRegField("city", v)}>
                      <SelectTrigger className={`mt-1.5 ${regErrors.city ? "border-destructive focus-visible:ring-destructive" : ""}`}>
                        <SelectValue placeholder="اختر المدينة" />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.length > 0
                          ? cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)
                          : <SelectItem value="__no_cities__" disabled>لا توجد مدن — أضف مدنًا من الإعدادات</SelectItem>
                        }
                      </SelectContent>
                    </Select>
                    {regErrors.city && <p className="mt-1 text-xs text-destructive">{regErrors.city}</p>}
                  </div>
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                    <span>سيتم مراجعة طلبك من قبل الإدارة وإبلاغك بالنتيجة</span>
                  </div>
                  <Button className="w-full" onClick={handleRegister} disabled={regLoading}>
                    {regLoading ? "جارٍ الإرسال..." : "إرسال الطلب"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            <Button size="sm" onClick={() => navigate("/login")}>
              <LogIn className="h-4 w-4 ml-1" />تسجيل الدخول
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-b from-primary/10 to-background py-16 md:py-24">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <img src={logoSrc} alt={branding.platform_name} className="h-20 w-20 mx-auto rounded-2xl object-contain bg-card p-3 shadow-md mb-6" onError={(e) => { (e.target as HTMLImageElement).src = fallbackLogo; }} />
          <h2 className="text-2xl md:text-4xl font-bold text-foreground mb-4">{branding.platform_name}</h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">{branding.org_description}</p>
          <div className="flex justify-center gap-3 mt-8">
            <Button size="lg" onClick={() => navigate("/login")}><LogIn className="h-5 w-5 ml-2" />ابدأ التطوع الآن</Button>
            <Button size="lg" variant="outline" onClick={() => setRegOpen(true)}><UserPlus className="h-5 w-5 ml-2" />سجّل كمتطوع</Button>
          </div>
        </div>
      </section>

      {/* Reorderable sections (counters, testimonials, gallery, faq, quiz, impact) render below via section_order */}

      {/* Opportunities */}
      <section className="py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-8">
            <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">الفرص التطوعية المتاحة</h3>
            <p className="text-sm text-muted-foreground">انضم إلينا وساهم في خدمة المجتمع</p>
          </div>

          {features.opp_filters.enabled && opportunities.length > 0 && (
            <OpportunityFilters
              search={search} onSearch={setSearch}
              department={deptFilter} onDepartment={setDeptFilter}
              departments={departmentNames}
              sort={sortBy} onSort={setSortBy}
            />
          )}

          {loading ? (
            features.skeleton_loaders.enabled ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[0,1,2,3,4,5].map(i => <div key={i} className="bg-muted/40 rounded-xl h-48 animate-pulse" />)}
              </div>
            ) : <p className="text-center text-muted-foreground text-sm">جارٍ التحميل...</p>
          ) : displayedOpps.length === 0 ? (
            <div className="bg-card rounded-xl border border-border p-12 text-center">
              <CalendarCheck className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
              <p className="text-muted-foreground font-medium">لا توجد فرص متاحة حاليًا</p>
              <p className="text-xs text-muted-foreground/60 mt-1">تابعنا لمعرفة الفرص الجديدة</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {(showAllOpps ? displayedOpps : displayedOpps.slice(0, INITIAL_OPPS)).map((opp) => {
                const full = isFull(opp);
                const ended = isEnded(opp);
                const seats = seatsLeft(opp);
                const disabled = full || ended;
                return (
                  <div key={opp.id} className={`relative bg-card rounded-xl border border-border p-5 hover:shadow-md transition-shadow ${disabled ? "opacity-75" : ""}`}>
                    <div className="flex items-start justify-between mb-2 gap-2">
                      <h4 className="font-bold text-foreground">{opp.title}</h4>
                      <div className="flex flex-col items-end gap-1 shrink-0">
                        {ended && <span className="text-[10px] bg-destructive/10 text-destructive px-2 py-0.5 rounded-full font-semibold">انتهت فترة التقديم</span>}
                        {!ended && full && <span className="text-[10px] bg-destructive/10 text-destructive px-2 py-0.5 rounded-full font-semibold">ممتلئة</span>}
                      </div>
                    </div>
                    <div className="space-y-1.5 text-sm text-muted-foreground mb-4">
                      {opp.departments?.name && (
                        <div className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /><span>{opp.departments.name}</span></div>
                      )}
                      <div className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /><span>الحد الأدنى: {opp.minimum_hours} ساعات</span></div>
                      {opp.start_at && (
                        <div className="flex items-center gap-1.5">
                          <CalendarCheck className="h-3.5 w-3.5" />
                          <span>{formatDate(opp.start_at)}</span>
                          {opp.end_at && <span>— {formatDate(opp.end_at)}</span>}
                        </div>
                      )}
                      <div className="flex items-center gap-1.5">
                        <Users className="h-3.5 w-3.5" />
                        <span>{opp.participant_count || 0} مشارك{seats !== null ? ` · ${seats} مقعد متبقي` : ""}</span>
                      </div>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => handleApply(opp.id)} disabled={disabled}>
                      <Send className="h-4 w-4 ml-1" />
                      {ended ? "انتهت فترة التقديم" : full ? "ممتلئة" : "التقديم على الفرصة"}
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
          {!loading && displayedOpps.length > INITIAL_OPPS && (
            <div className="text-center mt-6">
              <Button variant="outline" size="lg" onClick={() => setShowAllOpps(s => !s)}>
                {showAllOpps ? "عرض أقل" : `عرض الكل (${displayedOpps.length})`}
              </Button>
            </div>
          )}
        </div>
      </section>

      {features.section_order.map(key => {
        const bg = features.section_bg?.[key] || undefined;
        const fg = features.section_fg?.[key] || undefined;
        const wrap = (node: React.ReactNode) =>
          fg ? <div key={key} style={{ color: fg }}>{node}</div> : node;
        switch (key) {
          case "counters":
            return features.counters.enabled
              ? wrap(<Suspense key={key} fallback={null}><AnimatedCounters title={features.counters.title} bg={bg} /></Suspense>)
              : null;
          case "opp_quiz":
            return features.opp_quiz.enabled
              ? wrap(<Suspense key={key} fallback={null}><OpportunityQuiz bg={bg} /></Suspense>)
              : null;
          case "impact_calc":
            return features.impact_calc.enabled
              ? wrap(<Suspense key={key} fallback={null}><ImpactCalculator bg={bg} rates={{ general: features.impact_calc.rate_general ?? 30, skilled: features.impact_calc.rate_skilled ?? 60, professional: features.impact_calc.rate_professional ?? 100 }} /></Suspense>)
              : null;
          case "testimonials":
            return features.testimonials.enabled && features.testimonials.items.length > 0
              ? wrap(<Suspense key={key} fallback={null}><TestimonialsCarousel items={features.testimonials.items} bg={bg} /></Suspense>)
              : null;
          case "gallery":
            return features.gallery.enabled && features.gallery.images.length > 0
              ? wrap(<Suspense key={key} fallback={null}><Gallery images={features.gallery.images} bg={bg} /></Suspense>)
              : null;
          case "faq":
            return features.faq.enabled && features.faq.items.length > 0
              ? wrap(<Suspense key={key} fallback={null}><FaqAccordion items={features.faq.items} bg={bg} /></Suspense>)
              : null;
          default:
            return null;
        }
      })}

      {/* Bank Accounts */}
      {bankAccounts.length > 0 && (
        <section className="py-12 md:py-16">
          <div className="max-w-5xl mx-auto px-4">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-2xl bg-primary/10 text-primary mb-3">
                <Landmark className="h-6 w-6" />
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">الحسابات البنكية للتبرع</h3>
              <p className="text-sm text-muted-foreground">يمكنك دعم رسالتنا عبر التحويل لأي من الحسابات التالية</p>
            </div>
            <div className={`grid gap-4 ${bankAccounts.length === 1 ? "grid-cols-1 max-w-md mx-auto" : "grid-cols-1 md:grid-cols-2"}`}>
              {bankAccounts.map(acc => (
                <BankAccountCard key={acc.id} account={acc} showQr={features.qr_bank.enabled} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Contact */}
      <section className="py-12 md:py-16 bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-xl md:text-2xl font-bold text-foreground mb-6">تواصل معنا</h3>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            {branding.contact_email && (
              <a href={`mailto:${branding.contact_email}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                <Mail className="h-5 w-5 text-primary" /><span dir="ltr">{branding.contact_email}</span>
              </a>
            )}
            {branding.contact_phone && (
              <a href={`tel:${branding.contact_phone}`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                <Phone className="h-5 w-5 text-primary" /><span dir="ltr">{branding.contact_phone}</span>
              </a>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-6">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-xs text-muted-foreground">{branding.org_name} — {branding.platform_name}</p>
        </div>
      </footer>

      {features.back_to_top.enabled && <BackToTop />}
      {features.whatsapp.enabled && features.whatsapp.number && <WhatsappFab number={features.whatsapp.number} />}
    </div>
  );
};

const BankAccountCard = ({ account, showQr }: { account: PublicBankAccount; showQr?: boolean }) => {
  const copy = async (value: string, label: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(`تم نسخ ${label}`);
    } catch {
      toast.error("تعذّر النسخ");
    }
  };
  return (
    <div className="group relative bg-card rounded-2xl border border-border p-5 md:p-6 shadow-sm hover:shadow-md transition-all">
      <div className="flex items-center justify-between gap-3 mb-4 pb-4 border-b border-border">
        <div className="flex items-center gap-3 min-w-0">
          <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
            <Landmark className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">البنك</p>
            <h4 className="font-bold text-foreground truncate">{account.bank_name}</h4>
          </div>
        </div>
        {showQr && <BankQR value={account.iban} size={72} />}
      </div>
      <div className="space-y-3">
        <div className="flex items-start gap-2">
          <UserIcon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
          <div className="min-w-0 flex-1">
            <p className="text-[11px] text-muted-foreground">اسم صاحب الحساب</p>
            <p className="text-sm font-medium text-foreground break-words">{account.holder_name}</p>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <Hash className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
          <div className="min-w-0 flex-1">
            <p className="text-[11px] text-muted-foreground">رقم الحساب</p>
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-mono text-foreground break-all" dir="ltr">{account.account_number}</p>
              <Button variant="ghost" size="sm" className="h-8 px-2 shrink-0" onClick={() => copy(account.account_number, "رقم الحساب")}>
                <Copy className="h-3.5 w-3.5 ml-1" />نسخ
              </Button>
            </div>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <Hash className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
          <div className="min-w-0 flex-1">
            <p className="text-[11px] text-muted-foreground">رقم الآيبان (IBAN)</p>
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-mono text-foreground break-all tracking-wide" dir="ltr">{account.iban}</p>
              <Button variant="ghost" size="sm" className="h-8 px-2 shrink-0" onClick={() => copy(account.iban, "الآيبان")}>
                <Copy className="h-3.5 w-3.5 ml-1" />نسخ
              </Button>
            </div>
          </div>
        </div>
        {account.note && (
          <div className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-3 leading-relaxed">
            {account.note}
          </div>
        )}
      </div>
    </div>
  );
};

export default PublicPage;
