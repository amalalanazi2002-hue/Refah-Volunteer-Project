import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { refreshBranding } from "@/hooks/use-branding";
import { GeneralSettings } from "@/components/settings/GeneralSettings";
import { BrandingSettings } from "@/components/settings/BrandingSettings";
import { CitiesManager } from "@/components/settings/CitiesManager";
import { DepartmentsManager } from "@/components/settings/DepartmentsManager";
import { BadgesManager } from "@/components/settings/BadgesManager";
import { BankAccountsManager } from "@/components/settings/BankAccountsManager";
import { PublicFeaturesManager } from "@/components/settings/PublicFeaturesManager";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { RotateCcw, AlertTriangle } from "lucide-react";

interface SystemSettings {
  platform_name: string;
  org_name: string;
  org_description: string;
  contact_email: string;
  contact_phone: string;
  enable_notifications: boolean;
  default_min_hours: string;
  logo_url: string;
  timezone: string;
}

const defaultSettings: SystemSettings = {
  platform_name: "منصة رفادة التطوعية",
  org_name: "جمعية رفاه للأرامل والمطلقات",
  org_description: "",
  contact_email: "info@rafah.org",
  contact_phone: "920001234",
  enable_notifications: true,
  default_min_hours: "4",
  logo_url: "",
  timezone: "Asia/Riyadh",
};

const defaultColors: Record<string, string> = {
  color_primary: "#5E4EA2",
  color_secondary: "#A86DA8",
  color_accent: "#7C63AC",
  color_background: "#F6F3F8",
  color_card: "#FFFFFF",
  color_text: "#1A1A2E",
  color_button_primary: "#5E4EA2",
  color_button_secondary: "#A86DA8",
};

const colorKeys = [
  { key: "color_primary", label: "اللون الأساسي" },
  { key: "color_secondary", label: "اللون الثانوي" },
  { key: "color_accent", label: "لون التمييز" },
  { key: "color_background", label: "لون الخلفية" },
  { key: "color_card", label: "لون البطاقات" },
  { key: "color_text", label: "لون النصوص" },
  { key: "color_button_primary", label: "لون الأزرار الأساسية" },
  { key: "color_button_secondary", label: "لون الأزرار الثانوية" },
];

const SettingsPage = () => {
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings);
  const [colors, setColors] = useState<Record<string, string>>({});
  const [cities, setCities] = useState<string[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [badges, setBadges] = useState<any[]>([]);
  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const [resetting, setResetting] = useState(false);

  const loadAll = async () => {
    const [settingsRes, deptsRes, badgesRes] = await Promise.all([
      supabase.from("system_settings").select("*").limit(50),
      supabase.from("departments").select("*").order("name"),
      supabase.from("badge_levels").select("*").order("sort_order", { ascending: true }),
    ]);

    if (settingsRes.data) {
      const map: Record<string, string> = {};
      settingsRes.data.forEach((r: any) => { map[r.key] = r.value; });
      setSettings({
        platform_name: map.platform_name || defaultSettings.platform_name,
        org_name: map.org_name || defaultSettings.org_name,
        org_description: map.org_description || defaultSettings.org_description,
        contact_email: map.contact_email || defaultSettings.contact_email,
        contact_phone: map.contact_phone || defaultSettings.contact_phone,
        enable_notifications: map.enable_notifications !== "false",
        default_min_hours: map.default_min_hours || defaultSettings.default_min_hours,
        logo_url: map.logo_url || "",
        timezone: map.timezone || "Asia/Riyadh",
      });
      // Apply timezone globally
      const { setTimezone } = await import("@/lib/format-date");
      setTimezone(map.timezone || "Asia/Riyadh");
      const colorMap: Record<string, string> = {};
      colorKeys.forEach(c => { colorMap[c.key] = map[c.key] || ""; });
      setColors(colorMap);
      setCities(map.cities ? JSON.parse(map.cities) : []);
    }
    setDepartments(deptsRes.data || []);
    setBadges(badgesRes.data || []);
  };

  useEffect(() => { loadAll(); }, []);

  const saveSettings = async () => {
    const entries = Object.entries(settings).map(([key, value]) => ({
      key, value: String(value),
    }));
    for (const entry of entries) {
      const { data: existing } = await supabase.from("system_settings").select("id").eq("key", entry.key).limit(1);
      if (existing && existing.length > 0) {
        await supabase.from("system_settings").update({ value: entry.value }).eq("key", entry.key);
      } else {
        await supabase.from("system_settings").insert(entry);
      }
    }
    refreshBranding();
    toast.success("تم حفظ الإعدادات بنجاح");
  };

  const saveColors = async () => {
    for (const [key, value] of Object.entries(colors)) {
      const { data: existing } = await supabase.from("system_settings").select("id").eq("key", key).limit(1);
      if (existing && existing.length > 0) {
        await supabase.from("system_settings").update({ value }).eq("key", key);
      } else {
        await supabase.from("system_settings").insert({ key, value });
      }
    }
    toast.success("تم حفظ الألوان بنجاح");
  };

  const handleResetDefaults = async () => {
    setResetting(true);
    // Reset general settings
    for (const [key, value] of Object.entries(defaultSettings)) {
      const { data: existing } = await supabase.from("system_settings").select("id").eq("key", key).limit(1);
      if (existing && existing.length > 0) {
        await supabase.from("system_settings").update({ value: String(value) }).eq("key", key);
      } else {
        await supabase.from("system_settings").insert({ key, value: String(value) });
      }
    }
    // Reset colors
    for (const [key, value] of Object.entries(defaultColors)) {
      const { data: existing } = await supabase.from("system_settings").select("id").eq("key", key).limit(1);
      if (existing && existing.length > 0) {
        await supabase.from("system_settings").update({ value }).eq("key", key);
      } else {
        await supabase.from("system_settings").insert({ key, value });
      }
    }
    refreshBranding();
    setResetting(false);
    setResetDialogOpen(false);
    toast.success("تم إعادة ضبط الإعدادات الافتراضية بنجاح");
    loadAll();
  };

  const colorSettings = colorKeys.map(c => ({ key: c.key, label: c.label, value: colors[c.key] || "" }));

  return (
    <div>
      <PageHeader title="الإعدادات" description="إعدادات النظام والتخصيصات" actions={
        <Button variant="outline" onClick={() => setResetDialogOpen(true)}>
          <RotateCcw className="h-4 w-4 ml-2" />إعادة ضبط الافتراضي
        </Button>
      } />
      <div className="space-y-5">
        <GeneralSettings settings={settings} onChange={setSettings} onSave={saveSettings} />
        <BrandingSettings colors={colorSettings} onChange={(key, val) => setColors(prev => ({ ...prev, [key]: val }))} onSave={saveColors} />
        <CitiesManager cities={cities} onRefresh={loadAll} />
        <DepartmentsManager departments={departments} onRefresh={loadAll} />
        <BadgesManager badges={badges} onRefresh={loadAll} />
        <BankAccountsManager />
        <PublicFeaturesManager />
      </div>

      <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>إعادة ضبط الإعدادات الافتراضية</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-lg bg-destructive/10">
              <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-destructive">تحذير</p>
                <p className="text-muted-foreground mt-1">سيتم إعادة ضبط الإعدادات العامة والهوية البصرية إلى القيم الافتراضية. لن يتأثر المتطوعون أو الفرص أو المشاركات أو المستخدمون الداخليون.</p>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button variant="destructive" onClick={handleResetDefaults} disabled={resetting}>
              {resetting ? "جارٍ الإعادة..." : "تأكيد إعادة الضبط"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SettingsPage;
