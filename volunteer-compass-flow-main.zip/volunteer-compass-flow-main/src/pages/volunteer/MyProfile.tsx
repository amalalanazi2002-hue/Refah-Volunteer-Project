import { useState, useEffect } from "react";
import { PageHeader } from "@/components/shared/PageHeader";
import { VolunteerListSection } from "@/components/shared/VolunteerListSection";
import { StatCard } from "@/components/shared/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { useRole } from "@/contexts/RoleContext";
import { User, Phone, MapPin, CreditCard, Clock, Award, Target, CalendarCheck, Edit, Mail, CheckCircle2 } from "lucide-react";
import { sumValidHours } from "@/lib/hours-utils";
import { roundHours } from "@/lib/hours-utils";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { notifyProfileChangeRequest } from "@/lib/ticket-notifications";
import { formatDate, formatDateTime } from "@/lib/format-date";
import { validateContactForm, normalizeMobile, normalizeEmail, handleMobileInput, handleEmailInput } from "@/lib/validators";
import { formatHours, formatTotalHours } from "@/lib/hours-format";

interface BadgeLevel {
  id: string;
  name: string;
  icon: string;
  min_hours: number;
  sort_order: number;
}

const changeStatusMap: Record<string, string> = { pending: "قيد المراجعة", approved: "مقبول", rejected: "مرفوض" };
const changeStatusVariant = (s: string) => s === "approved" ? "success" : s === "rejected" ? "danger" : "warning";

const MyProfile = () => {
  const { volunteerId } = useRole();
  const [profile, setProfile] = useState<any>(null);
  const [totalHours, setTotalHours] = useState(0);
  const [totalParticipations, setTotalParticipations] = useState(0);
  const [totalOpps, setTotalOpps] = useState(0);
  const [badges, setBadges] = useState<BadgeLevel[]>([]);
  const [currentBadge, setCurrentBadge] = useState<BadgeLevel | null>(null);
  const [nextBadge, setNextBadge] = useState<BadgeLevel | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({ full_name: "", mobile: "", email: "", city: "" });
  const [cities, setCities] = useState<string[]>([]);
  const [changeRequests, setChangeRequests] = useState<any[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!volunteerId) return;
    const fetchAll = async () => {
      const [profileRes, hoursRes, partsRes, badgeRes, citiesRes, changesRes] = await Promise.all([
        supabase.from("volunteers").select("*").eq("id", volunteerId).single(),
        supabase.from("volunteer_hours").select("approved_hours, status, opportunities(minimum_hours), participations(total_minutes)").eq("volunteer_id", volunteerId),
        supabase.from("participations").select("id, opportunity_id").eq("volunteer_id", volunteerId),
        supabase.from("badge_levels").select("*").order("sort_order", { ascending: true }),
        supabase.from("system_settings").select("value").eq("key", "cities").limit(1),
        supabase.from("volunteer_profile_change_requests").select("*").eq("volunteer_id", volunteerId).order("created_at", { ascending: false }).limit(10),
      ]);

      const prof = profileRes.data;
      setProfile(prof);
      if (prof) setEditForm({ full_name: prof.full_name || "", mobile: prof.mobile || "", email: prof.email || "", city: prof.city || "" });

      // Fallback: if approved_hours is 0/missing on an approved row, derive from
      // participation duration or the opportunity's minimum_hours so the totals
      // never under-report a participation that was actually approved.
      const enrichedHours = (hoursRes.data || []).map((r: any) => {
        const stored = Number(r.approved_hours);
        if (stored > 0) return r;
        const minutes = Number(r?.participations?.total_minutes || 0);
        if (minutes > 0) return { ...r, approved_hours: roundHours(minutes / 60) };
        const minH = Number(r?.opportunities?.minimum_hours || 0);
        if (minH > 0) return { ...r, approved_hours: roundHours(minH) };
        return r;
      });
      const hours = sumValidHours(enrichedHours);
      setTotalHours(hours);
      setTotalParticipations(partsRes.data?.length || 0);
      const uniqueOpps = new Set((partsRes.data || []).map((p: any) => p.opportunity_id));
      setTotalOpps(uniqueOpps.size);

      const allBadges = badgeRes.data || [];
      setBadges(allBadges);
      let current: BadgeLevel | null = null;
      let next: BadgeLevel | null = null;
      for (let i = 0; i < allBadges.length; i++) {
        if (hours >= allBadges[i].min_hours) current = allBadges[i];
        else { next = allBadges[i]; break; }
      }
      setCurrentBadge(current);
      setNextBadge(next);

      if (citiesRes.data?.[0]?.value) {
        try { setCities(JSON.parse(citiesRes.data[0].value)); } catch {}
      }
      setChangeRequests(changesRes.data || []);
    };
    fetchAll();
  }, [volunteerId]);

  const handleSubmitChange = async () => {
    if (!volunteerId || !profile) return;

    // Validate edited values (mobile/email only — id is non-editable here)
    const normalizedMobile = normalizeMobile(editForm.mobile);
    const normalizedEmail = normalizeEmail(editForm.email);
    const errs = validateContactForm({
      full_name: editForm.full_name,
      mobile: normalizedMobile,
      email: normalizedEmail,
    });
    if (Object.keys(errs).length > 0) {
      const first = Object.values(errs)[0];
      toast.error(first || "الرجاء تصحيح الحقول");
      return;
    }

    const changes: Record<string, string> = {};
    if (editForm.full_name !== profile.full_name) changes.full_name = editForm.full_name;
    if (normalizedMobile !== profile.mobile) changes.mobile = normalizedMobile;
    if ((normalizedEmail || "") !== (profile.email || "")) changes.email = normalizedEmail;
    if ((editForm.city || "") !== (profile.city || "")) changes.city = editForm.city;

    if (Object.keys(changes).length === 0) { toast.error("لم يتم تغيير أي بيانات"); return; }

    // Embed snapshot of "before" values inside `changes` so the admin can still
    // see them, without depending on a non-existent `previous_values` column.
    const enrichedChanges: Record<string, any> = { ...changes };
    const before: Record<string, string | null> = {};
    Object.keys(changes).forEach(k => { before[k] = (profile as any)[k] ?? null; });
    enrichedChanges.__previous_values = before;

    setSubmitting(true);
    const { data: inserted, error } = await supabase.from("volunteer_profile_change_requests").insert({
      volunteer_id: volunteerId,
      changes: enrichedChanges,
    }).select("id").single();
    setSubmitting(false);
    if (error) { toast.error(`خطأ: ${error.message}`); return; }
    if (inserted?.id) {
      notifyProfileChangeRequest(profile.full_name || "متطوع", volunteerId, inserted.id);
    }
    toast.success("تم إرسال طلب التعديل — سيتم مراجعته من الإدارة");
    setEditOpen(false);
    const { data: newReqs } = await supabase.from("volunteer_profile_change_requests").select("*").eq("volunteer_id", volunteerId).order("created_at", { ascending: false }).limit(10);
    setChangeRequests(newReqs || []);
  };

  if (!profile) {
    return (
      <div>
        <PageHeader title="ملفي" description="بيانات المتطوع" />
        <p className="text-muted-foreground text-sm">جارٍ التحميل...</p>
      </div>
    );
  }

  const fields = [
    { label: "الاسم الكامل", value: profile.full_name, icon: User },
    { label: "رقم الجوال", value: profile.mobile, icon: Phone },
    { label: "البريد الإلكتروني", value: profile.email || "—", icon: Mail },
    { label: "رقم الهوية", value: profile.national_id, icon: CreditCard },
    { label: "المدينة", value: profile.city || "—", icon: MapPin },
  ];

  const progressToNext = nextBadge ? Math.min(100, (totalHours / nextBadge.min_hours) * 100) : 100;
  const hoursRemaining = nextBadge ? roundHours(nextBadge.min_hours - totalHours) : 0;

  return (
    <div>
      <PageHeader title="ملفي" description="بيانات المتطوع والإنجازات" actions={
        <Button variant="outline" onClick={() => { setEditForm({ full_name: profile.full_name || "", mobile: profile.mobile || "", email: profile.email || "", city: profile.city || "" }); setEditOpen(true); }}>
          <Edit className="h-4 w-4 ml-2" />تعديل البيانات
        </Button>
      } />

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-6">
        <StatCard title="ساعاتي المعتمدة" value={formatTotalHours(totalHours)} icon={Clock} color="primary" />
        <StatCard title="مشاركاتي" value={totalParticipations} icon={CalendarCheck} color="success" />
        <StatCard title="الفرص المشارك بها" value={totalOpps} icon={Target} color="accent" />
        <StatCard title="وسامي الحالي" value={currentBadge ? `${currentBadge.icon} ${currentBadge.name}` : "لا يوجد بعد"} icon={Award} color="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Personal Info */}
        <div className="bg-card rounded-lg border border-border p-5 md:p-6 flex flex-col relative overflow-hidden group">
          {/* Decorative ambient glow */}
          <div className="pointer-events-none absolute -top-16 -left-16 h-40 w-40 rounded-full bg-primary/10 blur-3xl opacity-70 transition-opacity duration-700 group-hover:opacity-100" />
          <div className="pointer-events-none absolute -bottom-20 -right-10 h-44 w-44 rounded-full bg-accent/10 blur-3xl opacity-60" />

          <div className="flex items-center justify-between mb-5 relative">
            <h3 className="font-bold text-foreground text-sm flex items-center gap-2">
              <User className="h-4 w-4 text-primary" />
              البيانات الشخصية
            </h3>
            <StatusBadge
              status={profile.status === "active" ? "نشط" : profile.status}
              variant={profile.status === "active" ? "success" : "warning"}
            />
          </div>

          {/* Centered hero block: avatar + name */}
          <div
            className="relative rounded-xl bg-gradient-to-br from-primary/15 via-primary/5 to-accent/10 border border-primary/15 p-5 mb-5 flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-500"
          >
            <div className="relative mb-3">
              <div className="absolute inset-0 rounded-full bg-primary/30 blur-md scale-110 animate-pulse" />
              <div className="relative h-20 w-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-primary-foreground font-bold text-2xl shadow-lg ring-4 ring-background">
                {(profile.full_name || "?").trim().charAt(0)}
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground tracking-wide uppercase">الاسم الكامل</p>
            <p className="text-lg font-bold text-foreground mt-0.5">{profile.full_name}</p>
          </div>

          {/* Centered, balanced grid for the remaining fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1 relative">
            {fields.slice(1).map((f, idx) => (
              <div
                key={f.label}
                className="flex flex-col items-center text-center gap-2 rounded-xl border border-border/70 bg-muted/30 p-4 hover:bg-muted/60 hover:border-primary/30 hover:-translate-y-0.5 hover:shadow-md transition-all duration-300 animate-in fade-in slide-in-from-bottom-2"
                style={{ animationDelay: `${idx * 60}ms`, animationFillMode: "both" }}
              >
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary/15 to-accent/10 flex items-center justify-center shrink-0 ring-1 ring-primary/10">
                  <f.icon className="h-4 w-4 text-primary" />
                </div>
                <div className="min-w-0 w-full">
                  <p className="text-[11px] text-muted-foreground">{f.label}</p>
                  <p
                    className="text-sm font-semibold text-foreground truncate mt-0.5"
                    dir={f.label === "البريد الإلكتروني" || f.label === "رقم الجوال" || f.label === "رقم الهوية" ? "ltr" : undefined}
                  >
                    {f.value}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Footer hint */}
          <div className="mt-5 pt-4 border-t border-border/70 flex items-center justify-center gap-2 text-xs text-muted-foreground text-center relative">
            <CheckCircle2 className="h-3.5 w-3.5 text-success shrink-0" />
            <span>لتعديل أي من بياناتك، اضغط زر «تعديل البيانات» أعلى الصفحة — التعديلات تخضع لمراجعة الإدارة.</span>
          </div>
        </div>

        {/* Badge Progress */}
        <div className="bg-card rounded-lg border border-border p-5 md:p-6">
          <h3 className="font-bold text-foreground mb-4 text-sm flex items-center gap-2">
            <Award className="h-4 w-4 text-warning" />
            الأوسمة والتقدم
          </h3>
          {currentBadge ? (
            <div className="bg-primary/5 rounded-lg p-4 mb-4 text-center">
              <span className="text-4xl block mb-2">{currentBadge.icon}</span>
              <p className="font-bold text-foreground">{currentBadge.name}</p>
              <p className="text-xs text-muted-foreground mt-1">{currentBadge.min_hours}+ ساعة</p>
            </div>
          ) : (
            <div className="bg-muted/60 rounded-lg p-4 mb-4 text-center">
              <span className="text-4xl block mb-2">🌱</span>
              <p className="font-bold text-foreground">لم تحصل على وسام بعد</p>
              <p className="text-xs text-muted-foreground mt-1">ابدأ بتسجيل ساعاتك التطوعية</p>
            </div>
          )}
          {nextBadge && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">الوسام التالي:</span>
                <span className="font-medium text-foreground">{nextBadge.icon} {nextBadge.name}</span>
              </div>
              <Progress value={progressToNext} className="h-3" />
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{totalHours.toFixed(1)} ساعة</span>
                <span>{nextBadge.min_hours} ساعة</span>
              </div>
              <p className="text-center text-sm text-primary font-medium">
                المتبقي: {hoursRemaining > 0 ? hoursRemaining.toFixed(1) : 0} ساعة
              </p>
            </div>
          )}
          {!nextBadge && currentBadge && (
            <p className="text-center text-sm text-success font-medium mt-2">🎉 وصلت لأعلى وسام — أحسنت!</p>
          )}
          {badges.length > 0 && (
            <div className="mt-5 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground mb-3">جميع الأوسمة</p>
              <div className="grid grid-cols-2 gap-2">
                {badges.map((b) => (
                  <div key={b.id} className={`rounded-lg p-2.5 text-center text-xs ${totalHours >= b.min_hours ? "bg-success/10 border border-success/20" : "bg-muted/40 border border-border opacity-50"}`}>
                    <span className="text-lg block">{b.icon}</span>
                    <p className="font-medium mt-0.5">{b.name}</p>
                    <p className="text-muted-foreground">{b.min_hours} ساعة</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Change Requests History */}
      {changeRequests.length > 0 && (
        <div className="mt-6">
          <VolunteerListSection
            title="طلبات التعديل السابقة"
            icon={<Edit className="h-4 w-4" />}
            total={changeRequests.length}
            summary={[
              { label: "مقبول", value: changeRequests.filter(r => r.status === "approved").length, variant: "success" },
              { label: "قيد المراجعة", value: changeRequests.filter(r => r.status === "pending").length, variant: "warning" },
              { label: "مرفوض", value: changeRequests.filter(r => r.status === "rejected").length, variant: "danger" },
            ]}
          >
            {(limit) => (
              <div className="space-y-2">
                {(limit ? changeRequests.slice(0, limit) : changeRequests).map(req => (
                  <div key={req.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 text-sm">
                    <div>
                      <span className="text-muted-foreground text-xs">{formatDate(req.created_at)}</span>
                      <span className="text-foreground mr-2">{Object.keys(req.changes || {}).filter((k: string) => k !== "__previous_values").map((k: string) => ({ full_name: "الاسم", mobile: "الجوال", email: "البريد", city: "المدينة" }[k] || k)).join("، ")}</span>
                    </div>
                    <StatusBadge status={changeStatusMap[req.status] || req.status} variant={changeStatusVariant(req.status)} />
                  </div>
                ))}
              </div>
            )}
          </VolunteerListSection>
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>طلب تعديل البيانات الشخصية</DialogTitle></DialogHeader>
          <p className="text-xs text-muted-foreground mb-2">التعديلات لن تُطبق مباشرة — ستُرسل للإدارة للمراجعة والاعتماد</p>
          <div className="space-y-4">
            <div><Label>الاسم الكامل</Label><Input className="mt-1.5" value={editForm.full_name} onChange={e => setEditForm({ ...editForm, full_name: e.target.value })} /></div>
            <div><Label>رقم الجوال</Label><Input className="mt-1.5" dir="ltr" inputMode="numeric" maxLength={10} value={editForm.mobile} onChange={e => setEditForm({ ...editForm, mobile: handleMobileInput(e.target.value) })} /></div>
            <div><Label>البريد الإلكتروني</Label><Input className="mt-1.5" type="email" dir="ltr" maxLength={254} value={editForm.email} onChange={e => setEditForm({ ...editForm, email: handleEmailInput(e.target.value) })} /></div>
            <div><Label>المدينة</Label>
              <Select value={editForm.city || ""} onValueChange={v => setEditForm({ ...editForm, city: v })}>
                <SelectTrigger className="mt-1.5"><SelectValue placeholder="اختر المدينة" /></SelectTrigger>
                <SelectContent>
                  {cities.length > 0
                    ? cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)
                    : <SelectItem value="__no_cities__" disabled>لا توجد مدن</SelectItem>
                  }
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">إلغاء</Button></DialogClose>
            <Button onClick={handleSubmitChange} disabled={submitting}>{submitting ? "جارٍ الإرسال..." : "إرسال طلب التعديل"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyProfile;
