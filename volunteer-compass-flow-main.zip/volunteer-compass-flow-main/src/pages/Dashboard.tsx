import { useState, useEffect } from "react";
import { StatCard } from "@/components/shared/StatCard";
import { DataTable } from "@/components/shared/DataTable";
import { PageHeader } from "@/components/shared/PageHeader";
import { Users, CalendarCheck, FileCheck, Clock, AlertTriangle } from "lucide-react";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import { isAnomalousHours, roundHours } from "@/lib/hours-utils";

const statusMap: Record<string, string> = {
  approved: "معتمد",
  pending: "قيد المراجعة",
  rejected: "مرفوض",
  active: "نشطة",
  closed: "منتهية",
  draft: "مسودة",
};

const Dashboard = () => {
  const [stats, setStats] = useState({ volunteers: 0, activeOpportunities: 0, pendingProofs: 0, totalHours: 0 });
  const [recentParticipations, setRecentParticipations] = useState<any[]>([]);
  const [recentOpportunities, setRecentOpportunities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [volRes, oppRes, proofRes, hoursRes, partRes, oppListRes] = await Promise.all([
          supabase.from("volunteers").select("id", { count: "exact", head: true }),
          supabase.from("opportunities").select("id", { count: "exact", head: true }).eq("status", "active"),
          supabase.from("proofs").select("id", { count: "exact", head: true }).eq("review_status", "pending"),
          supabase.from("volunteer_hours").select("approved_hours").eq("status", "approved"),
          supabase.from("participations").select("*, volunteers(full_name), opportunities(title)").order("created_at", { ascending: false }).limit(4),
          supabase.from("opportunities").select("*, departments(name)").order("created_at", { ascending: false }).limit(4),
        ]);

        const validHours = (hoursRes.data || []).filter((r: any) => !isAnomalousHours(Number(r.approved_hours)));
        const totalHours = roundHours(validHours.reduce((sum: number, r: any) => sum + Number(r.approved_hours), 0));
        setStats({
          volunteers: volRes.count || 0,
          activeOpportunities: oppRes.count || 0,
          pendingProofs: proofRes.count || 0,
          totalHours,
        });
        setRecentParticipations((partRes.data || []).map((p: any) => ({
          volunteer: p.volunteers?.full_name || "—",
          opportunity: p.opportunities?.title || "—",
          status: statusMap[p.approval_status] || p.approval_status,
        })));
        setRecentOpportunities((oppListRes.data || []).map((o: any) => ({
          name: o.title,
          department: o.departments?.name || "—",
          status: statusMap[o.status] || o.status,
        })));
      } catch (err) {
        console.error("Dashboard fetch error:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div>
      <PageHeader title="لوحة التحكم" description="نظرة عامة على منصة رفادة التطوعية" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-8">
        <StatCard title="عدد المتطوعين" value={loading ? "..." : stats.volunteers} icon={Users} color="primary" />
        <StatCard title="الفرص النشطة" value={loading ? "..." : stats.activeOpportunities} icon={CalendarCheck} color="success" />
        <StatCard title="إثباتات قيد المراجعة" value={loading ? "..." : stats.pendingProofs} icon={FileCheck} color="warning" />
        <StatCard title="إجمالي الساعات المعتمدة" value={loading ? "..." : stats.totalHours.toFixed(2)} icon={Clock} color="accent" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-6">
        <div className="bg-card rounded-lg border border-border p-4 md:p-5">
          <h3 className="font-bold text-foreground mb-4 text-sm">آخر المشاركات</h3>
          <DataTable
            columns={[
              { header: "المتطوع", accessor: "volunteer" },
              { header: "الفرصة", accessor: "opportunity" },
              { header: "الحالة", accessor: (r: any) => <StatusBadge status={r.status} variant={r.status === "معتمد" ? "success" : "warning"} /> },
            ]}
            data={recentParticipations}
          />
        </div>

        <div className="bg-card rounded-lg border border-border p-4 md:p-5">
          <h3 className="font-bold text-foreground mb-4 text-sm">آخر الفرص</h3>
          <DataTable
            columns={[
              { header: "الفرصة", accessor: "name" },
              { header: "الإدارة", accessor: "department" },
              { header: "الحالة", accessor: (r: any) => <StatusBadge status={r.status} variant={r.status === "نشطة" ? "success" : "neutral"} /> },
            ]}
            data={recentOpportunities}
          />
        </div>
      </div>

      <div className="bg-card rounded-lg border border-border p-4 md:p-5">
        <h3 className="font-bold text-foreground mb-4 flex items-center gap-2 text-sm">
          <AlertTriangle className="h-[18px] w-[18px] text-warning" />
          تنبيهات
        </h3>
        <ul className="space-y-2">
          <li className="flex items-center gap-3 p-3 rounded-lg bg-warning/5 text-foreground text-sm">
            <span className="h-2 w-2 rounded-full bg-warning shrink-0" />
            يوجد {stats.pendingProofs} إثباتات بانتظار المراجعة
          </li>
          <li className="flex items-center gap-3 p-3 rounded-lg bg-primary/5 text-foreground text-sm">
            <span className="h-2 w-2 rounded-full bg-primary shrink-0" />
            يوجد {stats.activeOpportunities} فرص نشطة حالياً
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;
