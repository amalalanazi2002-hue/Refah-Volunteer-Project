// Public page features flags + content stored in system_settings.public_features (JSON)
import { supabase } from "@/integrations/supabase/client";

export interface FaqItem { q: string; a: string }
export interface TestimonialItem { name: string; role?: string; text: string; image?: string }

export type SectionKey = "counters" | "testimonials" | "gallery" | "faq" | "opp_quiz" | "impact_calc";

export const DEFAULT_SECTION_ORDER: SectionKey[] = [
  "counters", "testimonials", "gallery", "faq", "opp_quiz", "impact_calc",
];

export type SectionBg = Record<SectionKey, string>;
export type SectionFg = Record<SectionKey, string>;

export const DEFAULT_SECTION_BG: SectionBg = {
  counters: "", testimonials: "", gallery: "", faq: "", opp_quiz: "", impact_calc: "",
};
export const DEFAULT_SECTION_FG: SectionFg = {
  counters: "", testimonials: "", gallery: "", faq: "", opp_quiz: "", impact_calc: "",
};

export interface PublicFeatures {
  section_order: SectionKey[];
  section_bg: SectionBg;
  section_fg: SectionFg;
  counters: { enabled: boolean; title?: string };
  qr_bank: { enabled: boolean };
  opp_filters: { enabled: boolean };
  opp_quiz: { enabled: boolean };
  impact_calc: { enabled: boolean; rate_general?: number; rate_skilled?: number; rate_professional?: number };
  faq: { enabled: boolean; items: FaqItem[] };
  testimonials: { enabled: boolean; items: TestimonialItem[] };
  gallery: { enabled: boolean; images: string[] };
  news_ticker: { enabled: boolean; text: string };
  whatsapp: { enabled: boolean; number: string };
  dark_mode: { enabled: boolean };
  font_size: { enabled: boolean };
  back_to_top: { enabled: boolean };
  scroll_progress: { enabled: boolean };
  smooth_scroll: { enabled: boolean };
  schema_seo: { enabled: boolean };
  skeleton_loaders: { enabled: boolean };
  lazy_images: { enabled: boolean };
}

export const defaultPublicFeatures: PublicFeatures = {
  section_order: DEFAULT_SECTION_ORDER,
  section_bg: DEFAULT_SECTION_BG,
  section_fg: DEFAULT_SECTION_FG,
  counters: { enabled: false, title: "" },
  qr_bank: { enabled: false },
  opp_filters: { enabled: false },
  opp_quiz: { enabled: false },
  impact_calc: { enabled: false, rate_general: 30, rate_skilled: 60, rate_professional: 100 },
  faq: { enabled: false, items: [] },
  testimonials: { enabled: false, items: [] },
  gallery: { enabled: false, images: [] },
  news_ticker: { enabled: false, text: "" },
  whatsapp: { enabled: false, number: "" },
  dark_mode: { enabled: false },
  font_size: { enabled: false },
  back_to_top: { enabled: false },
  scroll_progress: { enabled: false },
  smooth_scroll: { enabled: false },
  schema_seo: { enabled: false },
  skeleton_loaders: { enabled: false },
  lazy_images: { enabled: false },
};

export const PUBLIC_FEATURES_KEY = "public_features";

export const normalizeSectionOrder = (arr: any): SectionKey[] => {
  const valid = DEFAULT_SECTION_ORDER;
  const incoming: SectionKey[] = Array.isArray(arr) ? arr.filter((k: any) => valid.includes(k)) : [];
  const missing = valid.filter(k => !incoming.includes(k));
  return [...incoming, ...missing];
};

export const parsePublicFeatures = (raw: string | undefined | null): PublicFeatures => {
  if (!raw) return defaultPublicFeatures;
  try {
    const parsed = JSON.parse(raw);
    const merged = { ...defaultPublicFeatures, ...parsed };
    merged.section_order = normalizeSectionOrder(parsed.section_order);
    merged.section_bg = { ...DEFAULT_SECTION_BG, ...(parsed.section_bg || {}) };
    merged.section_fg = { ...DEFAULT_SECTION_FG, ...(parsed.section_fg || {}) };
    return merged;
  } catch {
    return defaultPublicFeatures;
  }
};

export const loadPublicFeatures = async (): Promise<PublicFeatures> => {
  const { data } = await supabase
    .from("system_settings")
    .select("value")
    .eq("key", PUBLIC_FEATURES_KEY)
    .limit(1);
  return parsePublicFeatures(data?.[0]?.value);
};

export const savePublicFeatures = async (features: PublicFeatures): Promise<void> => {
  const value = JSON.stringify(features);
  const { data: existing } = await supabase
    .from("system_settings")
    .select("id")
    .eq("key", PUBLIC_FEATURES_KEY)
    .limit(1);
  if (existing && existing.length > 0) {
    await supabase.from("system_settings").update({ value }).eq("key", PUBLIC_FEATURES_KEY);
  } else {
    await supabase.from("system_settings").insert({ key: PUBLIC_FEATURES_KEY, value });
  }
};
